# 
## PowerShortTerm-webapp Project Status
[![Quality gate](https://sesvc.shell.com/api/project_badges/quality_gate?project=com.shell.PowerShortTerm-webapp&token=sqb_66f3fb4f9df623440c3edb960a159150b3ef79a3)](https://sesvc.shell.com/dashboard?id=com.shell.PowerShortTerm-webapp)

[![Bugs](https://sesvc.shell.com/api/project_badges/measure?project=com.shell.PowerShortTerm-webapp&metric=bugs&token=sqb_66f3fb4f9df623440c3edb960a159150b3ef79a3)](https://sesvc.shell.com/dashboard?id=com.shell.PowerShortTerm-webapp)
[![Reliability Rating](https://sesvc.shell.com/api/project_badges/measure?project=com.shell.PowerShortTerm-webapp&metric=reliability_rating&token=sqb_66f3fb4f9df623440c3edb960a159150b3ef79a3)](https://sesvc.shell.com/dashboard?id=com.shell.PowerShortTerm-webapp)
[![Maintainability Rating](https://sesvc.shell.com/api/project_badges/measure?project=com.shell.PowerShortTerm-webapp&metric=sqale_rating&token=sqb_66f3fb4f9df623440c3edb960a159150b3ef79a3)](https://sesvc.shell.com/dashboard?id=com.shell.PowerShortTerm-webapp)
[![Security Rating](https://sesvc.shell.com/api/project_badges/measure?project=com.shell.PowerShortTerm-webapp&metric=security_rating&token=sqb_66f3fb4f9df623440c3edb960a159150b3ef79a3)](https://sesvc.shell.com/dashboard?id=com.shell.PowerShortTerm-webapp)
[![Security Hotspots](https://sesvc.shell.com/api/project_badges/measure?project=com.shell.PowerShortTerm-webapp&metric=security_hotspots&token=sqb_66f3fb4f9df623440c3edb960a159150b3ef79a3)](https://sesvc.shell.com/dashboard?id=com.shell.PowerShortTerm-webapp)
[![Coverage](https://sesvc.shell.com/api/project_badges/measure?project=com.shell.PowerShortTerm-webapp&metric=coverage&token=sqb_66f3fb4f9df623440c3edb960a159150b3ef79a3)](https://sesvc.shell.com/dashboard?id=com.shell.PowerShortTerm-webapp)
[![Duplicated Lines (%)](https://sesvc.shell.com/api/project_badges/measure?project=com.shell.PowerShortTerm-webapp&metric=duplicated_lines_density&token=sqb_66f3fb4f9df623440c3edb960a159150b3ef79a3)](https://sesvc.shell.com/dashboard?id=com.shell.PowerShortTerm-webapp)



## How to contribute
Refer [Contribute](./CONTRIBUTION.md) page to get more info on how to contribute.
