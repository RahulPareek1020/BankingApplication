import { Theme } from '@sede-x/shell-ds-react-framework';

declare module 'styled-components' {
  export interface DefaultTheme extends Theme {
    _toExtend?: string;
  }
}
