import React from 'react';
import { Alert, AlertTitle, Stack } from '@mui/material';

type AlertType = {
  alert: string;
  helpText?: string;
};

export const AccessAlerts = (props: AlertType) => {
  return (
    <Stack flexGrow={1} alignItems="center" justifyContent="center" sx={{ color: 'rgba(252,216,57,.75)' }}>
      <h1>Shell Nomination Engine</h1>
      <Alert variant="filled" severity="error">
        <AlertTitle>{props.alert}</AlertTitle>
        {props.helpText}
      </Alert>
    </Stack>
  );
};
