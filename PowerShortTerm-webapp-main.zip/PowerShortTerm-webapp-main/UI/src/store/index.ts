import { configureStore } from '@reduxjs/toolkit';
import Theme, { ITheme } from './reducers';
import reducer from './reducers';



const store = configureStore<ITheme>({
    reducer:Theme
})
export default store;
