import { createSlice, PayloadAction } from "@reduxjs/toolkit"

export interface ITheme {
    isDark:boolean;
  }

  const initialState:ITheme={
    isDark:true
  }

  const Theme=createSlice({
    name:'theme',
    initialState,
    reducers:{
        updateTheme:(state:ITheme ,{payload}: PayloadAction<ITheme>)=>{
            state.isDark = payload.isDark
        }
    }
  })
  
 
  export const toggleActions = Theme.actions;
  export default Theme.reducer;