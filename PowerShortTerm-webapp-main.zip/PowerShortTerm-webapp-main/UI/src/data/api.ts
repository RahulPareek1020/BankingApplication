import {
  CounterpartyAggPos,
  CounterpartyAgg,
  MappingRuleDetails,
  NomStatus,
  NomTradeDetail,
  NomDetail,
  NomHeader,
  RunAligneBatch,
  SendNomPosToPowertrak,
  SendNomToPowertrak,
} from "../constants/api-constants";

const fetchData = async (endpoint: string, jwtToken: any, params: any = {}) => {
  const url = new URL(endpoint);
  Object.keys(params).forEach((key) =>
    url.searchParams.append(key, params[key])
  );

  try {
    const response = await fetch(url.toString(), {
      method: "GET",
      headers: {
        Authorization: `Bearer ${jwtToken}`,
      },
    });
    if (endpoint == NomStatus) 
    {
      return await response.text();
    } 
    else if (endpoint == SendNomPosToPowertrak) 
    {
      if (response?.status === 200) {
        return response.json();
      } 
      else {
        return "error";
      }
    } else {
      return await response.json();
    }
  } 
  catch (error) {
    return [];
  }
};

export const getNominationHeader = async (jwtToken: any) => {
  return await fetchData(NomHeader, jwtToken);
};

export const getCounterpartyPositions = async (nominationRunId: any) => {
  return await fetchData(NomDetail, getLatestToken(), {
    nominationrunId: nominationRunId,
  });
};

export const getNominationTradeDetails = async (aggPosRefId: number) => {
  return await fetchData(NomTradeDetail, getLatestToken(), { aggPosRefId });
};

export const getMappingRuleDetails = async () => {
  return await fetchData(MappingRuleDetails, getLatestToken());
};

export const getCounterpartyAggregations = async (
  nominationDefinitionId: any,
  deliveryDate: any
) => {
  return await fetchData(CounterpartyAggPos, getLatestToken(), {
    nominationDefinitionId,
    deliveryDate,
  });
};

export const sendNominationToPowertrak = async (
  nominationDefinitionId: any,
  deliveryDate: any
  ) => {
  const response = await fetchData(SendNomToPowertrak, getLatestToken(), {
    nominationDefinitionId,
    deliveryDate,
  });
  if (response.status === 200) {
    return response;
  } else {
    return "error";
  }
};

export const runAligneBatch = async (
  nominationDefinitionId: any,
    deliveryDate: any,
    isAuto: boolean
  ) => {
  return await fetchData(RunAligneBatch, getLatestToken(), {
    nominationDefinitionId,
    deliveryDate,
    isAuto,
  });
};

export const getNominationStatus = async (nominationDefinitionId: number) => {
  return await fetchData(NomStatus, getLatestToken(), {
    nominationRunId: nominationDefinitionId,
  });
};

export const getCounterpartyAggregationsNomRun = async (nominationRunId: number) => {
  return await fetchData(CounterpartyAggPos, getLatestToken(), { nominationRunId });
};

export const sendNominationRunToPowertrak = async (nominationRunId: number) => {
  return await fetchData(SendNomPosToPowertrak, getLatestToken(), { nominationRunId });
};

export const getLatestToken = () => 
{
  if(sessionStorage.getItem('accessToken')){
    return sessionStorage.getItem('accessToken');
  }
  else 
  {
    console.log("Access Token is null");
  }
}