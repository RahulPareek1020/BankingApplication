import { jwtDecode } from 'jwt-decode';
import ICustomJwtPayload from '../components/Interfaces/customPayload';
import { sne } from '../constants/constants';

export const filterRoles = (accessToken: any) => {
  let role;
  const authClientId = process.env.REACT_APP_ENV || '';
  let env = authClientId.split("SNE_")[1].toLowerCase();
  const decodedToken = jwtDecode<ICustomJwtPayload>(accessToken);
  const knownEnvSuffixes = (process.env.REACT_APP_KNOWN_ENV_SUFFIXES || "").split(',');
  
  if (env == "prod") {
    role = decodedToken.realm_access.roles.filter(str => str.startsWith(sne)
          && !knownEnvSuffixes.some(suffix => str.toLowerCase().endsWith(suffix)))
          .map(str => str.replace(`${sne}_`, '').replace(/_/g, ' '))[0];
  }
  else {
    role = decodedToken.realm_access.roles
        .filter(str => str.toLowerCase().endsWith(`_${env}`))
        .map(str => str.replace(new RegExp(`^${sne}_`, 'i'), '')
        .replace(new RegExp(`_${env}$`, 'i'), '').replace(/_/g, ' '))[0];
  }

  return { role, name: decodedToken.name };
};