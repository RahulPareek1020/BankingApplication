import { Dayjs } from "dayjs";

export type FilterOption =  {
    nominations: string[];
    mappingTypes: string[];
    outputValues: string[];
}