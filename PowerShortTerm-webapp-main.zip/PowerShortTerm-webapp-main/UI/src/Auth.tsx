import React, { useEffect, useState } from 'react';
import { useAuth } from 'react-oidc-context';
import { Outlet } from 'react-router-dom';
import { AccessAlerts } from './pages/accessAlerts/AccessAlerts';
import { jwtDecode, JwtPayload } from 'jwt-decode';
import { sne } from './constants/constants';
import ICustomJwtPayload from './components/Interfaces/customPayload';

export const Auth = () => {
  const { signinRedirect, isLoading, isAuthenticated, error, user } = useAuth();
  const firstLogin = React.useRef(true);
  const isLoggedIn = (!isLoading && !firstLogin.current) || isAuthenticated;
  const [hasValidRole, setValidRole] = useState(true);
  
  useEffect(() => {
    if (!isLoading && firstLogin.current) {
      firstLogin.current = false;
      if (!isAuthenticated) {
        signinRedirect({ extraQueryParams: { kc_idp_hint: 'oidc' } });
      }
    }

    if(user?.access_token){
      const decodedToken = jwtDecode<ICustomJwtPayload>(user?.access_token);
      if (decodedToken && decodedToken.realm_access) {
        const roles = decodedToken.realm_access.roles.filter((str: string) => str.startsWith(sne))[0];
        
        if(!roles){
          setValidRole(!hasValidRole);
        }
        else
        {
          sessionStorage.setItem('accessToken', user?.access_token);
        }
      }
    }
  }, [isAuthenticated, isLoading, signinRedirect, user]);

  if (!isLoggedIn) {
    sessionStorage.clear();
    return <div className="spinner" />;
  }

  if (!isAuthenticated && !error) {
    sessionStorage.clear();
    return <AccessAlerts alert="Unable to authenticate, please make sure that you are connected to Shell network." />;
  }
  else if (isAuthenticated && !hasValidRole) {
    sessionStorage.clear();
    return <AccessAlerts alert="You are not authorized to access this application, please reach out to Shell Nomination Team for further assistance." />;
  }

  if (error) {
    sessionStorage.clear();
    if (navigator.onLine) {
      return (
        <AccessAlerts alert="Oops! something went wrong, please refresh your page." helpText="If the issue persists, please contact Shell Nomination Engine Team." />
      );
    } else {
      signinRedirect({ extraQueryParams: { kc_idp_hint: 'oidc' } });
    }
  }
  return <Outlet />;
};