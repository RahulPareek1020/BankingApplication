import { Button, Filter, Icons, Loading, TFoot, TH, TR } from '@sede-x/shell-ds-react-framework';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

export const Thead = styled.table`
    backgroundColor: red;
    `

export const StyledFilter = styled(Filter)`
    background : white;`

export const StyledDiv = styled.div`
    margin: 5px 5px 5px;
    box-shadow: 0px 35px 50px rgba( 0, 0, 0, 0.2 );
    border: 1px solid ${(p) => p.theme.border.subtle};
    background: ${(p) => p.theme.background.surface};
    margin-top: 0px;
    height: 100%;
`
export const StyledRawDiv = styled.div`
    margin: 5px 5px 5px;
    //box-shadow: 0px 35px 50px rgba( 0, 0, 0, 0.2 );
    border: 1px solid ${(p) => p.theme.background.surface};
    background: ${(p) => p.theme.background.surface};
    margin-top: 0px;
`

export const StyledDivChild = styled.div`
    // margin: 10px 20px 20px;
    // box-shadow: 0px 35px 50px rgba( 0, 0, 0, 0.2 );
    // overflow: scroll;
    // position:fixed;
    // top:20%;
    // left:8%;
    // max-width:90rem;
    // max-height:40rem;
    background: ${(p) => p.theme.background.surface};
    margin-top: 2vh;
`

export const StyledIcon = styled(Icons.Cross)`
    color: ${(p) => p.theme.text.onSurface.strong};
`

export const StyledTable = styled.table`
    border-radius: 5px;
    font-size: 0.65vw;
    font-weight: normal;
    border: none;
    border-collapse: collapse;
    width: 100%;
    max-width: 100%;
    white-space: nowrap;
    background-color: ${(p) => p.theme.background.surface};
    `

    export const StyledChildTable = styled.table`
    border-radius: 5px;
    font-size: 0.65vw;
    font-weight: normal;
    border: none;
    border-collapse: collapse;
    width: 100%;
    max-width: 100%;
    white-space: nowrap;
    background-color: ${(p) => p.theme.background.surface};
    table-layout: fixed;
    `

export const StyledTh = styled(TH)`
    &:nth-child(1){
    position: sticky;
    left: 0;
    z-index: 1;
    }
    &:nth-child(2){
    position: sticky;
    left: 14vw;
    width: 10vw;
    z-index: 1;
    }
    color: ${(p) => p.theme.text.onSurface.strong};
    background: ${(p) => p.theme.background.base};
    text-align: center;
    padding: 15px;
    position: sticky;
    top: 0;
`

export const StyledNoDataTh = styled(TH)`
    &:nth-child(1){
    position: sticky;
    left: 0;
    z-index: 1;
    }
    &:nth-child(2){
    position: sticky;
    left: 11vw;
    width: 10vw;
    z-index: 1;
    }
    color: ${(p) => p.theme.text.onSurface.strong};
    background: ${(p) => p.theme.background.base};
    text-align: center;
    padding: 15px;
    position: sticky;
    top: 0;
`

export const StyledLink = styled(Link)`
color: ${(p) => p.theme.text.onSurface.strong};
`

export const StyledChildTh = styled(TH)`
    &:nth-child(1){
    position: sticky;
    left: 0;
    z-index: 1;
    width: 15vw;
    }

    &:nth-child(2){
    position: sticky;
    left: 15vw;
    z-index: 2;
    width: 8vw;
    top:0;
    }

    &:nth-child(4){
    width: 8vw;
    }

    &:nth-child(7){
    width: 9vw;
    }
    &:nth-child(8){
    width: 9vw;
    }

    &:nth-child(10){
    width: 9vw;
    }
    &:nth-child(11){
    width: 8vw;
    }
     &:nth-child(19){
    width: 9vw;
    }

    &:nth-child(25){
    width: 10vw;
    }
    &:nth-child(26){
    width: 10vw;
    }
    &:nth-child(27){
    width: 11vw;
    }
     &:nth-child(30){
    width: 8vw;
    }
    width: 7vw;
    white-space: pre-wrap;
    line-height: 0.7vw;
    color: ${(p) => p.theme.text.onSurface.strong};
    background: ${(p) => p.theme.background.base};
    text-align: center;
    padding: 15px;
    position: sticky;
    top: 0;
`
export const StyledTd = styled.td`
    &:nth-child(1){
    text-align: left;
    position: sticky;
    left: 0;
    z-index: 0;
    }
    &:nth-child(2){
    text-align: left;
    position: sticky;
    left: 14vw;
    z-index: 0;
    }
    border-right: 1px solid ${(p) => p.theme.background.base};
    font-size: 0.65vw;
    text-align: center;
    padding: 15px;
`


export const StyledChildTd = styled.td`
    &:nth-child(1){
    text-align: left;
    position: sticky;
    left: 0;
    z-index: 0;
    width: 15vw;
    }
    width: 100px;
    &:nth-child(2){
    position: sticky;
    left: 15vw;
    z-index: 1;
    width: 8vw;
    }
    &:nth-child(7){
    width: 8vw;
    }
    &:nth-child(10){
    width: 8vw;
    }
     &:nth-child(19){
    width: 8vw;
    }
     &:nth-child(30){
    width: 8vw;
    }
    font-size: 0.65vw;
    text-align: center;
    padding: 15px;
`


export const StyledFootTd = styled.th`
    &:nth-child(1){
    text-align: left;
    position: sticky;
    left: 0;
    z-index: 1;
    }
    border-right: 1px solid ${(p) => p.theme.background.base};
    font-size: 0.65vw;
    text-align: center;
    padding: 0px;
    background-color: ${(p) => p.theme.background.base};
`

export const StyledFootTh= styled(TH)`
    &:nth-child(1){
    text-align: left;
    position: sticky;
    left: 0;
    z-index: 1;
    }
    &:nth-child(2){
    position: sticky;
    left: 13vw;
    z-index: 1;
    }
    border-right: 1px solid ${(p) => p.theme.background.base};
    font-size: 0.65vw;
    text-align: center;
    padding: 0px;
    background-color: ${(p) => p.theme.background.base};
`
export const StyledNoDataFootTh= styled(TH)`
    &:nth-child(1){
    text-align: left;
    position: sticky;
    left: 0;
    z-index: 1;
    }
    &:nth-child(2){
    position: sticky;
    left: 10vw;
    z-index: 1;
    }
    border-right: 1px solid ${(p) => p.theme.background.base};
    font-size: 0.65vw;
    text-align: center;
    padding: 0px;
    background-color: ${(p) => p.theme.background.base};
`

export const StyledNoDataTd = styled.td`
     &:nth-child(1){
    text-align: left;
    }
    border-right: 1px solid ${(p) => p.theme.background.base};
    font-size: 0.65vw;
    text-align: center;
    padding: 15px;
`

export const StyledTr = styled.tr`
    &:nth-child(even) {
    background: ${(p) => p.theme.background.base};
}
    &:nth-child(even) td:first-child {
    background-color: ${(p) => p.theme.background.base}; /* White for even rows */
  }
    &:nth-child(odd) td:first-child {
    background-color: ${(p) => p.theme.background.surface}; /* White for even rows */
  }

  &:nth-child(even) td:nth-child(2) {
    background-color: ${(p) => p.theme.background.base}; /* White for even rows */
  }
    &:nth-child(odd) td:nth-child(2) {
    background-color: ${(p) => p.theme.background.surface}; /* White for even rows */
  }
    line-height:5px;
`

export const StyledTR = styled(TR)`
    &:nth-child(even) {
    background: ${(p) => p.theme.background.base};
}
    line-height:5px;
`

export const StyledButtonClose = styled(Button)`
    // position: fixed;
    // left: 67%;
    float: right;
    background: rgb(232,232,232,0.1);,

`

export const StyledTableDiv= styled.div`
    margin: 20px;
    overflow: scroll;
    height: 53vh;
    @media (max-width: 1970px) {
    height: 40vh;
  }`

export const StyledRawTradeDiv= styled.div`
    width: 90%;
    textAlign: left;
    height: 20%;`

export const StyledChildTableDiv= styled.div`
    margin: 5px;
    overflow: auto;
    height: 85vh`

export const StyledLoader = styled(Loading)`
    position: fixed;
    left: 50%;
    top: 50%;
    stroke: rgb(230,245,246);
`

export const StyledTFoot = styled(TFoot)`
    position: sticky; 
    bottom: 0;
    background: ${(p) => p.theme.background.base};
    text-align: center;`