import {
  Icons,
  TBody,
  TFoot,
  TH,
  THead,
  TR,
} from "@sede-x/shell-ds-react-framework";
import {
  ColumnDef,
  ColumnFiltersState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  useReactTable,
} from "@tanstack/react-table";
import dayjs from "dayjs";
import React, { useEffect, useMemo, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  QH,
  transactionTypesBuy,
  transactionTypeSell,
  transmissionTrade,
} from "../../constants/constants";
import { FilterOption } from "../../context/tableContext/filter";
import { Product } from "../../context/tableContext/type";
import { getNominationTradeDetails } from "../../data/api";
import {
  StyledChildTable,
  StyledChildTableDiv,
  StyledChildTd,
  StyledChildTh,
  StyledDivChild,
  StyledIcon,
  StyledLoader,
  StyledNoDataTd,
  StyledRawDiv,
  StyledRawTradeDiv,
  StyledTable,
  StyledTd,
  StyledTh,
  StyledTr,
  StyledTR,
} from "./ChildTable.style";
import { StyledLabel } from "../MappingTable/MappingTable.style";

const ChildTableComponent = (args: any) => {
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [filterOption, setFilterOption] = useState<FilterOption>();
  const [loading, setLoading] = useState(true);
  // let filterData: Product[] = fetchdata;
  const location = useLocation();
  const dataValue = location.state;
  const [data, setData] = useState<Product[]>([]);
  const [periodCount, setperiodCount] = useState(96);
  const [newColumn, setNewColumn] = useState<any>([]);
  const [timespan, settimespan] = useState("QH");
  const [aggPosReference, setAggPosReference] = useState("");
  const [precision, setPrecision] = useState(2);
  const [statusCode, setStatusCode] = useState("");
  const [statusMessage, setStatusMessage] = useState("");

  useEffect(() => {
    setData([]);
    setLoading(true);
    if (args?.aggPosRefId != 0) {
      getNominationTradeDetailsData(args?.aggPosRefId);
    }
  }, [args?.aggPosRefId]);

  // Fetch Nomination Trade Details and format data
  const getNominationTradeDetailsData = async (aggPosRefId: number) => {
    const result = await getNominationTradeDetails(aggPosRefId);
    let filterData: Product[] = result;
    if (filterData.length == 0) {
      setLoading(false);
    }

    setPrecision(
      result.map((d: { nominationDefinitionPrecision: any }) => {
        return d.nominationDefinitionPrecision;
      })[0]
    );

    if (
      result.map((d: { aggPosReference: any }) => d.aggPosReference) !=
      undefined
    ) {
      setAggPosReference(
        result.map((d: { aggPosReference: any }) => {
          return d.aggPosReference;
        })[0]
      );
    }

    if (
      result.map((d: { periodCount: any }) => {
        return d.periodCount;
      })[0] > 0
    ) {
      setperiodCount(
        result.map((d: { periodCount: any }) => {
          return d.periodCount;
        })[0]
      );
    } else {
      setperiodCount(96);
    }
    if (
      result.map((d: { statusCode: any }) => {
        return d.statusCode;
      })[0]
    ) {
      setStatusCode(
        result.map((d: { statusCode: any }) => {
          return d.statusCode;
        })[0]
      );
    }

    if (
      result.map((d: { statusMessage: any }) => {
        return d.statusMessage;
      })[0]
    ) {
      setStatusMessage(
        result.map((d: { statusMessage: any }) => {
          return d.statusMessage;
        })[0]
      );
    }

    filterData = filterData.map((d) => {
      if (
        transactionTypesBuy.includes(d.transactionType?.toLocaleLowerCase()) &&
        d.transactionType != ""
      ) {
        return { ...d };
      }

      return { ...d };
    });

    filterData.forEach((element) => {
      if (
        element.transactionType?.toLocaleLowerCase() == transactionTypeSell &&
        element.tradeType?.toLocaleLowerCase() != transmissionTrade
      ) {
        Object.keys(element).forEach((key) => {
          if (key.startsWith(QH) && element[key] > 0) {
            element[key] = element[key] * -1;
          }
        });
      }
    });

    filterData.forEach((element) => {
      const values = Object.keys(element).filter((key) => key.startsWith(QH));
      element.total = values.reduce((sum, key) => sum + (element[key] || 0), 0);
    });

    setData(filterData);
  };

  //Set columns based on period count
  useEffect(() => {
    if (periodCount > 23) {
      var idCount = 104;
      var newColumn = [];
      for (let columnCount = 93; columnCount <= periodCount; columnCount++) {
        idCount = idCount + 1;
        newColumn.push({
          id: idCount.toString(),
          header: `${timespan + columnCount}`,
          accessorKey: `qH${columnCount}`,
        });
      }
      setNewColumn(newColumn);
    } else {
      setNewColumn([]);
    }
  }, [timespan, periodCount, aggPosReference]);

  const closeModalClick = () => {
    args?.onClose(false);
  };

  // Set static prefix columns
  const initialColumnArray = [
    {
      id: "1",
      header: "Trade Reference",
      accessorKey: "tradeReference",
    },
    {
      id: "2",
      accessorKey: "tradeType",
      header: "Trade Type",
    },
    {
      id: "3",
      header: "Transaction Type",
      accessorKey: "transactionType",
    },
    {
      id: "4",
      header: "Entity",
      accessorKey: "entity",
    },
    {
      id: "5",
      header: "Counterparty",
      accessorKey: "counterparty",
    },
    {
      id: "6",
      header: "From Market Operator",
      accessorKey: "fromMarketoperator",
    },
    {
      id: "7",
      header: "To Market Operator",
      accessorKey: "toMarketoperator",
    },
    {
      id: "8",
      header: "Capacity Type",
      accessorKey: "capacityType",
    },
    {
      id: "9",
      header: "Capacity Identification",
      accessorKey: "capacityIdentification",
    },
    {
      id: "10",
      header: "Interconnector",
      accessorKey: "interconnector",
    },
    {
      id: "11",
      header: "Delivery Date",
      accessorKey: "nomDeliveryDate",
      cell: (info: any) => {
        return dayjs(info.getValue()).format("D/M/YYYY");
      },
    },
    {
      id: "12",
      header: "Total",
      accessorKey: "total",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "13",
      header: "QH1",
      accessorKey: "qH1",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "14",
      header: "QH2",
      accessorKey: "qH2",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "15",
      header: "QH3",
      accessorKey: "qH3",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "16",
      header: "QH4",
      accessorKey: "qH4",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "17",
      header: "QH5",
      accessorKey: "qH5",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "18",
      header: "QH6",
      accessorKey: "qH6",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "19",
      header: "QH7",
      accessorKey: "qH7",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "20",
      header: "QH8",
      accessorKey: "qH8",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "21",
      header: "QH9",
      accessorKey: "qH9", 
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "22",
      header: "QH10",
      accessorKey: "qH10",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "23",
      header: "QH11",
      accessorKey: "qH11",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "24",
      header: "QH12",
      accessorKey: "qH12",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "25",
      header: "QH13",
      accessorKey: "qH13",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "26",
      header: "QH14",
      accessorKey: "qH14",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "27",
      header: "QH15",
      accessorKey: "qH15",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "28",
      header: "QH16",
      accessorKey: "qH16",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "29",
      header: "QH17",
      accessorKey: "qH17",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "30",
      header: "QH18",
      accessorKey: "qH18",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "31",
      header: "QH19",
      accessorKey: "qH19",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "32",
      header: "QH20",
      accessorKey: "qH20",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "33",
      header: "QH21",
      accessorKey: "qH21",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "34",
      header: "QH22",
      accessorKey: "qH22",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "35",
      header: "QH23",
      accessorKey: "qH23",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "36",
      header: "QH24",
      accessorKey: "qH24",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "37",
      header: "QH25",
      accessorKey: "qH25",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "38",
      header: "QH26",
      accessorKey: "qH26",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "39",
      header: "QH27",
      accessorKey: "qH27",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "40",
      header: "QH28",
      accessorKey: "qH28",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "41",
      header: "QH29",
      accessorKey: "qH29",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "42",
      header: "QH30",
      accessorKey: "qH30",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "43",
      header: "QH31",
      accessorKey: "qH31",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "44",
      header: "QH32",
      accessorKey: "qH32",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "45",
      header: "QH33",
      accessorKey: "qH33",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "46",
      header: "QH34",
      accessorKey: "qH34", 
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "47",
      header: "QH35",
      accessorKey: "qH35",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "48",
      header: "QH36",
      accessorKey: "qH36",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "49",
      header: "QH37",
      accessorKey: "qH37",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "50",
      header: "QH38",
      accessorKey: "qH38",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "51",
      header: "QH39",
      accessorKey: "qH39",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "52",
      header: "QH40",
      accessorKey: "qH40",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "53",
      header: "QH41",
      accessorKey: "qH41",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "54",
      header: "QH42",
      accessorKey: "qH42",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "55",
      header: "QH43",
      accessorKey: "qH43",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "56",
      header: "QH44",
      accessorKey: "qH44",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "57",
      header: "QH45",
      accessorKey: "qH45",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "58",
      header: "QH46",
      accessorKey: "qH46",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "59",
      header: "QH47",
      accessorKey: "qH47",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "60",
      header: "QH48",
      accessorKey: "qH48",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "61",
      header: "QH49",
      accessorKey: "qH49",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "62",
      header: "QH50",
      accessorKey: "qH50",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "63",
      header: "QH51",
      accessorKey: "qH51",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "64",
      header: "QH52",
      accessorKey: "qH52",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "65",
      header: "QH53",
      accessorKey: "qH53",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "66",
      header: "QH54",
      accessorKey: "qH54",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "67",
      header: "QH55",
      accessorKey: "qH55",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "68",
      header: "QH56",
      accessorKey: "qH56",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "69",
      header: "QH57",
      accessorKey: "qH57",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "70",
      header: "QH58",
      accessorKey: "qH58",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "71",
      header: "QH59",
      accessorKey: "qH59",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "72",
      header: "QH60",
      accessorKey: "qH60",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "73",
      header: "QH61",
      accessorKey: "qH61",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "74",
      header: "QH62",
      accessorKey: "qH62",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "75",
      header: "QH63",
      accessorKey: "qH63",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "76",
      header: "QH64",
      accessorKey: "qH64",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "77",
      header: "QH65",
      accessorKey: "qH65",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "78",
      header: "QH66",
      accessorKey: "qH66",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "79",
      header: "QH67",
      accessorKey: "qH67",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "80",
      header: "QH68",
      accessorKey: "qH68",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "81",
      header: "QH69",
      accessorKey: "qH69",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "82",
      header: "QH70",
      accessorKey: "qH70",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "83",
      header: "QH71",
      accessorKey: "qH71",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "84",
      header: "QH72",
      accessorKey: "qH72",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "85",
      header: "QH73",
      accessorKey: "qH73",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "86",
      header: "QH74",
      accessorKey: "qH74",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "87",
      header: "QH75",
      accessorKey: "qH75",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "88",
      header: "QH76",
      accessorKey: "qH76",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "89",
      header: "QH77",
      accessorKey: "qH77",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "90",
      header: "QH78",
      accessorKey: "qH78",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "91",
      header: "QH79",
      accessorKey: "qH79",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "92",
      header: "QH80",
      accessorKey: "qH80",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "93",
      header: "QH81",
      accessorKey: "qH81",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "94",
      header: "QH82",
      accessorKey: "qH82",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "95",
      header: "QH83",
      accessorKey: "qH83",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "96",
      header: "QH84",
      accessorKey: "qH84",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "97",
      header: "QH85",
      accessorKey: "qH85",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "98",
      header: "QH86",
      accessorKey: "qH86",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "99",
      header: "QH87",
      accessorKey: "qH87",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "100",
      header: "QH88",
      accessorKey: "qH88",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "101",
      header: "QH89",
      accessorKey: "qH89",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "102",
      header: "QH90",
      accessorKey: "qH90",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "103",
      header: "QH91",
      accessorKey: "qH91",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
    {
      id: "104",
      header: "QH92",
      accessorKey: "qH92",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },
    },
  ];

  // Set static suffix columns
  const suffixColumnArray = [
    {
      id: "113",
      header: "Granularity",
      accessorKey: "granularity",
    },
    {
      id: "114",
      header: "Power Counter",
      accessorKey: "powercounter",
    },
    {
      id: "115",
      header: "System Date",
      accessorKey: "systemdate",
      cell: (info: any) => {
        return dayjs(info.getValue()).format("D/M/YYYY");
      },
    },
    {
      id: "116",
      header: "System Time",
      accessorKey: "systemtime",
    },
    {
      id: "117",
      header: "Direct Secondary",
      accessorKey: "directsecondary",
    },
    {
      id: "118",
      header: "Sedfile Flag",
      accessorKey: "sedfileflag",
    },
    {
      id: "119",
      header: "Marketoperator Name",
      accessorKey: "marketOperatorName",
    },
    {
      id: "120",
      header: "Italy Matchcode",
      accessorKey: "italyMatchCode",
    },
    {
      id: "121",
      header: "Status",
      accessorKey: "status",
    },
    {
      id: "122",
      header: "Cdy1Attr1",
      accessorKey: "cdy1Attr1",
    },
    {
      id: "123",
      header: "Pwrnoms Override Type",
      accessorKey: "pwrNomsOverrideType",
    },
    {
      id: "124",
      header: "Pwrnoms Override Input",
      accessorKey: "pwrNomsOverrideInput",
    },
    {
      id: "125",
      header: "Pwrnoms Override Freeform",
      accessorKey: "pwrNomsOverrideFreeform",
    },
    {
      id: "126",
      header: "Aux So Cpty",
      accessorKey: "auxSoCpty",
    },
    {
      id: "127",
      header: "Cpty Noms",
      accessorKey: "cptyNoms",
    },
    {
      id: "128",
      header: "Peak Workaround",
      accessorKey: "peakWorkaround",
    },
    {
      id: "129",
      header: "Cpty Genpur2",
      accessorKey: "cptyGenPur2",
    },
    {
      id: "130",
      header: "Numrec",
      accessorKey: "numRec",
    },
  ];

  const columns = useMemo<ColumnDef<Product, any>[]>(() => {
    if (newColumn?.length == 0) {
      return [...initialColumnArray, ...suffixColumnArray];
    }
    return [...initialColumnArray, ...newColumn, ...suffixColumnArray];
  }, [timespan, newColumn]);

  const [columnOrder, setColumnOrder] = useState<String[]>(
    columns.map((column) => column.id as string)
  );
  const tableOptions = {
    state: {
      columnOrder,
    },
    onColumnOrderChange: setColumnOrder,
  };

  const table = useReactTable({
    data,
    columns,
    filterFns: {},
    state: {
      columnFilters,
    },
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
  });

  const getColumnWidth = (headerId: any) => {
    const id = Number(headerId);
    if (id <= 11) {
      return "9vw";
    } else if (id > 11 && id < 113) {
      return "4vw";
    } else if (id > 112 && id < 117) {
      return "7vw";
    } else if (id === 119 || (id > 122 && id < 125) || id === 128) {
      return "10vw";
    } else if (id === 117 || id === 125) {
      return "11vw";
    }
  };

  return (
    <>
      <StyledDivChild>
        <StyledRawDiv>
          <Link to="/" onClick={closeModalClick}>
            <span style={{ float: "right" }}>
              <StyledIcon />
            </span>
          </Link>
          <StyledRawTradeDiv>
            <StyledTd>
              <h2
                style={{
                  fontSize: 16,
                  padding: "0px 8px",
                  textAlign: "left",
                  lineHeight: "1px",
                  fontWeight: 600,
                }}
              >
                Nomination Trades (MW)
              </h2>
            </StyledTd>
            <StyledTd>
              <StyledLabel>
                Aggregated Position Reference : {aggPosReference}
              </StyledLabel>
            </StyledTd>
            {statusCode && statusCode.trim() !== "" && (
              <>
                <StyledTd>
                  <StyledLabel>Status Code : {statusCode}</StyledLabel>
                </StyledTd>
                {(statusCode.toLowerCase() === "rejected" || statusCode.toLowerCase() === "error") && (
                  <StyledTd>
                    <StyledLabel>Status Message : {statusMessage}</StyledLabel>
                  </StyledTd>
                )}
              </>
            )}
          </StyledRawTradeDiv>
        </StyledRawDiv>
        <StyledChildTableDiv>
          <StyledChildTable>
            <THead>
              {table.getHeaderGroups().map((headerGroup) => (
                <StyledTR key={headerGroup.id}>
                  {headerGroup.headers.map((header) => {
                    return (
                      <StyledChildTh
                        key={header.id}
                        colSpan={header.colSpan}
                        style={{ width: getColumnWidth(header.id) }}
                      >
                        {header.isPlaceholder ? null : (
                          <>
                            {flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                          </>
                        )}
                      </StyledChildTh>
                    );
                  })}
                </StyledTR>
              ))}
            </THead>
            <TBody>
              {table.getRowModel()?.rows?.length > 0 ? (
                table.getRowModel().rows.map((row) => (
                  <StyledTr key={row.id}>
                    {row.getVisibleCells().map((cell) => {
                      if (
                        Number(cell.column.id) > 11 &&
                        Number(cell.column.id) < 108
                      ) {
                        return (
                          <StyledChildTd key={cell.id}>
                            {flexRender(
                              cell.column.columnDef.cell,
                              cell.getContext()
                            )}
                          </StyledChildTd>
                        );
                      }
                      return (
                        <StyledChildTd key={cell.id}>
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </StyledChildTd>
                      );
                    })}
                  </StyledTr>
                ))
              ) : loading == true ? (
                <StyledLoader type="primary" />
              ) : (
                <StyledTR>
                  <StyledNoDataTd colSpan={columns?.length}>
                    No Raw Trades Found
                  </StyledNoDataTd>
                </StyledTR>
              )}
            </TBody>
            <TFoot>
              {table.getFooterGroups().map((footerGroup) => (
                <TR key={footerGroup.id}>
                  {footerGroup.headers.map((header) => (
                    <TH key={header.id} colSpan={header.colSpan}>
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.footer,
                            header.getContext()
                          )}
                    </TH>
                  ))}
                </TR>
              ))}
            </TFoot>
          </StyledChildTable>
        </StyledChildTableDiv>
      </StyledDivChild>
    </>
  );
};

export default ChildTableComponent;
