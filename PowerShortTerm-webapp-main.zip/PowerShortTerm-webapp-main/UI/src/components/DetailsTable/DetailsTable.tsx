import { Alert, Button, Modal, NOOP, Sentiments, Sizes, TBody, THead, TR } from "@sede-x/shell-ds-react-framework";
import {
  ColumnDef,
  ColumnFiltersState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  useReactTable,
} from "@tanstack/react-table";
import React, { useEffect, useMemo, useState } from "react";
import { cancelMessage, errorFromAligne, QH, resendToGMSLMessage, sneReadOnly, transactionTypesBuy, transactionTypeSell, transmissionTrade } from "../../constants/constants";
import { Product } from "../../context/tableContext/type";
import { getCounterpartyPositions, sendNominationRunToPowertrak } from "../../data/api";
import ChildTableComponent from "./ChildTable";
import {
  StyledDiv,
  StyledFootTd,
  StyledFootTh,
  StyledLink,
  StyledLoader,
  StyledNoDataFootTh,
  StyledNoDataTd,
  StyledNoDataTh,
  StyledTable,
  StyledTableDiv,
  StyledTd,
  StyledTFoot,
  StyledTh,
  StyledTr,
  StyledTR,
} from "./Table.style";
import { Link } from "react-router-dom";
import { useAuth } from "react-oidc-context";
import { StyledAlertDiv, StyledModalText, StyledSendButton } from "../NominationRun/NominationRun.style";
import { filterRoles } from "../../Utilities/RoleUtils";

const TableComponent = (args: any) => {
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [loading, setLoading] = useState(args?.load);
  const [data, setData] = useState<Product[]>([]);
  const [showChild, setshowChild] = useState(false);
  const [timespan, settimespan] = useState('H');
  const [granularity, setgranularity] = useState('');
  const[columnVisibility, setColumnVisibility]=useState<any>({
    "103": false,
    "108": false,
  });
  const [periodCount, setperiodCount] = useState(24);
  const [precision, setprecision] = useState(2);
  const [newColumn,setNewColumn] = useState<any>([]);
  const { user } = useAuth();
  
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState(resendToGMSLMessage);
  const [showAlert, setshowAlert] = useState(false);
  const [showErrorAlert, setshowErrorAlert] = useState(false);
  const [showErrorAligne, setshowErrorAligne] = useState(false);
  const [actions, setactions] = useState<any>([])
  const [responseMessage, setresponseMessage] = useState("string")
  const [nominationRunId, setnominationRunId] = useState(0);
  const [isProd, setProd] = useState(false);
  const [userRole, setUserRole] = useState<string>();
  const [showResendButton, setShowResendButton] = useState(false);

  const sendData = (aggPosRefId: number) => {
    args?.onLinkClick(true);
    args?.aggPosRefId(aggPosRefId);
  };
  useEffect(() => {
    setData([]);
    if (args.nominationData.length != 0) {
      setLoading(true);
      getCounterpartData();
    }
    else{
      settimespan ("H");
      setgranularity('')
      setperiodCount(24);
    }
  }, [args.nominationData]);

  // Fetch counterparty positions and format data
  const getCounterpartData = async () => {
    const result = await getCounterpartyPositions(args?.nominationData[0]?.nominationRunId);

    setnominationRunId(args?.nominationData[0]?.nominationRunId);
    setgranularity(result.map((d: { granularity: any; }) => {return(d.granularity)})[0]);
    setprecision(result.map((d: { nominationDefinitionPrecision: any; }) => {return(d.nominationDefinitionPrecision)})[0]);
    if(result.map((d: { periodCount: any; }) => {return(d.periodCount)})[0]>0){
    setperiodCount(result.map((d: { periodCount: any; }) => {return(d.periodCount)})[0]);
    }
    else{
      setperiodCount(24);
    }

    let filterData: Product[] = result;

    filterData = filterData.map((data) => {
      if (
        data.fromMarketOperator === data.toMarketOperator ||
        data.fromMarketOperator === "" || data.toMarketOperator === ""
      ) {
        return { ...data };
      }
      return {
        ...data,
        fromMarketOperator: `${data.fromMarketOperator}.${data.toMarketOperator}`,
      };
    });

    filterData = filterData.map((d) => {
      if (
        transactionTypesBuy.includes(d.transactionType?.toLocaleLowerCase()) &&
        d.transactionType != ""
      ) {
        return { ...d };
      }

      return { ...d };
    });

    filterData.forEach((element) => {
      if (element.transactionType?.toLocaleLowerCase() == transactionTypeSell  && element.tradeType?.toLocaleLowerCase() != transmissionTrade) {
        Object.keys(element).forEach((key) => {
          if (key.startsWith(QH) && element[key] > 0) {
            element[key] = element[key] * -1;
          }
        });
      }
    });
    setData(filterData);
    setLoading(false);
  };
//Set column header based on granularity
  useEffect(() => {
    if(granularity!= undefined){
      if(granularity=="15"){
       settimespan ("QH")
       setColumnVisibility({
        "103": false,
        "108": false,
       })
      }
      else if(granularity== "30"){
       settimespan ("HH")
      }
      else if(granularity== "60"){
       settimespan ("H")
      }
   }
   else{
    settimespan ("H")
   }
    
  }, [granularity]);

//Set columns based on period count
  useEffect(()=>{
    if(periodCount>23){
      var idCount = 29
      var newColumn = [];
      for(let columnCount= 24; columnCount<=periodCount; columnCount++){
        idCount = idCount+1;
        if(idCount==103){
          idCount= 104
        }
        newColumn.push({
          id: idCount.toString(),
          header: `${timespan+columnCount}`,
          accessorKey: `qH${columnCount}`,
          cell: (info:any) => {
            if (info.getValue() % 1 !== 0) {
              return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
            } else {
              return info.getValue().toLocaleString();
            }
          },
      
          footer: (info:any) => {
            if (info.table.getFilteredRowModel().rows.length > 0) {
              const total = info.table
                .getFilteredRowModel()
                .rows?.reduce(
                  (sum: any, row: any) => row.getValue(info.column.id) + sum,
                  0
                );
              return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
            }
          },
        })
      }
      setNewColumn(newColumn);
    }
    else {
      setNewColumn([]);
    }
  },[timespan,granularity,periodCount])

  const closeModal = () => {
    setshowChild(false);
  };
  
  // Set static column 
  const initialColumnArray = [
    {
      id: "0",
      header: "Aggregated Position Reference",
      accessorKey: "aggPosReferenceName",
      cell: (info:any) => (
        <StyledLink to="/" onClick={() => sendData(info.row.getValue("103"))}>
          {info.getValue()}
        </StyledLink>
      ),
      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          return (
            <>
              <StyledFootTd>Total (MW):</StyledFootTd>
            </>
          );
        }
      },
    },
    {
      id: "103",
      header: "Aggregated Position Reference Id",
      accessorKey: "aggPosReferenceId",
    },
    {
      id: "110",
      header: "Status",
      accessorKey: "statusCode",
      cell: (info: any) => {
        const statusCode = info.getValue().toLowerCase();
        const statusMessage = info.row.getValue("108");
        const isRejectOrError = (statusCode === "rejected" || statusCode === "error");
        const title =  isRejectOrError ? statusMessage : '';

        return (
          <span title={title}>
            {info.getValue()}
            {isRejectOrError && (
              <img
                src="/warning-icon.png"
                alt="Message"
                style={{ width: "8px", height: "8px", marginLeft: '5px'}}
              />
            )}
          </span>
        );  
      }
    },
    {
      id: "108",
      header: "Status Message",
      accessorKey: "statusMessage",
    },
    {
      id: "1",
      header: "Counterparty",
      accessorKey: "counterparty",
    },
    {
      id: "2",
      header: "Market",
      accessorKey: "fromMarketOperator",
    },
    {
      id: "4",
      header: "Capacity Type",
      accessorKey: "capacityType",
    },
    {
      id: "5",
      header: "Capacity Identification",
      accessorKey: "capacityIdentification",
    },
    {
      id: "6",
      header: "Interconnector",
      accessorKey: "interconnector",
    },
    {
      id: "7",
      header: `${timespan}1`,
      accessorKey: "qH1",
      minSize: 2,
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "8",
      header: `${timespan}2`,
      accessorKey: "qH2",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "9",
      header: `${timespan}3`,
      accessorKey: "qH3",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "10",
      header: `${timespan}4`,
      accessorKey: "qH4",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "11",
      header: `${timespan}5`,
      accessorKey: "qH5",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "12",
      header: `${timespan}6`,
      accessorKey: "qH6",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "13",
      header: `${timespan}7`,
      accessorKey: "qH7",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "14",
      header: `${timespan}8`,
      accessorKey: "qH8",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "15",
      header: `${timespan}9`,
      accessorKey: "qH9",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "16",
      header: `${timespan}10`,
      accessorKey: "qH10",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "17",
      header: `${timespan}11`,
      accessorKey: "qH11",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "18",
      header: `${timespan}12`,
      accessorKey: "qH12",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "19",
      header: `${timespan}13`,
      accessorKey: "qH13",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "20",
      header: `${timespan}14`,
      accessorKey: "qH14",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "21",
      header: `${timespan}15`,
      accessorKey: "qH15",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "22",
      header: `${timespan}16`,
      accessorKey: "qH16",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "23",
      header: `${timespan}17`,
      accessorKey: "qH17",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "24",
      header: `${timespan}18`,
      accessorKey: "qH18",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "25",
      header: `${timespan}19`,
      accessorKey: "qH19",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "26",
      header: `${timespan}20`,
      accessorKey: "qH20",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "27",
      header: `${timespan}21`,
      accessorKey: "qH21",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "28",
      header: `${timespan}22`,
      accessorKey: "qH22",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "29",
      header: `${timespan}23`,
      accessorKey: "qH23",
      cell: (info:any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
          return info.getValue().toLocaleString();
        }
      },

      footer: (info:any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    }
  ];
  //Columns generation for volumn values based on period count and timespan
  const columns = useMemo<ColumnDef<Product, any>[]>(
    () => {
      if(newColumn?.length==0){
        return [...initialColumnArray];
      }
      return [...initialColumnArray,...newColumn]}
    ,[timespan, columnVisibility,newColumn]
  );

  const [columnOrder, setColumnOrder] = useState<String[]>(
    columns.map((column) => column.id as string)
  );
 
  
  const tableOptions = {
    state: {
      columnOrder,
    },
    onColumnOrderChange: setColumnOrder,
  };

  const table = useReactTable({
    data,
    columns,
    filterFns: {},
    state: {
      columnFilters,
      columnVisibility
    },
    onColumnVisibilityChange: setColumnVisibility,
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
  });

    useEffect(() => {
        const restrictedRole = sneReadOnly;
        const authClientId = process.env.REACT_APP_AUTH_CLIENT_ID || '';
        const env = authClientId.split("SNE_")[1].toLowerCase();
        if (env == "prod") {
            setProd(true);
        }
        
        if (user?.access_token) {
          var roleInfo = filterRoles(user.access_token);
          if (roleInfo.role && roleInfo.role.length > 0) {
            setUserRole(roleInfo.role);
          }
        }

        if (isProd || userRole == restrictedRole) {
          setShowResendButton(false);
        }
        else {
          setShowResendButton(true);
        }
        if (!showErrorAlert){
        setactions([{
            label: 'Cancel',
            action: () => {
                handleOnClose();
            },
        }, {
            label: 'Confirm',
            action: () => {
                closeModalClick(nominationRunId)
            }
        }])
      }
      else{
        setactions([{
          label: 'Ok',
          action: () => {
            handleOnClose();
          },
        }])
      }
      
    }, [message, nominationRunId, userRole, showErrorAlert])

  const handleOnClose = () => {
    if (!showAlert && !showErrorAlert && !showErrorAligne) 
    {
      setshowAlert(false);
      setshowErrorAlert(false);
      setactions([{
        label: 'Cancel',
        action: () => {
          handleOnClose();
        },
      }, {
        label: 'Confirm',
        action: closeModalClick
      }])

     window.location.reload();
    }
    else {
      window.location.reload();
    }
  }

  const closeModalClick = (nominationPassedRunId: number = 0) => {
      if (message == cancelMessage) {
        setshowAlert(false);
        args?.onClose(false);
        return;
      }
      if (showAlert || showErrorAligne) {
        args?.onClose(false);
        return;
      }
      if (nominationPassedRunId > 0) {
        handleSendToGMSL(nominationPassedRunId);
      }
    };
    
    
  const handleSendToGMSL = (nominationPassedRunId: number) => {
    sentDataToGMSL(nominationPassedRunId);
  }

  const sentDataToGMSL = async (nominationPassedRunId: number) => {
      setLoading(true);
      const result = await sendNominationRunToPowertrak(nominationPassedRunId);
      if (result != "error") {
        if (result.PowerTrak.ValidationResult.Result === "Invalid") {
          setLoading(false);
          setshowErrorAlert(true);
          setactions([{
            label: 'OK',
            action: () => {
              window.location.reload();
            },
          }])
        }
        else {
          if (result.PowerTrak.ValidationResult.Result == "Valid" && result.PowerTrak.ValidationResult.Result.Errors == undefined) {
            setresponseMessage("Message Accepted")
          }
          if (result.PowerTrak.ValidationResult.Result == "Valid" && result.PowerTrak.ValidationResult.Result.Errors !== undefined) {
            setresponseMessage("Message Partially Accepted")
          }
          setLoading(false);
          setshowAlert(true);
          setactions([{
            label: 'Ok',
            action: () => {
              window.location.reload();
            },
          }])
        }
      }
      else {
        setLoading(false);
        setshowErrorAlert(true);
      }
    }   
  const tableHasData = table.getRowModel()?.rows?.length > 0
  return (
    <>
      <StyledDiv>
        <div >
          <table style={{ width: "100%"}}>
            <tr>
              <td style={{ width: "70%" }}>
                <h2
                  style={{
                    fontSize: 16,
                    padding: "0px 8px",
                    textAlign: "left",
                    lineHeight: "8px",
                    margin: "12px",
                    fontWeight: 600,
                  }}
                >
                Aggregated Counterparty Positions (MW)
                </h2>
              </td>
              <td style={{ width: "30%" }}>
                {
                  table.getRowModel()?.rows?.length > 0 && showResendButton && 
                  (
                    <StyledSendButton onClick={() => setOpen(true)}>Resend Nomination</StyledSendButton>
                  )
                }
              </td>
            </tr>
          </table>
        </div>
        <Modal open={open || args.open}  loading={loading} showHeader={false} bodyStyle={{ flex: 0 }} size={Sizes.Medium} onClose={() => {
          handleOnClose();
          if (NOOP) NOOP;
        }} 
        actions={actions}>
          {!showAlert && !showErrorAlert && !showErrorAligne &&
            <StyledModalText>
              {message}
            </StyledModalText>
          }
          {showAlert &&
            <StyledAlertDiv>
              <Alert sentiment={Sentiments.Positive} solidBgColor>

                {responseMessage}
              </Alert>
            </StyledAlertDiv>
          }
          {showErrorAlert &&
            <StyledAlertDiv>
              <Alert sentiment={Sentiments.Negative} solidBgColor>

                Message Rejected
              </Alert>
            </StyledAlertDiv>
          }
          {showErrorAligne &&
            <StyledAlertDiv>
              <Alert sentiment={Sentiments.Negative} solidBgColor>

                {errorFromAligne}
              </Alert>
            </StyledAlertDiv>
          }
        </Modal>
        <StyledTableDiv>
          <StyledTable>
            <THead>
              {table.getHeaderGroups().map((headerGroup) => (
                <StyledTR key={headerGroup.id}>
                  {headerGroup.headers.map((header) => {
                    const StyledThComponent = tableHasData ? StyledTh : StyledNoDataTh;
                    return (
                      <StyledThComponent key={header.id} colSpan={header.colSpan}>
                        {header.isPlaceholder ? null : (
                          <>
                            {flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                          </>
                        )}
                      </StyledThComponent>
                    );
                  })}
                </StyledTR>
              ))}
            </THead>
            <TBody>
              {table.getRowModel()?.rows?.length > 0 ? (
                table.getRowModel().rows.map((row) => (
                  <StyledTr key={row.id}>
                    {row.getVisibleCells().map((cell) => {
                      return (
                        <StyledTd key={cell.id}>
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </StyledTd>
                      );
                    })}
                  </StyledTr>
                ))
              ) : loading == true ? (
                <StyledLoader type="primary" />
              ) : (
                <StyledTR>
                  <StyledNoDataTd colSpan={columns?.length}>
                    No Aggregation Positions Found
                  </StyledNoDataTd>
                </StyledTR>
              )}
            </TBody>
            <StyledTFoot>
              {table.getFooterGroups().map((footerGroup) => (
                <TR key={footerGroup.id}>
                  {footerGroup.headers.map((header) => {
                    const StyledFooterComponent = tableHasData ? StyledFootTh : StyledNoDataFootTh;
                    return (
                      <StyledFooterComponent key={header.id} colSpan={header.colSpan}>
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.footer,
                            header.getContext()
                          )}
                      </StyledFooterComponent>
                    );
                  })}
                </TR>
              ))}
            </StyledTFoot>
          </StyledTable>
        </StyledTableDiv>
      </StyledDiv>
    </>
  );
};

export default TableComponent;