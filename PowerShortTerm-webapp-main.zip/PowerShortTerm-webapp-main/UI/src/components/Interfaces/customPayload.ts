import { JwtPayload } from "jwt-decode";

export default interface ICustomJwtPayload extends JwtPayload {
    name: string;
    realm_access: {
      roles: string[];
    };
  }