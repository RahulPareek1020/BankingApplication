import { Button, Label, Loading, Select, SingleDatePicker, TD, TH } from '@sede-x/shell-ds-react-framework';
import styled from 'styled-components';

export const StyledSelect = styled(Select)`
    z-Index: 99`

export const StyledDiv = styled.div`
    margin: 5px; 5px; 5px; 5px;
    border: 1px solid ${(p) => p.theme.border.subtle};
    border-bottom: none;
    position: static;
    background:${(p) => p.theme.background.surface};
    margin-top:5px;
    margin-bottom: 5px;
`

export const StyledTable = styled.table`
    border-radius: 5px;
    font-size: 0.65vw;
    border-left: 1px solid ${(p) => p.theme.border.strong};
    width: 100%;
    max-width: 100%;
    white-space: nowrap;
    border-spacing:0;
    border: none;
    // table-layout:fixed;
    line-height: 15px;
    tr:last-child td {
    border-bottom: none;
}
    `


export const StyledTd = styled(TD)`
  &:nth-child(1){
    text-align: left;
    }
    text-align: center;
    padding: 8px;
    font-size: 0.65vw;
    color:${(p) => p.theme.text.onSurface.strong}
    width:50px;
    white-space:normal;
`

export const StyledTr = styled.tr`
    &:nth-child(even) {
    background: ${(p) => p.theme.background.base};
}
`

export const StyledTH = styled(TH)`
    background: ${(p) => p.theme.background.base};
    text-align: center;
    padding: 8px;
    font-size: 0.65vw;
    color: ${(p) => p.theme.text.onSurface.strong};
    position: sticky;
    top: 0;`
    
export const StyledTableDiv = styled.div`
    margin: 20px; 20px 20px; 20px;
    height: 300px;
    display: block;
    overflow: auto;
    overflow-x: hidden;
    width: 60%;
`

export const StyledH2 = styled.h2`
    padding: 10px 25px;
    textAlign: left;`;

export const Styleda = styled.a`
    color: ${(p) => p.theme.text.onSurface.link}
    `

export const StyledLoader = styled(Loading)`
    position: fixed;
    left: 50%;
    top: 50%;
    `

export const StyledLabel = styled(Label)`
    font-size: 0.65vw;
    font-weight: bold;
    width:7vw;
    margin-top: 1vh;
    padding-left:2.2vh;
`

export const StyledSingleDatePicker = styled(SingleDatePicker)
`
width:11%;
margin-right:1vh;
`

export const StyledSelectNom = styled(Select)
`
`

export const StyledButton = styled(Button)
`
margin-left: 9vw
`