import {
  Flexbox,
  SinglePickerValueType,
  TBody,
  THead,
  Variants
} from "@sede-x/shell-ds-react-framework";
import { PlaySolid } from "@sede-x/shell-ds-react-framework/build/esm/components/Icon/components";
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  useReactTable,
} from "@tanstack/react-table";
import dayjs, { Dayjs } from "dayjs";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { NominationHeader } from "../../context/tableContext/type";
import { getNominationHeader } from "../../data/api";
import ChildTableComponent from "../DetailsTable/ChildTable";
import TableComponent from "../DetailsTable/DetailsTable";
import { MappingTable } from "../MappingTable/MappingTable";
import NominationRunComponent from "../NominationRun/NominationRun";
import {
  Styleda,
  StyledButton,
  StyledDiv,
  StyledLabel,
  StyledLoader,
  StyledSelectNom,
  StyledSingleDatePicker,
  StyledTable,
  StyledTableDiv,
  StyledTd,
  StyledTH,
  StyledTr,
} from "./NominationHeader.style";
import { aligneError, partialDataTransfer, sne, sneReadOnly, noTradesFound } from "../../constants/constants";
import { useAuth } from "react-oidc-context";
import { filterRoles } from "../../Utilities/RoleUtils";
import { useSelector } from "react-redux";
import { ITheme } from "../../store/reducers";

const NominationHeaderComponent = () => {
  const [data, setdata] = useState<NominationHeader[]>([]);
  const [loadDetails, setLoadDetails] = useState(false);
  const [loading, setLoadding] = useState(false);
  const [nominationData, setNominationData] = useState<NominationHeader[]>([]);
  const [showChild, setshowChild] = useState(false);
  const [showMapping, setshowMapping] = useState(false);
  const [aggPosRefId, setaggPosRefId] = useState(0);
  const [nomination, setnomination] = useState("");
  const [nominations, setnominations] = useState([]);
  const [nominationDefinitions, setnominationDefinitions] = useState<{ nominationName: string, nominationDefinitionId: number }[]>([]);
  const [nominationDefinition, setnominationDefinition] = useState(0);
  const [filterData, setfilterData] = useState<NominationHeader[]>([]);
  const [showButton, setshowButton] = useState(false);
  const [refresh, setRefresh] = useState(false);
  const { isDark } = useSelector((state: ITheme) => state);

  const [initialDate, setinitialDate] = useState<SinglePickerValueType>(
    dayjs().add(1, "day")
  );
  const [showNominationRun, setshowNominationRun] = useState(false);

  const { user } = useAuth();
  const [userRole, setUserRole] = useState<string>();

  const handleDataFromTable = (
    data: boolean | ((prevState: boolean) => boolean)
  ) => {
    setshowChild(data);
  };

  const handleMappingPage = (
    data: boolean | ((prevState: boolean) => boolean)
  ) => {
    setshowMapping(data);
  };

  const handleRunNomination = (
    data: boolean | ((prevState: boolean) => boolean)
  ) => {
    setshowNominationRun(data);
    if (data == false) {
      setRefresh(true);
      refreshData();
    }
  };

  const handleaggPosRefId = (data: any) => {
    setaggPosRefId(data);
  };

  useEffect(() => {
  getData();
}, [initialDate, nomination]);

  useEffect(() => {
    getData();
    if (user?.access_token) {
        var roleInfo = filterRoles(user.access_token);
        if (roleInfo.role && roleInfo.role.length > 0) {
          setUserRole(roleInfo.role);
        }
    }
  }, []);

  const OnClearNomination = () => {
    setnomination("");
  };

  useEffect(() => {
    let filter = data;
    if (nomination != "" && nomination != "All") {
      filter = filter.filter((x) => x.nominationDefinitionName == nomination);
    }
    if (initialDate != null) {
      filter = filter.filter(
        (x) => dayjs(initialDate)?.isSame(x.deliveryDate, 'date')
      );
    }
    if (filter.length == 0) {
      setNominationData([]);
    }
    setfilterData(filter);
  }, [nomination, initialDate, data]);

  // Assign nomination header details to be passed to counterparty view
  useEffect(() => {
    if (filterData?.length != 0) {
      getNomination(filterData[0].nominationRunId,false);
    }
  }, [filterData]);

  //Fetch nomination header data
  const getData = async () => {
    setLoadding(true);
    var token : any;
    if(sessionStorage.getItem('accessToken')){
      token = sessionStorage.getItem('accessToken');
    }
    else
    {
      token = user?.access_token;
      sessionStorage.setItem('accessToken', token);
    }

    const result = await getNominationHeader(token);
    let nomresult = result.map((product: any) => {
      if (product.processStepStatus == aligneError || product.processStepStatus == noTradesFound) {
        return ({
          ...product,
          status: `${product.processStepStatus}`,
        })
      }
      else if(product.processStepName == partialDataTransfer){
        return ({
          ...product,
          status: `${product.processStepName}`,
        })
      }
      else{
        return ({
          ...product,
          status: `${product.processStepName} : ${product.processStepStatus}`,
        })
      }
    });
    let nominations = nomresult.map((x: any) => x.nominationDefinitionName);
    nominations = nominations.filter(
      (value: any, index: any, self: any) => self.indexOf(value) === index
    );
    nominations = nominations.map((x: any) => ({
      value: x,
      label: x,
    }));
    nominations.unshift({
      value: "All",
      label: "All",
    })
    setnominations(nominations);
    let nominationDefinitions = nomresult.map((x: any) => ({
      nominationName: x.nominationDefinitionName,
      nominationDefinitionId: x.nominationDefinitionId
    }));
    nominationDefinitions = nominationDefinitions.filter(
      (value: any, index: any, self: any) => self.indexOf(value) === index
    );
    setnominationDefinitions(nominationDefinitions);
    nomresult = nomresult.filter((x: any) => x.nominationRunId != null);
    // --- Filter data based on current filters ---
  let filtered = nomresult;
  if (nomination && nomination !== "All") {
    filtered = filtered.filter((x: any) => x.nominationDefinitionName === nomination);
  }
  if (initialDate) {
    filtered = filtered.filter(
      (x: any) => dayjs(initialDate).isSame(x.deliveryDate, 'date')
    );
  }
  setfilterData(filtered);
    setdata(nomresult);
    setLoadding(false);
  };

  const refreshData = async () => {
    setLoadding(true);
    var token : any;
    if(sessionStorage.getItem('accessToken')){
      token = sessionStorage.getItem('accessToken');
    }
    else
    {
      token = user?.access_token;
      sessionStorage.setItem('accessToken', token);
    }
    
    const result = await getNominationHeader(token);
    let nomresult = result.map((product: any) => {
      if (product.processStepStatus == aligneError || product.processStepStatus == noTradesFound) {
        return ({
          ...product,
          status: `${product.processStepStatus}`,
        })
      }
      else{
        return ({
          ...product,
          status: `${product.processStepName} : ${product.processStepStatus}`,
        })
      }
    });
    nomresult = nomresult.filter((x: any) => x.nominationRunId != null);
    setdata(nomresult);
    setLoadding(false);
  }
  // Columns for nomination header
  const columns: ColumnDef<NominationHeader, string>[] = [
    {
      id: "0",
      header: "Nomination Run Id",
      accessorKey: "nominationRunId",
    },
    {
      id: "1",
      header: "Nomination",
      accessorKey: "nominationDefinitionName",
    },
    {
      id: "2",
      accessorKey: "deliveryDate",
      enableColumnFilter: false,
      enableSorting: false,
      header: "Delivery Date",
      cell: (info) => {
        return dayjs(info.getValue()).format("D/M/YYYY");
      },
    },

    {
      id: "3",
      header: "Status",
      accessorKey: "status",
    },
    {
      id: "4",
      accessorKey: "reason",
      enableColumnFilter: false,
      enableSorting: false,
      header: "Reason",
    },
    {
      id: "5",
      header: "Last Updated",
      accessorKey: "lastModificationTime",
      cell: (info) => {
        return dayjs(info.getValue()).format("D/M/YYYY @ HH:mm");
      },
    },
    {
      id: "6",
      accessorKey: "initiatedBy",
      enableColumnFilter: false,
      enableSorting: false,
      header: "Initiated By",
    },
  ];
  const [columnVisibility, setColumnVisibility] = useState({
    columnId1: true,
  });

  const [columnOrder, setColumnOrder] = useState<String[]>(
    columns.map((column) => column.id as string)
  );
  const tableOptions = {
    state: {
      columnOrder,
      columnVisibility,
    },
    onColumnOrderChange: setColumnOrder,
    onColumnVisibilityChange: setColumnVisibility,
  };

  const table = useReactTable({
    data: filterData,
    columns,
    initialState: {
      columnVisibility: {
        "0": false,
      },
    },
    getCoreRowModel: getCoreRowModel(),
  });
  const [highlightrow, sethighlightrow] = useState("");
  const getNomination = (nominationRunId: number, fromRowClick = false) => {
    setLoadDetails(true);
    const filtered = data.filter((x) => x.nominationRunId == nominationRunId);
  setNominationData((prev) => {
    if (fromRowClick) {
      // Always update on row click
      return filtered;
    }
    // Only update if different
    if (JSON.stringify(prev) !== JSON.stringify(filtered)) {
      return filtered;
    }
    return prev;
  });
  sethighlightrow(nominationRunId.toString());
  };
  const onSelectNomination = (nomination: string) => {
    const restrictedRole = sneReadOnly;
    setnomination(nomination);
    let nomniationDefinitionId = nominationDefinitions.filter(x => x.nominationName == nomination)[0]?.nominationDefinitionId
    setnominationDefinition(nomniationDefinitionId)
    if (nomination != "All" && nomination != "" && userRole != restrictedRole) {
      setshowButton(true);
    }
    else {
      setshowButton(false);
    }
  };
  return (
    <>
      <StyledDiv
        style={{ display: !showChild && !showMapping && !showNominationRun ? "block" : "none" }}
      >
        <div style={{ display: "flex" }}>
          <h2
            style={{
              fontSize: 16,
              padding: "6px 8px",
              textAlign: "left",
              lineHeight: "8px",
              margin: "12px",
              fontWeight: 600,
            }}
          >
            Nomination Header
          </h2>
        </div>
        <Flexbox>
          <StyledLabel>Delivery Date</StyledLabel>
          <StyledSingleDatePicker
            placeholder={"Delivery Date"}
            allowClear={false}
            value={initialDate}
            onSelect={(x) => setinitialDate(x)}
          />
          <StyledLabel>Nomination</StyledLabel>
          <div style={{ width: "11%", marginRight: "1vw" }}>
            <StyledSelectNom
              id="nomination"
              options={nominations}
              optionFilterProp="label"
              onSelect={onSelectNomination}
              allowClear={false}
              defaultValue={"All"}
            />
          </div>
          {showButton && <StyledButton variant={Variants.Filled} icon={<PlaySolid />} onClick={() => handleRunNomination(true)}>Run Nomination</StyledButton>}
        </Flexbox>
        <StyledTableDiv>
          <StyledTable>
            <THead>
              {table.getHeaderGroups().map((headerGroup) => (
                <StyledTr key={headerGroup.id}>
                  {headerGroup.headers.map((header) => (
                    <StyledTH key={header.id} colSpan={header.colSpan}>
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                          header.column.columnDef.header,
                          header.getContext()
                        )}
                    </StyledTH>
                  ))}
                </StyledTr>
              ))}
            </THead>
            <TBody>
              {table.getRowModel()?.rows?.length > 0 ? (
                table.getRowModel()?.rows.map((row) => (
                  <StyledTr
                    style={{
                      backgroundColor:
                        highlightrow == row.getValue("0")
                          ? (isDark? "rgb(37, 52, 54)": "rgb(230,245,246)")
                          : "",
                    }}
                    key={row.id}
                    onClick={() => getNomination(row.getValue("0"),true)}
                  >
                    {row.getVisibleCells().map((cell) => {
                      return (
                        <StyledTd key={cell.id}>
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </StyledTd>
                      );
                    })}
                  </StyledTr>
                ))
              ) : loading == true ? (
                <StyledLoader type="primary" />
              ) : (
                <StyledTr>
                  <td colSpan={columns?.length}> No Data</td>
                </StyledTr>
              )}
            </TBody>
          </StyledTable>
        </StyledTableDiv>
      </StyledDiv>
      <div style={{ display: !showChild && !showMapping && !showNominationRun ? "block" : "none", position: "relative"}}>
        <TableComponent
          nominationData={nominationData}
          load={loadDetails}
          onLinkClick={handleDataFromTable}
          aggPosRefId={handleaggPosRefId}
        />
      </div>

      {showChild && (
        <ChildTableComponent
          onClose={handleDataFromTable}
          aggPosRefId={aggPosRefId}
        />
      )}

      {showMapping && <MappingTable onClose={handleMappingPage} />}

      {showNominationRun &&
        <NominationRunComponent
          onClose={handleRunNomination}
          nomination={nomination} deliveryDate={initialDate}
          nominationDefinitionId={nominationDefinition}
        />
      }
    </>
  );
};

export default NominationHeaderComponent;
