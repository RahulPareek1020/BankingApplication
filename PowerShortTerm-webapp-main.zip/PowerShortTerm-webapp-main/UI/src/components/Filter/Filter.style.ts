import { Select, TH } from '@sede-x/shell-ds-react-framework';
import styled, { css } from 'styled-components';

export const StyledSelect = styled(Select)`
z-Index: 99`

export const StyledDiv = styled.div`
margin: 10px 20px 20px;
box-shadow: 0px 35px 50px rgba( 0, 0, 0, 0.2 );
`

export const StyledTable = styled.table`
    border-radius: 5px;
    font-size: 12px;
    font-weight: bold;
    border: none;
    border-collapse: collapse;
    width: 100%;
    max-width: 100%;
    white-space: nowrap;
    background-color: white;`


export const StyledTd = styled.td`
    text-align: center;
    padding: 8px;
    border: 1px solid #1d1b1b;
    font-size: 12px;

`

export const StyledTr = styled.tr`
    nth-child(odd) {
    background: #e0dede;
}
`

export const StyledTH = styled(TH)`
    background: #e0dede;
    text-align: center;
    padding: 8px;
    border: 1px solid #1d1b1b;
    font-size: 15px;
`
export const StyledTableDiv = styled.div`
margin: 10px 20px 20px;
box-shadow: 0px 35px 50px rgba( 0, 0, 0, 0.2 );
`