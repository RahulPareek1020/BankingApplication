import { THead, TBody } from "@sede-x/shell-ds-react-framework";
import React, { useEffect } from "react";
import { useState } from "react";
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  useReactTable,
} from "@tanstack/react-table";
import {
  Styleda,
  StyledDiv,
  StyledTable,
  StyledTableDiv,
  StyledTd,
  StyledTH,
  StyledTr,
} from "./NominationTable.style";
import dayjs from "dayjs";
import { NominationHeader, Product } from "../../context/tableContext/type";
import { getNominationHeader } from "../../data/api";
const NominationTableComponent = (args: any) => {
  const [data, setdata] = useState([]);
  useEffect(() => {
    setdata(args.data);
  }, [args.data]);

  const columns: ColumnDef<NominationHeader, string>[] = [
    {
      id: "0",
      header: "Nomination",
      accessorKey: "nomination",
    },
    {
      id: "1",
      accessorKey: "deliveryDate",
      enableColumnFilter: false,
      enableSorting: false,
      header: "Delivery Date",
      cell: (info) => {
        return dayjs(info.getValue()).format("D/M/YYYY");
      },
    },

    {
      id: "2",
      header: "Status",
      accessorKey: "status",
    },
    {
      id: "3",
      accessorKey: "reason",
      enableColumnFilter: false,
      enableSorting: false,
      header: "Reason",
    },
  ];
  const [columnOrder, setColumnOrder] = useState<String[]>(
    columns.map((column) => column.id as string)
  );
  const tableOptions = {
    state: {
      columnOrder,
    },
    onColumnOrderChange: setColumnOrder,
  };
  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
  });
  return (
    <>
      <StyledTable>
        <THead>
          {table.getHeaderGroups().map((headerGroup) => (
            <StyledTr key={headerGroup.id}>
              {headerGroup.headers.map((header) => (
                <StyledTH key={header.id} colSpan={header.colSpan}>
                  {header.isPlaceholder
                    ? null
                    : flexRender(
                        header.column.columnDef.header,
                        header.getContext()
                      )}
                </StyledTH>
              ))}
            </StyledTr>
          ))}
        </THead>
        <TBody>
          {table.getRowModel()?.rows?.length > 0 ? (
            table.getRowModel()?.rows.map((row) => (
              <StyledTr key={row.id}>
                {row.getVisibleCells().map((cell) => {
                  return (
                    <StyledTd key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </StyledTd>
                  );
                })}
              </StyledTr>
            ))
          ) : (
            <StyledTr>
              <td colSpan={columns?.length}> No Data</td>
            </StyledTr>
          )}
        </TBody>
      </StyledTable>
    </>
  );
};

export default NominationTableComponent;
