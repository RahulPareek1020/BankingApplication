import { Select, TH } from '@sede-x/shell-ds-react-framework';
import styled from 'styled-components';

export const StyledSelect = styled(Select)`
z-Index: 99`

export const StyledDiv = styled.div`
margin: 20px; 20px 20px; 20px;
box-shadow: 0px 35px 50px rgba( 0, 0, 0, 0.2 );
border: 1px solid ${(p) => p.theme.border.strong};
height: 20%;
position: static;
border
`

export const StyledTable = styled.table`
    border-radius: 5px;
    font-size: 0.65vw;
    //border: 1px ${(p) => p.theme.border.strong} ;
    border-collapse: collapse;
    width: 50%;
    max-width: 100%;
    white-space: nowrap;
    table-layout: fixed;`


export const StyledTd = styled.td`
    text-align: center;
    padding: 8px;
    //border: 1px solid #1d1b1b;
    font-size: 0.65vw;
    color:${(p) => p.theme.text.onSurface.strong}

`

export const StyledTr = styled.tr`
    nth-child(odd) {
    background: ${(p) => p.theme.background.surface};
}
`

export const StyledTH = styled(TH)`
    background: ${(p) => p.theme.background.base};
    text-align: center;
    padding: 8px;
    //border: 1px solid #1d1b1b;
    font-size: 0.65vw;
    color: ${(p) => p.theme.text.onSurface.strong}
`
export const StyledTableDiv = styled.div`
margin: 20px; 20px 20px; 20px;
//box-shadow: 0px 35px 50px rgba( 0, 0, 0, 0.2 );
height: 300px;
display:block;
overflow: scroll;
overflow-x: hidden;
`

export const StyledH2 = styled.h2`
// fontSize: 20; 
padding: 10px 25px;
textAlign: left;`;

export const Styleda = styled.a`
color: ${(p) => p.theme.text.onSurface.link}
`