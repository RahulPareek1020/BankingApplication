import React from "react";
import { Outlet } from "react-router-dom";
import Title from "./Title/Title";
import { StyledDiv } from "./Title/Title.style";

function AppRoute() {
  return (
    <StyledDiv className="App">
      <Title />
      <Outlet />
    </StyledDiv>
  );
}

export default AppRoute;
