import { Alert, Icons, Modal, NOOP, Sentiments, Spacings, TBody, THead, TR, Variants } from "@sede-x/shell-ds-react-framework";
import {
  ColumnDef,
  ColumnFiltersState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  useReactTable,
} from "@tanstack/react-table";
import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { cancelMessage, errorFromAligne, nominationInitiated, nominationPartialData, nominationReady, QH, sendToGMSLMessage, successMessage, transactionTypesBuy, transactionTypeSell, transmissionTrade } from "../../constants/constants";
import { Product } from "../../context/tableContext/type";
import { getCounterpartyAggregations, getCounterpartyAggregationsNomRun, getNominationStatus, runAligneBatch, sendNominationRunToPowertrak, sendNominationToPowertrak } from "../../data/api";
import {
  StyledAlertDiv,
  StyledCancelButton,
  StyledDiv,
  StyledDivButton,
  StyledDivLabel,
  StyledFlexbox,
  StyledFootTd,
  StyledFootTh,
  StyledIcon,
  StyledLoader,
  StyledModalText,
  StyledNoDataTd,
  StyledSendButton,
  StyledSpan,
  StyledSpanData,
  StyledTable,
  StyledTableDiv,
  StyledTd,
  StyledTFoot,
  StyledTh,
  StyledTr,
  StyledTR,
} from "./NominationRun.style";
import { Alignments, Sizes, Positions, Action } from '@sede-x/shell-ds-react-base';
import { useAuth } from "react-oidc-context";

const NominationRunComponent = (args: any) => {
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<Product[]>([]);
  const [showChild, setshowChild] = useState(false);
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState(sendToGMSLMessage);
  const [showAlert, setshowAlert] = useState(false);
  const [showErrorAlert, setshowErrorAlert] = useState(false);
  const [showErrorAligne, setshowErrorAligne] = useState(false);
  const [actions, setactions] = useState<any>([])
  const [responseMessage, setresponseMessage] = useState("string")
  const [periodCount, setperiodCount] = useState(24);
  const [newColumn, setNewColumn] = useState<any>([]);
  const [timespan, settimespan] = useState('H');
  const [granularity, setgranularity] = useState('');
  const [precision, setprecision] = useState(2);
  const [nominationStatus, setnominationStatus] = useState('');
  const [nominationRunId, setnominationRunId] = useState(0);
  const [intervalId, setintervalId] = useState(0);
  const [countInterval, setcountInterval] = useState(0);
  const limit = 40;
  const { user } = useAuth();

  const handleOnClose = () => {
    if (!showAlert && !showErrorAlert && !showErrorAligne) {
      setshowAlert(false);
      setshowErrorAlert(false);
      if (message != cancelMessage) {
        setactions([{
          label: 'Cancel',
          action: () => {
            handleOnClose();
          },
        }, {
          label: 'Confirm',
          action: () => {
            closeModalClick(nominationRunId)
          }
        }])
      }
      else {
        setactions([{
          label: 'Ok',
          action: () => {
            handleOnClose();
          },
        }])
        args?.onClose(false);
      }

      setOpen(false);
    }
    else {
      args?.onClose(false);
    }
  }

  const closeModalButton = () => {
    setshowAlert(false);
    setshowErrorAlert(false);
    setshowErrorAligne(false);
    setOpen(false);
  }

  useEffect(() => {
    setData([])
    setLoading(true);
    getCounterpartData();
    setshowAlert(false);
    setshowErrorAlert(false);
    setactions([{
      label: 'Cancel',
      action: () => {
        handleOnClose();
      },
    }, {
      label: 'Confirm',
      action: () => { closeModalClick(); }
    }]);
  }, []);

  useEffect(() => {
    if (!showErrorAlert && message != cancelMessage) {
      setactions([{
        label: 'Cancel',
        action: () => {
          handleOnClose();
        },
      }, {
        label: 'Confirm',
        action: () => {
          closeModalClick(nominationRunId)
        }
      }])
    }
    else {
      setactions([{
        label: 'Ok',
        action: () => {
          handleOnClose();
        },
      }])
    }
  }, [message, nominationRunId, showErrorAlert])

  // Fetch counterparty positions and format data
  const getCounterpartData = async () => {
    if (nominationStatus == '') {
      const aligneRunResult = await runAligneBatch(args?.nominationDefinitionId, args?.deliveryDate.format('YYYY-MM-DD').toString(), false);
      const nominationRunId = aligneRunResult.nominationRunId;
      setnominationRunId(nominationRunId);
      if (successMessage.some(aligneRunResponse => 
        aligneRunResult.aligneBatchResponse.toString().includes(aligneRunResponse)
      )) {
        const nominationStatusResult = await getNominationStatus(nominationRunId);
        setnominationStatus(nominationStatusResult.toString());
      }
      else {
        setLoading(false);
        setshowErrorAligne(true);
        setOpen(true);
      }
    }

    if (nominationStatus == nominationReady) {
      const result = await getCounterpartyAggregationsNomRun(nominationRunId);
      setgranularity(result.map((d: { granularity: any; }) => { return (d.granularity) })[0]);
      setprecision(result.map((d: { nominationDefinitionPrecision: any; }) => {return(d.nominationDefinitionPrecision)})[0]);

      if (result.map((d: { periodCount: any; }) => { return (d.periodCount) })[0] > 0) {
        setperiodCount(result.map((d: { periodCount: any; }) => { return (d.periodCount) })[0]);
      }
      else {
        setperiodCount(24);
      }
      let filterData: Product[] = result;
      filterData = filterData.map((data) => {
        if (
          data.fromMarketOperator === data.toMarketOperator ||
          data.fromMarketOperator === "" || data.toMarketOperator === ""
        ) {
          return { ...data };
        }
        return {
          ...data,
          fromMarketOperator: `${data.fromMarketOperator}.${data.toMarketOperator}`,
        };
      });

      filterData = filterData.map((d) => {
        if (
          transactionTypesBuy.includes(d.transactionType?.toLocaleLowerCase()) &&
          d.transactionType != ""
        ) {
          return { ...d };
        }

        return { ...d};
      });

      filterData.forEach((element) => {
        if (element.transactionType?.toLocaleLowerCase() == transactionTypeSell  && element.tradeType?.toLocaleLowerCase() != transmissionTrade) {
          Object.keys(element).forEach((key) => {
            if (key.startsWith(QH) && element[key] > 0) {
              element[key] = element[key] * -1;
            }
          });
        }
      });
      setData(filterData);
      setLoading(false);
    };
  }

  const getUpdatedNominationStatus = async () => {
    if (nominationRunId > 0) {
      const nominationStatusResult = await getNominationStatus(nominationRunId);
      setnominationStatus(nominationStatusResult.toString());
    }
  }
  //Set column header based on granularity
  useEffect(() => {
    if (nominationStatus == nominationInitiated || nominationStatus == nominationPartialData && nominationRunId > 0) {
      var interval = 0;
      const nominationStatusResult = setInterval(() => {
        interval = interval + 1;
        if (interval <= limit) {
          getUpdatedNominationStatus();
        }
        else {
          setLoading(false);
          setData([]);
          clearInterval(nominationStatusResult);
        }
      }, 15000);
      return () => {
        // clean up
        clearInterval(nominationStatusResult);
      };
    }
    else if (nominationStatus == nominationReady) {
      getCounterpartData();
    }
  }, [nominationStatus]);

  //Set column header based on granularity
  useEffect(() => {
    if (granularity != undefined) {
      if (granularity == "15") {
        settimespan("QH")
      }
      else if (granularity == "30") {
        settimespan("HH")
      }
      else if (granularity == "60") {
        settimespan("H")
      }
    }
    else {
      setperiodCount(24);
      settimespan("H")
    }

  }, [granularity]);

  //Set columns based on period count
  useEffect(() => {
    if (periodCount > 23) {
      var idCount = 29
      var newColumn = [];
      for (let columnCount = 24; columnCount <= periodCount; columnCount++) {
        idCount = idCount + 1;
        if (idCount == 103) {
          idCount = 104
        }
        newColumn.push({
          id: idCount.toString(),
          header: `${timespan + columnCount}`,
          accessorKey: `qH${columnCount}`,
          cell: (info: any) => {
            if (info.getValue() % 1 !== 0) {
              return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
            } else {
             return info.getValue().toLocaleString();
            }
          },

          footer: (info: any) => {
            if (info.table.getFilteredRowModel().rows.length > 0) {
              const total = info.table
                .getFilteredRowModel()
                .rows?.reduce(
                  (sum: any, row: any) => row.getValue(info.column.id) + sum,
                  0
                );
              return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
            }
          },
        })
      }
      setNewColumn(newColumn);
    }
    else {
      setNewColumn([]);
    }
  }, [timespan, granularity, periodCount])

  const sentDataToGMSL = async (nominationPassedRunId: number) => {
    setLoading(true);
    const result = await sendNominationRunToPowertrak(nominationPassedRunId);
    if (result != "error") {
      if (result.PowerTrak.ValidationResult.Result === "Invalid") {
        setLoading(false);
        setshowErrorAlert(true);
        setactions([{
          label: 'OK',
          action: () => {
            args?.onClose(false);
          },
        }])
      }
      else {
        if (result.PowerTrak.ValidationResult.Result == "Valid" && result.PowerTrak.ValidationResult.Result.Errors == undefined) {
          setresponseMessage("Message Accepted")
        }
        if (result.PowerTrak.ValidationResult.Result == "Valid" && result.PowerTrak.ValidationResult.Result.Errors !== undefined) {
          setresponseMessage("Message Partially Accepted")
        }
        setLoading(false);
        setshowAlert(true);
        setactions([{
          label: 'Ok',
          action: () => {
            args?.onClose(false);
          },
        }])
      }
    }
    else {
      setLoading(false);
      setshowErrorAlert(true);
    }
  }

  const handleCancelClick = () => {
    setMessage(cancelMessage);
    setOpen(true);
  }

  const handleSendNomClick = () => {
    setMessage(sendToGMSLMessage);
    setOpen(true);
  }

  const closeModalClick = (nominationPassedRunId: number = 0) => {
    if (message == cancelMessage) {
      setshowAlert(false);
      args?.onClose(false);
      return;
    }
    if (showAlert || showErrorAligne || showErrorAlert) {
      args?.onClose(false);
      return;
    }
    if (nominationPassedRunId > 0) {
      handleSendToGMSL(nominationPassedRunId);
    }
  };

  const closeModal = () => {
    args?.onClose(false);
  };

  const handleSendToGMSL = (nominationPassedRunId: number) => {
    sentDataToGMSL(nominationPassedRunId);
  }
  // Set static column 
  const initialColumnArray = [
    {
      id: "0",
      header: "Aggregated Position Reference",
      accessorKey: "aggPosReferenceName",
      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          return (
            <>
              <StyledFootTd>Total (MW):</StyledFootTd>
            </>
          );
        }
      },
    },
    {
      id: "103",
      header: "Aggregated Position Reference Id",
      accessorKey: "aggPosReferenceId",
    },
    {
      id: "1",
      header: "Counterparty",
      accessorKey: "counterparty",
    },
    {
      id: "2",
      header: "Market",
      accessorKey: "fromMarketOperator",
    },
    {
      id: "4",
      header: "Capacity Type",
      accessorKey: "capacityType",
    },
    {
      id: "5",
      header: "Capacity Identification",
      accessorKey: "capacityIdentification",
    },
    {
      id: "6",
      header: "Interconnector",
      accessorKey: "interconnector",
    },
    {
      id: "7",
      header: `${timespan}1`,
      accessorKey: "qH1",
      minSize: 2,
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "8",
      header: `${timespan}2`,
      accessorKey: "qH2",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "9",
      header: `${timespan}3`,
      accessorKey: "qH3",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "10",
      header: `${timespan}4`,
      accessorKey: "qH4",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "11",
      header: `${timespan}5`,
      accessorKey: "qH5",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "12",
      header: `${timespan}6`,
      accessorKey: "qH6",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "13",
      header: `${timespan}7`,
      accessorKey: "qH7",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "14",
      header: `${timespan}8`,
      accessorKey: "qH8",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "15",
      header: `${timespan}9`,
      accessorKey: "qH9",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "16",
      header: `${timespan}10`,
      accessorKey: "qH10",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "17",
      header: `${timespan}11`,
      accessorKey: "qH11",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "18",
      header: `${timespan}12`,
      accessorKey: "qH12",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "19",
      header: `${timespan}13`,
      accessorKey: "qH13",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "20",
      header: `${timespan}14`,
      accessorKey: "qH14",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "21",
      header: `${timespan}15`,
      accessorKey: "qH15",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "22",
      header: `${timespan}16`,
      accessorKey: "qH16",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "23",
      header: `${timespan}17`,
      accessorKey: "qH17",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "24",
      header: `${timespan}18`,
      accessorKey: "qH18",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "25",
      header: `${timespan}19`,
      accessorKey: "qH19",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "26",
      header: `${timespan}20`,
      accessorKey: "qH20",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "27",
      header: `${timespan}21`,
      accessorKey: "qH21",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "28",
      header: `${timespan}22`,
      accessorKey: "qH22",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    },
    {
      id: "29",
      header: `${timespan}23`,
      accessorKey: "qH23",
      cell: (info: any) => {
        if (info.getValue() % 1 !== 0) {
          return parseFloat(info.getValue()?.toFixed(precision)).toLocaleString();
        } else {
         return info.getValue().toLocaleString();
        }
      },

      footer: (info: any) => {
        if (info.table.getFilteredRowModel().rows.length > 0) {
          const total = info.table
            .getFilteredRowModel()
            .rows?.reduce(
              (sum: any, row: any) => row.getValue(info.column.id) + sum,
              0
            );
          return <>{parseFloat(total?.toFixed(precision)).toLocaleString()}</>;
        }
      },
    }
  ];
  //Columns generation for volumn values based on period count and timespan
  const columns = useMemo<ColumnDef<Product, any>[]>(
    () => {
      if (newColumn?.length == 0) {
        return [...initialColumnArray];
      }
      return [...initialColumnArray, ...newColumn]
    }
    , [timespan, newColumn]
  );

  const [columnOrder, setColumnOrder] = useState<String[]>(
    columns.map((column) => column.id as string)
  );
  const tableOptions = {
    state: {
      columnOrder,
    },
    onColumnOrderChange: setColumnOrder,
  };

  const table = useReactTable({
    data,
    columns,
    filterFns: {},
    state: {
      columnFilters,
    },
    initialState: {
      columnVisibility: {
        "103": false,
      },
    },
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
  });

  return (
    <>
      <StyledDiv>
        <Link to="/" onClick={closeModal} >
          <span style={{ float: "right" }}>
            <StyledIcon />
          </span>
        </Link>
        <h2
          style={{
            fontSize: 16,
            padding: "0px 8px",
            textAlign: "left",
            lineHeight: "8px",
            margin: "12px",
            fontWeight: 600,
          }}
        >
          Aggregated Counterparty Positions (MW)
        </h2>
        <StyledFlexbox>
          <StyledDivLabel>
            <StyledSpan>Nomination:</StyledSpan>
            <StyledSpanData>{args?.nomination}</StyledSpanData>
            <StyledSpan>Delivery Date:</StyledSpan>
            <StyledSpanData>{args?.deliveryDate?.format('DD/MM/YYYY').toString()}</StyledSpanData>
          </StyledDivLabel>
          {data?.length > 0 && (
            <StyledDivButton>
            <StyledCancelButton onClick={handleCancelClick}>Cancel</StyledCancelButton>
            <StyledSendButton onClick={handleSendNomClick}>Send Nomination</StyledSendButton>
          </StyledDivButton>)
          }
        </StyledFlexbox>
        <Modal open={open || args.open} loading={loading} showHeader={false} bodyStyle={{ flex: 0 }} size={Sizes.Medium} onClose={() => {
          closeModalButton();
          if (NOOP) NOOP;
        }} actions={actions}>
          {!showAlert && !showErrorAlert && !showErrorAligne &&
            <StyledModalText>
              {message}
            </StyledModalText>
          }
          {showAlert &&
            <StyledAlertDiv>
              {/* <Alert sentiment={Sentiments.Positive} solidBgColor onClick={() => { setshowAlert(false) }}> */}
              <Alert sentiment={Sentiments.Positive} solidBgColor>
                {responseMessage}
              </Alert>
            </StyledAlertDiv>
          }
          {showErrorAlert &&
            <StyledAlertDiv>
              {/* <Alert sentiment={Sentiments.Negative} solidBgColor onClick={() => { setshowErrorAlert(false) }}> */}
              <Alert sentiment={Sentiments.Negative} solidBgColor>
                Message Rejected
              </Alert>
            </StyledAlertDiv>
          }
          {showErrorAligne &&
            <StyledAlertDiv>
              {/* <Alert sentiment={Sentiments.Negative} solidBgColor onClick={() => { setshowErrorAligne(false) }}> */}
              <Alert sentiment={Sentiments.Negative} solidBgColor>
                {errorFromAligne}
              </Alert>
            </StyledAlertDiv>
          }
        </Modal>
        <StyledTableDiv>
          <StyledTable>
            <THead>
              {table.getHeaderGroups().map((headerGroup) => (
                <StyledTR key={headerGroup.id}>
                  {headerGroup.headers.map((header) => {
                    return (
                      <StyledTh key={header.id} colSpan={header.colSpan}>
                        {header.isPlaceholder ? null : (
                          <>
                            {flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                          </>
                        )}
                      </StyledTh>
                    );
                  })}
                </StyledTR>
              ))}
            </THead>
            <TBody>
              {table.getRowModel()?.rows?.length > 0 ? (
                table.getRowModel().rows.map((row) => (
                  <StyledTr key={row.id}>
                    {row.getVisibleCells().map((cell) => {
                      return (
                        <StyledTd key={cell.id}>
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </StyledTd>
                      );
                    })}
                  </StyledTr>
                ))
              ) : loading == true ? (
                <StyledLoader type="primary" />
              ) : (
                <StyledTR>
                  <StyledNoDataTd colSpan={columns?.length}>
                    No Trades Found
                  </StyledNoDataTd>
                </StyledTR>
              )}
            </TBody>
            <StyledTFoot>
              {table.getFooterGroups().map((footerGroup) => (
                <TR key={footerGroup.id}>
                  {footerGroup.headers.map((header) => (
                    <StyledFootTh key={header.id} colSpan={header.colSpan}>
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                          header.column.columnDef.footer,
                          header.getContext()
                        )}
                    </StyledFootTh>
                  ))}
                </TR>
              ))}
            </StyledTFoot>
          </StyledTable>
        </StyledTableDiv>
      </StyledDiv>
    </>
  );
};

export default NominationRunComponent;
