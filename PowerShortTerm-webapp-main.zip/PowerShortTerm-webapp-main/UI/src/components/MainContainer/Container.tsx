import { ReactNode } from "react";
import { StyledFlexbox } from "./MainContainer.styles";
import React from "react";

const Container = ({
  children,
  testId,
}: {
  children: ReactNode;
  testId?: string;
}) => {
  return <StyledFlexbox data-testid={testId}>{children}</StyledFlexbox>;
};

export default Container;
