import { Flexbox } from "@sede-x/shell-ds-react-framework";
import styled from "styled-components";

const StyledFlexbox = styled(Flexbox)`
  margin: 10px;
  width: 100%;
  height: 100%;
  text-align: center;
  flex-direction: ${(props: any) => props.$flexDirection};
  align-items: ${(props: any) => props.$alignItems};
  overflow: scroll;
`;

export { StyledFlexbox };
