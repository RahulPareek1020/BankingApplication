import {
  Flexbox,
  Icons,
  Select,
  SingleDatePicker,
  TBody,
  TFoot,
  TH,
  THead,
  TR
} from "@sede-x/shell-ds-react-framework";
import {
  ColumnDef,
  ColumnFiltersState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  Row,
  useReactTable,
} from "@tanstack/react-table";
import React, { useEffect, useMemo, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { FilterOption } from "../../context/tableContext/filter";
import { MappingData } from "../../context/tableContext/type";

import dayjs, { Dayjs } from "dayjs";
import { getMappingRuleDetails } from "../../data/api";
import {
  StyledChildTableDiv,
  StyledDateDiv,
  StyledDivChild,
  StyledDivFilter,
  StyledHeaderTR,
  StyledLabel,
  StyledNoDataTd,
  StyledRawDiv,
  StyledRawTradeDiv,
  StyledSelectDiv,
  StyledTable,
  StyledTd,
  StyledTh,
  StyledTR,
  StyledTr,
} from "./MappingTable.style";
import { useAuth } from "react-oidc-context";

export const MappingTable = (args: any) => {
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [filterOption, setFilterOption] = useState<FilterOption>();
  const [loading, setLoading] = useState(true);
  const location = useLocation();
  const dataValue = location.state;
  const [data, setData] = useState([]);
  const [filterData, setfilterData] = useState([]);

  const [nomination, setnomination] = useState("");
  const [mappingType, setmappingType] = useState("");
  const [outputValue, setoutputValue] = useState("");
  const [applicableFrom, setapplicableFrom] = useState<Dayjs>();
  const [applicableTo, setapplicableTo] = useState<Dayjs>();
  const { user } = useAuth();
  
  type DateRange = {
    from?: Dayjs;
    to?: Dayjs;
  };

  useEffect(() => {
    setData([]);
    setfilterData([]);
    setLoading(true);
    getMappingDetailsData(args?.aggPosRefId);
  }, []);

  useEffect(() => {
    if (data?.length != 0) {
      let filerData = data;
      let nominations = filerData.map((x: any) => x.nominationDefinitionName);
      nominations = nominations.filter(
        (value: any, index: any, self: any) => self.indexOf(value) === index
      );
      nominations = nominations.map((x: any) => ({
        value: x,
        label: x,
      }));
      let mappingTypes = filerData.map((x: any) => x.mappingTypeName);
      mappingTypes = mappingTypes.filter(
        (value: any, index: any, self: any) => self.indexOf(value) === index
      );

      mappingTypes = [
        { value: "Counterparty", label: "Counterparty" },
        { value: "Market", label: "Market" },
        { value: "Other", label: "Other" },
        { value: "DM Route", label: "DM Route" },
      ];
      let outputValues = filerData.map((x: any) => x.mappingOutputValue);
      outputValues = outputValues.filter(
        (value: any, index: any, self: any) => self.indexOf(value) === index
      );
      outputValues = outputValues.map((x: any) => ({
        value: x,
        label: x,
      }));
      let filterOptions: FilterOption = {
        nominations: nominations,
        mappingTypes: mappingTypes,
        outputValues: outputValues,
      };
      setFilterOption(filterOptions);
    }
  }, [data]);

  useEffect(() => {
    filterDataOnSelection();
  }, [nomination, mappingType, outputValue, applicableFrom, applicableTo]);
  const onSelectNomination = (nomination: string) => {
    setnomination(nomination);
  };

  const onSelectMappingType = (mappingType: string) => {
    setmappingType(mappingType);
  };

  const onSelectOuptutValue = (outputValue: string) => {
    setoutputValue(outputValue);
  };

  const onSelectFromDate = (val: any) => {
    setapplicableFrom(val);
  };
  const onSelectToDate = (val: any) => {
    setapplicableTo(val);
  };

  const OnClearNomination = (nomination: string) => {
    setnomination("");
  };

  const OnClearMappingType = (nomination: string) => {
    setmappingType("");
  };

  const OnClearOutputValue = (nomination: string) => {
    setoutputValue("");
  };
  const OnClearApplicableFromDate = (nomination: string) => {
    setapplicableFrom(undefined);
  };
  const OnClearApplicableToDate = (nomination: string) => {
    setapplicableTo(undefined);
  };

  // Fetch Nomination Trade Details and format data
  const getMappingDetailsData = async (aggPosRefId: number) => {
    const result = await getMappingRuleDetails();
    result.sort((a: MappingData, b: MappingData) =>
      a.nominationDefinitionName.localeCompare(b.nominationDefinitionName)
    );
    result.sort((a: MappingData, b: MappingData) =>
      a.mappingTypeName.localeCompare(b.mappingTypeName)
    );
    result.sort((a: MappingData, b: MappingData) =>
      a.mappingMasterName.localeCompare(b.mappingMasterName)
    );
    setfilterData(result);
    setData(result);
  };

  const closeModalClick = () => {
    args?.onClose(false);
  };

  const filterDataOnSelection = () => {
    let filterData = data;
    if (nomination != "") {
      filterData = filterData.filter(
        (x: any) => x.nominationDefinitionName == nomination
      );
    }

    if (mappingType != "") {
      filterData = filterData.filter(
        (x: any) => x.mappingTypeName == mappingType
      );
    }

    if (outputValue != "") {
      filterData = filterData.filter(
        (x: any) => x.mappingOutputValue == outputValue
      );
    }

    if (applicableFrom != undefined) {
      filterData = filterData.filter(
        (x: any) =>
          (applicableFrom.isAfter(dayjs(x.mappingOutputStartDate)) ||
            applicableFrom.isSame(dayjs(x.mappingOutputStartDate))) &&
          applicableFrom.isBefore(x.mappingOutputEndDate)
      );
    }

    if (applicableTo != undefined) {
      filterData = filterData.filter(
        (x: any) =>
          applicableTo.isAfter(dayjs(x.mappingOutputEndDate)) ||
          applicableTo.isSame(dayjs(x.mappingOutputEndDate))
      );
    }

    setfilterData(filterData);
  };

  const columns = useMemo<ColumnDef<unknown, any>[]>(
    () => [
      {
        header: "Mapping Details",
        columns: [
          {
            id: "0",
            header: "Mapping Name",
            accessorKey: "mappingMasterName",
            meta: { enableRowSpan: true },
          },
          {
            id: "1",
            header: "Mapping Type",
            accessorKey: "mappingTypeName",
            meta: { enableRowSpan: true },
          },
          {
            id: "2",
            accessorKey: "nominationDefinitionName",
            header: "Nomination",
            meta: { enableRowSpan: true },
          },
        ],
      },

      {
        header: "Mapping Input",
        columns: [
          {
            id: "3",
            header: "Input Field",
            accessorKey: "mappingInputField",
          },
          {
            id: "4",
            header: "Input Value",
            accessorKey: "mappingInputValue",
          },
          {
            id: "5",
            header: "Valid From",
            accessorKey: "mappingInputStartDate",
            cell: (info) => {
              return dayjs(info.getValue()).format("D/M/YYYY");
            },
          },
          {
            id: "6",
            header: "Valid To",
            accessorKey: "mappingInputEndDate",
            cell: (info) => {
              return dayjs(info.getValue()).format("D/M/YYYY");
            },
          },
        ],
      },
      {
        header: "Mapping Output",
        columns: [
          {
            id: "7",
            header: "Output Value",
            accessorKey: "mappingOutputValue",
          },
          {
            id: "8",
            header: "Valid From",
            accessorKey: "mappingOutputStartDate",
            cell: (info) => {
              return dayjs(info.getValue()).format("D/M/YYYY");
            },
          },
          {
            id: "9",
            header: "Valid To",
            accessorKey: "mappingOutputEndDate",
            cell: (info) => {
              return dayjs(info.getValue()).format("D/M/YYYY");
            },
          },
        ],
      },
    ],
    []
  );
  // Render rows function to group rows based on data
  const renderRows = (rows: Row<any>[]) => {
    rows.map((row: any, i: number, rows) => {
      const topRow: any = rows[i - 1];
      for (let j = 0; j < row.getVisibleCells().length; j++) {
        let cell = row.getVisibleCells()[j];
        let cell2 = row.getVisibleCells()[1];
        let cell3 = row.getVisibleCells()[2];
        if (
          !cell.column.columnDef.meta?.enableRowSpan ||
          !topRow ||
          topRow?.getIsGrouped() ||
          row?.getIsGrouped()
        ) {
          cell.rowSpan = 1;
          cell.isRowSpanned = false;
          continue;
        }

        // Grouping logic for cells
        const getMergeTopCell = (ri: number, ci: number): any => {
          const topRow: any = rows[ri - 1];
          const cell: any = (rows[ri] as any).getVisibleCells()[ci];
          if (topRow != undefined) {
            const topCell: any = topRow?.getVisibleCells()[ci];
            const topCelll0: any = topRow?.getVisibleCells()[0];
            const topCelll1: any = topRow?.getVisibleCells()[1];
            const topCelll2: any = topRow?.getVisibleCells()[2];

            const celll0: any = (rows[ri] as any).getVisibleCells()[0];
            const celll1: any = (rows[ri] as any).getVisibleCells()[1];
            const celll2: any = (rows[ri] as any).getVisibleCells()[2];

            if (
              !(
                JSON.stringify(topCelll0.getValue()) ===
                  JSON.stringify(celll0.getValue()) &&
                JSON.stringify(topCelll1.getValue()) ===
                  JSON.stringify(celll1.getValue()) &&
                JSON.stringify(topCelll2.getValue()) ===
                  JSON.stringify(celll2.getValue())
              )
            )
              return cell;

            if (
              !topRow ||
              topRow.getIsGrouped() ||
              JSON.stringify(topCell.getValue()) !==
                JSON.stringify(cell.getValue())
            ) {
              return cell;
            } else {
              return getMergeTopCell(ri - 1, ci);
            }
          } else {
            return cell;
          }
        };

        let topCell = topRow.getVisibleCells()[j];
        let topCell2 = topRow.getVisibleCells()[1];
        let topCell3 = topRow.getVisibleCells()[2];

        if (
          JSON.stringify(topCell.getValue()) ===
            JSON.stringify(cell.getValue()) &&
          JSON.stringify(topCell2.getValue()) ===
            JSON.stringify(cell2.getValue()) &&
          JSON.stringify(topCell3.getValue()) ===
            JSON.stringify(cell3.getValue())
        ) {
          getMergeTopCell(i, j).rowSpan += 1;
          cell.isRowSpanned = true;
        } else {
          cell.rowSpan = 1;
          cell.isRowSpanned = false;
        }
      }

      return null;
    });

    return rows.map((row: any) => {
      return (
        <StyledTr key={row.id}>
          {row.getVisibleCells().map((cell: any) => {
            if (cell.isRowSpanned) return null;
            else {
              return (
                <StyledTd
                  key={cell.id}
                  rowSpan={cell.rowSpan}
                  style={cell.column.id == "3" ? { textAlign: "left" } : {}}
                >
                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                </StyledTd>
              );
            }
          })}
        </StyledTr>
      );
    });
  };

  const [columnOrder, setColumnOrder] = useState<String[]>(
    columns.map((column) => column.id as string)
  );
  const tableOptions = {
    state: {
      columnOrder,
    },
    onColumnOrderChange: setColumnOrder,
  };

  const table = useReactTable({
    data: filterData,
    columns,
    filterFns: {},
    state: {
      columnFilters,
    },
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
  });

  return (
    <>
      <StyledDivFilter>
        <Flexbox style={{ margin: "5px" }}>
          <StyledSelectDiv>
            <StyledLabel htmlFor="nomination">Nomination</StyledLabel>
            <Select
              id="nomination"
              options={filterOption?.nominations}
              optionFilterProp="label"
              onSelect={onSelectNomination}
              onClear={OnClearNomination}
              {...args}
            />
          </StyledSelectDiv>
          <StyledSelectDiv>
            <StyledLabel htmlFor="mappingType" style={{ margin: "9px" }}>
              Mapping Type
            </StyledLabel>
            <Select
              id="mappingType"
              options={filterOption?.mappingTypes}
              optionFilterProp="label"
              onSelect={onSelectMappingType}
              onClear={OnClearMappingType}
              {...args}
            />
          </StyledSelectDiv>
          <StyledSelectDiv>
            <StyledLabel htmlFor="outputValue">Output Value</StyledLabel>
            <Select
              id="outputValue"
              options={filterOption?.outputValues}
              optionFilterProp="label"
              onSelect={onSelectOuptutValue}
              onClear={OnClearOutputValue}
              {...args}
            />
          </StyledSelectDiv>
        </Flexbox>
        <Flexbox>
          <StyledDateDiv>
            <StyledLabel style={{ margin: "0px" }}>Applicable From</StyledLabel>
            <SingleDatePicker
              placeholder={"From"}
              onChange={onSelectFromDate}
            />
          </StyledDateDiv>
          <StyledDateDiv>
            <StyledLabel style={{ margin: "10px" }}>Applicable To</StyledLabel>
            <SingleDatePicker placeholder={"To"} onChange={onSelectToDate} />
          </StyledDateDiv>
        </Flexbox>
      </StyledDivFilter>

      <StyledDivChild>
        <StyledRawDiv>
          <StyledRawTradeDiv>
            <h2
              style={{
                fontSize: 16,
                padding: "0px 8px",
                textAlign: "left",
                lineHeight: "1px",
                fontWeight: 600,
              }}
            >
              Mapping Details
            </h2>
          </StyledRawTradeDiv>
        </StyledRawDiv>
        <StyledChildTableDiv>
          <StyledTable>
            <THead style={{ position: "sticky", top: "0px" }}>
              {table.getHeaderGroups().map((headerGroup) => (
                <StyledHeaderTR key={headerGroup.id}>
                  {headerGroup.headers.map((header) => {
                    return (
                      <StyledTh key={header.id} colSpan={header.colSpan}>
                        {header.isPlaceholder ? null : (
                          <>
                            {flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                          </>
                        )}
                      </StyledTh>
                    );
                  })}
                </StyledHeaderTR>
              ))}
            </THead>
            <TBody>
              {table.getRowModel()?.rows?.length > 0 ? (
                renderRows(table.getRowModel().rows)
              ) : (
                <StyledTR>
                  <StyledNoDataTd colSpan={10}>
                    No Mapping Details Found
                  </StyledNoDataTd>
                </StyledTR>
              )}
            </TBody>
          </StyledTable>
        </StyledChildTableDiv>
      </StyledDivChild>
    </>
  );
};
