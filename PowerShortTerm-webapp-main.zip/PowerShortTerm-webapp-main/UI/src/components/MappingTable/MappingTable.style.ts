import { Button, Filter, Flexbox, Label, Loading, TFoot, TH, TR } from '@sede-x/shell-ds-react-framework';
import styled from 'styled-components';

export const Thead = styled.table`
    backgroundColor: red;
    `

export const StyledFilter = styled(Filter)`
    background : white;`

export const StyledDiv = styled.div`
    margin: 5px 5px 5px;
    box-shadow: 0px 35px 50px rgba( 0, 0, 0, 0.2 );
    border: 1px solid ${(p) => p.theme.border.subtle};
    background: ${(p) => p.theme.background.surface};
    margin-top: 0px;
`
export const StyledRawDiv = styled.div`
    margin: 5px 5px 5px;
    //box-shadow: 0px 35px 50px rgba( 0, 0, 0, 0.2 );
    border: 1px solid ${(p) => p.theme.background.surface};
    background: ${(p) => p.theme.background.surface};
    margin-top: 0px;
`

export const StyledDivChild = styled.div`
    // margin: 10px 20px 20px;
    // box-shadow: 0px 35px 50px rgba( 0, 0, 0, 0.2 );
    // overflow: scroll;
    // position:fixed;
    // top:20%;
    // left:8%;
    // max-width:90rem;
    // max-height:40rem;
    background: ${(p) => p.theme.background.surface};

`

export const StyledDivFilter = styled.div`
    border: 1px solid ${(p) => p.theme.border.subtle};
    width: 98%;
    margin-left: 20px;
    margin-bottom: 5px;
    margin-right: 50px;
    margin-top: 3vh;
`

export const StyledTable = styled.table`
    border-radius: 5px;
    font-size: 0.65vw;
    font-weight: normal;
    border: none;
    border-collapse: collapse;
    width: 100%;
    max-width: 100%;
    white-space: nowrap;
    background-color: ${(p) => p.theme.background.surface};`

export const StyledLabel = styled(Label)`
    font-size: 0.65vw;
    font-weight: bold;
    width:20%;
    margin-top: 1vh;
`

export const StyledTh = styled(TH)`
    color: ${(p) => p.theme.text.onSurface.strong};
    background: ${(p) => p.theme.background.base};
    text-align: center;
    padding: 15px;
    border-left:1px solid ${(p) => p.theme.border.strong};

    &:nth-child(10){
    border-right:1px solid ${(p) => p.theme.border.strong};
    }
    &:nth-child(3){
    border-right:1px solid ${(p) => p.theme.border.strong};
    }

    &:before {
    top: -1px;
    border-top: 1px solid ${(p) => p.theme.border.subtle};
    content: '';
    position: absolute;
    left: 0;
    width: 100%;
    }

    &:after {
    bottom: -1px;
    //border-bottom: 2px solid ${(p) => p.theme.border.subtle};
    content: '';
    position: absolute;
    left: 0;
    width: 100%;
    }

    // position: sticky;
    // top: 0;
    //border: 1px solid ${(p) => p.theme.border.strong};
`

export const StyledTd = styled.td`
    &:nth-child(1){
    text-align: left;
    }
    border-right: 1px solid ${(p) => p.theme.background.base};
    font-size: 0.65vw;
    text-align: center;
    padding: 15px;
    border: 1px solid ${(p) => p.theme.border.strong};
`
export const StyledFootTd = styled.th`
    &:nth-child(1){
    text-align: left;
    }
    border-right: 1px solid ${(p) => p.theme.background.base};
    font-size: 0.65vw;
    text-align: center;
    padding: 0px;
    background-color: ${(p) => p.theme.background.base};
`

export const StyledFootTh= styled(TH)`
    &:nth-child(1){
    text-align: left;
    }
    border-right: 1px solid ${(p) => p.theme.background.base};
    font-size: 0.65vw;
    text-align: center;
    padding: 0px;
    background-color: ${(p) => p.theme.background.base};
`
export const StyledNoDataTd = styled.td`
    border: 1px solid ${(p) => p.theme.background.base};
    font-size: 0.65vw;
    text-align: center;
    padding: 15px;
`

export const StyledTr = styled.tr`
    &:nth-child(even) {
    background: ${(p) => p.theme.background.base};
}
    line-height:5px;
`

export const StyledTR = styled(TR)`
    &:nth-child(even) {
    background: ${(p) => p.theme.background.base};
}
    line-height:5px;
`


export const StyledHeaderTR = styled(TR)`
    line-height:5px;
    position: sticky;
    top:0px;
    border-bottom:0px!important;
`

export const StyledButtonClose = styled(Button)`
    // position: fixed;
    // left: 67%;
    float: right;
    background: rgb(232,232,232,0.1);,

`

export const StyledTableDiv= styled.div`
    margin: 20px;
    overflow: scroll;
    height: 43vh`

export const StyledSelectDiv= styled(Flexbox)`
    width: 30%;
    padding: 5px;
    `
export const StyledDateDiv= styled(Flexbox)`
    width: 29%;
    margin-left: 10px;
    margin-bottom: 10px;
    `
export const StyledRawTradeDiv= styled.div`
    width: 100%;
    textAlign: left;
    height: 20%;
    margin-left:10px;`

export const StyledChildTableDiv= styled.div`
    margin-left: 20px;
    overflow: scroll;
    height: 70vh;
    border-top: 1px solid ${(p) => p.theme.border.strong};
    `

export const StyledLoader = styled(Loading)`
    position: fixed;
    left: 50%;
    top: 50%;
    stroke: rgb(230,245,246);
`

export const StyledTFoot = styled(TFoot)`
    position: sticky; 
    bottom: 0;
    background: ${(p) => p.theme.background.base};
    text-align: center;`