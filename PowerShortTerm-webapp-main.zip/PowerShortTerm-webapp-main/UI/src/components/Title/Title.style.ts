import { Filter } from "@sede-x/shell-ds-react-framework";
import styled from "styled-components"

const StyledDiv = styled.div`
background:${(p) => p.theme.background.surface};
height:100vh;
`;
export {StyledDiv};