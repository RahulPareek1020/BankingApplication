import React, { useEffect, useState } from "react";
import { Icons, NavBar } from "@sede-x/shell-ds-react-framework";
import { useAuth } from "react-oidc-context";
import { filterRoles } from '../../Utilities/RoleUtils'
import { GlobalHeader } from "@sede-x/glass-design-library";
import { useLocation, useNavigate } from "react-router-dom";
import { ITheme, toggleActions } from "../../store/reducers";
import { useDispatch, useSelector } from "react-redux";

const Title = () => {
  const { user } = useAuth();
  const [userName, setUserName] = useState<string>();
  const [userRole, setUserRole] = useState<string>();
  const navigate = useNavigate();
  const { isDark } = useSelector((state: ITheme) => state);
  const { MoonSolid, SunSolid } = Icons;
  const dispatch = useDispatch();
  const location = useLocation();
  const args = {
    expandMode: "auto_push",
    header: {
      title: "Shell Nomination Engine : Counterparty Aggregation Positions View",
    },
    avatarProps: {
      label: userName,
      secondaryLabel: userRole,
    },
  };

    const handleThemeOnChange = (value: boolean) => {
      dispatch(
        toggleActions.updateTheme({
          isDark: value,
        })
      );
    };

  useEffect(() => {
    if (user?.access_token) {
      var roleInfo = filterRoles(user?.access_token);
      setUserName(roleInfo.name);
      setUserRole(roleInfo.role);
    }
  }, [user?.access_token]);

  return (
    <>
      <GlobalHeader tabs={[{
        key: 'Home',
        label: 'Nominations',
        action: ()=>{
          navigate('/');
        },
      },
      {
        key: 'map',
        label: 'Rules Mapping',
        action: ()=>{
          navigate('/mapping');
        },
      }
      ]} defaultTab= {location.pathname == '/'?'Home': 'map'} 
        subtitle = "Shell Nomination Engine" title="Counterparty Aggregation Positions View"
        avatar={{
          description: userRole,
          title: userName,
        }}
        hideGlassHub 
        icons={[
          {
            icon: isDark ? <SunSolid /> : <MoonSolid />,
            action: () => handleThemeOnChange(!isDark),
            label: true ? 'Light theme' : 'Dark theme',
          },
        ]} />
    </>
  );
};

export default Title;
