import React from 'react';
import { ShellThemeProvider } from '@sede-x/shell-ds-react-framework';
import CssBaseline from '@mui/material/CssBaseline';
import { AuthProvider } from 'react-oidc-context';
import { RootComponent } from './RootComponent';
import { Provider, useSelector } from 'react-redux';
import store from './store';
import { ITheme } from './store/reducers';

const onSigninCallback = (): void => {
  window.history.replaceState({}, document.title, window.location.pathname);
};

const oidcConfig = {
  authority: process.env.REACT_APP_AUTH_AUTHORITY || '',
  client_id: process.env.REACT_APP_AUTH_CLIENT_ID || '',
  redirect_uri: `${location.protocol}//${location.host}/`,
  onSigninCallback,
};



const App = () => {
  const { isDark } = useSelector((state: ITheme) => state);
  return (
    <ShellThemeProvider theme= {isDark ? 'dark' : 'light'}>
      <CssBaseline />
        <AuthProvider {...oidcConfig}>
          <RootComponent />
        </AuthProvider>
    </ShellThemeProvider>
  );
};

export default App;