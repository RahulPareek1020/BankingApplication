let BASE_URL : string=``
if(process.env.REACT_APP_POWERSHORTTERMAPIURL!=undefined)
{
    BASE_URL= process.env.REACT_APP_POWERSHORTTERMAPIURL ;
}
else
{
    BASE_URL=`https://shellnominationengine-dev-api.azurewebsites.net/api/PowertrakTrade`
}

export const CounterpartyAggPos = `${BASE_URL}/get-counterparty-agg-positions`
export const CounterpartyAgg = `${BASE_URL}/get-counterparty-aggregations`
export const MappingRuleDetails = `${BASE_URL}/get-mapping-rule-details`
export const NomStatus = `${BASE_URL}/get-nom-status`
export const NomTradeDetail = `${BASE_URL}/get-nom-trade-details`
export const NomDetail = `${BASE_URL}/get-nomination-details`
export const NomHeader = `${BASE_URL}/get-nomination-headers`
export const RunAligneBatch = `${BASE_URL}/run-aligne-batch-async`
export const SendNomPosToPowertrak = `${BASE_URL}/send-nom-positions-to-powertrak`
export const SendNomToPowertrak =`${BASE_URL}/send-nomination-to-powertrak`