import React, { useEffect } from 'react';
import { createBrowserRouter, RouterProvider, useNavigate } from 'react-router-dom';
import { Auth } from './Auth';
import AppRoute from './components/AppRoute';
import NominationHeaderComponent from './components/NominationHeader/NominationHeader';
import { MappingTable } from './components/MappingTable/MappingTable';

export const RootComponent: React.FC = () => {
  const router = createBrowserRouter([
    {
      element: <Auth />,
      children: [
        {
          path: "/",
          element: <AppRoute />,
          children: [
            {
              path: "",
              element: <NominationHeaderComponent />,
            },
            {
              path: "/mapping",
              element: <MappingTable />,
            }
          ],
        },
        {
          path: "/mapping",
          element: <AppRoute />,
          children: [
            {
              path: "",
              element: <MappingTable />,
            }
          ],
        }
      ],
    },
  ]);

  return (
    <RouterProvider router={router} />
  );
};