﻿namespace PowerShortTerm_API.Model
{
    using System.Xml.Serialization;

    [XmlRoot("results")]
    public class Results
    {
        [XmlElement("batch")]
        public string? Batch { get; set; }

        [XmlElement("msg")]
        public Message? Msg { get; set; }
    }

    public class Message
    {
        [XmlAttribute("type")]
        public string? Type { get; set; }

        [XmlText]
        public string? Text { get; set; }
    }
}
