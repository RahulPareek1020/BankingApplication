﻿using System.Xml.Linq;

namespace PowerShortTerm_API.Model
{
    public class GmslStatusResponseResult
    {
        public required XElement GmslStatusResponse { get; set; }
        public int NominationRunId { get; set; }
    }
}
