﻿using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Data.Repository;
using Shell.Energy.STPower.Shared.PowerTrak;
using Shell.Energy.STPower.Services.TradeTransformer.Interfaces;
using Shell.Energy.STPower.Services.TradeTransformer;

namespace PowerShortTerm_API.Modules
{
    /// <summary>
    /// DI class for adding core modules
    /// </summary>
    public static class STPowerCoreModule
    {
        public static IServiceCollection AddSTPowerCore(this IServiceCollection collection, IConfiguration configuration)
        {
            collection.AddScoped<ISqlDataRepository, SqlDataRepository>();
            collection.AddHttpClient();
            collection.AddSingleton<IDateTimeProvider, DateTimeProvider>();
            collection.AddScoped<IPowertrakTradeService, PowertrakTradeService>();
            collection.AddScoped<IApiService, ApiService>();
            collection.AddScoped<IPowerTrakSender, PowerTrakSender>();
            collection.AddScoped<IAppLogger, AppLogger>();
            collection.AddScoped<ITransformTradeDataService, TransformTradeDataService>();

            return collection;
        }
    }
}
