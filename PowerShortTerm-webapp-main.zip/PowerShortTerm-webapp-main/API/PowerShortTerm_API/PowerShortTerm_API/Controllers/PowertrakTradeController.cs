﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using OpenTelemetry;
using OpenTelemetry.Context.Propagation;
using PowerShortTerm_API.Model;
using Shell.Energy.STPower.Data.Dto;
using Shell.Energy.STPower.Data.Models;
using Shell.Energy.STPower.Services.TradeTransformer.Interfaces;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Messages;
using Shell.Energy.STPower.Shared.Model;
using Shell.Energy.STPower.Shared.PowerTrak;
using Shell.SNE.Common.OpenTelemetry;
using System.Diagnostics;
using System.Globalization;
using System.Net.Http.Headers;
using System.Xml.Serialization;
using Results = PowerShortTerm_API.Model.Results;

namespace PowerShortTerm_API.Controllers
{
    /// <summary>
    /// Controller for Powertrak Trade
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy = "SNEWithReadOnlyPolicy")]
    public class PowertrakTradeController : ControllerBase
    {
        private readonly IAppLogger _logger;
        private readonly IPowertrakTradeService _powertrakTradeService;
        private readonly ITransformTradeDataService _transformTradeDataService;
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _config;
        private readonly IDateTimeProvider _dateTimeProvider;
        private readonly string _vnetRunBatchAsyncApiUrl = "SNE-VnetRunBatchAsyncApiUrl";
        private readonly string[] validAligneBatchResponseMsgTypes = ["123", "199", "200"];
        private readonly int _batchErrStepId = 5;
        private readonly int _nomSentStepId = 4;
        private readonly int _nomSendingStepId = 6;
        private readonly int _nomNoTradesStepId = 7;
        private readonly string _batchErrStatus = "Aligne Error";
        private readonly string _noTradesFoundError = "No Trades Found";
        private readonly ITelemetryActivity _telemetryActivity;
        private readonly string _traceFlags = "1";
        private readonly string _telemetryActivityName = "ShellNominationEngine.SendNomination";
        private readonly string _callAligneActivityName = "Calling Aligne Batch";
        private readonly string _aggCptyPosActivityName = "Aggregating Counterparty Positions";
        private readonly string _sendNomActivityName = "Sending Nomination to Powertrak";
        public PowertrakTradeController(
            IAppLogger logger,
            IPowertrakTradeService powertrakTradeSvc,
            ITransformTradeDataService transformTradeDataSvc,
            IConfiguration config,
            HttpClient httpClient,
            IDateTimeProvider dateTimeProvider,
            ITelemetryActivity telemetryActivity)
        {
            _powertrakTradeService = powertrakTradeSvc;
            _logger = logger;
            _config = config;
            _transformTradeDataService = transformTradeDataSvc;
            _dateTimeProvider = dateTimeProvider;
            _httpClient = httpClient;
            _telemetryActivity = telemetryActivity;
        }

        /// <summary>
        /// API to fetch nomination headers.
        /// </summary>
        /// <returns>A list of nomination headers.</returns>
        /// <response code="200">Returns the list of nomination headers.</response>
        /// <response code="500">If an error occurs while fetching the nomination headers.</response>
        /// <response code="403">If an user is not authorized to access the method.</response>
        [HttpGet("get-nomination-headers", Name = "get-nomination-headers")]
        public async Task<ActionResult<IEnumerable<NominationHeader>>> GetNominationHeaders()
        {
            _logger.LogInformation("Started fetching nomination headers.");

            try
            {
                var data = await _powertrakTradeService.GetNominationHeaderData();
                _logger.LogInformation("Successfully fetched nomination headers.");
                return Ok(data);
            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred while fetching nomination headers: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// API to fetch nomination details by runid.
        /// </summary>
        /// <param name="nominationRunId">run id of the nomination.</param>
        /// <returns>A list of nomination details.</returns>
        /// <response code="200">Returns the list of nomination details.</response>
        /// <response code="400">If the input parameters are invalid.</response>
        /// <response code="500">If an error occurs while fetching the nomination details.</response>
        /// <response code="403">If an user is not authorized to access the method.</response>
        [HttpGet("get-nomination-details", Name = "get-nomination-details")]
        public async Task<ActionResult<IEnumerable<NominationDetailsDto>>> GetNominationDetails([FromQuery] int? nominationRunId)
        {
            try
            {
                if (!nominationRunId.HasValue)
                {
                    return StatusCode(StatusCodes.Status400BadRequest, ResponseMessages.InvalidInputParameters);
                }
                _logger.LogInformation($"Started fetching nomination details for RunId: {nominationRunId}");

                var data = await _powertrakTradeService.GetNominationDetailsByRunIdAsync(nominationRunId.Value);
                _logger.LogInformation($"Successfully fetched nomination details for RunId: {nominationRunId}");
                return Ok(data);
            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred while fetching nomination details for RunId: {nominationRunId}: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// API to fetch nomination details by runid.
        /// </summary>
        /// <param name="aggPosRefId">run id of the nomination.</param>
        /// <returns>A list of nomination details.</returns>
        /// <response code="200">Returns the list of nomination details.</response>
        /// <response code="400">If the input parameters are invalid.</response>
        /// <response code="500">If an error occurs while fetching the nomination details.</response>
        /// <response code="403">If an user is not authorized to access the method.</response>
        [HttpGet("get-nom-trade-details", Name = "get-nom-trade-details")]
        public async Task<ActionResult<IEnumerable<RawTradeDto>>> GetNominationTradeDetails(int? aggPosRefId = null, int? nominationRunId = null)
        {
            try
            {
                IEnumerable<RawTradeDto> data;
                if (!aggPosRefId.HasValue && !nominationRunId.HasValue)
                {
                    return StatusCode(StatusCodes.Status400BadRequest, ResponseMessages.InvalidInputParameters);
                }
                _logger.LogInformation($"Started fetching raw trades");

                data = await _powertrakTradeService.GetRawTradesByAggPosOrRunIdAsync(aggPosRefId, nominationRunId);
                var rawTrades = TradeHelper.GetTradeDataBasedOnTimeZoneRawTrade(data, data.Max(x => x.NomDeliveryDate));
                _logger.LogInformation($"Successfully fetched raw trades");
                return Ok(rawTrades);
            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred while fetching raw trades: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// API to fetch mapping rule details.
        /// </summary>
        /// <returns>A list of mapping rule details.</returns>
        /// <response code="200">Returns the list of mapping rule details.</response>
        /// <response code="500">If an error occurs while fetching the mapping rule details.</response>
        /// <response code="403">If an user is not authorized to access the method.</response>
        [HttpGet("get-mapping-rule-details", Name = "get-mapping-rule-details")]
        public async Task<ActionResult<IEnumerable<MappingRuleDetailsDto>>> GetMappingRuleDetails()
        {
            _logger.LogInformation("Started fetching mapping rule details.");

            try
            {
                var data = await _powertrakTradeService.GetMappingRuleDetails();
                _logger.LogInformation("Successfully fetched mapping rule details.");
                return Ok(data);
            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred while fetching mapping rule details: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// API to fetch nomination run status based on NomRunId.
        /// </summary>
        /// <param name="nominationRunId"></param>
        /// <returns></returns>
        /// <response code="403">If an user is not authorized to access the method.</response>
        [HttpGet("get-nom-status", Name = "get-nom-status")]
        public async Task<ActionResult<string>> GetNominationStatus(int? nominationRunId = null)
        {
            string? nominationStatus = string.Empty;
            try
            {
                if (!nominationRunId.HasValue)
                {
                    return StatusCode(StatusCodes.Status400BadRequest, ResponseMessages.InvalidInputParameters);
                }
                _logger.LogInformation($"Started fetching nomination run status for nomination run id: {nominationRunId.Value}");

                var statusData = await _powertrakTradeService.GetNominationStatusByRunIdAsync(nominationRunId);
                nominationStatus = statusData?.ProcessStep;
                if (string.IsNullOrEmpty(nominationStatus))
                {
                    _logger.LogError($"No data found for nomination run id: {nominationRunId.Value}");
                    return StatusCode(StatusCodes.Status400BadRequest, ResponseMessages.NoDataFoundForNomRun);
                }
                _logger.LogInformation($"Successfully fetched nomination run status for nomination run id: {nominationRunId.Value}");
                return Ok(nominationStatus);
            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred while fetching nomination run status for nomination run id: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// API to apply filters and return aggregated counterparty positions based on NomRunId.
        /// </summary>
        /// <param name="nominationRunId"></param>
        /// <returns></returns>
        /// <response code="403">If an user is not authorized to access the method.</response>
        [HttpGet("get-counterparty-agg-positions", Name = "get-counterparty-agg-positions")]
        public async Task<ActionResult<IEnumerable<NominationDetailsDto>>> GetCounterpartyAggPositions([FromQuery] int? nominationRunId)
        {
            if (!nominationRunId.HasValue)
            {
                return StatusCode(StatusCodes.Status400BadRequest, ResponseMessages.InvalidInputParameters);
            }
            _logger.LogInformation($"Started fetching aggregated counterparty positions for NomRunId: {nominationRunId}");

            try
            {
                var data = await _powertrakTradeService.GetAggregatedCptyPositionsByRunIdWithFilters(nominationRunId.Value);
                if (data.Any() && data is IEnumerable<NominationDetailsDto> cptyAggPositionData)
                {
                    var nomStatusData = await _powertrakTradeService.GetNominationStatusByRunIdAsync(nominationRunId.Value);
                    var deliveryDate = nomStatusData.DeliveryDate;
                    if (deliveryDate == null)
                    {
                        return (await HandleNoTradesFound(nominationRunId.Value));
                    }

                    var tradeData = TradeHelper.GetTradeDataBasedOnTimeZone(cptyAggPositionData, deliveryDate.Value);
                    //Fetch trades from previous run id
                    var previousTrades = await _powertrakTradeService.GetPreviousAggregationPositions(tradeData, nominationRunId);
                    if (previousTrades.Any())
                    {
                        tradeData = tradeData.Concat(previousTrades).ToList();
                    }

                    if (!tradeData.Any())
                    {
                        await _powertrakTradeService.UpdateNominationBatchRunStatusAsync(nominationRunId.Value, _nomNoTradesStepId, _noTradesFoundError, "", _dateTimeProvider.Now, _dateTimeProvider.Now);
                        _logger.LogError(ResponseMessages.MissingData);
                        return StatusCode(StatusCodes.Status400BadRequest, ResponseMessages.MissingData);
                    }
                    _logger.LogInformation($"Successfully fetched aggregated counterparty positions for NomRunId: {nominationRunId}");
                    return Ok(tradeData);

                }
                else
                {
                    return (await HandleNoTradesFound(nominationRunId.Value));
                }
            }
            catch (TimeZoneNotFoundException)
            {
                return StatusCode(StatusCodes.Status400BadRequest, ResponseMessages.InvalidTimezone);
            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred while fetching aggregated counterparty positions for NomRunId: {nominationRunId}: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// API to save the nomination and send to powertrak based on NomRunId.
        /// </summary>
        /// <param name="nominationRunId"></param>
        /// <returns>GMSL API response/returns>
        /// <response code="403">If a user is not authorized to access the method.</response>
        [HttpGet("send-nom-positions-to-powertrak", Name = "send-nom-positions-to-powertrak")]
        [Authorize(Policy = "SNERolesPolicy")]
        public async Task<ActionResult<IEnumerable<string>>> SendNomPositionsToPowertrak(int? nominationRunId)
        {
            if (!nominationRunId.HasValue)
            {
                return StatusCode(StatusCodes.Status400BadRequest, ResponseMessages.InvalidInputParameters);
            }
            _logger.LogInformation($"Started sending nomination to powertrak for NomRunId: {nominationRunId}");

            try
            {
                var subActivity = await CreateConsumerActivityContext(nominationRunId.Value, _aggCptyPosActivityName);
                var data = await GetCounterpartyAggPositions(nominationRunId);
                if (data.Result is ObjectResult result && result.StatusCode == StatusCodes.Status400BadRequest)
                {
                    HandleNoDataFound(subActivity);
                    return StatusCode(StatusCodes.Status400BadRequest, result.Value);
                }
                if (data.Result is OkObjectResult okResult && okResult.Value is IEnumerable<NominationDetailsDto> cptyAggPositionData)
                {
                    if (cptyAggPositionData.Any())
                    {
                        HandleSuccessfulAggregation(subActivity, nominationRunId);
                        var processResult = await ProcessSaveAndSendNominations(nominationRunId.Value, cptyAggPositionData);
                        return Ok(processResult);
                    }
                    HandleNoDataFound(subActivity);
                    return StatusCode(StatusCodes.Status400BadRequest, ResponseMessages.NoDataFound);
                }
                else
                {
                    if (subActivity)
                    {
                        StopTelemetry();
                    }
                    _logger.LogError("Failed to retrieve valid data from GetCounterpartyAggregations.");
                    return StatusCode(StatusCodes.Status500InternalServerError, ResponseMessages.InternalError);
                }
            }
            catch (Exception ex)
            {
                if (IsConfigError(ex))
                {
                    await _powertrakTradeService.UpdateNominationBatchRunStatusAsync(nominationRunId.Value, _nomSendingStepId, "Failed", "Config Error", _dateTimeProvider.Now, _dateTimeProvider.Now);
                }
                StopTelemetry();
                _logger.LogError($"{LogMessages.SendNominationError} for NomRunId: {nominationRunId}: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Method to save the nomination data and send to powertrak.
        /// </summary>
        /// <param name="nominationRunId"></param>
        /// <param name="cptyAggPositionData"></param>
        /// <returns></returns>
        /// <response code="403">If an user is not authorized to access the method.</response>
        private async Task<string> ProcessSaveAndSendNominations(int nominationRunId, IEnumerable<NominationDetailsDto> cptyAggPositionData)
        {
            await _powertrakTradeService.SaveNominationPositionsInDB(cptyAggPositionData);
            var powertrakXmlRequestMessage = _transformTradeDataService.ConvertTradeMessageToPowerTrakFormat(cptyAggPositionData);

            if (string.IsNullOrEmpty(powertrakXmlRequestMessage))
            {
                throw new InvalidDataException("Powertrak XML request message cannot be null or empty.");
            }

            await _powertrakTradeService.UpdateNominationBatchRunStatusAsync(nominationRunId, _nomSendingStepId, "Started", "", _dateTimeProvider.Now, null);
            await CreateConsumerActivityContext(nominationRunId, _sendNomActivityName);

            //Get the environment from the DB for the particular NominationRunId
            var powerTrakEnvironment = await _powertrakTradeService.GetPowerTrakEnv(nominationRunId);
            if (string.IsNullOrEmpty(powerTrakEnvironment))
            {
                throw new InvalidDataException($"Environment is null for the NomRunId: {nominationRunId}.");
            }

            //Get the powertrak configurations based on the environment fetched from DB
            var powertrakConfig = GetPowerTrakConfig(powerTrakEnvironment);
            if (powertrakConfig is null)
            {
                throw new InvalidDataException($"PowertrakConfig is null or empty for the Env: {powerTrakEnvironment} ");
            }

            var powertrakApiResponse = await _powertrakTradeService.SendNominationToPowertrak(powertrakXmlRequestMessage, powertrakConfig);
            _logger.LogInformation($"Successfully sent nomination to powertrak for NomRunId: {nominationRunId}");
            await _powertrakTradeService.UpdateNominationBatchRunResponse(powertrakApiResponse, nominationRunId);
            var powertrakApiResponseString = JsonConvert.SerializeObject(powertrakApiResponse);
            var statusMessage = GetStatusMessage(powertrakApiResponseString);

            if (!_telemetryActivity.IsStopped)
            {
                _telemetryActivity.AddEvent($"Nomination sent to powertrak: {statusMessage} for NominationRunId: {nominationRunId}");
                _telemetryActivity.StopActivity();
            }

            await _powertrakTradeService.UpdateNominationBatchRunStatusAsync(nominationRunId, _nomSentStepId, statusMessage, "", null, _dateTimeProvider.Now);
            return powertrakApiResponseString;
        }

        private static string GetStatusMessage(string powertrakApiResponseString)
        {
            if (powertrakApiResponseString.Contains("Invalid", StringComparison.OrdinalIgnoreCase))
            {
                return "Rejected";
            }
            else if (powertrakApiResponseString.Contains("CorrelationId", StringComparison.OrdinalIgnoreCase) &&
                     !powertrakApiResponseString.Contains("Errors", StringComparison.OrdinalIgnoreCase))
            {
                return "Accepted";
            }
            else
            {
                return "Partially accepted";
            }
        }

        private static bool IsConfigError(Exception ex)
        {
            string[] errorMessages = { "BadRequest", "NotFound" };
            return (ex is InvalidDataException) || (ex is HttpRequestException) || errorMessages.Any(substring => errorMessages.Contains(substring));
        }

        private void StopTelemetry()
        {
            if (!_telemetryActivity.IsStopped)
            {
                _telemetryActivity.AddEvent(LogMessages.SendNominationError);
                _telemetryActivity.StopActivity();
            }
        }
        private async Task ProcessAligneBatchResponse(string aligneBatchResponse, int nominationRunId)
        {
            var serializer = new XmlSerializer(typeof(Results));
            if (aligneBatchResponse == null)
            {
                await _powertrakTradeService.UpdateNominationBatchRunStatusAsync(nominationRunId, _batchErrStepId,
                    _batchErrStatus, "Null response", _dateTimeProvider.Now, _dateTimeProvider.Now);
                return;
            }

            using var reader = new StringReader(aligneBatchResponse);
            var results = serializer.Deserialize(reader) as Results;
            if (results == null)
            {
                await _powertrakTradeService.UpdateNominationBatchRunStatusAsync(nominationRunId, _batchErrStepId,
                    _batchErrStatus, "Null response", _dateTimeProvider.Now, _dateTimeProvider.Now);
                return;
            }

            var msgType = results.Msg?.Type;
            var msgText = results.Msg?.Text;
            if (string.IsNullOrEmpty(msgType) || string.IsNullOrEmpty(msgText))
            {
                await _powertrakTradeService.UpdateNominationBatchRunStatusAsync(nominationRunId, _batchErrStepId,
                    _batchErrStatus, "Null response", _dateTimeProvider.Now, _dateTimeProvider.Now);
                return;
            }
            if (!Array.Exists(validAligneBatchResponseMsgTypes, type => string.Equals(type, msgType, StringComparison.OrdinalIgnoreCase)))
            {
                await _powertrakTradeService.UpdateNominationBatchRunStatusAsync(nominationRunId, _batchErrStepId,
                    _batchErrStatus, $"{msgText} ({msgType})", _dateTimeProvider.Now, _dateTimeProvider.Now);
            }
        }

        /// <summary>
        /// API to fetch nominations in ready status.
        /// </summary>
        /// <returns>A list of nomination run ids in ready status.</returns>
        /// <response code="200">Returns the list of nomination run ids in ready status.</response>
        /// <response code="500">If an error occurs while fetching the nomination run ids in ready status.</response>
        /// <response code="403">If an user is not authorized to access the method.</response>
        [HttpGet("get-ready-nominations", Name = "get-ready-nominations")]
        public async Task<ActionResult<NominationReady>> GetReadyNominations()
        {
            _logger.LogInformation("Started fetching nominations in ready status.");

            try
            {
                var data = await _powertrakTradeService.GetReadyNominations();
                _logger.LogInformation("Successfully fetched nominations in ready status.");
                if (data != null && data.NominationRunIDs != null && data.NominationRunIDs.Any())
                {
                    return Ok(data);
                }
                else
                {
                    return NotFound("No nominations found in ready status.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred while fetching nominations in ready status: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// API to run aligne batch asynchronously by calling VNet aligne batch run API.
        /// </summary>
        /// <param name="nominationDefinitionId"></param>
        /// <param name="deliveryDate"></param>
        /// <returns></returns>
        /// <response code="403">If an user is not authorized to access the method.</response>
        [Authorize(Policy = "SNERolesPolicy")]
        [HttpGet("run-aligne-batch-async", Name = "run-aligne-batch-async")]
        public async Task<ActionResult<AligneBatchApiResponseModel>> RunAligneBatchAsync(
            [FromQuery] int? nominationDefinitionId,
            [FromQuery] DateTime? deliveryDate,
            [FromQuery] bool? isAuto = true,
            [FromHeader] AuthorizationHeaderModel? authorizationHeaderModel = null)
        {
            var authorizationHeader = authorizationHeaderModel?.Authorization;
            if (string.IsNullOrEmpty(authorizationHeader))
            {
                _logger.LogError(ResponseMessages.AuthorizationHeaderNotPresent);
                return StatusCode(StatusCodes.Status400BadRequest, ResponseMessages.AuthorizationHeaderNotPresent);
            }

            if (!nominationDefinitionId.HasValue || !deliveryDate.HasValue)
            {
                return StatusCode(StatusCodes.Status400BadRequest, ResponseMessages.InvalidInputParameters);
            }
            _logger.LogInformation($"Started getting configurations for nominationDefinitionId: {nominationDefinitionId} and DeliveryDate: {deliveryDate}");
            try
            {
                string initiatedBy = string.Empty;

                initiatedBy = User.Identity?.Name ?? initiatedBy;
                var marketOperator = await _powertrakTradeService.GetMarketOperators(nominationDefinitionId.Value);
                var tradeTypes = await _powertrakTradeService.GetTradeTypes(nominationDefinitionId.Value, deliveryDate.Value);
                if (string.IsNullOrEmpty(marketOperator))
                {
                    _logger.LogError($"{ResponseMessages.NoMarketConfigFoundForNomDef} for NomDefId: {nominationDefinitionId}");
                    return StatusCode(StatusCodes.Status404NotFound, ResponseMessages.NoMarketConfigFoundForNomDef);
                }
                // Call VNet aligne batch run API
                string? url = !string.IsNullOrEmpty(_config[_vnetRunBatchAsyncApiUrl]) ? _config[_vnetRunBatchAsyncApiUrl] : "";
                if (string.IsNullOrEmpty(url))
                {
                    _logger.LogError(ResponseMessages.VnetAPIUrlNotConfigured);
                    return StatusCode(StatusCodes.Status404NotFound, ResponseMessages.VnetAPIUrlNotConfigured);
                }

                var nominationRunId = await _powertrakTradeService.InsertNominationBatchRun(nominationDefinitionId.Value, deliveryDate.Value, initiatedBy, isAuto);
                if (nominationRunId.HasValue && nominationRunId.Value < 0)
                {
                    _logger.LogError($"{ResponseMessages.NoConfigFoundForNomDef} for NomDefId: {nominationDefinitionId}");
                    return StatusCode(StatusCodes.Status404NotFound, ResponseMessages.NoConfigFoundForNomDef);
                }

                // Create the request model
                var requestModel = TradeHelper.GetAligneBatchRequestModel(deliveryDate, marketOperator, tradeTypes, nominationRunId.Value, isAuto);
                await CreateOtelActivity(nominationRunId.Value);


                var content = new StringContent(JsonConvert.SerializeObject(requestModel), System.Text.Encoding.UTF8, "application/json");
                var apiRequestTimeoutInSec = Convert.ToDouble(_config["ApiRequestTimeoutInSec"], CultureInfo.InvariantCulture);
                var token = authorizationHeader.Split(" ")[authorizationHeader.Split(" ").Length - 1];

                _httpClient.Timeout = TimeSpan.FromSeconds(apiRequestTimeoutInSec);
                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);


                var response = await _httpClient.PostAsync(new Uri(url), content);
                var aligneBatchResponse = await response.Content.ReadAsStringAsync();

                if (!_telemetryActivity.IsStopped)
                {
                    _telemetryActivity.AddEvent($"Response from aligne batch for NominationRunId {nominationRunId.Value}: {aligneBatchResponse}");
                    _telemetryActivity.StopActivity();
                }

                await ProcessAligneBatchResponse(aligneBatchResponse, nominationRunId.Value);

                _logger.LogInformation($"Response from aligne batch:{aligneBatchResponse}");
                return Ok(new AligneBatchApiResponseModel { NominationRunId = nominationRunId.Value, AligneBatchResponse = aligneBatchResponse });
            }
            catch (TimeZoneNotFoundException ex)
            {
                _logger.LogError($"An error occurred while running aligne batch for " +
                    $"NomDefId: {nominationDefinitionId} and DeliveryDate: {deliveryDate}: {ex.Message}");
                if (!_telemetryActivity.IsStopped)
                {
                    _telemetryActivity.AddEvent($"Invalid timezone configured");
                    _telemetryActivity.StopActivity();
                }
                return StatusCode(StatusCodes.Status400BadRequest, ResponseMessages.InvalidTimezone);
            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred while running aligne batch for " +
                    $"NomDefId: {nominationDefinitionId} and DeliveryDate: {deliveryDate}: {ex.Message}");
                if (!_telemetryActivity.IsStopped)
                {
                    _telemetryActivity.AddEvent($"An error occurred while running aligne batch");
                    _telemetryActivity.StopActivity();
                }
                throw;
            }
        }


        /// <summary>
        /// API to update powertrak status.
        /// </summary>
        /// <returns></returns>
        [HttpGet("update-powertrak-status", Name = "update-powertrak-status")]
        [Authorize(Policy = "SNERolesPolicy")]
        public async Task<ActionResult<string>> UpdatePowertrakStatus()
        {
            try
            {
                _logger.LogInformation("Started fetching correlationids.");
                var correlationIds = await _powertrakTradeService.GetCorrelationIds();
                _logger.LogInformation("Successfully fetched correlationids.");

                if (correlationIds == null || correlationIds.Count == 0)
                {
                    return NotFound("No correlationids found.");
                }

                var nominationRunIds = string.Join(", ", correlationIds.Select(c => c.NominationRunId));
                _logger.LogInformation($"Fetching powertrak status report for Nomination Run IDs: {nominationRunIds}");

                var gmslStatusResponses = await FetchGmslStatusResponsesAsync(correlationIds);
                var tradeStatuses = ExtractTradeStatuses(gmslStatusResponses);

                if (tradeStatuses.Count == 0)
                {
                    return NotFound("No correlationids found.");
                }

                _powertrakTradeService.UpdatePowertrakTradeStatuses(tradeStatuses);
                
                return Ok(nominationRunIds);
            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred while fetching correlationids: {ex.Message}");
                throw;
            }
        }

        private async Task<IEnumerable<GmslStatusResponseResult>> FetchGmslStatusResponsesAsync(IEnumerable<NominationCorrelationId> correlationIds)
        {
            var tasks = correlationIds.Select(async correlationId =>
            {
                var powertrakConfig = GetPowerTrakConfig(correlationId.PowertrakEnv);
                if (powertrakConfig is null)
                {
                    _logger.LogError($"PowertrakConfig is null or empty for the Env: {correlationId.PowertrakEnv} for runId: {correlationId.NominationRunId}");
                    return null;
                }
                var gmslStatusResponse = await _powertrakTradeService.GetPowertrakStatusReport(powertrakConfig, correlationId.CorrelationId);
                return new GmslStatusResponseResult
                {
                    GmslStatusResponse = gmslStatusResponse,
                    NominationRunId = correlationId.NominationRunId
                };
            }).ToList();

            return (await Task.WhenAll(tasks)).Where(r => r != null).ToList();
        }

        private List<TradeStatusDto> ExtractTradeStatuses(IEnumerable<GmslStatusResponseResult> gmslStatusResponses)
        {
            var tradeStatuses = new List<TradeStatusDto>();

            Parallel.ForEach(gmslStatusResponses, response =>
            {
                var statuses = PowertrakHelper.GetTradeStatuses(JsonConvert.SerializeObject(response.GmslStatusResponse));
                foreach (var status in statuses)
                {
                    if (response.NominationRunId != 0)
                    {
                        status.NominationRunId = response.NominationRunId;
                    }
                    else
                    {
                        _logger.LogError("NominationRunId is null in the response.");
                    }
                    lock (tradeStatuses)
                    {
                        tradeStatuses.Add(status);
                    }
                }
            });

            return tradeStatuses;
        }

        /// <summary>
        /// Create Otel Activity
        /// </summary>
        /// <param name="nominationRunId"></param>
        private async Task CreateOtelActivity(int nominationRunId)
        {
            _telemetryActivity.StartProducerActivity($"{_telemetryActivityName}-{nominationRunId}");

            var traceId = _telemetryActivity.Context.TraceId.ToString();
            var spanId = _telemetryActivity.Context.SpanId.ToString();
            await _powertrakTradeService.InsertNominationRunOtel(nominationRunId, traceId, spanId);

            _telemetryActivity.StopActivity();

            var subActivity = await CreateConsumerActivityContext(nominationRunId, _callAligneActivityName);
            if (subActivity)
            {
                _telemetryActivity.AddEvent($"Triggered aligne batch for NominationRunId:{nominationRunId}");
            }
        }

        /// <summary>
        /// Create Consumer Activity Context based on NominationRunId
        /// </summary>
        /// <param name="nominationRunId"></param>
        /// <param name="activityName"></param>
        /// <returns></returns>
        private async Task<bool> CreateConsumerActivityContext(int nominationRunId, string activityName)
        {
            var nominationRunOtelIds = await _powertrakTradeService.GetNominationRunTraceSpanId(nominationRunId);
            if (nominationRunOtelIds == null)
            {
                return false;
            }
            var isNominationRunOtelIdsNull = string.IsNullOrEmpty(nominationRunOtelIds.SpanId) || string.IsNullOrEmpty(nominationRunOtelIds.TraceId);
            if (isNominationRunOtelIdsNull)
            {
                return false;
            }

            var parentContext = new ActivityContext(
                traceId: ActivityTraceId.CreateFromString(nominationRunOtelIds.TraceId),
                spanId: ActivitySpanId.CreateFromString(nominationRunOtelIds.SpanId),
                (ActivityTraceFlags)Enum.Parse(typeof(ActivityTraceFlags), _traceFlags)
            );

            var propagationContext = new PropagationContext(parentContext, Baggage.Current);
            _telemetryActivity.StartConsumerActivity(activityName, propagationContext, ActivityKind.Consumer);
            return true;
        }

        private void HandleNoDataFound(bool subActivity)
        {
            if (!_telemetryActivity.IsStopped && subActivity)
            {
                _telemetryActivity.AddEvent(ResponseMessages.NoDataFound);
                _telemetryActivity.StopActivity();
            }
            _logger.LogError(ResponseMessages.NoDataFound);
        }

        private void HandleSuccessfulAggregation(bool subActivity, int? nominationRunId)
        {
            if (!_telemetryActivity.IsStopped && subActivity)
            {
                _telemetryActivity.AddEvent($"Successfully aggregated counterparty positions for NominationRunId: {nominationRunId}");
                _telemetryActivity.StopActivity();
            }
        }

        private PowerTrakConfig? GetPowerTrakConfig(string env)
        {
            var confEnv = $"PowerTrakConfiguration-{env}";
            var configurationSection = _config.GetChildren().FirstOrDefault(x => x.Key == confEnv);

            if (configurationSection != null)
            {
                return new PowerTrakConfig
                {
                    BaseUrl = new Uri(configurationSection["BaseUrl"]!),
                    AuthenticationUrlPath = configurationSection["AuthenticationUrlPath"],
                    Role = configurationSection["Role"],
                    Password = configurationSection["Password"],
                    StatusReportUrlPath = configurationSection["StatusReportUrlPath"],
                    SubmitPowerTradesUrlPath = configurationSection["SubmitPowerTradesUrlPath"],
                    Username = configurationSection["Username"]
                };
            }

            return null;
        }

        /// <summary>
        /// Handle No Trades Found
        /// </summary>
        /// <param name="nominationRunId"></param>
        /// <returns></returns>
        private async Task<ActionResult> HandleNoTradesFound(int nominationRunId)
        {
            await _powertrakTradeService.UpdateNominationBatchRunStatusAsync(nominationRunId, _nomNoTradesStepId, _noTradesFoundError, "", _dateTimeProvider.Now, _dateTimeProvider.Now);
            _logger.LogError(ResponseMessages.NoDataFound);
            return StatusCode(StatusCodes.Status400BadRequest, ResponseMessages.NoDataFound);
        }
    }
}