using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using OpenTelemetry;
using OpenTelemetry.Exporter;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using PowerShortTerm_API.Controllers;
using PowerShortTerm_API.Modules;
using Shell.Energy.STPower.Shared.Middlewares;
using Shell.Energy.STPower.Shared.Modules;
using Shell.Energy.STPower.Shared.PowerTrak;
using Shell.SNE.Common.OpenTelemetry;
using Shell.Stratos.DotNet.SDK.KeyVault;
using Swashbuckle.AspNetCore.SwaggerUI;

const string otlpClientName = "SNE_OtlpClient";
const string serviceName = "ShellNominationEngine.SendNomination";

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
var allowedOrigins = builder.Configuration.GetSection("AllowedOrigins").Get<string[]>();
var env = builder.Configuration.GetSection("STPowerEnv")?.Value;
builder.Configuration.AddKeyVault<Program>(env);
builder.Services.AddControllers();
builder.Services.AddSTPowerCore(builder.Configuration);
builder.Services.AddStratosKeyVault();
builder.Services.ConfigureOpenTelemetryDependencies(builder.Configuration, serviceName, otlpClientName);

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.Http,
        Scheme = "Bearer",
        Description = "Enter your Bearer token here"
    });

    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new List<string>()
        }
    });
});
builder.Services.AddApplicationInsightsTelemetry();

builder.Services.Configure<LoggerFilterOptions>(options =>
{
    LoggerFilterRule? toRemove = options.Rules?.FirstOrDefault(rule => rule.ProviderName
    == "Microsoft.Extensions.Logging.ApplicationInsights.ApplicationInsightsLoggerProvider");

    if (toRemove is not null)
    {
        options.Rules?.Remove(toRemove);
    }
});

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSpecificOrigins",
        policy =>
        {
            if (allowedOrigins != null && allowedOrigins.Length > 0)
            {
                policy.WithOrigins(allowedOrigins)
                      .AllowAnyMethod()
                      .AllowAnyHeader();
            }
            else
            {
                throw new InvalidOperationException("Allowed origins cannot be null or empty.");
            }
        });
});

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
        };
    });

var sneRoles = builder.Configuration.GetSection("SNERoles")?.Value;
var sneReadonlyRoles = builder.Configuration.GetSection("SNEReadOnlyRoles")?.Value;

builder.Services.AddAuthorizationBuilder()
    .AddPolicy("SNERolesPolicy", policy =>
    {
        if (!string.IsNullOrEmpty(sneRoles))
        {
            var roles = sneRoles.ToUpperInvariant().Split(",").ToList();
            policy.RequireAssertion(context => CheckRoles(context, roles));
        }
    })
    .AddPolicy("SNEWithReadOnlyPolicy", policy =>
    {
        if (!string.IsNullOrEmpty(sneRoles) && !string.IsNullOrEmpty(sneReadonlyRoles))
        {
            var roles = $"{sneRoles},{sneReadonlyRoles}".ToUpperInvariant().Split(",").ToList();
            policy.RequireAssertion(context => CheckRoles(context, roles));
        }
    });

static bool CheckRoles(AuthorizationHandlerContext context, List<string> roles)
{
    var userRoles = context.User.Claims.Where(c => c.Type == ClaimTypes.Role).Select(c => c.Value).FirstOrDefault();

    return userRoles != null && roles.Exists(role => roles.Contains(userRoles.ToUpperInvariant()));
}

var app = builder.Build();

var serviceProvider = app.Services;
var openTelemetrySettings = serviceProvider.GetService<OpenTelemetrySettings>();
var otelCustomAttributes = serviceProvider.GetService<CustomAttributes>();
var serviceInfo = typeof(PowertrakTradeController).GetServiceNameAndVersion();
Sdk.CreateTracerProviderBuilder()
    .AddSource(serviceName)
    .ConfigureResource(r =>
    {
        r.AddService(serviceName, serviceInfo.ServiceVersion);
        r.AddAttributes(new Dictionary<string, object>
        {
            { "service.name", serviceInfo.ServiceName },
            { "service.version", serviceInfo.ServiceVersion },
            { "service.environment", otelCustomAttributes!.Environment ?? string.Empty},
            { "application.id", otelCustomAttributes.ApplicationId ?? string.Empty }
        });
    })
    .AddOtlpExporter(exporter =>
    {
        exporter.Endpoint = openTelemetrySettings!.OtlpExporterEndpoint!;
        exporter.Protocol = OtlpExportProtocol.HttpProtobuf;
        exporter.ExportProcessorType = ExportProcessorType.Simple;
        exporter.HttpClientFactory = () =>
        {
            var httpClientFactory = serviceProvider.GetRequiredService<IHttpClientFactory>();
            return httpClientFactory.CreateClient(otlpClientName);
        };
    })
    .Build();

app.UseCors("AllowSpecificOrigins");
app.UseMiddleware<JwtTokenMiddleware>();

app.UseSwagger();
app.UseSwaggerUI(x =>
{
    x.SwaggerEndpoint("/swagger/v1/swagger.json", "SNE API V1");
#if DEBUG
    x.RoutePrefix = "swagger"; // For localhost
#else
    x.RoutePrefix = string.Empty; //  For azure
    x.SupportedSubmitMethods(Array.Empty<SubmitMethod>());
#endif
});

app.UseHttpsRedirection();
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

await app.RunAsync();