﻿using System.Reflection;

namespace Shell.Energy.STPower.Data.Dto
{
    /// <summary>
    /// Dto class for nomination detail
    /// </summary>
    public class NominationDetailsDto
    {
        public int NominationRunId { get; set; }

        public int NominationDefinitionId { get; set; }
        public string? NominationDefinitionName { get; set; }
        public int NominationDefinitionPrecision { get; set; }
        public string? TimeZone { get; set; }
        public DateTime DeliveryDate { get; set; }
        public int AggPosReferenceId { get; set; }
        public string? AggPosReferenceName { get; set; }
        public string? ContributingTradeHeaderIds { get; set; }
        public int PeriodCount { get; set; }
        public string? TradeType { get; set; }
        public string? TransactionType { get; set; }
        public string? Granularity { get; set; }
        public string? Entity { get; set; }
        public string? ClientName { get; set; }
        public string? Counterparty { get; set; }
        public string? FromMarketOperator { get; set; }
        public string? ToMarketOperator { get; set; }
        public string? CapacityType { get; set; }
        public string? CapacityIdentification { get; set; }
        public string? Interconnector { get; set; }
        public double? QH1 { get; set; }
        public double? QH2 { get; set; }
        public double? QH3 { get; set; }
        public double? QH4 { get; set; }
        public double? QH5 { get; set; }
        public double? QH6 { get; set; }
        public double? QH7 { get; set; }
        public double? QH8 { get; set; }
        public double? QH9 { get; set; }
        public double? QH10 { get; set; }
        public double? QH11 { get; set; }
        public double? QH12 { get; set; }
        public double? QH13 { get; set; }
        public double? QH14 { get; set; }
        public double? QH15 { get; set; }
        public double? QH16 { get; set; }
        public double? QH17 { get; set; }
        public double? QH18 { get; set; }
        public double? QH19 { get; set; }
        public double? QH20 { get; set; }
        public double? QH21 { get; set; }
        public double? QH22 { get; set; }
        public double? QH23 { get; set; }
        public double? QH24 { get; set; }
        public double? QH25 { get; set; }
        public double? QH26 { get; set; }
        public double? QH27 { get; set; }
        public double? QH28 { get; set; }
        public double? QH29 { get; set; }
        public double? QH30 { get; set; }
        public double? QH31 { get; set; }
        public double? QH32 { get; set; }
        public double? QH33 { get; set; }
        public double? QH34 { get; set; }
        public double? QH35 { get; set; }
        public double? QH36 { get; set; }
        public double? QH37 { get; set; }
        public double? QH38 { get; set; }
        public double? QH39 { get; set; }
        public double? QH40 { get; set; }
        public double? QH41 { get; set; }
        public double? QH42 { get; set; }
        public double? QH43 { get; set; }
        public double? QH44 { get; set; }
        public double? QH45 { get; set; }
        public double? QH46 { get; set; }
        public double? QH47 { get; set; }
        public double? QH48 { get; set; }
        public double? QH49 { get; set; }
        public double? QH50 { get; set; }
        public double? QH51 { get; set; }
        public double? QH52 { get; set; }
        public double? QH53 { get; set; }
        public double? QH54 { get; set; }
        public double? QH55 { get; set; }
        public double? QH56 { get; set; }
        public double? QH57 { get; set; }
        public double? QH58 { get; set; }
        public double? QH59 { get; set; }
        public double? QH60 { get; set; }
        public double? QH61 { get; set; }
        public double? QH62 { get; set; }
        public double? QH63 { get; set; }
        public double? QH64 { get; set; }
        public double? QH65 { get; set; }
        public double? QH66 { get; set; }
        public double? QH67 { get; set; }
        public double? QH68 { get; set; }
        public double? QH69 { get; set; }
        public double? QH70 { get; set; }
        public double? QH71 { get; set; }
        public double? QH72 { get; set; }
        public double? QH73 { get; set; }
        public double? QH74 { get; set; }
        public double? QH75 { get; set; }
        public double? QH76 { get; set; }
        public double? QH77 { get; set; }
        public double? QH78 { get; set; }
        public double? QH79 { get; set; }
        public double? QH80 { get; set; }
        public double? QH81 { get; set; }
        public double? QH82 { get; set; }
        public double? QH83 { get; set; }
        public double? QH84 { get; set; }
        public double? QH85 { get; set; }
        public double? QH86 { get; set; }
        public double? QH87 { get; set; }
        public double? QH88 { get; set; }
        public double? QH89 { get; set; }
        public double? QH90 { get; set; }
        public double? QH91 { get; set; }
        public double? QH92 { get; set; }
        public double? QH93 { get; set; }
        public double? QH94 { get; set; }
        public double? QH95 { get; set; }
        public double? QH96 { get; set; }
        public double? QH97 { get; set; }
        public double? QH98 { get; set; }
        public double? QH99 { get; set; }
        public double? QH100 { get; set; }
        public string? StatusCode { get; set; }
        public string? StatusMessage { get; set; }

        public double? TotalVolume
        {

            get
            {
                return this.GetType()
                .GetProperties(BindingFlags.Public | BindingFlags.Instance)
                .Where(p => p.Name.Contains("QH",StringComparison.OrdinalIgnoreCase))
                .Sum(p => (double?)p.GetValue(this));
            }


        }
    }
}
