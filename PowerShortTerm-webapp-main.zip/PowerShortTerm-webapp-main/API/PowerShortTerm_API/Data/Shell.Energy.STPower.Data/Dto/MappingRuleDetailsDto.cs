﻿namespace Shell.Energy.STPower.Data.Dto
{
    /// <summary>
    /// Class to hold Mapping Rule Details dto
    /// </summary>
    public class MappingRuleDetailsDto
    {
        public int MappingMasterId { get; set; }
        public int NominationDefinitionId { get; set; }
        public string? NominationDefinitionName { get; set; }
        public string? MappingMasterName { get; set; }
        public DateTime? MappingMasterCreatedDate { get; set; }
        public DateTime? MappingMasterModifiedDate { get; set; }
        public string? MappingMasterStatus { get; set; }
        public int MappingTypeId { get; set; }
        public string? MappingTypeName { get; set; }
        public DateTime? MappingTypeCreatedDate { get; set; }
        public DateTime? MappingTypeModifiedDate { get; set; }
        public string? MappingTypeStatus { get; set; }
        public int MappingInputId { get; set; }
        public string? MappingInputField { get; set; }
        public string? MappingInputValue { get; set; }
        public DateTime? MappingInputStartDate { get; set; }
        public DateTime? MappingInputEndDate { get; set; }
        public DateTime MappingInputCreatedDate { get; set; }
        public DateTime? MappingInputModifiedDate { get; set; }
        public string? MappingInputStatus { get; set; }
        public int MappingOutputId { get; set; }
        public string? MappingOutputValue { get; set; }
        public DateTime? MappingOutputStartDate { get; set; }
        public DateTime? MappingOutputEndDate { get; set; }
        public DateTime MappingOutputCreatedDate { get; set; }
        public DateTime? MappingOutputModifiedDate { get; set; }
        public string? MappingOutputStatus { get; set; }


       
    }
}
