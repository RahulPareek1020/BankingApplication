﻿namespace Shell.Energy.STPower.Data.Models
{
    public class NominationCorrelationId
    {
        public int NominationRunId { get; set; }
        public string CorrelationId { get; set; } = string.Empty;
        public string PowertrakEnv { get; set; } = string.Empty;
    }
}