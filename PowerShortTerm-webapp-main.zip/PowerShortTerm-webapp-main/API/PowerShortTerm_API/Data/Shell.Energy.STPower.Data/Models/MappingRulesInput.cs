﻿namespace Shell.Energy.STPower.Data.Models
{
    /// <summary>
    /// Model class to hold Mapping Rules Input
    /// </summary>
    public class MappingRulesInput
    {
        public int MappingInputId { get; set; }
        public string MappingInputField { get; set; }
        public string MappingInputValue { get; set; }
        public DateTime? MappingInputStartDate { get; set; }
        public DateTime? MappingInputEndDate { get; set; }
        public DateTime MappingInputCreatedDate { get; set; }
        public DateTime? MappingInputModifiedDate { get; set; }
        public string MappingInputStatus { get; set; }
    }
}
