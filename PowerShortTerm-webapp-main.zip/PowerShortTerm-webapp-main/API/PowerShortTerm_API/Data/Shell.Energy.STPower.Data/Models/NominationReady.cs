﻿namespace Shell.Energy.STPower.Data.Models
{
    public class NominationReady
    {
        public IEnumerable<int?>? NominationRunIDs { get; set; }
    }
}
