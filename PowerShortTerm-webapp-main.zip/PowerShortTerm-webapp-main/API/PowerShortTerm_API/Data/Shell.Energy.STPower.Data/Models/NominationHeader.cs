﻿namespace Shell.Energy.STPower.Data.Models
{
    /// <summary>
    /// Model class for powertrak nomination header
    /// </summary>
    public class NominationHeader
    {
        public int? NominationRunId { get; set; }
        public int NominationDefinitionId { get; set; }
        public string NominationDefinitionName { get; set; }
        public DateTime? DeliveryDate { get; set; }
        public string? ProcessStepName { get; set; }
        public string? ProcessStepStatus { get; set; }
        public string? Reason { get; set; }
        public DateTime? LastModificationTime { get; set; }
        public string? InitiatedBy { get; set; }
    }
}
