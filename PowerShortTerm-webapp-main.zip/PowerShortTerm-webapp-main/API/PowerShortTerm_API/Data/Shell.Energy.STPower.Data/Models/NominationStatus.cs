﻿namespace Shell.Energy.STPower.Data.Models
{
    /// <summary>
    /// Model class for powertrak nomination header
    /// </summary>
    public class NominationStatus
    {
        public string? ProcessStep { get; set; }
        public DateTime? DeliveryDate { get; set; }
    }
}
