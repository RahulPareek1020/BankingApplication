﻿namespace Shell.Energy.STPower.Data.Models
{
    /// <summary>
    /// Model class to hold Mapping Rules Type
    /// </summary>
    public class MappingRulesType
    {
        public int MappingTypeId { get; set; }
        public string MappingTypeName { get; set; }
        public DateTime? MappingTypeCreatedDate { get; set; }
        public DateTime? MappingTypeModifiedDate { get; set; }
        public string MappingTypeStatus { get; set; }
    }
}
