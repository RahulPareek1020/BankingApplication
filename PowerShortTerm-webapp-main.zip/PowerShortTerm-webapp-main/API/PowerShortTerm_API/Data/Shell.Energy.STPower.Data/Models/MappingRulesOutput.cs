﻿namespace Shell.Energy.STPower.Data.Models
{
    /// <summary>
    /// Model class to hold Mapping Rules Output
    /// </summary>
    public class MappingRulesOutput
    {
        public int MappingOutputId { get; set; }
        public string MappingOutputValue { get; set; }
        public DateTime? MappingOutputStartDate { get; set; }
        public DateTime? MappingOutputEndDate { get; set; }
        public DateTime MappingOutputCreatedDate { get; set; }
        public DateTime? MappingOutputModifiedDate { get; set; }
        public string MappingOutputStatus { get; set; }
    }
}
