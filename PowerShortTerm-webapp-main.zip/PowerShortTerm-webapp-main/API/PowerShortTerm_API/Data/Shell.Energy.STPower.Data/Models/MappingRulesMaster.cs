﻿namespace Shell.Energy.STPower.Data.Models
{
    /// <summary>
    /// Model class to hold Mapping Rules Master
    /// </summary>
    public class MappingRulesMaster
    {
        public int MappingMasterId { get; set; }
        public string MappingMasterName { get; set; }
        public DateTime? MappingMasterCreatedDate { get; set; }
        public DateTime? MappingMasterModifiedDate { get; set; }
        public string MappingMasterStatus { get; set; }
    }
}
