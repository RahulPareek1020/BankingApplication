﻿namespace Shell.Energy.STPower.Data.Models
{
    public class NominationRunOtelIds
    {
        public string? TraceId { get; set;}
        public string? SpanId { get; set; }

    }
}
