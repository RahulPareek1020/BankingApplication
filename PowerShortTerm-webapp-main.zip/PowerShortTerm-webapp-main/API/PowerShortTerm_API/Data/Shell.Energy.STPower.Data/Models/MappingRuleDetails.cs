﻿namespace Shell.Energy.STPower.Data.Models
{
    /// <summary>
    /// Model class for Mapping Rules Details
    /// </summary>
    public class MappingRuleDetails
    {
        public int NominationDefinitionId { get; set; }
        public string NominationDefinitionName { get; set; }
        public MappingRulesMaster MappingRulesMaster { get; set; }
        public MappingRulesType MappingRulesType { get; set; }
        public MappingRulesInput MappingRulesInput { get; set; }
        public MappingRulesOutput MappingRulesOutput { get; set; }
    }
}
