﻿namespace Shell.Energy.STPower.Data.Models
{
    /// <summary>
    /// Model class for powertrak nomination details
    /// </summary>
    public class NominationDetails
    {
        public int NominationRunId { get; set; }

        public int NominationDefinitionId { get; set; }
        public string NominationDefinitionName { get; set; }
        public int NominationDefinitionPrecision { get; set; }
        public DateTime DeliveryDate { get; set; }
        public int AggPosReferenceId { get; set; }
        public string AggPosReferenceName { get; set; }
        public string TimeZone { get; set; }
        public string ContributingTradeHeaderIds { get; set; }
        public string TradeType { get; set; }
        public string TransactionType { get; set; }
        public string Granularity { get; set; }
        public string Entity { get; set; }
        public string? ClientName { get; set; }
        public string Counterparty { get; set; }
        public string FromMarketOperator { get; set; }
        public string ToMarketOperator { get; set; }
        public string CapacityType { get; set; }
        public string CapacityIdentification { get; set; }
        public string Interconnector { get; set; }
        public NominationVolume NominationVolume { get; set; }
        public string StatusCode { get; set; }
        public string StatusMessage { get; set; }
    }
}