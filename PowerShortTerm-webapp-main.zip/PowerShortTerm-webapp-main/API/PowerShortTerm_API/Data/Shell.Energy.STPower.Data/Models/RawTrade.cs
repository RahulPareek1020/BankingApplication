﻿namespace Shell.Energy.STPower.Data.Models
{
    /// <summary>
    /// Class to hold the raw trade header data
    /// </summary>
    public class RawTrade
    { 
        public int RawTradeHeaderId { get; set; }
        
        public int NominationRunId { get; set; }
        public int NominationDefinitionPrecision { get; set; }
        public int AggPosReferenceId { get; set; }
        public string AggPosReference { get; set; }
        public string? TimeZone { get; set; }
        public string TradeReference { get; set; }
        public string TradeType { get; set; }
        public string TransactionType { get; set; }
        public string Entity { get; set; }
        public string Counterparty { get; set; }
        public string FromMarketoperator { get; set; }
        public string ToMarketoperator { get; set; }
        public string CapacityType { get; set; }
        public string CapacityIdentification { get; set; }
        public string Interconnector { get; set; }
        public DateTime DeliveryDate { get; set; }
        public DateTime NomDeliveryDate { get; set; }
        public DateTime? DelDateStart { get; set; }
        public DateTime? DelDateEnd { get; set; }
        public string Cdy1Attr1 { get; set; }
        public string PwrNomsOverrideType { get; set; }
        public string PwrNomsOverrideInput { get; set; }
        public string PwrNomsOverrideFreeform { get; set; }
        public string AuxSoCpty { get; set; }
        public string CptyNoms { get; set; }
        public string PeakWorkaround { get; set; }
        public int InsNumRec { get; set; }
        public NominationVolume RawTradeVolume { get; set; }
        public string? StatusCode { get; set; }
        public string? StatusMessage { get; set; }
    }
}
