namespace Shell.Energy.STPower.Data.Constants
{
    /// <summary>
    /// Class to hold the constants used in the service
    /// </summary>
    public static class ServiceConstants
    {
        public static readonly string STPowerConnectionStringName = "STPowerConnString";
        public static readonly string GetNomHeaderSPName= "GetNominationHeader";
        public static readonly string GetNomDetailsByRunIdSPName = "GetNominationDetailsByRunId";
        public static readonly string GetNomTradeDetailsByAggPosOrRunIdSPName = "GetNominationTradeDetails";
        public static readonly string GetMappingRuleDetailsSPName = "GetMappingRuleDetails";
        public static readonly string GetCounterpartyAggregationsSPName = "GetCounterpartyAggregations";
        public static readonly string SaveNominationDataSPName = "SaveNominationData";
        public static readonly string UpdateNominationBatchRunStatusSPName = "UpdateNominationBatchRunStatus";
        public static readonly string UpdateNominationBatchRunResponseSPName = "UpdateNominationBatchRunResponse";
        public static readonly string GetMarketOperatorSPName = "GetMarketOperatorNames";
        public static readonly string GetTradeTypeSPName = "GetTradeTypes";
        public static readonly string InsertNominationRunSPName = "InsertNominationRun";
        public static readonly string NominationId = "@NominationRunId";
        public static readonly string GetNominationStatusByRunIdSPName = "GetNominationStatusByRunId";
        public static readonly string GetAggregatedCptyPositionsByRunIdSPName = "GetCounterpartyAggPositions";
        public static readonly string SaveNominationPositionsSPName = "SaveNominationPositions";
        public static readonly Double? ZeroValue = 0.00;
        public static readonly string GetReadyNominationsSPName = "GetReadyNominations";
        public static readonly string DeliveryDate = "DeliveryDate";
        public static readonly string InsertNominationRunOtelSPName = "InsertNominationRunOtel";
        public static readonly string GetNomRunTraceSpanIdsSPName = "GetTraceAndSpanIds";
        public static readonly string GetPowerTrakEnvNameByNomRunIdSPName = "GetPowerTrakEnvNameByNomRunId";
        public static readonly string IntegrationVNetDBConnectionStringName = "IntegrationVNetDBConnString";
        public static readonly string BatchRunIdParam = "@BatchRunId";
        public static readonly string IsAutoSPParam = "@IsAuto";
        public static readonly string InsertBatchRunTypeSPName = "SNE.InsertBatchRunType";
        public static readonly string Timezone = "TimeZone";
        public static readonly string GetCorrelationIdsSPName = "GetCorrelationIds";
        public static readonly string UpdatePowertrakTradeStatusSPName = "UpdatePowertrakTradeStatus";
        public static readonly string GetPreviousAggregationPositionsSPName = "GetPreviousAggregationPositions";
        public static readonly string AggPosReferenceName = "AggPosReferenceName";
    }
}
