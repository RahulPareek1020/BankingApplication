﻿using Microsoft.Extensions.Configuration;
using System.Data;
using Microsoft.Data.SqlClient;
using Shell.Energy.STPower.Data.Constants;
using Dapper;
using System.Globalization;

namespace Shell.Energy.STPower.Data.Repository
{
    /// <summary>
    /// Class to interact with SQL database
    /// </summary>
    public class SqlDataRepository : ISqlDataRepository
    {
        private readonly string? _connectionString;
        private readonly string? _connectionVNETString;
        private readonly int _commandTimeout;


        public SqlDataRepository(IConfiguration configuration)
        {
            var env = configuration.GetSection("STPowerEnv")?.Value.ToUpper();
            _connectionString = configuration.GetConnectionString($"{ServiceConstants.STPowerConnectionStringName}-{env}");
            _connectionVNETString = configuration.GetConnectionString($"{ServiceConstants.IntegrationVNetDBConnectionStringName}-{env}");
            _commandTimeout = Convert.ToInt32(configuration.GetSection("CommandTimeout")?.Value, CultureInfo.CurrentCulture);
        }

        /// <summary>
        /// Execute reader asynchronously
        /// </summary>
        /// <param name="storedProcedureName"></param>
        /// <param name="parameters"></param>
        public async Task<IDataReader?> ExecuteReaderAsync(string storedProcedureName, SqlParameter[]? parameters = null, bool closeConnection = false, bool isVnet = false)
        {
            string? connectionString = isVnet ? _connectionVNETString : _connectionString;
            var connection = new SqlConnection(connectionString);
            try
            {
                await connection.OpenAsync();
                var command = new SqlCommand(storedProcedureName, connection)
                {
                    CommandType = CommandType.StoredProcedure,
                    CommandTimeout = _commandTimeout
                };
                if (parameters != null)
                {
                    command.Parameters.AddRange(parameters);
                }
                var reader = await command.ExecuteReaderAsync(CommandBehavior.CloseConnection);
                if (closeConnection)
                {
                    await connection.CloseAsync();
                }
                return reader;
            }
            catch (Exception)
            {
                connection.Close();
                throw;
            }
        }
    }
}
