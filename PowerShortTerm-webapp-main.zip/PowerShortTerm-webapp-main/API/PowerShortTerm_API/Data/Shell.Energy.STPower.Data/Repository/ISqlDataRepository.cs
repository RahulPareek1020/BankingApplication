﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace Shell.Energy.STPower.Data.Repository;

/// <summary>
/// Interface for SQL Data Repository
/// </summary>
public interface ISqlDataRepository
{
    Task<IDataReader?> ExecuteReaderAsync(string storedProcedureName, SqlParameter[]? parameters = null, bool closeConnection = false, bool isVnet = false);
}
