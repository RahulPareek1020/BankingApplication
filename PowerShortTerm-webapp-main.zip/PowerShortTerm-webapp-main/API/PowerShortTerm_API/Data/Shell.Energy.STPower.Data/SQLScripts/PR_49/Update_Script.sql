﻿UPDATE PST_NOMINATION_DEFINITION
SET Client_NAME = 'Shell Germany'
where Nomination_Definition_Name in ('EON','50 Hertz')

UPDATE PST_NOMINATION_DEFINITION
SET Client_NAME = 'Shell' where Nomination_Definition_Name not in ('EON','50 Hertz')