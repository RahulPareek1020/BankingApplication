﻿/****** Object:  UserDefinedFunction [dbo].[udf_GenerateQuantityBasedOnGranularity]    Script Date: 12/11/2024 17:52:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER FUNCTION [dbo].[udf_GenerateQuantityBasedOnGranularity](@Granularity int)
RETURNS NVARCHAR(MAX)
AS
-- Returns the stock level for the product.
BEGIN
   DECLARE @QHcounter INT = 0
   DECLARE @AddFourcounter INT = 0
   DECLARE @returnValue NVARCHAR(MAX)=''
	IF @Granularity = 15
	BEGIN

		WHILE @QHcounter<96
		BEGIN

		SET @returnValue = @returnValue+ ',QH'+CAST (@QHcounter+1 AS NVARCHAR)			
			SET @QHcounter = @QHcounter+1

		END

	END
	IF @Granularity = 30
	BEGIN

		WHILE @QHcounter<=96
		BEGIN
			if(@QHcounter=1)
				BEGIN
				SET @QHcounter = @QHcounter+1
				continue;
				END
			if(@QHcounter>48)
				BEGIN
				SET @returnValue = @returnValue+ ',NULL AS QH'+CAST (@QHcounter AS NVARCHAR)
				SET @QHcounter = @QHcounter+1
				continue;
				END
			if(@QHcounter=0)
				BEGIN 
				SET @returnValue = @returnValue+ ',CAST(((QH'+CAST(@QHcounter+1 AS NVARCHAR)+'+ QH'+CAST(@QHcounter+2 AS NVARCHAR)+')/2) AS DECIMAL(18,2))  AS QH'+CAST (@QHcounter+1 AS NVARCHAR)
				END
			ELSE 
				BEGIN
				SET @returnValue = @returnValue+ ',CAST(((QH'+CAST(@QHcounter+(@QHcounter-1) AS NVARCHAR)+'+ QH'+CAST(@QHcounter+@QHcounter AS NVARCHAR)+')/2) AS DECIMAL(18,2)) AS QH'+CAST (@QHcounter AS NVARCHAR)
				END			
			SET @QHcounter = @QHcounter+1

		END

	END

	IF @Granularity = 60
	BEGIN

		WHILE @QHcounter<=96
		BEGIN
			if(@QHcounter=1)
				BEGIN
				SET @QHcounter = @QHcounter+1
				continue;
				END
			if(@QHcounter>24)
				BEGIN
				SET @returnValue = @returnValue+ ',NULL AS QH'+CAST (@QHcounter AS NVARCHAR)
				SET @QHcounter = @QHcounter+1
				continue;
				END
			if(@QHcounter=0)
				BEGIN 
				SET @returnValue = @returnValue+ ',CAST(((QH'+CAST(@QHcounter+1 AS NVARCHAR)+'+ QH'+CAST(@QHcounter+2 AS NVARCHAR)+'+ QH'+CAST(@QHcounter+3 AS NVARCHAR)+'+ QH'+CAST(@QHcounter+4 AS NVARCHAR)+')/4) AS DECIMAL(18,2))  AS QH'+CAST (@QHcounter+1 AS NVARCHAR)
				SET @AddFourcounter= @QHcounter+4
				END
			ELSE 
				BEGIN
				SET @returnValue = @returnValue+ ',CAST(((QH'+CAST(@AddFourcounter+1 AS NVARCHAR)+'+ QH'+CAST(@AddFourcounter+2 AS NVARCHAR)+'+ QH'+CAST(@AddFourcounter+3 AS NVARCHAR)+'+ QH'+CAST(@AddFourcounter+4 AS NVARCHAR)+')/4) AS DECIMAL(18,2)) AS QH'+CAST (@QHcounter AS NVARCHAR)
				SET @AddFourcounter= @AddFourcounter+4
				END			
			SET @QHcounter = @QHcounter+1

		END

	END

	SET @returnValue= @returnValue+' FROM AggregatedPositions
	ORDER BY 
        FromMarketoperator, ToMarketoperator, Counterparty, AggPosReferenceName ASC;' 

	return @returnValue;
END;
