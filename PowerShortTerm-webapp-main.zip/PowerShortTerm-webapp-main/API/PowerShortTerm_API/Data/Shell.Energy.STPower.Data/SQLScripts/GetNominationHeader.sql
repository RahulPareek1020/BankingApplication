﻿/****** Object:  StoredProcedure [dbo].[GetNominationHeader]    Script Date: 29/01/2025 17:24:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER PROCEDURE [dbo].[GetNominationHeader]
AS
BEGIN
    ;WITH RankedNomination AS (
        SELECT
            NomRun.Nomination_Run_ID as NominationRunId,
            NomDef.Nomination_Definition_Id as NominationDefinitionId,
            NomDef.Nomination_Definition_Name as NominationDefinitionName, 
            CASE 
                WHEN NomHStat.Nomination_Process_Step_Id IN (1, 3) THEN NULL 
                ELSE NomRun.Delivery_Date 
            END as DeliveryDate, 
            NomProcStep.Nomination_Process_Step as ProcessStepName,
            NomHStat.Status as ProcessStepStatus, 
            NomHStat.Nomination_Process_Step_Id,
            NomHStat.Reason as Reason, 
            ISNULL(NomHStat.EndDateTime, NomHStat.StartDateTime) as LastModificationTime,
            ROW_NUMBER() OVER (PARTITION BY NomRun.Nomination_Run_ID, NomDef.Nomination_Definition_Id ORDER BY NomHStat.Nomination_Batch_Run_Status_Id DESC) as RowNum
        FROM [dbo].[SNE_Nomination_definition] AS NomDef 
        LEFT JOIN [dbo].[SNE_NOMINATION_Batch_RUN] AS NomRun 
            ON NomDef.Nomination_Definition_Id = NomRun.Nomination_Definition_Id 
        LEFT JOIN [dbo].[SNE_NOMINATION_BATCH_RUN_STATUS] AS NomHStat 
            ON NomRun.Nomination_Run_ID = NomHStat.Nomination_Run_ID 
        LEFT JOIN [dbo].[SNE_NOMINATION_PROCESS_STEP] AS NomProcStep
            ON NomHStat.Nomination_Process_Step_Id = NomProcStep.Nomination_Process_Step_Id
    )
    SELECT 
        NominationRunId,
        NominationDefinitionId, 
        NominationDefinitionName,
        DeliveryDate, 
        ProcessStepName, 
        ProcessStepStatus,
        Reason, 
        LastModificationTime
    FROM RankedNomination
    WHERE RowNum = 1
    ORDER BY LastModificationTime DESC;
END;