﻿/****** Object:  StoredProcedure [dbo].[InsertNominationRun]    Script Date: 22/01/2025 17:37:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER PROCEDURE [dbo].[InsertNominationRun]
    @NominationDefinitionId INT,
    @DeliveryDate DATETIME,
    @InitiatedBy VARCHAR(100),
    @IsAuto BIT =1
AS
BEGIN
    SET NOCOUNT ON;

    -- Check if the nomination definition ID exists
    IF NOT EXISTS (SELECT 1 FROM [dbo].[SNE_NOMINATION_DEFINITION] WHERE Nomination_Definition_ID = @NominationDefinitionId)
    BEGIN
        -- Return null if the nomination definition ID does not exist
        SELECT -1 AS NominationRunId;
        RETURN;
    END

    DECLARE @NominationRunId INT;
    
    IF @InitiatedBy = ''
    BEGIN
        SET @InitiatedBy = 'System User';
    END

    INSERT INTO [dbo].[SNE_NOMINATION_BATCH_RUN] (Nomination_Definition_Id, Delivery_Date, Correlation_ID, Nomination_Run_DateTime,Initiated_By,IS_AUTO)
    VALUES (@NominationDefinitionId, @DeliveryDate, null, GETDATE(),@InitiatedBy,@IsAuto);

    SET @NominationRunId = SCOPE_IDENTITY();

    INSERT INTO [dbo].[SNE_NOMINATION_BATCH_RUN_STATUS]([Nomination_Run_ID], [Nomination_Process_Step_ID], [StartDateTime], [EndDateTime], [Status], [Reason], [Market_Operator_ID])
    VALUES (@NominationRunId, 1, GETDATE(), GETDATE(), 'Accepted', null, null);

    SELECT @NominationRunId as NominationRunId;
END

GO