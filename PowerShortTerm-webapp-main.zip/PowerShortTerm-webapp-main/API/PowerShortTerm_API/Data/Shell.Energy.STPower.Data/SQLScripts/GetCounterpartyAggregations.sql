﻿/****** Object:  StoredProcedure [dbo].[GetCounterpartyAggregations]    Script Date: 13/11/2024 13:35:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE OR ALTER   PROCEDURE [dbo].[GetCounterpartyAggregations] 
    @NominationDefinitionId INT,
    @DeliveryDate DATE
AS
BEGIN

	DECLARE @Granularity INT,
	@sql nvarchar(max);

	SELECT @Granularity = Granularity_Value FROM SNE_NOMINATION_DEFINITION ND
	INNER JOIN SNE_GRANULARITY G ON ND.Granularity_ID = G.Granularity_ID
	WHERE ND.Nomination_Definition_ID = @NominationDefinitionId

	
	SET @sql = N'

	WITH NominationMappings AS ( SELECT 
        nomrulemap.Nomination_Definition_ID AS NominationDefinitionId,
        mapinput.Input_Field AS MappingInputField,
        mapinput.Input_Value AS MappingInputValue,
        mapOutput.OutputValue AS MappingOutputValue
    FROM [dbo].[SNE_MAPPING_RULES_MASTER] mapmaster
    INNER JOIN [dbo].[SNE_NOM_DEF_MAPPING_RULES_ASSOCIATION] nomrulemap ON mapmaster.Mapping_ID = nomrulemap.Mapping_ID
    INNER JOIN [dbo].[SNE_NOMINATION_DEFINITION] nomdef ON nomdef.Nomination_Definition_ID = nomrulemap.Nomination_Definition_ID
    INNER JOIN [dbo].[SNE_MAPPING_RULES_TYPE] maptype ON maptype.Mapping_Type_Id = mapmaster.Mapping_Type_Id
    INNER JOIN [dbo].[SNE_MAPPING_RULES_INPUT] mapinput ON mapinput.Mapping_ID = mapmaster.Mapping_ID
    INNER JOIN [dbo].[SNE_MAPPING_RULES_OUTPUT] mapoutput ON mapinput.MAPPING_INPUT_ID = mapoutput.MAPPING_INPUT_ID
    WHERE nomdef.Nomination_Definition_ID = @NominationDefinitionId  
      AND @DeliveryDate BETWEEN mapinput.START_DATE AND ISNULL(mapinput.END_DATE, @DeliveryDate)
		AND mapinput.STATUS = 1
		AND @DeliveryDate BETWEEN mapoutput.START_DATE AND ISNULL(mapoutput.END_DATE, @DeliveryDate)
		AND mapoutput.STATUS = 1
	  AND nomrulemap.STATUS=1 and mapmaster.STATUS=1 
	  AND (SELECT COUNT(*) FROM [dbo].[SNE_MAPPING_RULES_INPUT] WHERE Mapping_ID = mapmaster.Mapping_ID) >= 1
	  ),

    FilterCriteria AS (    
	SELECT DISTINCT
        t.Trade_Type_Name as TradeType,
        fm.MarketOperator_Name as FromMarketOperator,
        tm.MarketOperator_Name as ToMarketOperator,
        e.Entity_Name as Entity,
        c.Counterparty_Name as Counterparty,
		rawTradeHeader.CapacityType,
		rawTradeHeader.CapacityIdentification,
		rawTradeHeader.Interconnector,
		rawTradeHeader.Reference
    FROM 
        SNE_NOMINATION_BATCH_definition NomBatchDef
    LEFT JOIN SNE_TradeType t ON NomBatchDef.NOMINATION_batch_filter_type_ID = 1 AND NomBatchDef.NOMINATION_batch_filter_Value = CAST(t.Trade_Type_Id as CHAR(50))
    LEFT JOIN SNE_marketoperator fm ON NomBatchDef.NOMINATION_batch_filter_type_ID = 2 AND NomBatchDef.NOMINATION_batch_filter_Value = CAST(fm.MarketOperator_Id AS CHAR(50))
    LEFT JOIN SNE_marketoperator tm ON NomBatchDef.NOMINATION_batch_filter_type_ID = 3 AND NomBatchDef.NOMINATION_batch_filter_Value =  CAST(tm.MarketOperator_Id AS CHAR(50))
    LEFT JOIN SNE_entity e ON NomBatchDef.NOMINATION_batch_filter_type_ID = 4 AND NomBatchDef.NOMINATION_batch_filter_Value = CAST(e.Entity_Id AS CHAR(50))
    LEFT JOIN SNE_counterparty c ON NomBatchDef.NOMINATION_batch_filter_type_ID = 5 AND NomBatchDef.NOMINATION_batch_filter_Value = CAST(c.Counterparty_Id AS CHAR(50))
	LEFT JOIN [dbo].[ALIGNE_RAW_TRADE_HEADER] rawTradeHeader ON ((NomBatchDef.NOMINATION_batch_filter_type_ID = 6 AND NomBatchDef.NOMINATION_batch_filter_Value = rawTradeHeader.CapacityType)
	OR (NomBatchDef.NOMINATION_batch_filter_type_ID = 7 AND NomBatchDef.NOMINATION_batch_filter_Value = rawTradeHeader.CapacityIdentification)
	OR (NomBatchDef.NOMINATION_batch_filter_type_ID = 8 AND NomBatchDef.NOMINATION_batch_filter_Value = rawTradeHeader.Interconnector)
	OR (NomBatchDef.NOMINATION_batch_filter_type_ID = 9 AND NomBatchDef.NOMINATION_batch_filter_Value = rawTradeHeader.Reference))

    WHERE NomBatchDef.Nomination_Definition_ID = @NominationDefinitionId and NomBatchDef.Include = 1 and @DeliveryDate BETWEEN NomBatchDef.StartDate AND NomBatchDef.EndDate
    ),
	ValidTradeReferences AS (  
		SELECT Reference
	FROM [dbo].[ALIGNE_RAW_TRADE_HEADER] ar
	INNER JOIN SNE_NOMINATION_DEFINITION nomDef ON nomDef.Nomination_Definition_ID = @NominationDefinitionId
	INNER JOIN SNE_TIMEZONE tz ON tz.TimeZone_ID = nomDef.TimeZone_Id
	WHERE (ar.DeliveryDate = @DeliveryDate OR ar.DeliveryDate = DATEADD(day, -1, @DeliveryDate))
	  AND tz.TimeZone_Name != ''Greenwich Standard Time''
	GROUP BY Reference
	HAVING COUNT(Reference) > 1

	UNION

	SELECT Reference
	FROM [dbo].[ALIGNE_RAW_TRADE_HEADER] ar
	INNER JOIN SNE_NOMINATION_DEFINITION nomDef ON nomDef.Nomination_Definition_ID = @NominationDefinitionId
	INNER JOIN SNE_TIMEZONE tz ON tz.TimeZone_ID = nomDef.TimeZone_Id
	WHERE tz.TimeZone_Name = ''Greenwich Standard Time'' and ar.DeliveryDate = @DeliveryDate
	GROUP BY Reference
	HAVING COUNT(Reference) >= 1
	)
	, AggregatedPositions AS (

    SELECT 
        -1 as NominationRunId,
        @NominationDefinitionId as NominationDefinitionId,
        NomDef.Nomination_Definition_Name as NominationDefinitionName,
		tz.TimeZone_Name as TimeZone,
        AligneHeader.DeliveryDate as DeliveryDate,
        -1 as AggPosReferenceId,    
        CASE WHEN AligneHeader.TradeType = ''PW_TRANS''
		THEN 
		MAX(CONCAT(AligneHeader.Entity, ''_'', Left(AligneHeader.FromMarketOperator,6),''.'',Left(AligneHeader.ToMarketOperator,6), ''_'', FORMAT(@DeliveryDate, ''yyyy-MM-dd''),''_'',AligneHeader.Reference))
		ELSE
        CONCAT(AligneHeader.TransactionType, ''_'', AligneHeader.Entity, ''_'', AligneHeader.Counterparty, ''_'', AligneHeader.FromMarketOperator, ''_'', FORMAT(@DeliveryDate, ''yyyy-MM-dd''))
		END AS AggPosReferenceName,
        STRING_AGG(AligneHeader.Aligne_Raw_Trade_Header_ID, '','') AS ContributingTradeHeaderIds,
		AligneHeader.TradeType as TradeType,
        AligneHeader.TransactionType as TransactionType,
        AligneHeader.Granularity as Granularity,
        AligneHeader.Entity as Entity,
		NomDef.Client_Name as ClientName,
		ISNULL(NomMappingCP.MappingOutputValue, AligneHeader.Counterparty) as Counterparty,
        ISNULL(NomMappingFM.MappingOutputValue, AligneHeader.FromMarketOperator) as FromMarketOperator,
		ISNULL(NomMappingTM.MappingOutputValue, AligneHeader.ToMarketOperator) as ToMarketOperator,
		AligneHeader.MarketOperator_Name as MarketOperator,
        AligneHeader.CapacityType as CapacityType,
        AligneHeader.CapacityIdentification as CapacityIdentification,
        AligneHeader.Interconnector as Interconnector,
        SUM(AligneVolume.QH1) AS QH1,
        SUM(AligneVolume.QH2) AS QH2,
        SUM(AligneVolume.QH3) AS QH3,
        SUM(AligneVolume.QH4) AS QH4,
        SUM(AligneVolume.QH5) AS QH5,
        SUM(AligneVolume.QH6) AS QH6,
        SUM(AligneVolume.QH7) AS QH7,
        SUM(AligneVolume.QH8) AS QH8,
        SUM(AligneVolume.QH9) AS QH9,
        SUM(AligneVolume.QH10) AS QH10,
        SUM(AligneVolume.QH11) AS QH11,
        SUM(AligneVolume.QH12) AS QH12,
        SUM(AligneVolume.QH13) AS QH13,
        SUM(AligneVolume.QH14) AS QH14,
        SUM(AligneVolume.QH15) AS QH15,
        SUM(AligneVolume.QH16) AS QH16,
        SUM(AligneVolume.QH17) AS QH17,
        SUM(AligneVolume.QH18) AS QH18,
        SUM(AligneVolume.QH19) AS QH19,
        SUM(AligneVolume.QH20) AS QH20,
        SUM(AligneVolume.QH21) AS QH21,
        SUM(AligneVolume.QH22) AS QH22,
        SUM(AligneVolume.QH23) AS QH23,
        SUM(AligneVolume.QH24) AS QH24,
        SUM(AligneVolume.QH25) AS QH25,
        SUM(AligneVolume.QH26) AS QH26,
        SUM(AligneVolume.QH27) AS QH27,
        SUM(AligneVolume.QH28) AS QH28,
        SUM(AligneVolume.QH29) AS QH29,
        SUM(AligneVolume.QH30) AS QH30,
        SUM(AligneVolume.QH31) AS QH31,
        SUM(AligneVolume.QH32) AS QH32,
        SUM(AligneVolume.QH33) AS QH33,
        SUM(AligneVolume.QH34) AS QH34,
        SUM(AligneVolume.QH35) AS QH35,
        SUM(AligneVolume.QH36) AS QH36,
        SUM(AligneVolume.QH37) AS QH37,
        SUM(AligneVolume.QH38) AS QH38,
        SUM(AligneVolume.QH39) AS QH39,
        SUM(AligneVolume.QH40) AS QH40,
        SUM(AligneVolume.QH41) AS QH41,
        SUM(AligneVolume.QH42) AS QH42,
        SUM(AligneVolume.QH43) AS QH43,
        SUM(AligneVolume.QH44) AS QH44,
        SUM(AligneVolume.QH45) AS QH45,
        SUM(AligneVolume.QH46) AS QH46,
        SUM(AligneVolume.QH47) AS QH47,
        SUM(AligneVolume.QH48) AS QH48,
        SUM(AligneVolume.QH49) AS QH49,
        SUM(AligneVolume.QH50) AS QH50,
        SUM(AligneVolume.QH51) AS QH51,
        SUM(AligneVolume.QH52) AS QH52,
        SUM(AligneVolume.QH53) AS QH53,
        SUM(AligneVolume.QH54) AS QH54,
        SUM(AligneVolume.QH55) AS QH55,
        SUM(AligneVolume.QH56) AS QH56,
        SUM(AligneVolume.QH57) AS QH57,
        SUM(AligneVolume.QH58) AS QH58,
        SUM(AligneVolume.QH59) AS QH59,
        SUM(AligneVolume.QH60) AS QH60,
        SUM(AligneVolume.QH61) AS QH61,
        SUM(AligneVolume.QH62) AS QH62,
        SUM(AligneVolume.QH63) AS QH63,
        SUM(AligneVolume.QH64) AS QH64,
        SUM(AligneVolume.QH65) AS QH65,
        SUM(AligneVolume.QH66) AS QH66,
        SUM(AligneVolume.QH67) AS QH67,
        SUM(AligneVolume.QH68) AS QH68,
        SUM(AligneVolume.QH69) AS QH69,
        SUM(AligneVolume.QH70) AS QH70,
        SUM(AligneVolume.QH71) AS QH71,
        SUM(AligneVolume.QH72) AS QH72,
        SUM(AligneVolume.QH73) AS QH73,
        SUM(AligneVolume.QH74) AS QH74,
        SUM(AligneVolume.QH75) AS QH75,
        SUM(AligneVolume.QH76) AS QH76,
        SUM(AligneVolume.QH77) AS QH77,
        SUM(AligneVolume.QH78) AS QH78,
        SUM(AligneVolume.QH79) AS QH79,
        SUM(AligneVolume.QH80) AS QH80,
        SUM(AligneVolume.QH81) AS QH81,
        SUM(AligneVolume.QH82) AS QH82,
        SUM(AligneVolume.QH83) AS QH83,
        SUM(AligneVolume.QH84) AS QH84,
        SUM(AligneVolume.QH85) AS QH85,
        SUM(AligneVolume.QH86) AS QH86,
        SUM(AligneVolume.QH87) AS QH87,
        SUM(AligneVolume.QH88) AS QH88,
        SUM(AligneVolume.QH89) AS QH89,
        SUM(AligneVolume.QH90) AS QH90,
        SUM(AligneVolume.QH91) AS QH91,
        SUM(AligneVolume.QH92) AS QH92,
        SUM(AligneVolume.QH93) AS QH93,
        SUM(AligneVolume.QH94) AS QH94,
        SUM(AligneVolume.QH95) AS QH95,
        SUM(AligneVolume.QH96) AS QH96
    FROM 
        [dbo].[ALIGNE_RAW_TRADE_HEADER] AligneHeader
    INNER JOIN [dbo].[Aligne_raw_Trade_volume] AligneVolume ON AligneHeader.Aligne_Raw_Trade_Header_ID = AligneVolume.Aligne_Raw_Trade_Header_ID
	INNER JOIN ValidTradeReferences ON AligneHeader.Reference=ValidTradeReferences.Reference
	INNER JOIN [dbo].[SNE_NOMINATION_DEFINITION] NomDef ON NomDef.Nomination_Definition_ID = @NominationDefinitionId
	INNER JOIN [dbo].[SNE_TIMEZONE] tz ON NomDef.TimeZone_ID=tz.TimeZone_ID
	LEFT JOIN NominationMappings NomMappingFM ON AligneHeader.FromMarketOperator = NomMappingFM.MappingInputValue AND NomMappingFM.MappingInputField = ''FROMMARKETOPERATOR''
	LEFT JOIN NominationMappings NomMappingTM ON AligneHeader.ToMarketOperator = NomMappingTM.MappingInputValue AND PARSENAME(NomMappingTM.MappingInputField, 1) = ''ToMarketOperator''
	LEFT JOIN NominationMappings NomMappingCP ON AligneHeader.Counterparty = NomMappingCP.MappingInputValue AND PARSENAME(NomMappingCP.MappingInputField, 1) = ''Counterparty''
    WHERE
        (AligneHeader.DeliveryDate = @DeliveryDate or AligneHeader.DeliveryDate = DATEADD(day, -1, @DeliveryDate))
		AND (NOT EXISTS (SELECT TradeType FROM FilterCriteria where TradeType is not null) OR AligneHeader.TradeType IN (SELECT TradeType from FilterCriteria)) 
		AND (NOT EXISTS (SELECT FromMarketOperator FROM FilterCriteria where FromMarketOperator is not null) OR AligneHeader.FromMarketOperator IN (SELECT FromMarketOperator from FilterCriteria)) 
		AND (NOT EXISTS (SELECT ToMarketOperator FROM FilterCriteria where ToMarketOperator is not null) OR AligneHeader.ToMarketOperator IN (SELECT ToMarketOperator from FilterCriteria)) 
		AND (NOT EXISTS (SELECT Entity FROM FilterCriteria where Entity is not null) OR AligneHeader.Entity IN (SELECT Entity from FilterCriteria) )
		AND (NOT EXISTS (SELECT Counterparty FROM FilterCriteria where Counterparty is not null) OR AligneHeader.Counterparty IN (SELECT Counterparty from FilterCriteria))
		
		AND (NOT EXISTS (SELECT CapacityType FROM FilterCriteria where CapacityType is not null) OR AligneHeader.CapacityType IN (SELECT CapacityType from FilterCriteria)) 
		AND (NOT EXISTS (SELECT CapacityIdentification FROM FilterCriteria where CapacityIdentification is not null) OR AligneHeader.CapacityIdentification IN (SELECT CapacityIdentification from FilterCriteria)) 
		AND (NOT EXISTS (SELECT Interconnector FROM FilterCriteria where Interconnector is not null) OR AligneHeader.Interconnector IN (SELECT Interconnector from FilterCriteria)) 
		AND (NOT EXISTS (SELECT Reference FROM FilterCriteria where Reference is not null) OR AligneHeader.Reference IN (SELECT Reference from FilterCriteria)) 
    GROUP BY 
        CASE WHEN AligneHeader.TradeType = ''PW_TRANS''
		THEN
		CONCAT(AligneHeader.Entity, ''_'', Left(AligneHeader.FromMarketOperator,6),''.'',Left(AligneHeader.ToMarketOperator,6), ''_'', FORMAT(@DeliveryDate, ''yyyy-MM-dd''),''_'',AligneHeader.Reference)
		ELSE
        CONCAT(AligneHeader.TransactionType, ''_'', AligneHeader.Entity, ''_'', AligneHeader.Counterparty, ''_'', AligneHeader.FromMarketOperator, ''_'', FORMAT(@DeliveryDate, ''yyyy-MM-dd''))
		END,
		CASE WHEN AligneHeader.TradeType = ''PW_TRANS''
		THEN
		AligneHeader.Reference
		ELSE
        NULL
		END,
        NomDef.Nomination_Definition_Name,
        AligneHeader.TransactionType,
        AligneHeader.Entity,
		NomDef.Client_Name,
        AligneHeader.Counterparty,
        AligneHeader.FromMarketOperator,
        AligneHeader.TradeType,
		AligneHeader.DeliveryDate,
        AligneHeader.Granularity,
        AligneHeader.ToMarketoperator,
		AligneHeader.MarketOperator_Name,
        AligneHeader.CapacityType,
        AligneHeader.CapacityIdentification,
        AligneHeader.Interconnector,
		NomMappingFM.MappingOutputValue,
		NomMappingTM.MappingOutputValue,
		NomMappingCP.MappingOutputValue,
		tz.TimeZone_Name
		)

		SELECT 
	NominationRunId,
	NominationDefinitionId,
	NominationDefinitionName,
	TimeZone,
	DeliveryDate,
	AggPosReferenceId,
	AggPosReferenceName,
	ContributingTradeHeaderIds,
	TradeType,
	TransactionType,
	@Granularity AS Granularity,
	Entity,
	ClientName,
	Counterparty,
	FromMarketOperator,
	ToMarketOperator,
	MarketOperator,
	CapacityType,
	CapacityIdentification,
	Interconnector'

	DECLARE @ret NVARCHAR(MAX);
	EXEC @ret = dbo.udf_GenerateQuantityBasedOnGranularity @Granularity = @Granularity;
	
	SET @sql= @sql+ @ret

	EXEC sp_executesql @sql ,N'@NominationDefinitionId INT, @DeliveryDate DATE, @Granularity INT', @NominationDefinitionId, @DeliveryDate, @Granularity

END

