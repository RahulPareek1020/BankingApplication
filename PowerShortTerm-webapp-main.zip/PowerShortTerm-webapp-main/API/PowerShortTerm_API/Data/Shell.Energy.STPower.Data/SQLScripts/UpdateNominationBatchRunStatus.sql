﻿/****** Object:  StoredProcedure [dbo].[UpdateNominationBatchRunStatus]    Script Date: 27/01/2025 11:20:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER   PROCEDURE [dbo].[UpdateNominationBatchRunStatus]
    @NominationRunId INT,
    @StepId INT,
    @Status NVARCHAR(200),
	@Reason NVARCHAR(200),
    @StartDateTime DATETIME = NULL,
    @EndDateTime DATETIME = NULL
AS
BEGIN

	IF(@Status = 'Rejected')
		BEGIN
			SET @Reason = 'Message rejected'
		END
	ELSE IF(@Status = 'Partially accepted')
		BEGIN
			SET @Reason = 'Message partially accepted'
		END

    -- Check if the NominationRunId exists
    IF EXISTS (SELECT 1 FROM [dbo].[SNE_NOMINATION_BATCH_RUN_STATUS] WHERE Nomination_Run_ID = @NominationRunId and Nomination_Process_Step_ID=@StepId)
    BEGIN
        -- Update the existing row
        UPDATE [dbo].[SNE_NOMINATION_BATCH_RUN_STATUS]
        SET 
            Status = @Status, 
            StartDateTime = COALESCE(@StartDateTime, StartDateTime),
            EndDateTime = COALESCE(@EndDateTime, EndDateTime),
			Reason = @Reason
        WHERE 
            Nomination_Run_ID = @NominationRunId and Nomination_Process_Step_ID=@StepId;
    END
    ELSE
    BEGIN
        -- Insert a new row
        INSERT INTO [dbo].[SNE_NOMINATION_BATCH_RUN_STATUS] 
        (
            Nomination_Run_ID, 
            Nomination_Process_Step_ID, 
            Status, 
			Reason,
            StartDateTime, 
            EndDateTime
        )
        VALUES 
        (
            @NominationRunId, 
            @StepId, 
            @Status, 
			@Reason,
            @StartDateTime, 
            @EndDateTime			
        );
    END
END
