﻿/****** Object:  StoredProcedure [dbo].[GetNominationDetailsByRunId]    Script Date: 12/11/2024 17:49:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER   PROCEDURE [dbo].[GetNominationDetailsByRunId]
    @NominationRunId INT
AS
BEGIN
SELECT 
    NomRun.Nomination_Run_ID as NominationRunId, 
	NomDef.Nomination_Definition_Id as NominationDefinitionId,
    NomDef.Nomination_Definition_Name as NominationDefinitionName,
    NomRun.Delivery_Date as DeliveryDate,
	AggPosRef.Agg_Pos_Reference_ID as AggPosReferenceId, 
    AggPosRef.AGG_POS_REFERENCE as AggPosReferenceName, 
    TradeType.Trade_Type_Name as TradeType, 
    TransactionType.Transaction_Type_Name as TransactionType, 
    Granularity.Granularity_Value as Granularity, 
    Entity.Entity_Name as Entity, 
	NomDef.Client_Name as ClientName,
	TZ.TimeZone_Name as TimeZone,
    Counterparty.Counterparty_Name as Counterparty,
    FromMarketOperator.Marketoperator_Name as FromMarketOperator,
    ToMarketOperator.Marketoperator_Name as ToMarketOperator,
    AggHeader.Capacity_Type as CapacityType,
    AggHeader.Capacity_Identification as CapacityIdentification,
    AggHeader.Interconnector as Interconnector,
    AggVol.QH1,
    AggVol.QH2,
    AggVol.QH3,
    AggVol.QH4,
    AggVol.QH5,
    AggVol.QH6,
    AggVol.QH7,
    AggVol.QH8,
    AggVol.QH9,
    AggVol.QH10,
    AggVol.QH11,
    AggVol.QH12,
    AggVol.QH13,
    AggVol.QH14,
    AggVol.QH15,
    AggVol.QH16,
    AggVol.QH17,
    AggVol.QH18,
    AggVol.QH19,
    AggVol.QH20,
    AggVol.QH21,
    AggVol.QH22,
    AggVol.QH23,
    AggVol.QH24,
    AggVol.QH25,
    AggVol.QH26,
    AggVol.QH27,
    AggVol.QH28,
    AggVol.QH29,
    AggVol.QH30,
    AggVol.QH31,
    AggVol.QH32,
    AggVol.QH33,
    AggVol.QH34,
    AggVol.QH35,
    AggVol.QH36,
    AggVol.QH37,
    AggVol.QH38,
    AggVol.QH39,
    AggVol.QH40,
    AggVol.QH41,
    AggVol.QH42,
    AggVol.QH43,
    AggVol.QH44,
    AggVol.QH45,
    AggVol.QH46,
    AggVol.QH47,
    AggVol.QH48,
    AggVol.QH49,
    AggVol.QH50,
    AggVol.QH51,
    AggVol.QH52,
    AggVol.QH53,
    AggVol.QH54,
    AggVol.QH55,
    AggVol.QH56,
    AggVol.QH57,
    AggVol.QH58,
    AggVol.QH59,
    AggVol.QH60,
    AggVol.QH61,
    AggVol.QH62,
    AggVol.QH63,
    AggVol.QH64,
    AggVol.QH65,
    AggVol.QH66,
    AggVol.QH67,
    AggVol.QH68,
    AggVol.QH69,
    AggVol.QH70,
    AggVol.QH71,
    AggVol.QH72,
    AggVol.QH73,
    AggVol.QH74,
    AggVol.QH75,
    AggVol.QH76,
    AggVol.QH77,
    AggVol.QH78,
    AggVol.QH79,
    AggVol.QH80,
    AggVol.QH81,
    AggVol.QH82,
    AggVol.QH83,
    AggVol.QH84,
    AggVol.QH85,
    AggVol.QH86,
    AggVol.QH87,
    AggVol.QH88,
    AggVol.QH89,
    AggVol.QH90,
    AggVol.QH91,
    AggVol.QH92,
    AggVol.QH93,
    AggVol.QH94,
    AggVol.QH95,
    AggVol.QH96,
	AggVol.QH97,
	AggVol.QH98,
	AggVol.QH99,
	AggVol.QH100
FROM 
    SNE_Nomination_Batch_Run NomRun
    INNER JOIN SNE_Nomination_Definition NomDef ON NomRun.nomination_definition_id = NomDef.nomination_definition_id
	INNER JOIN SNE_TIMEZONE TZ on NomDef.TimeZone_Id=tz.TimeZone_ID
	INNER JOIN SNE_AGG_POS_REFERENCE AggPosRef ON AggPosRef.nomination_run_id= NomRun.nomination_run_id
    INNER JOIN SNE_COUNTERPARTY_POSAGG_HEADER AggHeader ON AggPosRef.AGG_POS_REFERENCE_ID = AggHeader.Agg_Pos_Reference_Id
    INNER JOIN SNE_COUNTERPARTY_POSAGG_VOLUME AggVol ON AggPosRef.Agg_Pos_Reference_Id = AggVol.Agg_Pos_Reference_Id
    INNER JOIN SNE_Tradetype TradeType ON AggHeader.trade_type_id = TradeType.trade_type_id
    INNER JOIN SNE_Transactiontype TransactionType ON AggHeader.transaction_type_id = TransactionType.transaction_type_id
    INNER JOIN SNE_Granularity Granularity ON AggHeader.granularity_id = Granularity.granularity_id
    INNER JOIN SNE_Entity Entity ON AggHeader.entity_id = Entity.entity_id
    INNER JOIN SNE_Counterparty Counterparty ON AggHeader.counterparty_id = Counterparty.counterparty_id
    INNER JOIN SNE_MarketOperator FromMarketOperator ON AggHeader.from_marketoperator_id = FromMarketOperator.marketoperator_id
    INNER JOIN SNE_MarketOperator ToMarketOperator ON AggHeader.to_marketoperator_id = ToMarketOperator.marketoperator_id
WHERE 
    NomRun.nomination_run_id = @NominationRunId
Order by FromMarketoperator,ToMarketoperator,Counterparty,AGG_POS_REFERENCE asc;
END;
