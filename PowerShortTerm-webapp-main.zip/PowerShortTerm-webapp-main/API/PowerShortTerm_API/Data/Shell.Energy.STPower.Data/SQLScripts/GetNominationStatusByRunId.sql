﻿/****** Object:  StoredProcedure [dbo].[GetNominationStatusByRunId]    Script Date: 21/01/2025 09:48:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER   PROCEDURE [dbo].[GetNominationStatusByRunId]
    @NominationRunId INT
AS
BEGIN
    ;WITH RankedNomination AS (
		SELECT
        NomProcStep.Nomination_Process_Step_Name as ProcessStep,
        ROW_NUMBER() OVER (PARTITION BY @NominationRunId ORDER BY NomRunStat.Nomination_Batch_Run_Status_Id DESC) as RowNum
        from [dbo].[SNE_NOMINATION_BATCH_RUN_STATUS] AS NomRunStat 
        LEFT JOIN [dbo].[SNE_NOMINATION_PROCESS_STEP] AS NomProcStep
            ON NomRunStat.Nomination_Process_Step_Id = NomProcStep.Nomination_Process_Step_Id
			where NomRunStat.Nomination_Run_ID=@NominationRunId
    )
    SELECT 
    ProcessStep 
      FROM RankedNomination
    WHERE RowNum = 1
END;