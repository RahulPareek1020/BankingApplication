/****** Object:  StoredProcedure [dbo].[GetPowerTrakEnvNameByNomRunId]    Script Date: 17-03-2025 18:52:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:      Rahul Pareek
-- Create Date: 17-03-2025
-- Description: Get PowerTrak Env Name
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[GetPowerTrakEnvNameByNomRunId] 
 @NominationRunId INT
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON

    -- Insert statements for procedure here
    SELECT SND.[Powertrak_Env]
	FROM [dbo].[SNE_NOMINATION_DEFINITION] SND
	JOIN [dbo].[SNE_NOMINATION_BATCH_RUN] NBR
	ON SND.Nomination_Definition_ID = NBR.Nomination_Definition_ID
	WHERE NBR.[Nomination_Run_ID] = @NominationRunId

END
GO


