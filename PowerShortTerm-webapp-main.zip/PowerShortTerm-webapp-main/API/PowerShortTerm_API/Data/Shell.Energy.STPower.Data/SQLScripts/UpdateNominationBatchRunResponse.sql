﻿/****** Object:  StoredProcedure [dbo].[UpdateNominationBatchRunResponse]    Script Date: 12/11/2024 17:50:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER   PROCEDURE [dbo].[UpdateNominationBatchRunResponse]
    @NominationRunId INT,
    @CorrelationId VARCHAR(250) = NULL,
	@ErrorList NVARCHAR(MAX)= NULL
AS
BEGIN
    -- Check if the NominationRunId exists
    IF EXISTS (SELECT 1 FROM [dbo].[SNE_NOMINATION_BATCH_RUN] WHERE Nomination_Run_ID = @NominationRunId) AND @CorrelationId IS NOT NULL
    BEGIN
        -- Update the existing row
        UPDATE [dbo].[SNE_NOMINATION_BATCH_RUN]
        SET 
            Correlation_ID = @CorrelationId
        WHERE 
            Nomination_Run_ID = @NominationRunId
    END
	
	IF @ErrorList IS NOT NULL
	BEGIN
		--INSERT ERRORS IF PRESENT
		INSERT INTO SNE_NOMINATION_BATCH_RUN_ERROR_DETAILS (Nomination_Run_ID,Error_Details)
		SELECT @NominationRunId, value FROM STRING_SPLIT(@ErrorList,',')		
	END
END
