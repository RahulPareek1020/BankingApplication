﻿/****** Object:  StoredProcedure [dbo].[GetCounterpartyAggPositions]    Script Date: 18/02/2025 10:17:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER     PROCEDURE [dbo].[GetCounterpartyAggPositions]
    @NominationRunId INT
AS
BEGIN

	DECLARE @NominationDefinitionId INT,
	@DeliveryDate DATETIME,
	@Granularity INT,
	@sql nvarchar(max)

	SELECT TOP (1) 
    @NominationDefinitionId = [Nomination_Definition_Id],
    @DeliveryDate = [Delivery_Date]
	FROM [dbo].[SNE_NOMINATION_BATCH_RUN]
	WHERE [Nomination_Run_ID] = @NominationRunId

	SELECT @Granularity = Granularity_Value FROM SNE_NOMINATION_DEFINITION ND
	INNER JOIN SNE_GRANULARITY G ON ND.Granularity_ID = G.Granularity_ID
	WHERE ND.Nomination_Definition_ID = @NominationDefinitionId

	CREATE TABLE #TempPrevCptyAggregation (
    AGG_POS_REFERENCE NVARCHAR(255),
	Agg_Pos_Reference_ID INT,
    Nomination_Run_ID INT
);

	CREATE TABLE #TempCptyAggregation (
    NominationRunId INT,
    NominationDefinitionId INT,
    NominationDefinitionName NVARCHAR(255),
    TimeZone NVARCHAR(50),
    DeliveryDate DATE,
    AggPosReferenceId INT,
    AggPosReferenceName NVARCHAR(255),
    ContributingTradeHeaderIds NVARCHAR(MAX),
    TradeType NVARCHAR(50),
    TransactionType NVARCHAR(50),
    Granularity INT,
    Entity NVARCHAR(50),
    ClientName NVARCHAR(255),
    Counterparty NVARCHAR(255),
    FromMarketOperator NVARCHAR(50),
    ToMarketOperator NVARCHAR(50),
    CapacityType NVARCHAR(50),
    CapacityIdentification NVARCHAR(50),
    Interconnector NVARCHAR(50),
    PWRNOMS_OVERRIDE_TYPE NVARCHAR(50),
    PWRNOMS_OVERRIDE_INPUT NVARCHAR(50),
    PWRNOMS_OVERRIDE_FREEFORM NVARCHAR(255),
    AUX_SO_CPTY NVARCHAR(50),
    QH1 DECIMAL(10, 2),
    QH2 DECIMAL(10, 2),
    QH3 DECIMAL(10, 2),
    QH4 DECIMAL(10, 2),
    QH5 DECIMAL(10, 2),
    QH6 DECIMAL(10, 2),
    QH7 DECIMAL(10, 2),
    QH8 DECIMAL(10, 2),
    QH9 DECIMAL(10, 2),
    QH10 DECIMAL(10, 2),
    QH11 DECIMAL(10, 2),
    QH12 DECIMAL(10, 2),
    QH13 DECIMAL(10, 2),
    QH14 DECIMAL(10, 2),
    QH15 DECIMAL(10, 2),
    QH16 DECIMAL(10, 2),
    QH17 DECIMAL(10, 2),
    QH18 DECIMAL(10, 2),
    QH19 DECIMAL(10, 2),
    QH20 DECIMAL(10, 2),
    QH21 DECIMAL(10, 2),
    QH22 DECIMAL(10, 2),
    QH23 DECIMAL(10, 2),
    QH24 DECIMAL(10, 2),
    QH25 DECIMAL(10, 2),
    QH26 DECIMAL(10, 2),
    QH27 DECIMAL(10, 2),
    QH28 DECIMAL(10, 2),
    QH29 DECIMAL(10, 2),
    QH30 DECIMAL(10, 2),
    QH31 DECIMAL(10, 2),
    QH32 DECIMAL(10, 2),
    QH33 DECIMAL(10, 2),
    QH34 DECIMAL(10, 2),
    QH35 DECIMAL(10, 2),
    QH36 DECIMAL(10, 2),
    QH37 DECIMAL(10, 2),
    QH38 DECIMAL(10, 2),
    QH39 DECIMAL(10, 2),
    QH40 DECIMAL(10, 2),
    QH41 DECIMAL(10, 2),
    QH42 DECIMAL(10, 2),
    QH43 DECIMAL(10, 2),
    QH44 DECIMAL(10, 2),
    QH45 DECIMAL(10, 2),
    QH46 DECIMAL(10, 2),
    QH47 DECIMAL(10, 2),
    QH48 DECIMAL(10, 2),
    QH49 DECIMAL(10, 2),
    QH50 DECIMAL(10, 2),
    QH51 DECIMAL(10, 2),
    QH52 DECIMAL(10, 2),
    QH53 DECIMAL(10, 2),
    QH54 DECIMAL(10, 2),
    QH55 DECIMAL(10, 2),
    QH56 DECIMAL(10, 2),
    QH57 DECIMAL(10, 2),
    QH58 DECIMAL(10, 2),
    QH59 DECIMAL(10, 2),
    QH60 DECIMAL(10, 2),
    QH61 DECIMAL(10, 2),
    QH62 DECIMAL(10, 2),
    QH63 DECIMAL(10, 2),
    QH64 DECIMAL(10, 2),
    QH65 DECIMAL(10, 2),
    QH66 DECIMAL(10, 2),
    QH67 DECIMAL(10, 2),
    QH68 DECIMAL(10, 2),
    QH69 DECIMAL(10, 2),
    QH70 DECIMAL(10, 2),
    QH71 DECIMAL(10, 2),
    QH72 DECIMAL(10, 2),
    QH73 DECIMAL(10, 2),
    QH74 DECIMAL(10, 2),
    QH75 DECIMAL(10, 2),
    QH76 DECIMAL(10, 2),
    QH77 DECIMAL(10, 2),
    QH78 DECIMAL(10, 2),
    QH79 DECIMAL(10, 2),
    QH80 DECIMAL(10, 2),
    QH81 DECIMAL(10, 2),
    QH82 DECIMAL(10, 2),
    QH83 DECIMAL(10, 2),
    QH84 DECIMAL(10, 2),
    QH85 DECIMAL(10, 2),
    QH86 DECIMAL(10, 2),
    QH87 DECIMAL(10, 2),
    QH88 DECIMAL(10, 2),
    QH89 DECIMAL(10, 2),
    QH90 DECIMAL(10, 2),
    QH91 DECIMAL(10, 2),
    QH92 DECIMAL(10, 2),
    QH93 DECIMAL(10, 2),
    QH94 DECIMAL(10, 2),
    QH95 DECIMAL(10, 2),
    QH96 DECIMAL(10, 2)
);
	
	SET @sql = N'

	WITH NominationMappings AS ( SELECT 
        nomrulemap.Nomination_Definition_ID AS NominationDefinitionId,
        mapinput.Input_Field AS MappingInputField,
        mapinput.Input_Value AS MappingInputValue,
        mapOutput.OutputValue AS MappingOutputValue,
		mapinput.MAPPING_ID AS Mapping_id
    FROM [dbo].[SNE_MAPPING_RULES_MASTER] mapmaster
    INNER JOIN [dbo].[SNE_NOM_DEF_MAPPING_RULES_ASSOCIATION] nomrulemap ON mapmaster.Mapping_ID = nomrulemap.Mapping_ID
    INNER JOIN [dbo].[SNE_NOMINATION_DEFINITION] nomdef ON nomdef.Nomination_Definition_ID = nomrulemap.Nomination_Definition_ID
    INNER JOIN [dbo].[SNE_MAPPING_RULES_TYPE] maptype ON maptype.Mapping_Type_Id = mapmaster.Mapping_Type_Id
    INNER JOIN [dbo].[SNE_MAPPING_RULES_INPUT] mapinput ON mapinput.Mapping_ID = mapmaster.Mapping_ID
    INNER JOIN [dbo].[SNE_MAPPING_RULES_OUTPUT] mapoutput ON mapinput.MAPPING_INPUT_ID = mapoutput.MAPPING_INPUT_ID
    WHERE nomdef.Nomination_Definition_ID = @NominationDefinitionId  
      AND @DeliveryDate BETWEEN mapinput.START_DATE AND ISNULL(mapinput.END_DATE, @DeliveryDate)
		AND mapinput.STATUS = 1
		AND @DeliveryDate BETWEEN mapoutput.START_DATE AND ISNULL(mapoutput.END_DATE, @DeliveryDate)
		AND mapoutput.STATUS = 1
	  AND nomrulemap.STATUS=1 and mapmaster.STATUS=1 
	  AND (SELECT COUNT(*) FROM [dbo].[SNE_MAPPING_RULES_INPUT] WHERE Mapping_ID = mapmaster.Mapping_ID) >= 1
	  ),
	  RANKEDDATA AS (
		SELECT 
        mapinput.Input_Field AS MappingInputField,
        mapinput.Input_Value AS MappingInputValue,
        mapOutput.OutputValue AS MappingOutputValue,
		MAX(mapinput.MAPPING_ID) as Mapping_Id
		,ROW_NUMBER() OVER (PARTITION BY mapinput.Mapping_Id ORDER BY mapinput.Input_Value) AS RowNum 
		FROM [dbo].[SNE_MAPPING_RULES_MASTER] mapmaster
		INNER JOIN [dbo].[SNE_NOM_DEF_MAPPING_RULES_ASSOCIATION] nomrulemap ON mapmaster.Mapping_ID = nomrulemap.Mapping_ID
		INNER JOIN [dbo].[SNE_NOMINATION_DEFINITION] nomdef ON nomdef.Nomination_Definition_ID = nomrulemap.Nomination_Definition_ID
		INNER JOIN [dbo].[SNE_MAPPING_RULES_TYPE] maptype ON maptype.Mapping_Type_Id = mapmaster.Mapping_Type_Id
		INNER JOIN [dbo].[SNE_MAPPING_RULES_INPUT] mapinput ON mapinput.Mapping_ID = mapmaster.Mapping_ID
		INNER JOIN [dbo].[SNE_MAPPING_RULES_OUTPUT] mapoutput ON mapinput.MAPPING_INPUT_ID = mapoutput.MAPPING_INPUT_ID
		WHERE nomdef.Nomination_Definition_ID = @NominationDefinitionId  
		AND @DeliveryDate BETWEEN mapinput.START_DATE AND ISNULL(mapinput.END_DATE, @DeliveryDate)
		AND mapinput.STATUS = 1
		AND @DeliveryDate BETWEEN mapoutput.START_DATE AND ISNULL(mapoutput.END_DATE, @DeliveryDate)
		AND mapoutput.STATUS = 1
		AND nomrulemap.STATUS=1 and mapmaster.STATUS=1 
		AND (SELECT COUNT(*) FROM [dbo].[SNE_MAPPING_RULES_INPUT] WHERE Mapping_ID = mapmaster.Mapping_ID) >= 1
		AND mapmaster.MAPPING_TYPE_ID=4
		GROUP BY
		  mapinput.Mapping_Id
		 ,mapinput.Input_Field 
		 , mapinput.Input_Value 
		 , mapOutput.OutputValue
	  ),
	 NominationMultipleMappings AS (
			SELECT MAPPING_ID,
			MAX(CASE WHEN RowNum = 1 THEN MappingInputValue END) AS VALUE_1,
			MAX(CASE WHEN RowNum = 2 THEN MappingInputValue END) AS VALUE_2
			FROM RANKEDDATA
			GROUP BY Mapping_Id
	),

    FilterCriteria AS (    
	SELECT DISTINCT
		t.Trade_Type_Name as TradeType,
        fm.MarketOperator_Name as FromMarketOperator,
        tm.MarketOperator_Name as ToMarketOperator,
        e.Entity_Name as Entity,
        c.Counterparty_Name as Counterparty,
		CASE 
		WHEN Nomination_Batch_Filter_Type_ID = 6
		THEN Nomination_Batch_Filter_Value
		ELSE
		NULL
		END
		AS CapacityType,
		CASE 
		WHEN Nomination_Batch_Filter_Type_ID = 7
		THEN Nomination_Batch_Filter_Value
		ELSE
		NULL
		END
		AS CapacityIdentification,
		CASE 
		WHEN Nomination_Batch_Filter_Type_ID = 8
		THEN Nomination_Batch_Filter_Value
		ELSE
		NULL
		END
		AS Interconnector,
		CASE 
		WHEN Nomination_Batch_Filter_Type_ID = 9
		THEN Nomination_Batch_Filter_Value
		ELSE
		NULL
		END
		AS Reference
 
	FROM 
        dbo.SNE_NOMINATION_BATCH_definition NomBatchDef
    LEFT JOIN dbo.SNE_TradeType t ON NomBatchDef.NOMINATION_batch_filter_type_ID = 1 AND NomBatchDef.NOMINATION_batch_filter_Value = CAST(t.Trade_Type_Id as varchar(5))
    LEFT JOIN dbo.SNE_marketoperator fm ON NomBatchDef.NOMINATION_batch_filter_type_ID = 2 AND NomBatchDef.NOMINATION_batch_filter_Value = CAST(fm.MarketOperator_Id AS varchar(5))
    LEFT JOIN dbo.SNE_marketoperator tm ON NomBatchDef.NOMINATION_batch_filter_type_ID = 3 AND NomBatchDef.NOMINATION_batch_filter_Value =  CAST(tm.MarketOperator_Id AS varchar(5))
	LEFT JOIN dbo.SNE_entity e ON NomBatchDef.NOMINATION_batch_filter_type_ID = 4 AND NomBatchDef.NOMINATION_batch_filter_Value = CAST(e.Entity_Id AS varchar(5))
    LEFT JOIN dbo.SNE_counterparty c ON NomBatchDef.NOMINATION_batch_filter_type_ID = 5 AND NomBatchDef.NOMINATION_batch_filter_Value = CAST(c.Counterparty_Id AS varchar(5))
 
    WHERE NomBatchDef.Nomination_Definition_ID = @NominationDefinitionId and NomBatchDef.Include = 1 and @DeliveryDate BETWEEN NomBatchDef.StartDate AND NomBatchDef.EndDate
    ),
	
	MappedRawTrades AS(
	SELECT [Aligne_Raw_Trade_Header_ID]
      ,[REFERENCE]
      ,[TRADETYPE]
      ,[TRANSACTIONTYPE]
      ,[ENTITY]
      ,CASE 
		WHEN [PWRNOMS_OVERRIDE_TYPE] = ''CO_OOFF''
		THEN PWRNOMS_OVERRIDE_FREEFORM 
		WHEN [PWRNOMS_OVERRIDE_TYPE] = ''CO_SO''
		THEN AUX_SO_CPTY  
		ELSE [Counterparty]
	   END AS COUNTERPARTY
      ,[FROMMARKETOPERATOR]
      ,[TOMARKETOPERATOR]
      ,[DELIVERYDATE]
      ,[TRADEDATE]
      ,[DEL_DATESTART]
      ,[DEL_DATEEND]
      ,[CDY1ATTR1]
      ,[PWRNOMS_OVERRIDE_TYPE]
      ,[PWRNOMS_OVERRIDE_INPUT]
      ,[PWRNOMS_OVERRIDE_FREEFORM]
      ,[AUX_SO_CPTY]
      ,[CPTY_NOMS]
      ,[PEAK_WORKAROUND]
      ,[CapacityType]
      ,[CapacityIdentification]
      ,[Interconnector]
      ,[BATCH_RUN_DATE]
      ,[BATCH_RUN_TIME]
      ,[SOURCE]
      ,[BATCH_RUN_ID]
      ,[INSNUMREC]
	  ,[PRODCON]
	  FROM [dbo].[SNE_ALIGNE_RAW_TRADE_HEADER]
	  WHERE
        Batch_Run_ID=@NominationRunId
        AND (NOT EXISTS (SELECT TradeType FROM FilterCriteria where TradeType is not null) OR TradeType IN (SELECT TradeType from FilterCriteria)) 
		AND (NOT EXISTS (SELECT FromMarketOperator FROM FilterCriteria where FromMarketOperator is not null) OR FromMarketOperator IN (SELECT FromMarketOperator from FilterCriteria)) 
		AND (NOT EXISTS (SELECT ToMarketOperator FROM FilterCriteria where ToMarketOperator is not null) OR ToMarketOperator IN (SELECT ToMarketOperator from FilterCriteria)) 
		AND (NOT EXISTS (SELECT Entity FROM FilterCriteria where Entity is not null) OR Entity IN (SELECT Entity from FilterCriteria) )
		AND (NOT EXISTS (SELECT Counterparty FROM FilterCriteria where Counterparty is not null) OR Counterparty IN (SELECT Counterparty from FilterCriteria))
		
		AND (NOT EXISTS (SELECT CapacityType FROM FilterCriteria where CapacityType is not null) OR CapacityType IN (SELECT CapacityType from FilterCriteria)) 
		AND (NOT EXISTS (SELECT CapacityIdentification FROM FilterCriteria where CapacityIdentification is not null) OR CapacityIdentification IN (SELECT CapacityIdentification from FilterCriteria)) 
		AND (NOT EXISTS (SELECT Interconnector FROM FilterCriteria where Interconnector is not null) OR Interconnector IN (SELECT Interconnector from FilterCriteria)) 
		AND (NOT EXISTS (SELECT Reference FROM FilterCriteria where Reference is not null) OR Reference IN (SELECT Reference from FilterCriteria)) 
	)
	,AggregatedPositions AS (

    SELECT 
        @NominationRunId as NominationRunId,
        @NominationDefinitionId as NominationDefinitionId,
        NomDef.Nomination_Definition_Name as NominationDefinitionName,
		tz.TimeZone_Name as TimeZone,
        AligneHeader.DeliveryDate as DeliveryDate,
        -1 as AggPosReferenceId,    
        CASE WHEN AligneHeader.TradeType = ''PW_TRANS''
		THEN 
		MAX(CONCAT(AligneHeader.Entity, ''_'', Left(AligneHeader.FromMarketOperator,6),''.'',Left(AligneHeader.ToMarketOperator,6), ''_'', FORMAT(@DeliveryDate, ''yyyy-MM-dd''),''_'',AligneHeader.Reference))
		ELSE
        CONCAT(AligneHeader.TransactionType, ''_'', AligneHeader.Entity, ''_'', ISNULL(NomMappingPC.MappingOutputValue,ISNULL(NomMappingCP.MappingOutputValue, AligneHeader.Counterparty)), ''_'', AligneHeader.FromMarketOperator, ''_'', FORMAT(@DeliveryDate, ''yyyy-MM-dd''))
		END AS AggPosReferenceName,
        STRING_AGG(CAST(AligneHeader.Aligne_Raw_Trade_Header_ID as nvarchar(max)), '','') AS ContributingTradeHeaderIds,
		AligneHeader.TradeType as TradeType,
        AligneHeader.TransactionType as TransactionType,
        AligneHeader.Entity as Entity,
		NomDef.Client_Name as ClientName,
		ISNULL(NomMappingPC.MappingOutputValue,ISNULL(NomMappingCP.MappingOutputValue, AligneHeader.Counterparty)) AS Counterparty,
        ISNULL(NomMappingFM.MappingOutputValue, AligneHeader.FromMarketOperator) as FromMarketOperator,
		ISNULL(NomMappingTM.MappingOutputValue, AligneHeader.ToMarketOperator) as ToMarketOperator,
        AligneHeader.CapacityType as CapacityType,
        AligneHeader.CapacityIdentification as CapacityIdentification,
        AligneHeader.Interconnector as Interconnector
	  ,AligneHeader.[PWRNOMS_OVERRIDE_TYPE]
      ,AligneHeader.[PWRNOMS_OVERRIDE_INPUT]
      ,AligneHeader.[PWRNOMS_OVERRIDE_FREEFORM]
      ,AligneHeader.[AUX_SO_CPTY],
        SUM(AligneVolume.QH1) AS QH1,
        SUM(AligneVolume.QH2) AS QH2,
        SUM(AligneVolume.QH3) AS QH3,
        SUM(AligneVolume.QH4) AS QH4,
        SUM(AligneVolume.QH5) AS QH5,
        SUM(AligneVolume.QH6) AS QH6,
        SUM(AligneVolume.QH7) AS QH7,
        SUM(AligneVolume.QH8) AS QH8,
        SUM(AligneVolume.QH9) AS QH9,
        SUM(AligneVolume.QH10) AS QH10,
        SUM(AligneVolume.QH11) AS QH11,
        SUM(AligneVolume.QH12) AS QH12,
        SUM(AligneVolume.QH13) AS QH13,
        SUM(AligneVolume.QH14) AS QH14,
        SUM(AligneVolume.QH15) AS QH15,
        SUM(AligneVolume.QH16) AS QH16,
        SUM(AligneVolume.QH17) AS QH17,
        SUM(AligneVolume.QH18) AS QH18,
        SUM(AligneVolume.QH19) AS QH19,
        SUM(AligneVolume.QH20) AS QH20,
        SUM(AligneVolume.QH21) AS QH21,
        SUM(AligneVolume.QH22) AS QH22,
        SUM(AligneVolume.QH23) AS QH23,
        SUM(AligneVolume.QH24) AS QH24,
        SUM(AligneVolume.QH25) AS QH25,
        SUM(AligneVolume.QH26) AS QH26,
        SUM(AligneVolume.QH27) AS QH27,
        SUM(AligneVolume.QH28) AS QH28,
        SUM(AligneVolume.QH29) AS QH29,
        SUM(AligneVolume.QH30) AS QH30,
        SUM(AligneVolume.QH31) AS QH31,
        SUM(AligneVolume.QH32) AS QH32,
        SUM(AligneVolume.QH33) AS QH33,
        SUM(AligneVolume.QH34) AS QH34,
        SUM(AligneVolume.QH35) AS QH35,
        SUM(AligneVolume.QH36) AS QH36,
        SUM(AligneVolume.QH37) AS QH37,
        SUM(AligneVolume.QH38) AS QH38,
        SUM(AligneVolume.QH39) AS QH39,
        SUM(AligneVolume.QH40) AS QH40,
        SUM(AligneVolume.QH41) AS QH41,
        SUM(AligneVolume.QH42) AS QH42,
        SUM(AligneVolume.QH43) AS QH43,
        SUM(AligneVolume.QH44) AS QH44,
        SUM(AligneVolume.QH45) AS QH45,
        SUM(AligneVolume.QH46) AS QH46,
        SUM(AligneVolume.QH47) AS QH47,
        SUM(AligneVolume.QH48) AS QH48,
        SUM(AligneVolume.QH49) AS QH49,
        SUM(AligneVolume.QH50) AS QH50,
        SUM(AligneVolume.QH51) AS QH51,
        SUM(AligneVolume.QH52) AS QH52,
        SUM(AligneVolume.QH53) AS QH53,
        SUM(AligneVolume.QH54) AS QH54,
        SUM(AligneVolume.QH55) AS QH55,
        SUM(AligneVolume.QH56) AS QH56,
        SUM(AligneVolume.QH57) AS QH57,
        SUM(AligneVolume.QH58) AS QH58,
        SUM(AligneVolume.QH59) AS QH59,
        SUM(AligneVolume.QH60) AS QH60,
        SUM(AligneVolume.QH61) AS QH61,
        SUM(AligneVolume.QH62) AS QH62,
        SUM(AligneVolume.QH63) AS QH63,
        SUM(AligneVolume.QH64) AS QH64,
        SUM(AligneVolume.QH65) AS QH65,
        SUM(AligneVolume.QH66) AS QH66,
        SUM(AligneVolume.QH67) AS QH67,
        SUM(AligneVolume.QH68) AS QH68,
        SUM(AligneVolume.QH69) AS QH69,
        SUM(AligneVolume.QH70) AS QH70,
        SUM(AligneVolume.QH71) AS QH71,
        SUM(AligneVolume.QH72) AS QH72,
        SUM(AligneVolume.QH73) AS QH73,
        SUM(AligneVolume.QH74) AS QH74,
        SUM(AligneVolume.QH75) AS QH75,
        SUM(AligneVolume.QH76) AS QH76,
        SUM(AligneVolume.QH77) AS QH77,
        SUM(AligneVolume.QH78) AS QH78,
        SUM(AligneVolume.QH79) AS QH79,
        SUM(AligneVolume.QH80) AS QH80,
        SUM(AligneVolume.QH81) AS QH81,
        SUM(AligneVolume.QH82) AS QH82,
        SUM(AligneVolume.QH83) AS QH83,
        SUM(AligneVolume.QH84) AS QH84,
        SUM(AligneVolume.QH85) AS QH85,
        SUM(AligneVolume.QH86) AS QH86,
        SUM(AligneVolume.QH87) AS QH87,
        SUM(AligneVolume.QH88) AS QH88,
        SUM(AligneVolume.QH89) AS QH89,
        SUM(AligneVolume.QH90) AS QH90,
        SUM(AligneVolume.QH91) AS QH91,
        SUM(AligneVolume.QH92) AS QH92,
        SUM(AligneVolume.QH93) AS QH93,
        SUM(AligneVolume.QH94) AS QH94,
        SUM(AligneVolume.QH95) AS QH95,
        SUM(AligneVolume.QH96) AS QH96
    FROM 
        MappedRawTrades AligneHeader
    INNER JOIN [dbo].[SNE_Aligne_raw_Trade_volume] AligneVolume ON AligneHeader.Aligne_Raw_Trade_Header_ID = AligneVolume.Aligne_Raw_Trade_Header_ID
	INNER JOIN [dbo].[SNE_NOMINATION_DEFINITION] NomDef ON NomDef.Nomination_Definition_ID = @NominationDefinitionId
	INNER JOIN [dbo].[SNE_TIMEZONE] tz ON NomDef.TimeZone_ID=tz.TimeZone_ID
	LEFT JOIN NominationMappings NomMappingFM ON AligneHeader.FromMarketOperator = NomMappingFM.MappingInputValue AND NomMappingFM.MappingInputField = ''FROMMARKETOPERATOR''
	LEFT JOIN NominationMappings NomMappingTM ON AligneHeader.ToMarketOperator = NomMappingTM.MappingInputValue AND PARSENAME(NomMappingTM.MappingInputField, 1) = ''ToMarketOperator''
	LEFT JOIN NominationMultipleMappings MM ON AligneHeader.PRODCON = MM.VALUE_1 AND AligneHeader.COUNTERPARTY=MM.VALUE_2
	LEFT JOIN NominationMappings NomMappingCP ON AligneHeader.Counterparty = NomMappingCP.MappingInputValue AND PARSENAME(NomMappingCP.MappingInputField, 1) = ''Counterparty'' and NomMappingCP.Mapping_Id <> MM.MAPPING_ID
	LEFT JOIN NominationMappings NomMappingPC ON AligneHeader.PRODCON = NomMappingPC.MappingInputValue AND PARSENAME(NomMappingPC.MappingInputField, 1) = ''PRODCON'' AND NomMappingPC.Mapping_Id = MM.MAPPING_ID
    WHERE
	AligneHeader.Batch_Run_Id=@NominationRunId 
    AND (NOT EXISTS (SELECT TradeType FROM FilterCriteria where TradeType is not null) OR AligneHeader.TradeType IN (SELECT TradeType from FilterCriteria)) 
		AND (NOT EXISTS (SELECT FromMarketOperator FROM FilterCriteria where FromMarketOperator is not null) OR AligneHeader.FromMarketOperator IN (SELECT FromMarketOperator from FilterCriteria)) 
		AND (NOT EXISTS (SELECT ToMarketOperator FROM FilterCriteria where ToMarketOperator is not null) OR AligneHeader.ToMarketOperator IN (SELECT ToMarketOperator from FilterCriteria)) 
		AND (NOT EXISTS (SELECT Entity FROM FilterCriteria where Entity is not null) OR AligneHeader.Entity IN (SELECT Entity from FilterCriteria) )
		AND (NOT EXISTS (SELECT Counterparty FROM FilterCriteria where Counterparty is not null) OR AligneHeader.Counterparty IN (SELECT Counterparty from FilterCriteria))
		
		AND (NOT EXISTS (SELECT CapacityType FROM FilterCriteria where CapacityType is not null) OR AligneHeader.CapacityType IN (SELECT CapacityType from FilterCriteria)) 
		AND (NOT EXISTS (SELECT CapacityIdentification FROM FilterCriteria where CapacityIdentification is not null) OR AligneHeader.CapacityIdentification IN (SELECT CapacityIdentification from FilterCriteria)) 
		AND (NOT EXISTS (SELECT Interconnector FROM FilterCriteria where Interconnector is not null) OR AligneHeader.Interconnector IN (SELECT Interconnector from FilterCriteria)) 
		AND (NOT EXISTS (SELECT Reference FROM FilterCriteria where Reference is not null) OR AligneHeader.Reference IN (SELECT Reference from FilterCriteria)) 
	GROUP BY 
        CASE WHEN AligneHeader.TradeType = ''PW_TRANS''
		THEN
		CONCAT(AligneHeader.Entity, ''_'', Left(AligneHeader.FromMarketOperator,6),''.'',Left(AligneHeader.ToMarketOperator,6), ''_'', FORMAT(@DeliveryDate, ''yyyy-MM-dd''),''_'',AligneHeader.Reference)
		ELSE
        CONCAT(AligneHeader.TransactionType, ''_'', AligneHeader.Entity, ''_'', AligneHeader.Counterparty, ''_'', AligneHeader.FromMarketOperator, ''_'', FORMAT(@DeliveryDate, ''yyyy-MM-dd''))
		END,
		CASE WHEN AligneHeader.TradeType = ''PW_TRANS''
		THEN
		AligneHeader.Reference
		ELSE
        NULL
		END,
        NomDef.Nomination_Definition_Name,
        AligneHeader.TransactionType,
        AligneHeader.Entity,
		NomDef.Client_Name,
        AligneHeader.Counterparty,
        AligneHeader.FromMarketOperator,
        AligneHeader.TradeType,
		AligneHeader.DeliveryDate,
        AligneHeader.ToMarketoperator,
        AligneHeader.CapacityType,
        AligneHeader.CapacityIdentification,
        AligneHeader.Interconnector,
		NomMappingFM.MappingOutputValue,
		NomMappingTM.MappingOutputValue,
		NomMappingCP.MappingOutputValue,
		tz.TimeZone_Name
		,AligneHeader.[PWRNOMS_OVERRIDE_TYPE]
      ,AligneHeader.[PWRNOMS_OVERRIDE_INPUT]
      ,AligneHeader.[PWRNOMS_OVERRIDE_FREEFORM]
      ,AligneHeader.[AUX_SO_CPTY]
	  ,NomMappingPC.MappingOutputValue
		)

		SELECT 
	NominationRunId,
	NominationDefinitionId,
	NominationDefinitionName,
	TimeZone,
	DeliveryDate,
	AggPosReferenceId,
	AggPosReferenceName,
	ContributingTradeHeaderIds,
	TradeType,
	TransactionType,
	@Granularity AS Granularity,
	Entity,
	ClientName,
	Counterparty,
	FromMarketOperator,
	ToMarketOperator,
	CapacityType,
	CapacityIdentification,
	Interconnector
	,[PWRNOMS_OVERRIDE_TYPE]
    ,[PWRNOMS_OVERRIDE_INPUT]
    ,[PWRNOMS_OVERRIDE_FREEFORM]
    ,[AUX_SO_CPTY]'

	DECLARE @ret NVARCHAR(MAX)
	EXEC @ret = dbo.udf_GenerateQuantityBasedOnGranularity @Granularity = @Granularity
	
	SET @sql= @sql+ @ret
	INSERT INTO #TempCptyAggregation
	EXEC sp_executesql @sql ,N'@NominationRunId INT, @NominationDefinitionId INT, @DeliveryDate DATE, @Granularity INT', @NominationRunId,@NominationDefinitionId, @DeliveryDate, @Granularity

	DECLARE @LastNomRunId INT;

    -- Get the last run id with the same Nomination_Definition_Id and Delivery_Date
    SELECT TOP 1
        @LastNomRunId = Nomination_Run_ID
    FROM [dbo].[SNE_NOMINATION_BATCH_RUN]
    WHERE Nomination_Definition_Id = @NominationDefinitionId
      AND Delivery_Date = @DeliveryDate
      AND Nomination_Run_ID < @NominationRunId
	  AND Correlation_ID <>''
    ORDER BY Nomination_Run_ID DESC;
	
    -- Get the previous agg_pos_references
	Insert into #TempPrevCptyAggregation 
    SELECT
        aggPosRef.AGG_POS_REFERENCE,
		aggPosRef.Agg_Pos_Reference_ID,
        aggPosRef.Nomination_Run_ID
    FROM [dbo].[SNE_AGG_POS_REFERENCE] aggPosRef
	WHERE Nomination_Run_ID = @LastNomRunId;

	--Insert into temp table all the missing counterparty aggregations
	IF EXISTS (
	SELECT 1
	FROM #TempPrevCptyAggregation prevCptyAgg
	WHERE NOT EXISTS (
		SELECT 1
		FROM #TempCptyAggregation cptyAgg
		WHERE prevCptyAgg.AGG_POS_REFERENCE = cptyAgg.AggPosReferenceName
		)
	)
	BEGIN	
		INSERT INTO #TempCptyAggregation (NominationRunId,NominationDefinitionId,NominationDefinitionName,
		TimeZone,DeliveryDate,AggPosReferenceId,AggPosReferenceName,TradeType,TransactionType,Entity,ClientName,
		ContributingTradeHeaderIds,Granularity,Counterparty,FromMarketOperator,ToMarketOperator,CapacityType,CapacityIdentification,Interconnector,
		QH1, QH2, QH3, QH4, QH5, QH6, QH7, QH8, QH9, QH10,
		QH11, QH12, QH13, QH14, QH15, QH16, QH17, QH18, QH19, QH20,
		QH21, QH22, QH23, QH24, QH25, QH26, QH27, QH28, QH29, QH30,
		QH31, QH32, QH33, QH34, QH35, QH36, QH37, QH38, QH39, QH40,
		QH41, QH42, QH43, QH44, QH45, QH46, QH47, QH48, QH49, QH50,
		QH51, QH52, QH53, QH54, QH55, QH56, QH57, QH58, QH59, QH60,
		QH61, QH62, QH63, QH64, QH65, QH66, QH67, QH68, QH69, QH70,
		QH71, QH72, QH73, QH74, QH75, QH76, QH77, QH78, QH79, QH80,
		QH81, QH82, QH83, QH84, QH85, QH86, QH87, QH88, QH89, QH90,
		QH91, QH92, QH93, QH94, QH95, QH96)
		SELECT 
		@NominationRunId,
		@NominationDefinitionId,
		NomDef.Nomination_Definition_Name,
		tz.TimeZone_Name,
		@DeliveryDate,
		-1,
		prevCptyAgg.AGG_POS_REFERENCE,
		tradetype.Trade_Type_Name,
		TransactionType.Transaction_Type_Name,
		Entity.Entity_Name,
		NomDef.Client_Name,
		'',
		@Granularity,
		Counterparty.Counterparty_Name,
		FromMarketOperator.Marketoperator_Name,
		ToMarketOperator.Marketoperator_Name,
		aggPosRefHeader.Capacity_Type,
		aggPosRefHeader.Capacity_Identification,
		aggPosRefHeader.Interconnector,
		0,0,0,0,0,0,0,0,0,0,
		0,0,0,0,0,0,0,0,0,0,
		0,0,0,0,0,0,0,0,0,0,
		0,0,0,0,0,0,0,0,0,0,
		0,0,0,0,0,0,0,0,0,0,
		0,0,0,0,0,0,0,0,0,0,
		0,0,0,0,0,0,0,0,0,0,
		0,0,0,0,0,0,0,0,0,0,
		0,0,0,0,0,0,0,0,0,0,
		0,0,0,0,0,0
		FROM #TempPrevCptyAggregation prevCptyAgg
		INNER JOIN [dbo].[SNE_NOMINATION_DEFINITION] NomDef ON NomDef.Nomination_Definition_ID = @NominationDefinitionId
		INNER JOIN [dbo].[SNE_TIMEZONE] tz ON NomDef.TimeZone_ID=tz.TimeZone_ID
		INNER JOIN [dbo].[SNE_COUNTERPARTY_POSAGG_HEADER] aggPosRefHeader ON prevCptyAgg.Agg_Pos_Reference_ID=aggPosRefHeader.Agg_Pos_Reference_ID
		INNER JOIN [dbo].[SNE_TRADETYPE] tradetype ON tradetype.Trade_Type_ID=aggPosRefHeader.Trade_Type_ID
		INNER JOIN [dbo].[SNE_TRANSACTIONTYPE] TransactionType ON aggPosRefHeader.Transaction_Type_ID = TransactionType.Transaction_Type_ID
		INNER JOIN [dbo].[SNE_ENTITY] Entity ON aggPosRefHeader.Entity_ID = Entity.Entity_ID
		INNER JOIN [dbo].[SNE_COUNTERPARTY] Counterparty ON aggPosRefHeader.Counterparty_ID = Counterparty.Counterparty_ID
		INNER JOIN [dbo].[SNE_MARKETOPERATOR] FromMarketOperator ON aggPosRefHeader.From_Marketoperator_ID = FromMarketOperator.Marketoperator_ID
		LEFT JOIN [dbo].[SNE_MARKETOPERATOR] ToMarketOperator ON aggPosRefHeader.To_Marketoperator_ID = ToMarketOperator.Marketoperator_ID AND aggPosRefHeader.To_Marketoperator_ID <> ''
    
		WHERE NOT EXISTS (
			SELECT 1
			FROM #TempCptyAggregation cptyAgg
			WHERE prevCptyAgg.AGG_POS_REFERENCE = cptyAgg.AggPosReferenceName
		);
	END

	SELECT NominationRunId,NominationDefinitionId,NominationDefinitionName,TimeZone,DeliveryDate,AggPosReferenceId,AggPosReferenceName,
	ContributingTradeHeaderIds,TradeType,TransactionType,Granularity,Entity,ClientName,Counterparty,FromMarketOperator,ToMarketOperator,
	CapacityType,CapacityIdentification,Interconnector,PWRNOMS_OVERRIDE_TYPE,PWRNOMS_OVERRIDE_INPUT,PWRNOMS_OVERRIDE_FREEFORM,AUX_SO_CPTY,
	QH1,QH2,QH3,QH4,QH5,QH6,QH7,QH8,QH9,QH10,QH11,QH12,QH13,QH14,QH15,QH16,QH17,QH18,QH19,QH20,QH21,QH22,QH23,QH24,QH25,QH26,QH27,QH28,QH29,
	QH30,QH31,QH32,QH33,QH34,QH35,QH36,QH37,QH38,QH39,QH40,QH41,QH42,QH43,QH44,QH45,QH46,QH47,QH48,QH49,QH50,QH51,QH52,QH53,QH54,QH55,QH56,
	QH57,QH58,QH59,QH60,QH61,QH62,QH63,QH64,QH65,QH66,QH67,QH68,QH69,QH70,QH71,QH72,QH73,QH74,QH75,QH76,QH77,QH78,QH79,QH80,QH81,QH82,QH83,
	QH84,QH85,QH86,QH87,QH88,QH89,QH90,QH91,QH92,QH93,QH94,QH95,QH96 
	FROM #TempCptyAggregation
END


