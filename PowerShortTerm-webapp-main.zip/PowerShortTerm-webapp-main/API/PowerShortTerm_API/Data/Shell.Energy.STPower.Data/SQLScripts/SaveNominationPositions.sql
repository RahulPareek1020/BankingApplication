﻿/****** Object:  StoredProcedure [dbo].[SaveNominationPositions]    Script Date: 27/01/2025 14:19:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER   PROCEDURE [dbo].[SaveNominationPositions]
	@NominationDetails [dbo].[NominationDetailsDtoType] READONLY
AS
BEGIN  

	-- Step 1: Extract the top row from the table-valued parameter
	DECLARE @NominationDefinitionId INT;
	DECLARE @NominationBatchRunId INT;
	DECLARE @DeliveryDate DATETIME;

	SELECT TOP 1
		@NominationBatchRunId = NominationRunId,
		@NominationDefinitionId = NominationDefinitionId,
		@DeliveryDate = DeliveryDate
	FROM @NominationDetails;

    -- Step 2: Insert new entries into SNE_AGG_POS_REFERENCE and capture the generated IDs
    CREATE TABLE #AggPosReferenceIds (
        AggPosReferenceId INT,
        AggPosReferenceName NVARCHAR(255)
    );
	INSERT INTO SNE_AGG_POS_REFERENCE (Agg_Pos_Reference, Created_Date, Nomination_Run_Id)
    OUTPUT INSERTED.Agg_Pos_Reference_Id, INSERTED.Agg_Pos_Reference INTO #AggPosReferenceIds (AggPosReferenceId, AggPosReferenceName)
    SELECT DISTINCT AggPosReferenceName, GETDATE(), @NominationBatchRunId
    FROM @NominationDetails;

	-- Step 3: Insert new counterparty to master table
	INSERT INTO [dbo].[SNE_COUNTERPARTY] (Counterparty_Name)
    SELECT DISTINCT Counterparty
    FROM @NominationDetails
    WHERE Counterparty NOT IN (SELECT Counterparty_Name FROM SNE_Counterparty);

-- Step 4: Insert new entries into COUNTERPARTY_POSAGG_HEADER
	INSERT INTO SNE_COUNTERPARTY_POSAGG_HEADER (Trade_Type_Id, Transaction_Type_Id, Entity_ID, Counterparty_ID, From_MarketOperator_ID, To_MarketOperator_ID, Capacity_Type, Capacity_Identification, Interconnector, Delivery_Date, Granularity_ID, Agg_Pos_Reference_Id)
	SELECT TradeType.Trade_type_id, TransactionType.Transaction_Type_Id, Entity.Entity_ID, Counterparty.Counterparty_Id, FromMarketOperator.Marketoperator_Id, 
		   ISNULL(ToMarketOperator.Marketoperator_Id, FromMarketOperator.Marketoperator_Id), NomDet.CapacityType, NomDet.CapacityIdentification, NomDet.Interconnector, 
		   NomDet.DeliveryDate, Granularity.Granularity_Id, ar.AggPosReferenceId
	FROM @NominationDetails NomDet
	INNER JOIN #AggPosReferenceIds ar ON NomDet.AggPosReferenceName = ar.AggPosReferenceName
	INNER JOIN SNE_Tradetype TradeType ON NomDet.TradeType = TradeType.Trade_type_Name
	INNER JOIN SNE_Transactiontype TransactionType ON NomDet.TransactionType = TransactionType.Transaction_Type_Name
	INNER JOIN SNE_Granularity Granularity ON NomDet.granularity = Granularity.Granularity_Value
	INNER JOIN SNE_Entity Entity ON NomDet.Entity = Entity.Entity_Name
	INNER JOIN SNE_Counterparty Counterparty ON NomDet.Counterparty = Counterparty.Counterparty_Name
	INNER JOIN SNE_MarketOperator FromMarketOperator ON NomDet.FromMarketOperator = FromMarketOperator.Marketoperator_Name
	LEFT JOIN SNE_MarketOperator ToMarketOperator ON NomDet.ToMarketOperator = ToMarketOperator.Marketoperator_Name AND NomDet.ToMarketOperator <> ''

    -- Step 5: Insert new entries into COUNTERPARTY_POSAGG_VOLUME
    INSERT INTO SNE_COUNTERPARTY_POSAGG_VOLUME (Agg_Pos_Reference_Id, QH1, QH2, QH3, QH4, QH5, QH6, QH7, QH8, QH9, QH10, QH11, QH12, QH13, QH14, QH15, QH16, QH17, QH18, QH19, QH20, QH21, QH22, QH23, QH24, QH25, QH26, QH27, QH28, QH29, QH30, QH31, QH32, QH33, QH34, QH35, QH36, QH37, QH38, QH39, QH40, QH41, QH42, QH43, QH44, QH45, QH46, QH47, QH48, QH49, QH50, QH51, QH52, QH53, QH54, QH55, QH56, QH57, QH58, QH59, QH60, QH61, QH62, QH63, QH64, QH65, QH66, QH67, QH68, QH69, QH70, QH71, QH72, QH73, QH74, QH75, QH76, QH77, QH78, QH79, QH80, QH81, QH82, QH83, QH84, QH85, QH86, QH87, QH88, QH89, QH90, QH91, QH92, QH93, QH94, QH95, QH96,QH97,QH98,QH99,QH100)
    SELECT ar.AggPosReferenceId, NomDet.QH1, NomDet.QH2, NomDet.QH3, NomDet.QH4, NomDet.QH5, NomDet.QH6, NomDet.QH7, NomDet.QH8, NomDet.QH9, NomDet.QH10, NomDet.QH11, NomDet.QH12, NomDet.QH13, NomDet.QH14, NomDet.QH15, NomDet.QH16, NomDet.QH17, NomDet.QH18, NomDet.QH19, NomDet.QH20, NomDet.QH21, NomDet.QH22, NomDet.QH23, NomDet.QH24, NomDet.QH25, NomDet.QH26, NomDet.QH27, NomDet.QH28, NomDet.QH29, NomDet.QH30, NomDet.QH31, NomDet.QH32, NomDet.QH33, NomDet.QH34, NomDet.QH35, NomDet.QH36, NomDet.QH37, NomDet.QH38, NomDet.QH39, NomDet.QH40, NomDet.QH41, NomDet.QH42, NomDet.QH43, NomDet.QH44, NomDet.QH45, NomDet.QH46, NomDet.QH47, NomDet.QH48, NomDet.QH49, NomDet.QH50, NomDet.QH51, NomDet.QH52, NomDet.QH53, NomDet.QH54, NomDet.QH55, NomDet.QH56, NomDet.QH57, NomDet.QH58, NomDet.QH59, NomDet.QH60, NomDet.QH61, NomDet.QH62, NomDet.QH63, NomDet.QH64, NomDet.QH65, NomDet.QH66, NomDet.QH67, NomDet.QH68, NomDet.QH69, NomDet.QH70, NomDet.QH71, NomDet.QH72, NomDet.QH73, NomDet.QH74, NomDet.QH75, NomDet.QH76, NomDet.QH77, NomDet.QH78, NomDet.QH79, NomDet.QH80, NomDet.QH81, NomDet.QH82, NomDet.QH83, NomDet.QH84, NomDet.QH85, NomDet.QH86,NomDet.QH87,NomDet.QH88,NomDet.QH89,NomDet.QH90,NomDet.QH91, NomDet.QH92,NomDet.QH93,NomDet.QH94,NomDet.QH95,NomDet.QH96, NomDet.QH97,NomDet.QH98,NomDet.QH99,NomDet.QH100
	FROM @NominationDetails NomDet
	INNER JOIN #AggPosReferenceIds ar ON NomDet.AggPosReferenceName = ar.AggPosReferenceName

    -- Step 6: Insert new entries into SNE_AGG_POS_REFERENCE_TRADE_MAP
	INSERT INTO SNE_AGG_POS_REFERENCE_TRADE_MAP (Agg_Pos_Reference_ID, RawTrade_Header_ID)
    SELECT 
        ar.AggPosReferenceId,
        TRIM(value) AS RawTradeHeaderId
    FROM @NominationDetails NomDet
	CROSS APPLY STRING_SPLIT(ContributingTradeHeaderIds, ',')
	JOIN #AggPosReferenceIds ar ON NomDet.AggPosReferenceName = ar.AggPosReferenceName;

	-- Step 7: Insert new entries into SNE_AGG_POS_REFERENCE_STATUS
	INSERT INTO [dbo].[SNE_AGG_POS_REFERENCE_STATUS] (Agg_Pos_Reference_ID,Nomination_Run_ID)
	SELECT ar.AggPosReferenceId, @NominationBatchRunId
	FROM #AggPosReferenceIds ar;

	DROP TABLE #AggPosReferenceIds;

	SELECT @NominationBatchRunId as NominationRunId;
END
