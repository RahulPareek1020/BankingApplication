﻿
Update [dbo].[SNE_NOMINATION_DEFINITION] set TimeZone_ID=1