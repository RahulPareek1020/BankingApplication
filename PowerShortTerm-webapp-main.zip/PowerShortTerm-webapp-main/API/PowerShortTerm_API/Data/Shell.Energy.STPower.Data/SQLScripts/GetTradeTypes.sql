﻿/****** Object:  StoredProcedure [dbo].[GetTradeTypes]    Script Date: 21/01/2025 09:50:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER PROCEDURE [dbo].[GetTradeTypes]
    @NominationDefinitionId INT,
    @DeliveryDate DATE
AS
BEGIN
    DECLARE @TradeTypes NVARCHAR(MAX);

    -- Get the data from tradetype table
    SELECT @TradeTypes = STRING_AGG(tradeType.Trade_Type_Name, ',')
    FROM SNE_TRADETYPE tradeType
    INNER JOIN SNE_Nomination_Batch_Definition def ON def.Nomination_Batch_Filter_Value = tradeType.Trade_Type_ID
    WHERE def.Nomination_Definition_ID = @NominationDefinitionId
      AND def.Nomination_Batch_Filter_Type_ID = 1
      AND def.Include = 1
      AND @DeliveryDate BETWEEN def.StartDate AND def.EndDate;

    -- If no data is returned, get all tradetypes
    IF @TradeTypes IS NULL
    BEGIN
        SELECT @TradeTypes = STRING_AGG(tradeType.Trade_Type_Name, ',')
        FROM SNE_TRADETYPE tradeType;
    END

    -- Return the result
    SELECT @TradeTypes AS TradeTypes;
END