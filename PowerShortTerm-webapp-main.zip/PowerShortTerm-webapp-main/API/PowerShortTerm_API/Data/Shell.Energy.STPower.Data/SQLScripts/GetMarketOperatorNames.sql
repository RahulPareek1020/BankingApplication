﻿/****** Object:  StoredProcedure [dbo].[GetMarketOperatorNames]    Script Date: 21/01/2025 09:49:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER PROCEDURE [dbo].[GetMarketOperatorNames]
    @NominationDefinitionId INT,
    @DeliveryDate DATE
AS
BEGIN
    DECLARE @FromMarketOperatorNames NVARCHAR(MAX);
    DECLARE @ToMarketOperatorNames NVARCHAR(MAX);

    -- Get the distinct data from market operator table
    SELECT @FromMarketOperatorNames = STRING_AGG(m.MarketOperator_Name, ',')
    FROM (
        SELECT DISTINCT m.MarketOperator_Name
        FROM SNE_MarketOperator m
        INNER JOIN SNE_Nomination_Batch_Definition def ON def.Nomination_Batch_Filter_Value = m.MarketOperator_ID
        WHERE def.Nomination_Definition_ID = @NominationDefinitionId
          AND def.Nomination_Batch_Filter_Type_ID = 2
          AND def.Include = 1
          AND @DeliveryDate BETWEEN def.StartDate AND def.EndDate
    ) m;

    -- Get the distinct data from market operator table
    SELECT @ToMarketOperatorNames = STRING_AGG(m.MarketOperator_Name, ',')
    FROM (
        SELECT DISTINCT m.MarketOperator_Name
        FROM SNE_MarketOperator m
        INNER JOIN SNE_Nomination_Batch_Definition def ON def.Nomination_Batch_Filter_Value = m.MarketOperator_ID
        WHERE def.Nomination_Definition_ID = @NominationDefinitionId
          AND def.Nomination_Batch_Filter_Type_ID = 3
          AND def.Include = 1
          AND @DeliveryDate BETWEEN def.StartDate AND def.EndDate
    ) m;

    -- Return the result
    SELECT @FromMarketOperatorNames AS FromMarketOperators, @ToMarketOperatorNames AS ToMarketOperators;
END
