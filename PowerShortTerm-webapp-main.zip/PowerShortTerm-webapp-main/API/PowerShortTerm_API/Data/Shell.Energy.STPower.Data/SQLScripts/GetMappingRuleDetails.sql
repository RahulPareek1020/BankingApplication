﻿/****** Object:  StoredProcedure [dbo].[GetMappingRuleDetails]    Script Date: 12/11/2024 17:48:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER   PROCEDURE [dbo].[GetMappingRuleDetails]
AS
BEGIN
	Select 
	mapmaster.Mapping_ID as MappingMasterId,
	mapMaster.Mapping_Name as MappingMasterName,
	maptype.mapping_type_id as MappingTypeId,
	mapMaster.Created_Date as MappingMasterCreatedDate,
    mapMaster.Modified_Date as MappingMasterModifiedDate,
    mapMaster.Status as MappingMasterStatus,
	nomrulemap.Nomination_Definition_ID as NominationDefinitionId,
	nomdef.Nomination_Definition_Name as NominationDefinitionName,
	maptype.Mapping_Type_Name as MappingTypeName,
	maptype.Created_Date as MappingTypeCreatedDate,
	maptype.Modified_Date as MappingTypeModifiedDate,
	maptype.Status as MappingTypeStatus,
	mapinput.Mapping_INPUT_ID as MappingInputId,
	mapinput.Input_Field as MappingInputField,
	mapinput.Input_Value as MappingInputValue,
	mapinput.Start_Date as MappingInputStartDate,
	mapinput.End_Date as MappingInputEndDate,
	mapinput.Created_Date as MappingInputCreatedDate,
	mapinput.Modified_Date as MappingInputModifiedDate,
	mapinput.Status as MappingInputStatus,
	mapOutput.Mapping_Output_ID as MappingOutputId,
	mapOutput.OutputValue as MappingOutputValue,
	mapOutput.Start_Date as MappingOutputStartDate,
	mapOutput.End_Date as MappingOutputEndDate,
	mapOutput.Created_Date as MappingOutputCreatedDate,
	mapOutput.Modified_Date as MappingOutputModifiedDate,
	mapOutput.Status as MappingOutputStatus
	FROM [dbo].[SNE_MAPPING_RULES_MASTER] mapmaster
	INNER JOIN [dbo].[SNE_NOM_DEF_MAPPING_RULES_ASSOCIATION] nomrulemap ON mapmaster.Mapping_ID=nomrulemap.Mapping_ID
	INNER JOIN [dbo].[SNE_NOMINATION_DEFINITION] nomdef ON nomdef.Nomination_Definition_ID=nomrulemap.Nomination_Definition_ID
	INNER JOIN  [dbo].[SNE_MAPPING_RULES_TYPE] maptype ON maptype.Mapping_Type_Id=mapmaster.Mapping_Type_Id
	INNER JOIN [dbo].[SNE_MAPPING_RULES_INPUT] mapinput ON mapinput.Mapping_ID=mapmaster.Mapping_ID
	INNER JOIN [dbo].[SNE_MAPPING_RULES_OUTPUT] mapoutput ON mapoutput.Mapping_Input_ID=mapinput.Mapping_Input_ID
END
