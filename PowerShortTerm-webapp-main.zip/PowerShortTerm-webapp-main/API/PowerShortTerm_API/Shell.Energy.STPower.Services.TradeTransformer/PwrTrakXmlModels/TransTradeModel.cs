﻿using Shell.Energy.STPower.Services.TradeTransformer.Interfaces;

namespace Shell.Energy.STPower.Services.TradeTransformer.PwrTrakXmlModels
{
    /// <summary>
    /// Model class for Power Trade
    /// </summary>
    public class TransTradeModel : TradeModelBase
    {
        public required string MarketOperator { get; set; }
        public required string FromMarketOperator { get; set; }
        public required string ToMarketOperator { get; set; }
        public required CustomShape CustomShape { get; set; }
        public required string CapacityType { get; set; }
        public required string CapacityIdentification { get; set; }
        
    }
}
