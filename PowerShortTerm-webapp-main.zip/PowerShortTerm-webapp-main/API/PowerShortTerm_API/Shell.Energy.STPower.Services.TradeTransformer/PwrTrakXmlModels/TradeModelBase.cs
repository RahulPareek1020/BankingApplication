﻿namespace Shell.Energy.STPower.Services.TradeTransformer.Interfaces
{
    public abstract class TradeModelBase
    {
        public required string Reference { get; set; }
    }
}
