﻿using Shell.Energy.STPower.Services.TradeTransformer.Interfaces;
using System.Xml.Serialization;

namespace Shell.Energy.STPower.Services.TradeTransformer.PwrTrakXmlModels;

/// <summary>
/// Model class for Power Trade
/// </summary>
public class PowerTradeModel :TradeModelBase
{
    public required string TransactionType { get; set; }
    public required string Counterparty { get; set; }
    public required string MarketOperator { get; set; }
    public required CustomShape CustomShape { get; set; }
    public required string TradeDate { get; set; }
}

/// <summary>
/// Class for Custom Shape
/// </summary>
public class CustomShape
{
    [XmlElement("Interval")]
    public List<Interval> Interval { get; set; }
}

/// <summary>
/// Class for Interval
/// </summary>
public class Interval
{
    public DateTime StartDateTime { get; set; }
    public DateTime EndDateTime { get; set; }
    public double Volume { get; set; }
}
