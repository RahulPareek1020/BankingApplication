﻿using Shell.Energy.STPower.Services.TradeTransformer.Interfaces;
using System.Xml.Serialization;

namespace Shell.Energy.STPower.Services.TradeTransformer.PwrTrakXmlModels;

/// <summary>
/// Model class for PowerTrak trade XML
/// </summary>
[XmlRoot("PowerTrak")]
[XmlInclude(typeof(PowerTradeModel))]
[XmlInclude(typeof(TransTradeModel))]
public class PowerTrakModel
{
    [XmlAttribute("Client")]
    public required string Client { get; set; }

    [XmlArray("Trades")]
    [XmlArrayItem("Trade")]
    public List<TradeModelBase> Trades { get; set; } = new List<TradeModelBase>();
}
