﻿using Shell.Energy.STPower.Data.Dto;
using Shell.Energy.STPower.Services.TradeTransformer.DTO;
using Shell.Energy.STPower.Services.TradeTransformer.Interfaces;
using Shell.Energy.STPower.Services.TradeTransformer.PwrTrakXmlModels;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Enums;

namespace Shell.Energy.STPower.Services.TradeTransformer.TradeTransformers;

/// <summary>
/// Strategy class for transforming Power/Transmission Trade data
/// </summary>
public class PowerTransTradeTransformerStrategy : ITradeTransformerStrategy<IEnumerable<NominationDetailsDto>, PowerTrakTradeDto>
{
    /// <summary>
    /// Method to transform trade data
    /// </summary>
    /// <param name="tradeData"></param>
    /// <returns></returns>
    public List<PowerTrakTradeDto>? TransformTrade(IEnumerable<NominationDetailsDto> tradeInputData)
    {
        var aggPosDetailsList = tradeInputData.ToList();
        var powerTransTradeModelList = new List<PowerTrakTradeDto>(aggPosDetailsList.Count);
        foreach (var trade in aggPosDetailsList)
        {
            Granularity granularity = TradeHelper.GetGranularity(trade.Granularity);
            int dlsPeriodCount = TradeHelper.GetDLSPeriodCount(trade.DeliveryDate, granularity,trade.TimeZone);
            var utcDateTime = DateTimeHelper.ConvertToUtcFromTimeZone(trade.DeliveryDate, trade.TimeZone);
            var powerTransTradeModel = CreatePowertrakTrade(trade);
            var volumeArray = GetVolumeArray(trade, dlsPeriodCount);
            var customShape = new CustomShape() { Interval = new List<Interval>(dlsPeriodCount) };

            //Added interval variable to increment date time based on different granularity
            int interval = TradeHelper.GetIntervalCount(granularity);

            for (int i = 0; i < dlsPeriodCount; i++)
            {
                customShape.Interval.Add(new Interval()
                {
                    StartDateTime = utcDateTime.AddMinutes(interval * i),
                    EndDateTime = utcDateTime.AddMinutes(interval * (i + 1)),
                    Volume = Math.Abs(volumeArray[i])
                });
            }
            powerTransTradeModel.CustomShape = customShape;
            powerTransTradeModelList.Add(powerTransTradeModel);
        }
        return powerTransTradeModelList;
    }

    /// <summary>
    /// Get volume array
    /// </summary>
    /// <param name="trade"></param>
    /// <param name="periodCount"></param>
    /// <returns></returns>
    private static List<double> GetVolumeArray(NominationDetailsDto trade, int periodCount)
    {
        var volumeProperties = TradeHelper.GetVolumeProperties(trade, periodCount);
        return TradeHelper.GetVolumeArray(volumeProperties, trade);
    }

    /// <summary>
    /// Create PowerTrak trade object
    /// </summary>
    /// <param name="powerTrakTrade"></param>
    /// <returns></returns>
    private static PowerTrakTradeDto CreatePowertrakTrade(NominationDetailsDto aggPosData)
    {
        return new PowerTrakTradeDto()
        {
            FromMarketOperator = aggPosData.FromMarketOperator,
            ToMarketOperator = aggPosData.ToMarketOperator,
            TransactionType = aggPosData.TransactionType,
            Reference = aggPosData.AggPosReferenceName,
            TradeDate = aggPosData.DeliveryDate,
            Counterparty = aggPosData.Counterparty,
            Entity = aggPosData.Entity,
            ClientName = aggPosData.ClientName,
            Granularity = aggPosData.Granularity,
            TradeType = aggPosData.TradeType,
            CapacityType = aggPosData.CapacityType,
            CapacityIdentification = aggPosData.CapacityIdentification,
            Interconnector = aggPosData.Interconnector
        };
    }
}