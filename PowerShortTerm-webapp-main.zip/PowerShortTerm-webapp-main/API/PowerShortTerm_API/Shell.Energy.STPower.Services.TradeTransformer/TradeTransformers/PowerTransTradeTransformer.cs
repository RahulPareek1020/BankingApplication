﻿using Shell.Energy.STPower.Data.Dto;
using Shell.Energy.STPower.Services.TradeTransformer.DTO;
using Shell.Energy.STPower.Services.TradeTransformer.Interfaces;
using Shell.Energy.STPower.Shared;

namespace Shell.Energy.STPower.Services.TradeTransformer.TradeTransformers;

/// <summary>
/// The PowerTransTradeTransformer class is responsible for transforming power/transmission trade data.
/// </summary>
public class PowerTransTradeTransformer : IEtrmTradeTransformer
{
    private readonly PowerTransTradeTransformerStrategy _strategy;
    private readonly IAppLogger _logger;
    /// <summary>
    /// Initializes a new instance of the PowerTransTradeTransformerStrategy class.
    /// </summary>
    /// <param name="market">The market.</param>
    public PowerTransTradeTransformer()
    {
        _strategy = new PowerTransTradeTransformerStrategy();
    }

    /// <summary>
    /// Transforms the trade data.
    /// </summary>
    /// <param name="tradeData">The trade data in JSON format.</param>
    /// <returns>The transformed trade data in XML format.</returns>
    public List<PowerTrakTradeDto>? TransformTradeData(IEnumerable<NominationDetailsDto> cptyAggPositionData)
    {
        return _strategy.TransformTrade(cptyAggPositionData);
    }
}
