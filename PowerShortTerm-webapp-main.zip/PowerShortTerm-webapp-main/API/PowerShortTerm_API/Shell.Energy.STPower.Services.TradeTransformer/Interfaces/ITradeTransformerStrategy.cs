﻿namespace Shell.Energy.STPower.Services.TradeTransformer.Interfaces;

/// <summary>
/// Interface for Trade Transformer Strategy
/// </summary>
/// <typeparam name="Schema"></typeparam>
/// <typeparam name="Trade"></typeparam>
public interface ITradeTransformerStrategy<Schema, Trade>
{
    List<Trade> TransformTrade(Schema tradeInputData);
}
