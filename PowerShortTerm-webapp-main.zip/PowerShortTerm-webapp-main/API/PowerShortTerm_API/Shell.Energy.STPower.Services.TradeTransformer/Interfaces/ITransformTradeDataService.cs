﻿using Shell.Energy.STPower.Data.Dto;

namespace Shell.Energy.STPower.Services.TradeTransformer.Interfaces;

/// <summary>
/// Interface for Transform ETRM Data Service
/// </summary>
public interface ITransformTradeDataService
{
    string? ConvertTradeMessageToPowerTrakFormat(IEnumerable<NominationDetailsDto> cptyAggPositionData);
}
