﻿using Shell.Energy.STPower.Services.TradeTransformer.DTO;

namespace Shell.Energy.STPower.Services.TradeTransformer.Interfaces;

/// <summary>
/// Interface for PowerTrak XML Trade Mapper
/// </summary>
public interface IPowerTrakXmlTradeMapper
{
    string? MapPowerTrakContent(List<PowerTrakTradeDto> powerTrakTradeDTOs);
}