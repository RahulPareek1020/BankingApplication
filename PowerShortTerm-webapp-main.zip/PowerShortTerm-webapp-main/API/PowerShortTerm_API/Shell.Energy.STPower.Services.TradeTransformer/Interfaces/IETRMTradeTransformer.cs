﻿using Shell.Energy.STPower.Data.Dto;
using Shell.Energy.STPower.Services.TradeTransformer.DTO;

namespace Shell.Energy.STPower.Services.TradeTransformer.Interfaces;

/// <summary>
/// Interface for ETRM Trade Transformer
/// </summary>
public interface IEtrmTradeTransformer
{
    List<PowerTrakTradeDto>? TransformTradeData(IEnumerable<NominationDetailsDto> cptyAggPositionData);
}
