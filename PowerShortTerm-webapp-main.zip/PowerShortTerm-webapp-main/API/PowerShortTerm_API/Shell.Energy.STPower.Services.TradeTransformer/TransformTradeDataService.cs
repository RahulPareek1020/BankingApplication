﻿using Shell.Energy.STPower.Data.Dto;
using Shell.Energy.STPower.Services.TradeTransformer.Interfaces;
using Shell.Energy.STPower.Services.TradeTransformer.TradeTransformers;
using Shell.Energy.STPower.Services.TradeTransformer.XML;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Enums;
using Shell.Energy.STPower.Shared.Messages;

namespace Shell.Energy.STPower.Services.TradeTransformer;

/// <summary>
/// The TransformETRMDataService class is responsible for transforming ETRM data to PowerTrak XML format.
/// </summary>
public class TransformTradeDataService : ITransformTradeDataService
{
    private readonly IAppLogger _logger;
    public TransformTradeDataService(IAppLogger logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// Converts ETRM data to powertrak format.
    /// </summary>
    /// <param name="topicMessage">The topic message containing the ETRM data.</param>
    /// <param name="tradeType">The mapping of the topic trade.</param>
    /// <returns>The ETRM data in powertrak format.</returns>
    /// <exception cref="ArgumentException">Thrown when the trade data could not be generated.</exception>
    public string? ConvertTradeMessageToPowerTrakFormat(IEnumerable<NominationDetailsDto> cptyAggPositionData)
    {
        _logger.LogInformation($"{LogMessages.StartedETRMProcessing}");

        var tradeTransformer = new PowerTransTradeTransformer();
        var powerTrakXmlMapper = new PowerTrakXmlTradeMapper(PwrTrakTradeTransformerType.PowerTransTradeTransformer);
        
        var powerTrakProcessor = new EtrmTradeProcessor(tradeTransformer, powerTrakXmlMapper.PowerTrakTradeMapper);
        var powerTrakRequestXMLContent = powerTrakProcessor.ConvertEtrmDataToPowerTrakXml(cptyAggPositionData);
        if (!string.IsNullOrEmpty(powerTrakRequestXMLContent))
        {
            _logger.LogInformation(LogMessages.PowerTrakTransformDataSuccess);
        }
        else
        {
            _logger.LogInformation(LogMessages.PowerTrakTransformDataEmpty);
        }
        return powerTrakRequestXMLContent;
    }
}
