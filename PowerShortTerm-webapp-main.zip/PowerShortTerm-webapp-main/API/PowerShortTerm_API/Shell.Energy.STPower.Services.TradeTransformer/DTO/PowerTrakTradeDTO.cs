﻿using Shell.Energy.STPower.Services.TradeTransformer.PwrTrakXmlModels;

namespace Shell.Energy.STPower.Services.TradeTransformer.DTO;

/// <summary>
/// Class for Power Trak Trade DTO
/// </summary>
public class PowerTrakTradeDto
{
    public double? PowerCounter { get; set; }
    public string? TradeType { get; set; }
    public string? Granularity { get; set; }
    public string? Entity { get; set; }
    public string? ClientName { get; set; }
    public string? Reference { get; set; }
    public string? TransactionType { get; set; }
    public string? Counterparty { get; set; }
    public string? FromMarketOperator { get; set; }
    public string? ToMarketOperator { get; set; }
    public string? MarketOperator { get; set; }
    public CustomShape? CustomShape { get; set; }
    public DateTime TradeDate { get; set; }
    public string? CapacityType { get; set; }
    public string? CapacityIdentification { get; set; }
    public string? Interconnector { get; set; }
}