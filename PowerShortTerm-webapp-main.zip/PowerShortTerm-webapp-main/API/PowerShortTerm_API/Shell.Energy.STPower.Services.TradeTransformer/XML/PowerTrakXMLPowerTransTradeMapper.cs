﻿using Shell.Energy.STPower.Services.TradeTransformer.DTO;
using Shell.Energy.STPower.Services.TradeTransformer.Interfaces;
using Shell.Energy.STPower.Services.TradeTransformer.PwrTrakXmlModels;
using Shell.Energy.STPower.Shared;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Serialization;

namespace Shell.Energy.STPower.Services.TradeTransformer.XML;

/// <summary>
/// Class for mapping PowerTrak content to PowerTrade XML
/// </summary>
public class PowerTrakXmlPowerTransTradeMapper : IPowerTrakXmlTradeMapper
{
    private const string TradeDateFormat = "yyyy-MM-dd";
    private const string _powerTrakClient = "Shell"; // Fixed spelling error

    /// <summary>
    /// Maps PowerTrak content to PowerTrade XML
    /// </summary>
    /// <param name="powerTrakTradeDTOs"></param>
    /// <returns></returns>
    public string MapPowerTrakContent(List<PowerTrakTradeDto> powerTrakTradeDTOs)
    {
        string clientName;
        if (powerTrakTradeDTOs.Count == 0)
        {
            return null;
        }
        else
        {
            clientName = powerTrakTradeDTOs[0]?.ClientName ?? string.Empty;
        }
        var powerTradeModelList = new List<TradeModelBase>(powerTrakTradeDTOs.Count);

        foreach (var powerTrakDTO in powerTrakTradeDTOs)
        {
            if (powerTrakDTO!=null && !string.IsNullOrEmpty(powerTrakDTO.TradeType))
            {
                if ((powerTrakDTO.TradeType.Equals("PW_TRADE")))
                {
                    powerTradeModelList.Add(new PowerTradeModel
                    {
                        Reference = powerTrakDTO.Reference,
                        TransactionType = powerTrakDTO.TransactionType,
                        Counterparty = powerTrakDTO.Counterparty,
                        MarketOperator = powerTrakDTO.FromMarketOperator,
                        CustomShape = powerTrakDTO.CustomShape,
                        TradeDate = powerTrakDTO.TradeDate.ToString(TradeDateFormat, CultureInfo.InvariantCulture)
                    });
                }
                else if (powerTrakDTO.TradeType.Equals("PW_TRANS"))
                {
                    powerTradeModelList.Add(new TransTradeModel
                    {
                        Reference = powerTrakDTO.Reference,
                        FromMarketOperator = powerTrakDTO.FromMarketOperator,
                        ToMarketOperator = powerTrakDTO.ToMarketOperator,
                        MarketOperator = powerTrakDTO.Interconnector,
                        CustomShape = powerTrakDTO.CustomShape,
                        CapacityType = powerTrakDTO.CapacityType,
                        CapacityIdentification = TradeHelper.IsUkFlow(powerTrakDTO.FromMarketOperator, powerTrakDTO.ToMarketOperator)?"": powerTrakDTO.CapacityIdentification
                    });
                }
            }
        }
        return FormatTradeMessageToPowerTrakXml(powerTradeModelList, clientName);
    }

    /// <summary>
    /// Formats trade message to PowerTrak XML
    /// </summary>
    /// <param name="powerTradeModelList"></param>
    /// <returns></returns>
    private static string  FormatTradeMessageToPowerTrakXml(List<TradeModelBase> powerTradeModelList, string clientName) // Changed to ITradeModel
    {
        // Logic to format the trade message to PowerTrak XML
        PowerTrakModel powerTrakModel = new() { Trades = powerTradeModelList, Client = clientName }; // Fixed spelling error

        var serializer = new XmlSerializer(typeof(PowerTrakModel));
        var namespaces = new XmlSerializerNamespaces();
        namespaces.Add(string.Empty, string.Empty);

        var settings = new XmlWriterSettings
        {
            OmitXmlDeclaration = true,
            Indent = true
        };
        using var textWriter = new StringWriter();
        using var xmlWriter = XmlWriter.Create(textWriter, settings);
        serializer.Serialize(xmlWriter, powerTrakModel, namespaces);
        var xmlContent= textWriter.ToString();

        string pattern = @"<Trade p3:type[^>]*>";
        string replacement = "<Trade>";

        // Perform the replacement
        string result = Regex.Replace(xmlContent, pattern, replacement,RegexOptions.NonBacktracking);
        return result;
    }
}
