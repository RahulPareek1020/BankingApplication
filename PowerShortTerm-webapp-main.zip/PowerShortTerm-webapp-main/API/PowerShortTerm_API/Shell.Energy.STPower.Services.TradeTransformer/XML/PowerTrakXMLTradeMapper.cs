﻿using Shell.Energy.STPower.Services.TradeTransformer.Interfaces;
using Shell.Energy.STPower.Shared.Enums;
using Shell.Energy.STPower.Shared.Exceptions;

namespace Shell.Energy.STPower.Services.TradeTransformer.XML;

/// <summary>
/// Class for PowerTrak XML Trade Mapper
/// </summary>
public class PowerTrakXmlTradeMapper
{
    public IPowerTrakXmlTradeMapper PowerTrakTradeMapper { get; set; }

    /// <summary>
    /// Initializes a new instance of the powerTrakXMLTradeMapper class.
    /// </summary>
    /// <param name="tradeTransformerType">The trade transformer type.</param>
    /// <exception cref="NotFoundException">Thrown when the trade transformer type is not supported.</exception>
    public PowerTrakXmlTradeMapper(PwrTrakTradeTransformerType tradeTransformerType)
    {
        switch (tradeTransformerType)
        {
            case PwrTrakTradeTransformerType.PowerTransTradeTransformer:
                PowerTrakTradeMapper = new PowerTrakXmlPowerTransTradeMapper();
                break;
            default:
                throw new NotFoundException($"TradeTransformerType {tradeTransformerType} is not supported.");
        }
    }
}
