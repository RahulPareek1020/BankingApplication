﻿using Shell.Energy.STPower.Data.Dto;
using Shell.Energy.STPower.Services.TradeTransformer.DTO;
using Shell.Energy.STPower.Services.TradeTransformer.Interfaces;

namespace Shell.Energy.STPower.Services.TradeTransformer;

/// <summary>
/// Class to process ETRM trade data and convert it to PowerTrak XML
/// </summary>
public class EtrmTradeProcessor
{
    private readonly IEtrmTradeTransformer _etrmTradeTransformer;
    private readonly IPowerTrakXmlTradeMapper _powerTrakXmlTradeMapper;

    /// <summary>
    /// Constructor for ETRMTradeProcessor
    /// </summary>
    /// <param name="etrmTradeTransformer"></param>
    /// <param name="powerTrakXMLTradeMapper"></param>
    public EtrmTradeProcessor(IEtrmTradeTransformer etrmTradeTransformer, IPowerTrakXmlTradeMapper powerTrakXMLTradeMapper)
    {
        _etrmTradeTransformer = etrmTradeTransformer;
        _powerTrakXmlTradeMapper = powerTrakXMLTradeMapper;
    }

    /// <summary>
    /// Convert ETRM trade data to PowerTrak XML
    /// </summary>
    /// <param name="tradeData"></param>
    /// <param name="tradeTransformerType"></param>
    /// <returns></returns>
    public string? ConvertEtrmDataToPowerTrakXml(IEnumerable<NominationDetailsDto> cptyAggPositionData)
    {
        List<PowerTrakTradeDto>? powerTrakTradeDTOs = _etrmTradeTransformer.TransformTradeData(cptyAggPositionData);
        if (powerTrakTradeDTOs == null || powerTrakTradeDTOs.Count == 0)
        {
            return null;
        }

        string? powerTrakXMLContent = _powerTrakXmlTradeMapper.MapPowerTrakContent(powerTrakTradeDTOs);
        return powerTrakXMLContent;
    }
}
