﻿using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Data.Repository;
using Shell.Energy.SNE.Service.AligneIntegration.Service;
using Shell.Energy.SNE.Service.AligneIntegration;
using Shell.Energy.STPower.Shared.PowerTrak;
namespace SNE_VNet_API.Modules
{
    /// <summary>
    /// DI class for adding core modules
    /// </summary>
    public static class STPowerCoreModule
    {
        public static IServiceCollection AddSTPowerCore(this IServiceCollection collection, IConfiguration configuration)
        {
            collection.AddScoped<ISqlDataRepository, SqlDataRepository>();
            collection.AddHttpClient();
            collection.AddSingleton<IDateTimeProvider, DateTimeProvider>();
            collection.AddScoped<IPowertrakTradeService, PowertrakTradeService>();
            collection.AddScoped<IApiService, ApiService>();
            collection.AddScoped<IPowerTrakSender, PowerTrakSender>();
            collection.AddScoped<IAligneReportService, AligneReportService>();
            collection.AddScoped<IExternalService, ExternalService>();
            collection.AddScoped<IAppLogger, AppLogger>();

            return collection;
        }
    }
}
