using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Shell.Energy.SNE.Service.AligneIntegration;
using Shell.Energy.SNE.Service.AligneIntegration.Service;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Constants;
using Shell.Energy.STPower.Shared.Messages;
using Shell.Energy.STPower.Shared.Model;
using System.Globalization;
using System.Net.Sockets;

namespace SNE_VNet_API.Controllers
{
    /// <summary>
    /// API controller class to run aligne batch
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Policy = "SNERolesPolicy")]
    public class AligneBatchController : ControllerBase
    {
        private readonly IAppLogger _logger;
        private readonly IAligneReportService _aligneReportService;
        private readonly IDateTimeProvider _dateTimeProvider;
        private readonly IConfiguration _configuration;
        private const int _tcpClientTimeout = 4;

        public AligneBatchController(IAppLogger logger, IAligneReportService aligneReportService, IDateTimeProvider dateTimeProvider, IConfiguration config)
        {
            _logger = logger;
            _aligneReportService = aligneReportService;
            _dateTimeProvider = dateTimeProvider;
            _configuration = config;
        }

        /// <summary>
        /// API to run aligne batch
        /// </summary>
        /// <param name="batchRequest"></param>
        /// <returns></returns>
        [HttpPost("run-batch-async", Name = "run-batch-async")]
        public async Task<ActionResult<string>> RunAligneBatchAsync([FromBody] AligneBatchRequestModel reqModel)
        {
            DateTime fromDate, toDate;
            if (reqModel == null)
            {
                return StatusCode(StatusCodes.Status400BadRequest, ResponseMessages.InvalidInputParameters);
            }
            _logger.LogInformation($"BatchRunId:{reqModel.NominationRunId} Calling RunAligneBatch in async mode");

            if (string.IsNullOrEmpty(reqModel.BatchName)
                || !DateTime.TryParse(reqModel.FromDate.ToString(CultureInfo.InvariantCulture), CultureInfo.InvariantCulture, out fromDate)
                || !DateTime.TryParse(reqModel.ToDate.ToString(CultureInfo.InvariantCulture), CultureInfo.InvariantCulture, out toDate))
            {
                return StatusCode(StatusCodes.Status400BadRequest, ResponseMessages.InvalidInputParameters);
            }

            var primaryHost = _configuration.GetSection(AligneConstants.AlignePrimConfigKey).Value ?? string.Empty;
            var secondaryHost = _configuration.GetSection(AligneConstants.AligneSecConfigKey).Value ?? string.Empty;
            var port = Convert.ToInt16(_configuration.GetSection(AligneConstants.AlignePortConfigKey).Value, CultureInfo.InvariantCulture);
            var aligneUser = _configuration.GetSection(AligneConstants.AligneUserConfigKey).Value ?? string.Empty;
            var alignePassword = _configuration.GetSection(AligneConstants.AlignePasswordConfigKey).Value ?? string.Empty;

            bool isPrimaryHealthy = await CheckServerHealthAsync(primaryHost, port, reqModel.NominationRunId);
            bool isSecondaryHealthy = await CheckServerHealthAsync(secondaryHost, port, reqModel.NominationRunId);

            string primaryServer, secondaryServer;

            if (!isPrimaryHealthy && !isSecondaryHealthy)
            {
                _logger.LogError($"BatchRunId:{reqModel.NominationRunId} {LogMessages.AligneServerHealthCheckFailed}");
                return $"<results><msg type=\"-1\">{LogMessages.AligneServerHealthCheckFailed}</msg></results>";
            }

            // Switch over primary and secondary in case of failover
            if (isPrimaryHealthy)
            {
                primaryServer = primaryHost;
                secondaryServer = secondaryHost;
            }
            else
            {
                primaryServer = secondaryHost;
                secondaryServer = primaryHost;
            }

            var aligneServerConfig = new AligneServerConfig() { 
                AligneUser = aligneUser, AlignePassword = alignePassword, Port = port, PrimaryServer=primaryServer, SecondaryServer=secondaryServer };

            var response = await _aligneReportService.ConfigureAndRunBatchAsync(reqModel.FromDate, reqModel.ToDate,
                reqModel.BatchName, reqModel.MarketOperator, reqModel.NominationRunId, aligneServerConfig);

            await _aligneReportService.InsertBatchRunType(reqModel.NominationRunId, reqModel.IsAuto);


            _logger.LogInformation($"BatchRunId:{reqModel.NominationRunId} Aligne batch (async) triggered at {_dateTimeProvider.Now} " +
                $"with parameters: {JsonConvert.SerializeObject(reqModel)}, aligne response: {response}");
            return response;
        }

        private async Task<bool> CheckServerHealthAsync(string host, int port, int nominationRunId)
        {
            _logger.LogInformation($"BatchRunId:{nominationRunId} {LogMessages.AligneServerHealthCheckStarted} for {host}:{port}");
            try
            {
                using (var client = new TcpClient())
                {
                    var connectTask = client.ConnectAsync(host, port);
                    var timeoutTask = Task.Delay(TimeSpan.FromSeconds(_tcpClientTimeout));

                    var completedTask = await Task.WhenAny(connectTask, timeoutTask);
                    if (completedTask == timeoutTask)
                    {
                        _logger.LogInformation($"BatchRunId:{nominationRunId} {LogMessages.AligneServerHealthCheckFailed} for {host}:{port}");
                        return false;
                    }

                    await connectTask; 
                }
                _logger.LogInformation($"BatchRunId:{nominationRunId} {LogMessages.AligneServerHealthCheckSuccess} for {host}:{port}");
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError($"BatchRunId:{nominationRunId} Aligne server health check failed for {host}:{port}: {ex.Message}");
                return false;
            }
        }
    }
}
