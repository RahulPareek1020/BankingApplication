﻿using System.Diagnostics.CodeAnalysis;

namespace Shell.SNE.Common
{
    /// <summary>
    /// Constant keys common across price data store
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class Constants
    {
        /// <summary>
        /// Connection string to mongo db server
        /// </summary>
        public static readonly string API_KEY_HEADER = "X-API-KEY";
        
    }
}
