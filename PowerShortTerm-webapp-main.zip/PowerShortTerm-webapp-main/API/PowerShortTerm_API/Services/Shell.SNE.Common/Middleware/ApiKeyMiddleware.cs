﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.Net;

namespace Shell.SNE.Common.Middleware
{
    /// <summary>
    /// Middleware that validates the X-API-KEY in the header with specified key
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class ApiKeyMiddleware : IMiddleware
    {
        /// <summary>
        /// The API Key Value
        /// </summary>
        private readonly string? _apiKeyValue;

        /// <summary>
        /// Request path for swagger resources for anonymous access
        /// </summary>
        private readonly PathString _swaggerResourcePathPattern = "/swagger";

        #region ApiKeyMiddleware
        /// <summary>
        /// Constructor expects configuration with APIKey
        /// </summary>
        /// <param name="configuration"></param>
        /// <exception cref="ArgumentException"></exception>
        public ApiKeyMiddleware(IConfiguration configuration)
        {
            //Extract API key from configuration
            _apiKeyValue = configuration.GetValue<string>("APIKey");
            //Validate API Key
            if (string.IsNullOrEmpty(_apiKeyValue))
            {
                throw new ArgumentException("Configured APIKey is null or empty");
            }
        }
        #endregion

        #region InvokeAsync
        /// <summary>
        /// InvokeAsync middleware implementation to check for API key
        /// </summary>
        /// <param name="context"></param>
        /// <param name="next"></param>
        /// <returns></returns>
        public Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            if (context is null)
            {
                throw new ArgumentNullException(nameof(context));
            }

            if (next is null)
            {
                throw new ArgumentNullException(nameof(next));
            }
            return VerifyApiKeyHeader(context, next);
        }

        private async Task VerifyApiKeyHeader(HttpContext context, RequestDelegate next)
        {
            //Initialize authorization as false
            bool _isInvocationAuthorized = false;

            //Header check
            if (context.Request.Headers.ContainsKey(Constants.API_KEY_HEADER))
            {
                if (!string.IsNullOrEmpty(context.Request.Headers[Constants.API_KEY_HEADER]))
                {
                    if (context.Request.Headers[Constants.API_KEY_HEADER].Equals(_apiKeyValue))
                    {
                        //AUTHORIZED invocation
                        _isInvocationAuthorized = true;
                    }
                    else
                    {
                        //Unauthorized invocation
                        _isInvocationAuthorized = false;
                    }
                }
                else
                {
                    //Unauthorized invocation
                    _isInvocationAuthorized = false;
                }
            }
            //Check if path configured for anonymous access
            else if (context.Request.Path.HasValue && context.Request.Path.StartsWithSegments(_swaggerResourcePathPattern, StringComparison.OrdinalIgnoreCase))
            {
                //Allow anonymous access if configured
                _isInvocationAuthorized = true;
            }
            else
            {
                //Unauthorized invocation
                _isInvocationAuthorized = false;
            }

            //Continue request pipeline if request is authorized
            if (_isInvocationAuthorized)
            {
                await next.Invoke(context);
            }
            else
            {
                //API invocation is unauthorized
                context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                await context.Response.WriteAsync($"API Access Unauthorized.");
            }
        }
        #endregion

    }
}
