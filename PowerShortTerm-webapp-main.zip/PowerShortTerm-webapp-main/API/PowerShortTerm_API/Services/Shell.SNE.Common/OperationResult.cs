﻿using System.Diagnostics.CodeAnalysis;

namespace Shell.SNE.Common
{
    /// <summary>
    /// The datacontracted operation result 
    /// </summary>
    /// <typeparam name="TResult">The type of data expected for the returning result</typeparam>
    [ExcludeFromCodeCoverage]
    public class OperationResult<TResult>
    {
        /// <summary>
        /// The operation result data to accomodate data
        /// </summary>
        public TResult Data { get; set; }

        /// <summary>
        /// An indicator of the operation success
        /// </summary>
        public OperationState State { get; set; }

        /// <summary>
        /// A string representing error message
        /// </summary>
        public string ErrorMessage { get; set; }
    }
}
