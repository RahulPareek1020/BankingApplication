﻿using System.Diagnostics.CodeAnalysis;

namespace Shell.SNE.Common
{
    /// <summary>
    /// Class representing the mapping of attributes between source and target application
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class SourceToTargetAttributeMap
    {
        /// <summary>
        /// Represent the name of source application's attribute
        /// </summary>
        public string SourceAttribute { get; set; }

        /// <summary>
        /// Represent the name of target application's attribute
        /// </summary>
        public string TargetAttribute { get; set; }

        /// <summary>
        /// Represent the type of source application's attribute
        /// </summary>
        public string SourceAttributeType { get; set; }

        /// <summary>
        /// Represent the type of target application's attribute
        /// </summary>
        public string TargetAttributeType { get; set; }

        /// <summary>
        /// Represent is mapping active
        /// </summary>
        public bool IsActive { get; set; }

        /// <summary>
        /// Represent is mapping mandatory for validation purpose
        /// </summary>
        public bool IsMandatory { get; set; }
    }
}
