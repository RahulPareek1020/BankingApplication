﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shell.SNE.Common.OpenTelemetry
{
    /// <summary>
    /// class representing open telemetry related settings
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class OpenTelemetrySettings
    {
        /// <summary>
        /// otlp exporter end point
        /// </summary>
        public Uri? OtlpExporterEndpoint { get; set; }
        /// <summary>
        /// endpoint to retrieve token
        /// </summary>
        public Uri? TokenEndPoint { get; set; }
        /// <summary>
        /// Client id for PDS to retrieve token from Otel Collector
        /// </summary>
        public string? ClientId { get; set; }
        /// <summary>
        /// Client secret for PDS to retrieve token from Otel Collector
        /// </summary>
        public string? ClientSecret { get; set; }
        /// <summary>
        /// audience PDS to retrieve token from Otel Collector
        /// </summary>
        public string? Audience { get; set; }
        /// <summary>
        /// grant type for token retrieval
        /// </summary>
        public string? GrantType { get; set; }
        /// <summary>
        /// name of section in appsettings for open telemetry settings
        /// </summary>
        public static readonly string SectionName = "OpenTelemetrySettings";
    }
}
