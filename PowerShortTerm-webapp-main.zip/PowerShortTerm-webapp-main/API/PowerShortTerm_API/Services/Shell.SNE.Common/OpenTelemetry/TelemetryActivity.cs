﻿using OpenTelemetry.Context.Propagation;
using OpenTelemetry;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;

namespace Shell.SNE.Common.OpenTelemetry
{
    /// <summary>
    /// <inheritdoc/>
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class TelemetryActivity : ITelemetryActivity
    {
        /// <summary>
        /// current activity for tracing purposes
        /// </summary>
        internal Activity? _activity;
        /// <summary>
        /// source for creating and managing activities
        /// </summary>
        private readonly ActivitySource _activitySource;
        /// <summary>
        /// reference to logger object
        /// </summary>
        private readonly ILogger<TelemetryActivity> _logger;
        /// <summary>
        /// reference to custom attributes that for trace event/span
        /// </summary>
        private readonly CustomAttributes _customAttributes;
        /// <summary>
        /// constructor method that takes an instance of activity source
        /// </summary>
        /// <param name="activitySource"></param>
        /// <param name="customAttributes"></param>
        /// <param name="logger"></param>
        /// <exception cref="ArgumentException"></exception>
        public TelemetryActivity(ActivitySource activitySource, ILogger<TelemetryActivity> logger, CustomAttributes customAttributes)
        {
            _activitySource = activitySource ?? throw new ArgumentException("activitySource is null");
            _customAttributes = customAttributes;
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }
        /// <summary>
        /// returns a list of allowed custom attributes for span/event
        /// </summary>
        public CustomAttributes CustomAttributes { get { return _customAttributes; } }
        /// <summary>
        /// <inheritdoc/>
        /// </summary>
        /// <param name="activityName"></param>
        /// <exception cref="InvalidOperationException"></exception>
        public void StartProducerActivity(string activityName)
        {
            Activity.Current = null;

            _activity = _activitySource.CreateActivity($"{activityName}", ActivityKind.Producer);

            if (_activity == null)
            {
                _logger.LogError($"ActivitySource has no listener attached.");
                throw new InvalidOperationException("ActivitySource has no listener attached.");
            }

            _activity.Start();
        }
        /// <summary>
        /// <inheritdoc/>
        /// </summary>
        /// <param name="activityName"></param>
        /// <param name="parentContext"></param>
        /// <param name="activityKind"></param>
        /// <exception cref="InvalidOperationException"></exception>
        public void StartConsumerActivity(string activityName, PropagationContext parentContext, ActivityKind activityKind)
        {
            Activity.Current = null;

            _activity = _activitySource.CreateActivity($"{activityName}", activityKind, parentContext.ActivityContext);
           
            if (_activity == null)
            {
                _logger.LogError($"ActivitySource has no listener attached.");
                throw new InvalidOperationException("ActivitySource has no listener attached.");
            }
            _activity.Start();
            _activity.ImportParentBaggage(parentContext);
            _activity.SetTagsFromBaggage();

        }
        public bool IsStopped => _activity is null || _activity!.IsStopped;
        public void StopActivity()
        {
            if (_activity == null)
            {
                return;
            }
            if (!_activity!.IsStopped)
            {
                _activity.Stop();
            }
        }
        /// <summary>
        /// Represents the current activity
        /// </summary>
        public ActivityContext Context => _activity!.Context;
        /// <summary>
        /// Represents the current activity
        /// </summary>
        public ActivityContext? ParentContext
        {
            get
            {
                if (_activity?.RootId != null && _activity.ParentSpanId != default)
                {
                    return new ActivityContext(ActivityTraceId.CreateFromString(_activity.RootId.AsSpan()), _activity.ParentSpanId, ActivityTraceFlags.None);
                }
                else
                {
                    return null;
                }
            }
        }
        
        /// <summary>
        /// <inheritdoc/>
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        /// <summary>
        /// Add event to current activity
        /// </summary>
        /// <param name="eventName"></param>
        /// <param name="eventAttributes"></param>
        public void AddEvent(string eventName, IDictionary<string, object?>? eventAttributes = null)
        {
            var tags = new Dictionary<string, object?> { };
            // Add baggage items to the tags
            foreach (var baggage in Baggage.Current)
            {
                tags[baggage.Key] = baggage.Value;
            }
            if (eventAttributes != null)
            {
                foreach (var attribute in eventAttributes)
                {
                    if (attribute.Value != null)
                    {
                        if (!tags.ContainsKey(attribute.Key))
                            tags.Add(attribute.Key, attribute.Value);
                    }
                    
                }
            }

            _activity?.AddEvent(new ActivityEvent(eventName, DateTime.UtcNow, new ActivityTagsCollection(tags)));
        }       
        /// <summary>
        /// sets tag to the current activity
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public void AddTag(string key, object? value) 
        {
            _activity?.SetTag(key, value);
        }
        /// <summary>
        /// Add baggage to current activity
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public void AddBaggage(string key, string value)
        {
            //_activity?.AddBaggage(key, value);
            Baggage.SetBaggage(key, value);
        }
        /// <summary>
        /// <inheritdoc/>
        /// </summary>
        /// <param name="existingContexts"></param>
        public void SetPropagationContext(IDictionary<string, object> existingContexts,  ActivityContext activityContext)
        {
            Propagators.DefaultTextMapPropagator.Inject(new(activityContext, Baggage.Current), existingContexts, (metadata, key, value) =>
            {                
                metadata.Add(key, value);
            });
        }
        /// <summary>
        /// <inheritdoc/>
        /// </summary>
        /// <param name="existingContexts"></param>
        public void SetPropagationContext(IDictionary<string, string> existingContexts, ActivityContext activityContext)
        {
            Propagators.DefaultTextMapPropagator.Inject(new(activityContext, Baggage.Current), existingContexts, (metadata, key, value) =>
            {
                metadata.Add(key, value);
            });
        }
        /// <summary>
        /// Extracts the propagation context from dictionary of string key value pairs
        /// </summary>
        /// <param name="applicationProperties"></param>
        /// <returns></returns>
        public static PropagationContext ExtractPropagationContext(IReadOnlyDictionary<string, object> applicationProperties)
        {
            return Propagators.DefaultTextMapPropagator.Extract(default, applicationProperties, (qProps, key) =>
            {
                if (!qProps.TryGetValue(key, out var value) || value?.ToString() is null)
                {
                    return Enumerable.Empty<string>();
                }

                return new[] { value.ToString() };
            });
        }
        /// <summary>
        /// When the activity is disposed off in the calling class, the diagnostics activity will be stopped
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (_activity == null)
            {
                return;
            }

            if (!_activity!.IsStopped)
            {
                _activity.Stop();
            }

            _activity.Dispose();
        }
    }
}
