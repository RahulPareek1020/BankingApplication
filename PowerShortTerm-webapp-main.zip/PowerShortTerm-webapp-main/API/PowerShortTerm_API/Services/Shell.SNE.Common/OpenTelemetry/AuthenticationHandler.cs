﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Polly;
using Polly.Retry;

namespace Shell.SNE.Common.OpenTelemetry
{
    /// <summary>
    /// handler which manages the token access from the Otel collector
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class AuthenticationHandler : DelegatingHandler
    {
        private readonly TokenManager _tokenManager;
        private readonly ILogger<AuthenticationHandler> _logger;
        private readonly RetryPolicy<HttpResponseMessage> _retryPolicy;
        /// <summary>
        /// constructor method to initialize tokenManager and logger instances
        /// </summary>
        /// <param name="tokenManager"></param>
        /// <param name="logger"></param>
        public AuthenticationHandler(TokenManager tokenManager, ILogger<AuthenticationHandler> logger)
        {
            _tokenManager = tokenManager;
            _logger = logger;
            //InnerHandler = new HttpClientHandler();
            _retryPolicy = Policy
                .Handle<HttpRequestException>()
                .OrResult<HttpResponseMessage>(r => !r.IsSuccessStatusCode)
                .WaitAndRetry(5, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)), (result, timespan, retryCount, context) =>
                {
                    _logger.LogWarning($"Request failed with {result.Result?.StatusCode}. Waiting {timespan} before next retry. retry attempt {retryCount}");
                }
                );
        }
        /// <summary>
        /// async operation for send. Fetches the token and adds to the authorization header. If token has expired, a new token is fetched and added
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            try
            {
                _logger.LogInformation("Sending async telemetry to {0}", request.RequestUri);
                await SetAuthTokenInHeader(request);
                _logger.LogInformation("Fetched Authorization token and added as header");
                var result = await base.SendAsync(request, cancellationToken);               
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error sending telemetry to {0}", request.RequestUri);
                throw;
            }

        }
        /// <summary>
        /// async operation for send. Fetches the token and adds to the authorization header. If token has expired, a new token is fetched and added
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        protected override HttpResponseMessage Send(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            return _retryPolicy.Execute(() => {
                try
                {
                    _logger.LogInformation("Sending telemetry to {0}", request.RequestUri);
                    SetAuthTokenInHeader(request).Wait(cancellationToken);
                    var result = base.Send(request, cancellationToken);
                    if (result.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {
                        SetAuthTokenInHeader(request).Wait(cancellationToken);
                        result = base.Send(request, cancellationToken);
                        _logger.LogInformation($"Status code received : {result.StatusCode} Resending telemetry to {request.RequestUri}");
                    }
                    else
                    {
                        _logger.LogInformation($"Status code received : {result.StatusCode} Resending telemetry to {request.RequestUri}");
                    }
                    return result;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error sending telemetry to {0}", request.RequestUri);
                    throw;
                }
            });            
        }
        /// <summary>
        /// check if token in memory has expired. If it has, then fetch new token. 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        /// <exception cref="InvalidOperationException"></exception>
        private async Task SetAuthTokenInHeader(HttpRequestMessage request)
        {
            if (_tokenManager.IsTokenExpired())
            {
                var newtoken = await _tokenManager.GetRefreshTokenAsync();
                if (newtoken == null)
                {
                    throw new InvalidOperationException("Token is null");
                }
            }
            var token = _tokenManager.GetToken();
            if (token != null)
            {
                // Remove existing Authorization header if it exists
                if (request.Headers.Contains("Authorization"))
                {
                    request.Headers.Remove("Authorization");
                }
                request.Headers.Add("Authorization", $"{token.TokenType} {token.AccessToken}");
            }
        }
    }
}
