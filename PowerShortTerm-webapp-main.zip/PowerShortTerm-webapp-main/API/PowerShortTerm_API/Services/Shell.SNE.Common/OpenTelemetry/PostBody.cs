﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Shell.SNE.Common.OpenTelemetry
{
    /// <summary>
    /// class representing body of message to otel collector for retreiving token
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class PostBody
    {
        /// <summary>
        /// constructor for postbody class. 
        /// </summary>
        /// <param name="clientId"></param>
        /// <param name="clientSecret"></param>
        /// <param name="audience"></param>
        /// <param name="grantType"></param>
        public PostBody(string clientId, string clientSecret, string audience, string grantType)
        {
            ClientId = clientId;
            ClientSecret = clientSecret;
            Audience = audience;
            GrantType = grantType;
        }
        /// <summary>
        /// specifies client id 
        /// </summary>
        [JsonPropertyName("client_id")]
        public string ClientId { get; }
        /// <summary>
        /// specifies client secret
        /// </summary>
        [JsonPropertyName("client_secret")]
        public string ClientSecret { get; }
        /// <summary>
        /// specifies audience
        /// </summary>
        [JsonPropertyName("audience")]
        public string Audience { get; }
        /// <summary>
        /// specifies grant type
        /// </summary>
        [JsonPropertyName("grant_type")]
        public string GrantType { get; }
    }
}
