﻿using OpenTelemetry;
using OpenTelemetry.Context.Propagation;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shell.SNE.Common.OpenTelemetry
{
    /// <summary>
    /// this is a class that defines the extension methods related to telemetry activity
    /// </summary>
    public static class Extension
    {
        /// <summary>
        /// This extension method sets tags from baggage from the activity
        /// </summary>
        /// <param name="activity"></param>
        public static void SetTagsFromBaggage(this Activity activity)
        {
            foreach (var baggage in Baggage.Current)
            {
                activity.AddTag(baggage.Key, baggage.Value);
            }
        }
        /// <summary>
        /// This extension method adds baggage from parent baggage
        /// </summary>
        /// <param name="activity"></param>
        /// <param name="parentContext"></param>
        public static void ImportParentBaggage(this Activity activity, PropagationContext parentContext)
        {
            foreach (var baggage in parentContext.Baggage)
            {
                Baggage.SetBaggage(baggage.Key, baggage.Value);
            }
        }
    }
}
