﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shell.SNE.Common.OpenTelemetry
{
    /// <summary>
    /// class representing the custom attributes associated with otel events/baggages
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CustomAttributes
    {
        /// <summary>
        /// indicates the resource environment
        /// </summary>
        public string Environment { get; set; } = "Environment";
        /// <summary>
        /// indicates the source of the curve
        /// </summary>
        public string Source { get; set; } = "process.object.source";
        /// <summary>
        /// indicates the name of the curve
        /// </summary>
        public string CurveName { get; set; } = "process.object.name";
        /// <summary>
        /// indicates the effective date of the curve
        /// </summary>
        public string EffectiveDate { get; set; } = "process.object.effectivedate";
        /// <summary>
        /// indicates when the curve was updated by the source
        /// </summary>
        public string SourceUpdatedDate { get; set; } = "process.object.updateddate";
        /// <summary>
        /// indicates the data provider of the curve
        /// </summary>
        public string DataProvider { get; set; } = "process.object.dataprovider";
        /// <summary>
        /// indicates the message in case of failure
        /// </summary>
        public string ErrorMessage { get; set; } = "error.message";
        /// <summary>
        /// indicates the name of the topic from which the message originates from
        /// </summary>
        public string MessagingOriginName { get; set; } = "messaging.origin.name";
        /// <summary>
        /// indicates the kind of message trasnport mechanism from source
        /// </summary>
        public string MessagingOriginKind { get; set; } = "messaging.origin.kind";
        /// <summary>
        /// indicates the instance from which message is originated
        /// </summary>
        public string MessagingOriginInstance { get; set; } = "messaging.origin.instance";
        /// <summary>
        /// indicates the value for the field MessagingOriginInstance
        /// </summary>
        public string MessagingOriginInstanceName { get; set; } = "";
        /// <summary>
        /// indicates the name of the topic to which the message is directed
        /// </summary>
        public string MessagingDestinationName { get; set; } = "messaging.destination.name";
        /// <summary>
        /// indicates the kind of message trasnport mechanism to destination
        /// </summary>
        public string MessagingDestinationKind { get; set; } = "messaging.destination.kind";
        /// <summary>
        /// indicates the instance to which message is directed
        /// </summary>
        public string MessagingDestinationInstance { get; set; } = "messaging.destination.instance";
        /// <summary>
        /// indicates the value for the field MessagingDestinationInstance
        /// </summary>
        public string MessagingDestinationInstanceName { get; set; } = "";
        /// <summary>
        /// indicates the application id 
        /// </summary>
        public string ApplicationId { get; set; } = "application.id";
        /// <summary>
        /// name of section in appsettings for open telemetry custom attributes
        /// </summary>
        public static readonly string SectionName = "CustomAttributes";

    }
}
