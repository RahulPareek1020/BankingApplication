﻿namespace Shell.SNE.Common.Interfaces
{
    /// <summary>
    /// An interface to deal with dates
    /// The implementation can be easily mocked when writing unit test cases
    /// </summary>
    public interface IClock
    {
        /// <summary>
        /// property to get current Utc time
        /// </summary>
        DateTime DatetimeUtc { get; }
        /// <summary>
        /// Gets a list of all long day end dates for all timezones for 10 years from year 2021
        /// </summary>
        /// <returns></returns>
        IReadOnlyDictionary<Tuple<int, string>, IList<DateTime>> GetLongDayEndDatesForAllTimeZones { get; }
        /// <summary>
        /// gets the long day end dates for a particular timezone identifier for the provided year
        /// </summary>
        /// <param name="Year"></param>
        /// <param name="TimezoneIdentifier"></param>
        /// <returns></returns>
        IList<DateTime> GetLongDayEndDateForYearAndTimeZoneId(int Year, string TimezoneIdentifier);
    }
}
