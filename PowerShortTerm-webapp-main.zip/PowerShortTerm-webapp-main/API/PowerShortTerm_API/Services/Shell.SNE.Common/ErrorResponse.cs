﻿using System.Diagnostics.CodeAnalysis;
using System.Text.Json;

namespace Shell.SNE.Common
{
    /// <summary>
    /// class used by api's to return error response
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class ErrorResponse
    {
        /// <summary>
        /// response status code
        /// </summary>
        public int StatusCode { get; set; }

        /// <summary>
        /// exception message to be returned in response
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// method to serialize the exception
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return JsonSerializer.Serialize(this);
        }
    }
}
