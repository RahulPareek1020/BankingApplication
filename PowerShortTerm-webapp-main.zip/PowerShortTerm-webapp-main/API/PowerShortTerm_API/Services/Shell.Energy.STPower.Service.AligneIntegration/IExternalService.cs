﻿using System.Text;

namespace Shell.Energy.SNE.Service.AligneIntegration
{
    public interface IExternalService
    {
        public void RunBatch(StringBuilder xmlResponse, int outsize, string primaryHost, string secondaryHost, int port, string xmlString);
    }
}
