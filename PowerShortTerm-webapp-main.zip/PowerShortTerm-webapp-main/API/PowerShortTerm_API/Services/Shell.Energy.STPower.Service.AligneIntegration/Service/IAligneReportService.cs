﻿namespace Shell.Energy.SNE.Service.AligneIntegration.Service
{
    public interface IAligneReportService
    {
        public Task<string> ConfigureAndRunBatchAsync(DateTime fromDate, DateTime toDate, string batchName, string fromMarketName, int nomRunID, 
            AligneServerConfig aligneServerConfig);
        public Task InsertBatchRunType(long batchRunId, bool? isAuto);
    }
}
