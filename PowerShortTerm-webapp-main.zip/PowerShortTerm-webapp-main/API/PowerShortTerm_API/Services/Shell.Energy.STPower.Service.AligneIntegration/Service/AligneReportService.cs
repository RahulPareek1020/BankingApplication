﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Shell.Energy.STPower.Data.Constants;
using Shell.Energy.STPower.Data.Repository;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Constants;
using Shell.Energy.STPower.Shared.Messages;
using System.Data;
using System.Globalization;
using System.Text;

namespace Shell.Energy.SNE.Service.AligneIntegration.Service
{
    /// <summary>
    /// Class to call Alignerunner DLL
    /// </summary>
    public class AligneReportService : IAligneReportService
    {
        private readonly IAppLogger _logger;

        private readonly IExternalService _externalService;
        private readonly IConfiguration _config;
        private readonly IDateTimeProvider _dateTimeProvider;
        private readonly ISqlDataRepository _sqlDataRepository;
        private const string _dateFormat = "ddMMMyyyy";


        public AligneReportService(IAppLogger logger, IExternalService externalService, IConfiguration config, IDateTimeProvider dateTimeProvider, ISqlDataRepository sqlDataRepository)
        {
            _logger = logger;
            _externalService = externalService;
            _config = config;
            _dateTimeProvider = dateTimeProvider;
            _sqlDataRepository = sqlDataRepository;
        }

        public async Task<string> ConfigureAndRunBatchAsync(DateTime fromDate, DateTime toDate, string batchName, string fromMarketName, int nomRunID,
            AligneServerConfig aligneServerConfig)
        {
            try
            {
                var aligneResponseTimeout = Convert.ToInt32(_config.GetSection(AligneConstants.AligneResponseTimeoutConfigKey).Value, CultureInfo.InvariantCulture);
                _logger.LogInformation($"Calling ConfigureAndRunBatch at  : {_dateTimeProvider.Now}");
                _logger.LogInformation($"Aligne Config Details -- Primary Server: {aligneServerConfig.PrimaryServer}, " +
                    $"Secondary Server: {aligneServerConfig.SecondaryServer}, Port: {aligneServerConfig.Port}");

                if (!aligneServerConfig.IsValid())
                {
                    _logger.LogError(LogMessages.AligneConfigError);
                    return $"<results><batch>{batchName}</batch><msg type=\"-1\">{LogMessages.AligneConfigError}</msg></results>";
                }
                var fromDateString = fromDate.ToString(_dateFormat, CultureInfo.InvariantCulture);
                var toDateString = toDate.ToString(_dateFormat, CultureInfo.InvariantCulture);
                var batchStartDate = toDate.AddDays(1).ToString(_dateFormat, CultureInfo.InvariantCulture);
                var batchEndDate = toDate.AddDays(-1).ToString(_dateFormat, CultureInfo.InvariantCulture);

                var xmlString =
                                 $"<batch type=\"B\">{batchName}</batch>" +
                                 $"<asof>{_dateTimeProvider.Now:ddMMMyy}</asof>" +
                                 $"<user>{aligneServerConfig.AligneUser}</user>" +
                                 $"<pw>*{aligneServerConfig.AlignePassword}</pw>+" +
                                 $"<filter type=\"_CMDLINE\">{"&gt;=" + fromDateString + " & &lt;=" + toDateString}</filter>" +
                                 $"<filter type=\"_CMDLINE2\">{fromMarketName}</filter >" +
                                 $"<filter type=\"_CMDLINE3\">{"&lt;=" + batchStartDate}</filter>" +
                                 $"<filter type=\"_CMDLINE4\">{nomRunID}</ filter >" +
                                 $"<filter type=\"_CMDLINE5\">{"&gt;=" + batchEndDate}</filter>";


                _logger.LogInformation($"Calling Aligne batch async at: {_dateTimeProvider.Now}");
                const int outsize = 10000;

                var xmlResponse = new StringBuilder(outsize);

                //Waits till timeout or aligne batch is completed
                using (var cts = new CancellationTokenSource())
                {
                    var runBatchTask = Task.Run(() => _externalService.RunBatch(xmlResponse, outsize, 
                        aligneServerConfig.PrimaryServer, aligneServerConfig.SecondaryServer, aligneServerConfig.Port, xmlString));
                    var delayTask = Task.Delay(TimeSpan.FromSeconds(aligneResponseTimeout), cts.Token);

                    var completedTask = await Task.WhenAny(runBatchTask, delayTask);

                    if (completedTask == delayTask)
                    {
                        return ResponseMessages.ValidAligneXmlResponse;
                    }

                    await cts.CancelAsync(); // Cancel the delay task if RunBatch completes first
                }
                // Return response from aligne batch
                return xmlResponse.ToString();
            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred while running Aligne batch {ex}");
                throw;
            }
        }

        public async Task InsertBatchRunType(long batchRunId, bool? isAuto)
        {
            _logger.LogInformation($"Started inserting batch run Id in VNET SQL DB");
            var parameters = new SqlParameter[]
                {
                    new SqlParameter(ServiceConstants.BatchRunIdParam, SqlDbType.VarChar) 
                    { Value = batchRunId.ToString(CultureInfo.CurrentCulture) },
                    new SqlParameter(ServiceConstants.IsAutoSPParam, SqlDbType.Bit) { Value = isAuto },
                };
            await _sqlDataRepository.ExecuteReaderAsync(ServiceConstants.InsertBatchRunTypeSPName, parameters, true, true);

            _logger.LogInformation($"Successfully inserted new batch run id: {batchRunId} with isAuto : {isAuto} in VNET SQL DB");
        }
    }
}
