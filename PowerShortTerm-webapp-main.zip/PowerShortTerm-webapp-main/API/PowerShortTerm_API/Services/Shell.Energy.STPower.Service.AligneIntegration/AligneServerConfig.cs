﻿namespace Shell.Energy.SNE.Service.AligneIntegration
{
    public class AligneServerConfig
    {
        public string PrimaryServer { get; set; } = string.Empty;
        public string SecondaryServer { get; set; } = string.Empty;
        public int Port { get; set; } = 0;
        public string AligneUser { get; set; } = string.Empty;
        public string AlignePassword { get; set; } = string.Empty;
        public bool IsValid()
        {
            return new[] { PrimaryServer, SecondaryServer, AligneUser, AlignePassword }
                .All(s => !string.IsNullOrEmpty(s)) && Port > 0;
        }
    }
}
