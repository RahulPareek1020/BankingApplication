﻿using System.Runtime.InteropServices;
using System.Text;

namespace Shell.Energy.SNE.Service.AligneIntegration
{
    /// <summary>
    /// Class for external service
    /// </summary>
    public class ExternalService : IExternalService
    {

        [DllImport("rptapi.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
        private static extern void RunBatchThread(StringBuilder xmlOutput, int outsize, string primaryHost, string secondaryHost, int port, string xmlInput);

        /// <summary>
        /// Run batch
        /// </summary>
        /// <param name="xmlResponse"></param>
        /// <param name="outsize"></param>
        /// <param name="primaryHost"></param>
        /// <param name="secondaryHost"></param>
        /// <param name="port"></param>
        /// <param name="xmlString"></param>
        /// <returns></returns>
        public void RunBatch(StringBuilder xmlResponse, int outsize, string primaryHost, string secondaryHost, int port, string xmlString)
        {
            RunBatchThread(xmlResponse, outsize, primaryHost, secondaryHost, port, xmlString);
        }
    }
}
