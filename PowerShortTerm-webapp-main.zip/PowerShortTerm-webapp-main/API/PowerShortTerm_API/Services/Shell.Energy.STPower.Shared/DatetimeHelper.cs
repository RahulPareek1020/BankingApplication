﻿namespace Shell.Energy.STPower.Shared
{
    /// <summary>
    /// DateTime helper class
    /// </summary>
    public static class DateTimeHelper
    {
        /// <summary>
        /// Returns datetime based on timezone
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public static DateTime ConvertToUtcFromTimeZone(DateTime time, string timeZoneId)
        {
            var timeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZoneId);
            DateTime formattedDateTime = DateTime.SpecifyKind(time, DateTimeKind.Unspecified);
            var resultDateTimeUtc = TimeZoneInfo.ConvertTimeToUtc(formattedDateTime, timeZone);
            return resultDateTimeUtc;
        }
    }
}
