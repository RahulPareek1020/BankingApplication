﻿using System.Runtime.Serialization;

namespace Shell.Energy.STPower.Shared.Exceptions
{
    [Serializable]
    public class InvalidTradeDataException : Exception
    {
        public InvalidTradeDataException()
        {
        }

        public InvalidTradeDataException(string message)
            : base(message)
        {
        }

        public InvalidTradeDataException(string message, Exception inner)
            : base(message, inner)
        {
        }

        protected InvalidTradeDataException(
            SerializationInfo info,
            StreamingContext context)
            : base(info, context)
        {
        }
    }
}
