﻿using System.Runtime.Serialization;

namespace Shell.Energy.STPower.Shared.Exceptions
{
    [Serializable]
    public class OAuthException : Exception
    {
        public OAuthException()
        {
        }

        public OAuthException(string message)
            : base(message)
        {
        }

        public OAuthException(string message, Exception inner)
            : base(message, inner)
        {
        }

        protected OAuthException(
            SerializationInfo info,
            StreamingContext context)
            : base(info, context)
        {
        }
    }
    }
