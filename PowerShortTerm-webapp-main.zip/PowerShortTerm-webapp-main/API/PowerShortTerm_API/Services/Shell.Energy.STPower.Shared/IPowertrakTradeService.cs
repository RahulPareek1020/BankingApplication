﻿using Shell.Energy.STPower.Data.Dto;
using Shell.Energy.STPower.Data.Models;
using Shell.Energy.STPower.Shared.Model;
using Shell.Energy.STPower.Shared.PowerTrak;
using System.Xml.Linq;

namespace Shell.Energy.STPower.Shared
{
    /// <summary>
    /// Interface for Powertrak Trade Service
    /// </summary>
    public interface IPowertrakTradeService
    {
        Task<IEnumerable<NominationHeader>> GetNominationHeaderData();
        Task<IEnumerable<NominationDetailsDto>> GetNominationDetailsByRunIdAsync(int runId);
        Task<IEnumerable<RawTradeDto>> GetRawTradesByAggPosOrRunIdAsync(int? aggPosRefId, int? runId);
        Task<IEnumerable<MappingRuleDetailsDto>> GetMappingRuleDetails();
        Task<IEnumerable<NominationDetailsDto>> GetAggregatedCptyPositionsWithFilters(int nominationDefinitionId, DateTime deliveryDate);
        Task<XElement> SendNominationToPowertrak(string powertrakRequestXmlMessage, PowerTrakConfig powerTrakConfig);
        Task UpdateNominationBatchRunStatusAsync(int nominationRunId, int stepId, string status, string reason, DateTime? startDateTime, DateTime? endDateTime);
        Task UpdateNominationBatchRunResponse(XElement powertrakApiResponse, int nominationRunId);
        Task<int?> SaveNominationDataWithOffsetInDB(IEnumerable<NominationDetailsDto> cptyAggPositionData);
        Task<string> GetMarketOperators(int nominationDefinitionId);
        Task<string> GetTradeTypes(int nominationDefinitionId, DateTime deliveryDate);
        Task<int?> InsertNominationBatchRun(int nominationDefinitionId, DateTime deliveryDate, string? initiatedBy, bool? isAuto = true);
        Task<NominationStatus> GetNominationStatusByRunIdAsync(int? runId);
        Task<IEnumerable<NominationDetailsDto>> GetAggregatedCptyPositionsByRunIdWithFilters(int nominationRunId);
        Task SaveNominationPositionsInDB(IEnumerable<NominationDetailsDto> cptyAggPositionData);
        Task<NominationReady> GetReadyNominations();
        Task InsertNominationRunOtel(int nominationRunId, string traceId, string spanId);
        Task<NominationRunOtelIds> GetNominationRunTraceSpanId(int nominationRunId);
        Task<string> GetPowerTrakEnv(int nominationRunId);
        Task<List<NominationCorrelationId>> GetCorrelationIds();
        Task<XElement> GetPowertrakStatusReport(PowerTrakConfig powerTrakConfig, string correlationId);
        void UpdatePowertrakTradeStatuses(IEnumerable<TradeStatusDto> statusList);
        Task<IEnumerable<NominationDetailsDto>> GetPreviousAggregationPositions(IEnumerable<NominationDetailsDto> cptyAggPositionData, int? nominationRunId);
    }
}
