﻿using Newtonsoft.Json.Linq;
using Shell.Energy.STPower.Data.Dto;

namespace Shell.Energy.STPower.Shared
{
    public static class PowertrakHelper
    {
        /// <summary>
        /// Get the trade statuses from the GMSL status response.
        /// </summary>
        /// <param name="gmslStatusResponse"></param>
        /// <returns></returns>
        public static IEnumerable<TradeStatusDto> GetTradeStatuses(string gmslStatusResponse)
        {
            var tradeStatusDtoList = new List<TradeStatusDto>();
            var jsonObject = JObject.Parse(gmslStatusResponse);

            var statuses = jsonObject["PowerTrak"]?["StatusReport"]?["Statuses"]?["Status"];
            if (statuses != null)
            {
                if (statuses.Type == JTokenType.Array)
                {
                    foreach (var status in statuses)
                    {
                        tradeStatusDtoList.Add(ParseTradeStatus(status));
                    }
                }
                else if (statuses.Type == JTokenType.Object)
                {
                    tradeStatusDtoList.Add(ParseTradeStatus(statuses));
                }
            }
            return tradeStatusDtoList;
        }

        /// <summary>
        /// Parse the trade status.
        /// </summary>
        /// <param name="status"></param>
        /// <returns></returns>
        private static TradeStatusDto ParseTradeStatus(JToken status)
        {
            return new TradeStatusDto
            {
                Reference = status["Reference"]?.ToString(),
                Result = status["Result"]?.ToString(),
                Text = status["Text"]?.ToString()
            };
        }
    }
}
