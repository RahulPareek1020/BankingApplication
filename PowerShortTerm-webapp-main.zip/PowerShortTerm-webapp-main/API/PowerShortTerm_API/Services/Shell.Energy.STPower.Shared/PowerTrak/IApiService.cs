﻿using System.Xml.Linq;

namespace Shell.Energy.STPower.Shared.PowerTrak
{
    public interface IApiService
    {
        Task<XElement> CallPowerApi(HttpClient client, HttpRequestMessage request, string jwtString);
        Task<string> CallApi(HttpClient client, HttpRequestMessage request);
    
}
}
