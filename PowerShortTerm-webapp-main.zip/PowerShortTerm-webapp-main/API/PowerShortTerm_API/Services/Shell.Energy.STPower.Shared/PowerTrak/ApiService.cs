﻿using System.Net.Http.Headers;
using System.Xml.Linq;

namespace Shell.Energy.STPower.Shared.PowerTrak
{

    public class ApiService : IApiService
    {
        private readonly IAppLogger _logger;
        private const string ApplicationXml = "application/xml";
        private const string BearerTokenHeaderValue = "Bearer";

        public ApiService(IAppLogger logger)
        {
            _logger = logger;
        }

        public async Task<XElement> CallPowerApi(HttpClient client, HttpRequestMessage request, string jwtString)
        {
            request.Headers.Authorization = new AuthenticationHeaderValue(BearerTokenHeaderValue, jwtString);
            request.Headers.Accept.Clear();
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue(ApplicationXml));
            var responseContent = await CallApi(client, request);
            return XElement.Parse(responseContent);
        }

        public async Task<string> CallApi(HttpClient client, HttpRequestMessage request)
        {
            var response = await client.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError($"{response.StatusCode} {response.ReasonPhrase}");
                throw new Exception($"{response.StatusCode} {response.ReasonPhrase}");
            }
            return await response.Content.ReadAsStringAsync();
        }
    }
}
