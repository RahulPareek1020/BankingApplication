﻿//namespace Shell.Energy.STPower.Shared.PowerTrak
//{
//    //public static class GmslToken
//    //{
//    //    public static string Token { get; set; }
//    //    public static DateTime Expiry { get; set; }
//    //}
//}
