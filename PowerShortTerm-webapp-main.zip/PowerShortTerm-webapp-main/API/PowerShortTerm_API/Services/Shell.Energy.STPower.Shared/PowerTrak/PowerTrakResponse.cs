﻿using System.Xml.Serialization;

namespace Shell.Energy.STPower.Shared.PowerTrak
{
    [XmlRoot("PowerTrak")]
    public class PowerTrakResponse
    {
        [XmlElement]
        public PowerTrakValidationResult? ValidationResult { get; set; }

        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string? Client { get; set; }
    }
    [XmlType]
    public class PowerTrakValidationResult
    {

        public string? Result { get; set; }

        public string? CorrelationId { get; set; }

        [XmlArray("Errors")]
        [XmlArrayItem("Error")]
        public string[]? Errors { get; set; }
        [System.Xml.Serialization.XmlAttributeAttribute()]

        private readonly System.DateTime timestampField;
    }


}
