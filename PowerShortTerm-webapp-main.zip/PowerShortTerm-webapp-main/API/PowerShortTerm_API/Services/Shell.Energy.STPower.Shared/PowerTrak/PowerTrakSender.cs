﻿using System.Text;
using System.Xml.Linq;
using Shell.Energy.STPower.Shared.Messages;

namespace Shell.Energy.STPower.Shared.PowerTrak
{
    /// <summary>
    /// Class to send power trades to PowerTrak
    /// </summary>
    public class PowerTrakSender : IPowerTrakSender
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IAppLogger _logger;
        private readonly IApiService _apiService;
        private const string ApplicationXml = "application/xml";
        private const string CorrelationIdQueryParam = "CorrelationId";

        /// <summary>
        /// Constructor to initialize PowerTrakTradeSender
        /// </summary>
        /// <param name="httpClientFactory"></param>
        /// <param name="logger"></param>
        /// <param name="apiService"></param>
        public PowerTrakSender(IHttpClientFactory httpClientFactory, IAppLogger logger, IApiService apiService)
        {
            _httpClientFactory = httpClientFactory;
            _logger = logger;
            _apiService = apiService;
        }

        /// <summary>
        /// Get JWT token and submit power trades
        /// </summary>
        /// <param name="powerTrades"></param>
        /// <param name="jwtString"></param>
        /// <returns></returns>
        public async Task<XElement> SubmitPowerTrades(XElement powerTrades, string jwtString, PowerTrakConfig powerTrakConfig)
        {
            _logger.LogInformation(LogMessages.SendPowerTradeRequest);

            if (string.IsNullOrEmpty(jwtString))
            {
                return null;
            }

            if (powerTrakConfig == null || powerTrakConfig.BaseUrl == null || string.IsNullOrEmpty(powerTrakConfig.SubmitPowerTradesUrlPath))
            {
                throw new InvalidDataException($"PowertrakConfig is null or empty.");
            }

            // Convert XElement to string and then to byte array to get the size
            var powerTradesString = powerTrades.ToString(SaveOptions.DisableFormatting);
            var powerTradesBytes = Encoding.UTF8.GetBytes(powerTradesString);
            var contentSize = powerTradesBytes.Length / 1024.0;

            // Log the content size
            _logger.LogInformation($"Request content length: {contentSize:F2} KB");
            
            var client = _httpClientFactory.CreateClient();
            var requestUri = new Uri(powerTrakConfig.BaseUrl!, powerTrakConfig.SubmitPowerTradesUrlPath);
            var requestContent = new StringContent(powerTradesString, Encoding.UTF8, ApplicationXml);

            var request = new HttpRequestMessage(HttpMethod.Post, requestUri) { Content = requestContent };
            return await _apiService.CallPowerApi(client, request, jwtString);
        }

        /// <summary>
        /// Get JWT token
        /// </summary>
        /// <returns></returns>
        public async Task<string> GetJwtString(PowerTrakConfig powerTrakConfig)
        {
            _logger.LogInformation(LogMessages.SendNewTokenRequestToPowertrak);

            if (powerTrakConfig == null || powerTrakConfig.BaseUrl == null || string.IsNullOrEmpty(powerTrakConfig.AuthenticationUrlPath))
            {
                throw new InvalidDataException($"PowertrakConfig is null or empty.");
            }

            var client = _httpClientFactory.CreateClient();
            var requestUri = new Uri(powerTrakConfig.BaseUrl!, powerTrakConfig.AuthenticationUrlPath);
            var content = new XElement("Credentials",
                new XElement("Role", powerTrakConfig.Role),
                new XElement("Username", powerTrakConfig.Username),
                new XElement("Password", powerTrakConfig.Password)).ToString(SaveOptions.DisableFormatting);

            var request = new HttpRequestMessage(HttpMethod.Post, requestUri) { Content = new StringContent(content, Encoding.UTF8, ApplicationXml) };
            return await _apiService.CallApi(client, request);
        }

        /// <summary>
        /// Method to get status report
        /// </summary>
        /// <param name="correlationId"></param>
        /// <param name="jwtString"></param>
        /// <returns></returns>
        public async Task<XElement> GetStatusReport(string correlationId, string jwtString, PowerTrakConfig powerTrakConfig)
        {
            if (powerTrakConfig == null || powerTrakConfig.BaseUrl == null || string.IsNullOrEmpty(powerTrakConfig.StatusReportUrlPath))
            {
                throw new InvalidDataException($"PowertrakConfig is null or empty.");
            }

            var client = _httpClientFactory.CreateClient();
            var requestUri = new Uri(powerTrakConfig.BaseUrl!, $"{powerTrakConfig.StatusReportUrlPath}?{CorrelationIdQueryParam}={correlationId}");
            var request = new HttpRequestMessage(HttpMethod.Get, requestUri);
            _logger.LogInformation($"Calling GetStatusReport, correlation ID {correlationId}...");
            return await _apiService.CallPowerApi(client, request, jwtString);
        }
    }
}