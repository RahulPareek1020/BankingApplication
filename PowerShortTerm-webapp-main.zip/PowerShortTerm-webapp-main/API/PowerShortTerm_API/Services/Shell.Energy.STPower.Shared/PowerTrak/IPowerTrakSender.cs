﻿using System.Xml.Linq;

namespace Shell.Energy.STPower.Shared.PowerTrak
{
    public interface IPowerTrakSender
    {
        Task<XElement> SubmitPowerTrades(XElement powerTrades, string jwtString, PowerTrakConfig powerTrakConfig);
        Task<string> GetJwtString(PowerTrakConfig powerTrakConfig);
        Task<XElement> GetStatusReport( string correlationId, string jwtString, PowerTrakConfig powerTrakConfig);
    }
}