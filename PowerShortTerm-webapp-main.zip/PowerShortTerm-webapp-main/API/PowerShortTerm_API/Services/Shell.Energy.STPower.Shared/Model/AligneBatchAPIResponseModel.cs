﻿namespace Shell.Energy.STPower.Shared.Model
{
    public class AligneBatchApiResponseModel
    {
        public required int NominationRunId { get; set; }
        public string? AligneBatchResponse { get; set; }
    }
}
