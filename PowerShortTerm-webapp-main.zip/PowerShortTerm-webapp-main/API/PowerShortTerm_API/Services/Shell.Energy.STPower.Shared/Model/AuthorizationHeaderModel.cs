﻿using Microsoft.AspNetCore.Mvc;

namespace Shell.Energy.STPower.Shared.Model
{
    public class AuthorizationHeaderModel
    {
        [FromHeader(Name = "Authorization")]
        public string? Authorization { get; set; }
    }
}
