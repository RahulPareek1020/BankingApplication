﻿namespace Shell.Energy.STPower.Shared.Model
{
    public class AligneBatchRequestModel
    {
        public required DateTime FromDate { get; set; }
        public required DateTime ToDate { get; set; }
        public required string BatchName { get; set; } = string.Empty;
        public required string MarketOperator { get; set; } = string.Empty;
        public required int NominationRunId { get; set; }
        public required bool? IsAuto { get; set; } = true;
    }
}
