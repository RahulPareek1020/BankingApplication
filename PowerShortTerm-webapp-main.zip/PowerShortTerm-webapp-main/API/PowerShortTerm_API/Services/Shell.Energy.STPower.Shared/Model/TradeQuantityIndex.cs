﻿namespace Shell.Energy.STPower.Shared.Model
{
    public class TradeQuantityIndex
    {
        public int StartIndex { get; set; }
        public int EndIndex { get; set; }
        public int PeriodCount { get; set; }

    }
}
