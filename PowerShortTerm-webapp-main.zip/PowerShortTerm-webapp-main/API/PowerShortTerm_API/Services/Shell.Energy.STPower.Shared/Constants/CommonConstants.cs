﻿namespace Shell.Energy.STPower.Shared.Constants
{
    public static class CommonConstants
    {
        public static readonly string Azp = "azp";
        public static readonly string Authorization = "Authorization";
        public static readonly string Issuer = "Jwt:Issuer";
        public static readonly string Jwt = "jwt";
        public static readonly string JwtIssuer = "Jwt:Issuer";
        public static readonly string M2M = "M2M";
        public static readonly string Name = "name";
        public static readonly string RealmAccess = "realm_access";
        public static readonly string Roles = "roles";
        public static readonly string SNE = "SNE";
        public static readonly string SNE_ = "SNE_";
        public static readonly string SNE_M2M_ = "SNE_M2M_";
    }
}
