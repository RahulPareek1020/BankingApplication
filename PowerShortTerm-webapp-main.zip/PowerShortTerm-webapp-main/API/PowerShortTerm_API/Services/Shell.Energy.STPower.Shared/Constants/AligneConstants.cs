﻿namespace Shell.Energy.STPower.Shared.Constants
{
    public static class AligneConstants
    {
        public static readonly string AlignePrimConfigKey = "AligneServerDetails:ZN-REPORTRUNNER-SERVERPRIM";
        public static readonly string AligneSecConfigKey = "AligneServerDetails:ZN-REPORTRUNNER-SERVERSEC";
        public static readonly string AlignePortConfigKey = "AligneServerDetails:ZN-REPORTRUNNER-PORT";
        public static readonly string AligneUserConfigKey = "AligneServerDetails:ZN-REPORTRUNNER-USERNAME";
        public static readonly string AlignePasswordConfigKey = "AligneServerDetails:ZN-REPORTRUNNER-PASSWORD";
        public static readonly string UKMarketOperator = "Elexon";
        public static readonly string PowerTradeType = "PW_TRADE";
        public static readonly string TransTradeType = "PW_TRANS";
        public static readonly string AligneResponseTimeoutConfigKey = "AligneResponseTimeoutInSec";
    }
}
