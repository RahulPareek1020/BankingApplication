﻿using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Shell.Stratos.DotNet.SDK.KeyVault;

namespace Shell.Energy.STPower.Shared.Modules;

/// <summary>
/// Module to add key vault configurations
/// </summary>
public static class KeyVaultModule
{
    private const string DevelopmentEnvironment = "LocalDevelopment";

    /// <summary>
    /// Adds KeyVault to the provided IFunctionsConfigurationBuilder.
    /// </summary>
    /// <typeparam name="T">The type of the configuration builder.</typeparam>
    /// <param name="configurationBuilder">The configuration builder to add KeyVault to.</param>
    /// <returns>The updated configuration with KeyVault added.</returns>
    public static IConfiguration AddKeyVault<T>(this IFunctionsConfigurationBuilder configurationBuilder)
    {
        ArgumentNullException.ThrowIfNull(configurationBuilder);
        var environment = configurationBuilder.GetContext().EnvironmentName;
        return AddKeyVault<T>(configurationBuilder.ConfigurationBuilder, environment);
    }

    /// <summary>
    /// Adds KeyVault to the provided IConfigurationBuilder.
    /// </summary>
    /// <typeparam name="T">The type of the configuration builder.</typeparam>
    /// <param name="configurationBuilder">The configuration builder to add KeyVault to.</param>
    /// <param name="environment">The environment in which the application is running.</param>
    /// <returns>The updated configuration with KeyVault added.</returns>
    public static IConfiguration AddKeyVault<T>(this IConfigurationBuilder configurationBuilder, string? environment)
    {
        ArgumentNullException.ThrowIfNull(configurationBuilder);

        if (environment==null || !environment.Equals(DevelopmentEnvironment, StringComparison.OrdinalIgnoreCase))
        {
            configurationBuilder.AddStratosKeyVault();
            return configurationBuilder.Build();
        }
        return configurationBuilder.Build();
    }
}
