﻿using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using Shell.Energy.STPower.Data.Constants;
using Shell.Energy.STPower.Data.Dto;
using Shell.Energy.STPower.Data.Models;
using Shell.Energy.STPower.Shared.Constants;
using Shell.Energy.STPower.Shared.Enums;
using Shell.Energy.STPower.Shared.Exceptions;
using Shell.Energy.STPower.Shared.Model;
using System.Data;
using System.Globalization;
using System.Reflection;
using System.Text;

namespace Shell.Energy.STPower.Shared
{
    /// <summary>
    /// Helper class for Trade
    /// </summary>
    public static class TradeHelper
    {
        private static float epsilon = 0.0001f;
        private static int maxQHIndex = 100;
        /// <summary>
        /// Method to get Raw Trade from reader
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        public static RawTrade GetRawTradeFromReader(SqlDataReader reader)
        {
            return new RawTrade
            {
                RawTradeHeaderId = reader.GetInt32("Aligne_Raw_Trade_Header_Id"),
                NominationRunId = reader.GetInt32("NominationRunId"),
                NominationDefinitionPrecision = reader.GetInt32("NominationDefinitionPrecision"),
                AggPosReferenceId = reader.GetInt32("AggPosReferenceId"),
                AggPosReference = reader.GetString("AggPosReference"),
                TradeReference = reader.GetString("Reference"),
                TradeType = reader.GetString("TradeType"),
                TransactionType = reader.GetString("TransactionType"),
                Entity = reader.GetString("Entity"),
                Counterparty = reader.GetString("Counterparty"),
                FromMarketoperator = reader.GetString("FromMarketOperator"),
                ToMarketoperator = reader.GetString("ToMarketOperator"),
                CapacityType = reader.GetString("CapacityType"),
                CapacityIdentification = reader.GetString("CapacityIdentification"),
                Interconnector = reader.GetString("Interconnector"),
                DeliveryDate = reader.GetDateTime("DeliveryDate"),
                NomDeliveryDate = reader.GetDateTime("NomDeliveryDate"),
                DelDateStart = reader.GetNullableDateTime("Del_DateStart"),
                DelDateEnd = reader.GetNullableDateTime("Del_DateEnd"),
                Cdy1Attr1 = reader.GetString("Cdy1Attr1"),
                PwrNomsOverrideType = reader.GetString("PwrNoms_Override_Type"),
                PwrNomsOverrideInput = reader.GetString("PwrNoms_Override_Input"),
                PwrNomsOverrideFreeform = reader.GetString("PwrNoms_Override_Freeform"),
                AuxSoCpty = reader.GetString("Aux_So_Cpty"),
                CptyNoms = reader.GetString("Cpty_Noms"),
                PeakWorkaround = reader.GetString("Peak_Workaround"),
                InsNumRec = reader.GetInt32("INSNUMREC"),
                RawTradeVolume = GetNominationVolumeFromReader(reader, true),
                TimeZone = reader.GetString(ServiceConstants.Timezone),
                StatusCode = reader.GetString("StatusCode"),
                StatusMessage = reader.GetString("StatusMessage")
            };
        }

        /// <summary>
        /// Get Nomination Details From Reader
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        public static NominationDetails GetNominationDetailFromReader(SqlDataReader reader, bool isAgg)
        {
            NominationDetails nominationDetails;
            nominationDetails = new NominationDetails
            {
                NominationRunId = reader.GetInt32("NominationRunId"),
                NominationDefinitionId = reader.GetInt32("NominationDefinitionId"),
                NominationDefinitionPrecision = reader.GetInt32("NominationDefinitionPrecision"),
                DeliveryDate = reader.GetDateTime("DeliveryDate"),
                AggPosReferenceId = reader.GetInt32("AggPosReferenceId"),
                AggPosReferenceName = reader.GetString("AggPosReferenceName"),
                TradeType = reader.GetString("TradeType"),
                TransactionType = reader.GetString("TransactionType"),
                Granularity = reader.GetString("Granularity"),
                Entity = reader.GetString("Entity"),
                TimeZone = reader.GetString("TimeZone"),
                ClientName = reader.GetString("ClientName"),
                Counterparty = reader.GetString("Counterparty"),
                FromMarketOperator = reader.GetString("FromMarketOperator"),
                ToMarketOperator = reader.GetString("ToMarketOperator"),
                CapacityType = reader.GetString("CapacityType"),
                CapacityIdentification = reader.GetString("CapacityIdentification"),
                Interconnector = reader.GetString("Interconnector"),
                NominationVolume = GetNominationVolumeFromReader(reader, isAgg),
                ContributingTradeHeaderIds = "N/A",
                StatusCode = reader.ColumnExists("StatusCode") ? reader.GetString("StatusCode") : string.Empty,
                StatusMessage = reader.ColumnExists("StatusMessage") ? reader.GetString("StatusMessage") : string.Empty,
            };
            if (isAgg)
            {
                nominationDetails.ContributingTradeHeaderIds = reader.GetString("ContributingTradeHeaderIds");
            }
            return nominationDetails;
        }

        /// <summary>
        /// Get Nomination Volume From Reader
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        private static NominationVolume GetNominationVolumeFromReader(SqlDataReader reader, bool isDetail)
        {
            var volume = new NominationVolume();
            var endIndex = isDetail ? 96 : 100;
            for (int i = 1; i <= endIndex; i++)
            {
                var propertyName = $"QH{i}";
                var property = typeof(NominationVolume).GetProperty(propertyName);
                if (property != null)
                {
                    property.SetValue(volume, reader.GetNullableDouble($"QH{i}"));
                }
            }
            return volume;
        }

        /// <summary>
        /// Get Mapping Rules Master From Reader
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        public static MappingRulesMaster GetMappingRulesMasterFromReader(IDataReader reader)
        {
            return new MappingRulesMaster
            {
                MappingMasterId = reader.GetInt32("MappingMasterId"),
                MappingMasterName = reader.GetString("MappingMasterName"),
                MappingMasterCreatedDate = reader.GetDateTime("MappingMasterCreatedDate"),
                MappingMasterModifiedDate = reader.GetDateTime("MappingMasterModifiedDate"),
                MappingMasterStatus = reader.GetString("MappingMasterStatus")
            };
        }

        /// <summary>
        /// Get Mapping Rules Type From Reader
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        public static MappingRulesType GetMappingRulesType(IDataReader reader)
        {
            return new MappingRulesType
            {
                MappingTypeId = reader.GetInt32("MappingTypeId"),
                MappingTypeName = reader.GetString("MappingTypeName"),
                MappingTypeCreatedDate = reader.GetDateTime("MappingTypeCreatedDate"),
                MappingTypeModifiedDate = reader.GetNullableDateTime("MappingTypeModifiedDate"),
                MappingTypeStatus = reader.GetString("MappingTypeStatus")
            };
        }

        /// <summary>
        /// Get Mapping Rules Input From Reader
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        public static MappingRulesInput GetMappingRulesInput(IDataReader reader)
        {
            return new MappingRulesInput
            {
                MappingInputId = reader.GetInt32("MappingInputId"),
                MappingInputField = reader.GetString("MappingInputField"),
                MappingInputValue = reader.GetString("MappingInputValue"),
                MappingInputStartDate = reader.GetNullableDateTime("MappingInputStartDate"),
                MappingInputEndDate = reader.GetNullableDateTime("MappingInputEndDate"),
                MappingInputCreatedDate = reader.GetDateTime("MappingInputCreatedDate"),
                MappingInputModifiedDate = reader.GetNullableDateTime("MappingInputModifiedDate"),
                MappingInputStatus = reader.GetString("MappingInputStatus")
            };
        }
        /// <summary>
        /// Get Mapping Rules Output From Reader
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>

        public static MappingRulesOutput GetMappingRulesOutput(IDataReader reader)
        {
            return new MappingRulesOutput
            {
                MappingOutputId = reader.GetInt32("MappingOutputId"),
                MappingOutputValue = reader.GetString("MappingOutputValue"),
                MappingOutputStartDate = reader.GetNullableDateTime("MappingOutputStartDate"),
                MappingOutputEndDate = reader.GetNullableDateTime("MappingOutputEndDate"),
                MappingOutputCreatedDate = reader.GetDateTime("MappingOutputCreatedDate"),
                MappingOutputModifiedDate = reader.GetNullableDateTime("MappingOutputModifiedDate"),
                MappingOutputStatus = reader.GetString("MappingOutputStatus")
            };
        }

        /// <summary>
        /// GetInt32 value from reader
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="columnName"></param>
        /// <returns></returns>
        public static int GetInt32(this IDataReader reader, string columnName)
        {
            return reader.GetInt32(reader.GetOrdinal(columnName));
        }

        /// <summary>
        /// GetDouble value from reader
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="columnName"></param>
        /// <returns></returns>
        private static double GetDouble(this IDataReader reader, string columnName)
        {
            return reader.GetDouble(reader.GetOrdinal(columnName));
        }

        /// <summary>
        /// GetDecimal value from reader
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="columnName"></param>
        /// <returns></returns>
        private static decimal GetDecimal(this IDataReader reader, string columnName)
        {
            return reader.GetDecimal(reader.GetOrdinal(columnName));
        }

        private static decimal? GetNullableDecimal(this IDataReader reader, string columnName)
        {
            return reader.IsDBNull(reader.GetOrdinal(columnName)) ? (decimal?)null : reader.GetDecimal(reader.GetOrdinal(columnName));
        }

        private static double? GetNullableDouble(this IDataReader reader, string columnName)
        {
            return reader.IsDBNull(reader.GetOrdinal(columnName)) ? (double?)null : reader.GetDouble(reader.GetOrdinal(columnName));
        }

        /// <summary>
        /// GetDateTime value from reader
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="columnName"></param>
        /// <returns></returns>
        private static DateTime GetDateTime(this IDataReader reader, string columnName)
        {
            return reader.GetDateTime(reader.GetOrdinal(columnName));
        }

        /// <summary>
        /// GetString value from reader
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="columnName"></param>
        /// <returns></returns>
        public static string GetString(this IDataReader reader, string columnName)
        {
            return reader[columnName]?.ToString() ?? string.Empty;
        }

        /// <summary>
        /// GetNullableDateTime value from reader
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="columnName"></param>
        /// <returns></returns>
        private static DateTime? GetNullableDateTime(this IDataReader reader, string columnName)
        {
            return reader.IsDBNull(reader.GetOrdinal(columnName)) ? (DateTime?)null : reader.GetDateTime(reader.GetOrdinal(columnName));
        }

        /// <summary>
        /// Get DLS period count based on the date and granularity
        /// </summary>
        /// <param name="date"></param>
        /// <param name="granularity"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentException"></exception>
        public static int GetDLSPeriodCount(DateTime date, Granularity granularity, string timezone)
        {
            double timezone_offset_delDate = GetOffsetByTimeZone(timezone, date).TotalHours;
            double timezone_offset_delDate_NextDay = GetOffsetByTimeZone(timezone, date.AddDays(1)).TotalHours;
            DateTime lastSundayOfOctober = GetLastSundayOfOctober(date.Year);
            DateTime lastSundayOfMarch = GetLastSundayOfMarch(date.Year);

            bool isOffset = Math.Abs(timezone_offset_delDate - 0) > epsilon || Math.Abs(timezone_offset_delDate_NextDay - 0) > epsilon;

            bool isLongDay = date.Date == lastSundayOfOctober.Date && isOffset;
            bool isShortDay = date.Date == lastSundayOfMarch.Date && isOffset;

            int periodCount = 0;

            switch (granularity)
            {
                case Granularity.QHR:
                    periodCount = isLongDay ? 100 : isShortDay ? 92 : 96;
                    break;
                case Granularity.HHR:
                    periodCount = isLongDay ? 50 : isShortDay ? 46 : 48;
                    break;
                case Granularity.HR:
                    periodCount = isLongDay ? 25 : isShortDay ? 23 : 24;
                    break;
                default:
                    throw new ArgumentException("Invalid granularity");
            }

            return periodCount;
        }

        /// <summary>
        /// Get interval count based on granularity
        /// </summary>
        /// <param name="granularity"></param>
        /// <returns></returns>
        public static int GetIntervalCount(Granularity granularity)
        {
            int interval;
            switch (granularity)
            {
                case Granularity.QHR:
                    interval = DayConstants.MinutesPerQuarterHour; break;
                case Granularity.HHR:
                    interval = DayConstants.MinutesPerHalfHour; break;
                case Granularity.HR:
                    interval = DayConstants.MinutesPerHour; break;
                default:
                    interval = DayConstants.MinutesPerQuarterHour; break;
            }
            return interval;
        }
        private static DateTime GetLastSundayOfOctober(int year)
        {
            DateTime lastDayOfOctober = new DateTime(year, 10, 31);
            int offset = DayOfWeek.Sunday - lastDayOfOctober.DayOfWeek;
            return lastDayOfOctober.AddDays(offset);
        }

        private static DateTime GetLastSundayOfMarch(int year)
        {
            DateTime lastDayOfMarch = new DateTime(year, 03, 31);
            int offset = DayOfWeek.Sunday - lastDayOfMarch.DayOfWeek;
            return lastDayOfMarch.AddDays(offset);
        }

        /// <summary>
        /// Get local time zone id based on market
        /// </summary>
        /// <param name="market"></param>
        /// <returns>string</returns>
        public static string GetLocalTimeZoneIdByMarket(string market)
        {
            return "Central European Standard Time";
        }

        public static Granularity GetGranularity(string granularity)
        {
            switch (granularity)
            {
                case "15":
                    return Granularity.QHR;
                case "30":
                    return Granularity.HHR;
                case "60":
                    return Granularity.HR;
                default:
                    throw new NotFoundException($"Granularity {granularity} is not supported.");
            }
        }

        /// <summary>
        /// Get the volume properties from the trade object
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="trade"></param>
        /// <param name="periodCount"></param>
        /// <returns></returns>
        public static PropertyInfo[] GetVolumeProperties<T>(T trade, int periodCount)
        {
            if (trade is null)
            {
                return [];
            }
            return trade.GetType()
                .GetProperties(BindingFlags.Public | BindingFlags.Instance)
                .Where(p => p.Name.Contains("QH")).Take(periodCount).ToArray();
        }

        /// <summary>
        /// Get the volume array from the trade object
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="volumeProperties"></param>
        /// <param name="trade"></param>
        /// <returns></returns>
        public static List<double> GetVolumeArray<T>(PropertyInfo[] volumeProperties, T trade)
        {
            return volumeProperties.Select(p => Convert.ToDouble(p.GetValue(trade), CultureInfo.InvariantCulture)).ToList();
        }

        /// <summary>
        /// Get the delivery date data based on the array
        /// </summary>
        /// <param name="cptyAggPositionData"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static IEnumerable<NominationDetailsDto> GetTradeDataBasedOnTimeZone(IEnumerable<NominationDetailsDto> cptyAggPositionData, DateTime value)
        {
            List<NominationDetailsDto> nominationDetailsDtoList = new List<NominationDetailsDto>();
            var filteredData = cptyAggPositionData
               .GroupBy(dto => dto.AggPosReferenceName)
               .Select(group => new
               {
                   AggPosReferenceName = group.Key,
                   NominationDetails = group.ToList()
               })
               .ToList();
            foreach (var data in filteredData)
            {
                int startIndex, endIndex;
                StringBuilder contributingTradeHeaderIdSb = new StringBuilder();
                double timezone_offset = GetOffsetByTimeZone(data.NominationDetails[0].TimeZone, value).TotalHours;
                int finalArrayIndex = 1;
                var nominationDetailsDto = new NominationDetailsDto();
                foreach (var item in data.NominationDetails)
                {
                    Granularity granularity = TradeHelper.GetGranularity(item.Granularity);
                    int periodCount = TradeHelper.GetDLSPeriodCount(value, granularity, item.TimeZone);
                    nominationDetailsDto.NominationRunId = item.NominationRunId;
                    nominationDetailsDto.NominationDefinitionId = item.NominationDefinitionId;
                    nominationDetailsDto.NominationDefinitionName = item.NominationDefinitionName;
                    nominationDetailsDto.NominationDefinitionPrecision = item.NominationDefinitionPrecision;
                    nominationDetailsDto.TimeZone = item.TimeZone;
                    nominationDetailsDto.AggPosReferenceId = item.AggPosReferenceId;
                    nominationDetailsDto.AggPosReferenceName = item.AggPosReferenceName;
                    nominationDetailsDto.ContributingTradeHeaderIds = item.ContributingTradeHeaderIds;
                    nominationDetailsDto.TradeType = item.TradeType;
                    nominationDetailsDto.TransactionType = item.TransactionType;
                    nominationDetailsDto.FromMarketOperator = item.FromMarketOperator;
                    nominationDetailsDto.ToMarketOperator = item.ToMarketOperator;
                    nominationDetailsDto.CapacityType = item.CapacityType;
                    nominationDetailsDto.CapacityIdentification = item.CapacityIdentification;
                    nominationDetailsDto.DeliveryDate = value;
                    nominationDetailsDto.Granularity = item.Granularity;
                    nominationDetailsDto.Entity = item.Entity;
                    nominationDetailsDto.Counterparty = item.Counterparty;
                    nominationDetailsDto.Interconnector = item.Interconnector;
                    nominationDetailsDto.PeriodCount = periodCount;
                    nominationDetailsDto.ClientName = item.ClientName;
                    (startIndex, endIndex) = GetQHIndexRange(granularity, timezone_offset);
                    if (data.NominationDetails.Count > 1 && item.DeliveryDate.Equals(value.AddDays(-1)) && Math.Abs(timezone_offset - 0) > epsilon)
                    {
                        finalArrayIndex = GetTradeValuesForDayMinusOne(startIndex, endIndex, finalArrayIndex, nominationDetailsDto, item);
                    }
                    else if (data.NominationDetails.Count > 1 && item.DeliveryDate.Equals(value))
                    {
                        int itemIndex = 1;
                        GetTradeValuesForDeliveryDate(finalArrayIndex, nominationDetailsDto, item, periodCount, itemIndex);
                    }
                    else
                    {
                        TradeQuantityIndex index = new TradeQuantityIndex();
                        index.StartIndex = startIndex;
                        index.EndIndex = endIndex;
                        index.PeriodCount = periodCount;
                        finalArrayIndex = GetTradesForPeakTrade(value, data.NominationDetails, nominationDetailsDto, item, index);
                    }
                    if (contributingTradeHeaderIdSb.Length > 0)
                    {
                        contributingTradeHeaderIdSb.Append(",");
                    }
                    contributingTradeHeaderIdSb.Append(item.ContributingTradeHeaderIds);
                }


                nominationDetailsDto.ContributingTradeHeaderIds = string.Join(",", contributingTradeHeaderIdSb.ToString().Split(',').Distinct());
                nominationDetailsDtoList.Add(nominationDetailsDto);

            }
            //Remove trades having total volume zero
            nominationDetailsDtoList.RemoveAll(x => x.TotalVolume != null && Math.Abs(x.TotalVolume.Value) < epsilon);

            return nominationDetailsDtoList;
        }

        /// <summary>
        /// Get raw trades based on timezone
        /// </summary>
        /// <param name="rawTradeData"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static IEnumerable<RawTradeDto> GetTradeDataBasedOnTimeZoneRawTrade(IEnumerable<RawTradeDto> rawTradeData, DateTime value)
        {
            List<RawTradeDto> rawTradesDtoList = new List<RawTradeDto>();
            var filteredData = rawTradeData
               .GroupBy(dto => dto.TradeReference)
               .Select(group => new
               {
                   AggPosReferenceName = group.Key,
                   NominationDetails = group.ToList()
               })
               .ToList();
            foreach (var data in filteredData)
            {
                int startIndex, endIndex;
                double timezone_offset = GetOffsetByTimeZone(data.NominationDetails[0].TimeZone, value).TotalHours;
                int finalArrayIndex = 1;
                var rawTradesDto = new RawTradeDto();
                foreach (var item in data.NominationDetails)
                {
                    const Granularity granularity = Granularity.QHR;
                    int periodCount = TradeHelper.GetDLSPeriodCount(value, granularity, item.TimeZone);

                    rawTradesDto.NominationRunId = item.NominationRunId;
                    rawTradesDto.TimeZone = item.TimeZone;
                    rawTradesDto.AggPosReferenceId = item.AggPosReferenceId;
                    rawTradesDto.AggPosReference = item.AggPosReference;
                    rawTradesDto.TradeType = item.TradeType;
                    rawTradesDto.TransactionType = item.TransactionType;
                    rawTradesDto.FromMarketoperator = item.FromMarketoperator;
                    rawTradesDto.ToMarketoperator = item.ToMarketoperator;
                    rawTradesDto.CapacityType = item.CapacityType;
                    rawTradesDto.CapacityIdentification = item.CapacityIdentification;
                    rawTradesDto.DeliveryDate = value;
                    rawTradesDto.NomDeliveryDate = item.NomDeliveryDate;
                    rawTradesDto.Entity = item.Entity;
                    rawTradesDto.Counterparty = item.Counterparty;
                    rawTradesDto.Interconnector = item.Interconnector;
                    rawTradesDto.TradeReference = item.TradeReference;
                    rawTradesDto.DelDateStart = item.DelDateStart;
                    rawTradesDto.DelDateEnd = item.DelDateEnd;
                    rawTradesDto.Cdy1Attr1 = item.Cdy1Attr1;
                    rawTradesDto.PwrNomsOverrideType = item.PwrNomsOverrideType;
                    rawTradesDto.PwrNomsOverrideInput = item.PwrNomsOverrideInput;
                    rawTradesDto.PwrNomsOverrideFreeform = item.PwrNomsOverrideFreeform;
                    rawTradesDto.AuxSoCpty = item.AuxSoCpty;
                    rawTradesDto.CptyNoms = item.CptyNoms;
                    rawTradesDto.PeakWorkaround = item.PeakWorkaround;
                    rawTradesDto.InsNumRec = item.InsNumRec;
                    rawTradesDto.PeriodCount = periodCount;
                    rawTradesDto.NominationDefinitionPrecision = item.NominationDefinitionPrecision;
                    rawTradesDto.StatusCode = item.StatusCode;
                    rawTradesDto.StatusMessage = item.StatusMessage;
                    (startIndex, endIndex) = GetQHIndexRange(granularity, timezone_offset);
                    if (data.NominationDetails.Count > 1 && item.DeliveryDate.Equals(value.AddDays(-1)) && Math.Abs(timezone_offset - 0) > epsilon)
                    {
                        finalArrayIndex = GetTradeValuesForDayMinusOneRawTrade(startIndex, endIndex, finalArrayIndex, rawTradesDto, item);
                    }
                    else if (data.NominationDetails.Count > 1 && item.DeliveryDate.Equals(value))
                    {
                        const int itemIndex = 1;
                        GetTradeValuesForDeliveryDateRawTrade(finalArrayIndex, rawTradesDto, item, periodCount, itemIndex);
                    }
                    else
                    {
                        TradeQuantityIndex index = new TradeQuantityIndex();
                        index.StartIndex = startIndex;
                        index.EndIndex = endIndex;
                        index.PeriodCount = periodCount;
                        finalArrayIndex = GetTradesForPeakTradeRawTrade(value, data.NominationDetails, rawTradesDto, item, index);
                    }
                }

                rawTradesDtoList.Add(rawTradesDto);

            }

            return rawTradesDtoList;
        }


        private static int GetTradesForPeakTrade(DateTime value, ICollection<NominationDetailsDto> nomDetails, NominationDetailsDto nomDetailsDto, NominationDetailsDto item, TradeQuantityIndex index)
        {
            int finalArrayIndex = 1;
            // Add condition to consider peak trade value where trade data is not available for D-1
            if (nomDetails.Count == 1 && item.DeliveryDate.Equals(value))
            {
                finalArrayIndex = GetPeakTradeValues(index.StartIndex, index.EndIndex, finalArrayIndex, nomDetailsDto, item, index.PeriodCount);
            }
            else if (nomDetails.Count == 1 && item.DeliveryDate.Equals(value.AddDays(-1)))
            {
                finalArrayIndex = GetPeakTradeValuesForDayMinusOne(index.StartIndex, index.EndIndex, finalArrayIndex, nomDetailsDto, item, index.PeriodCount);
            }

            return finalArrayIndex;
        }

        private static int GetTradesForPeakTradeRawTrade(DateTime value, ICollection<RawTradeDto> nomDetails, RawTradeDto nomDetailsDto, RawTradeDto item, TradeQuantityIndex index)
        {
            int finalArrayIndex = 1;
            // Add condition to consider peak trade value where trade data is not available for D-1
            if (nomDetails.Count == 1 && item.DeliveryDate.Equals(value))
            {
                finalArrayIndex = GetPeakTradeValuesRawTrade(index.StartIndex, index.EndIndex, finalArrayIndex, nomDetailsDto, item, index.PeriodCount);
            }
            else if (nomDetails.Count == 1 && item.DeliveryDate.Equals(value.AddDays(-1)))
            {
                finalArrayIndex = GetPeakTradeValuesForDayMinusOneRawTrade(index.StartIndex, index.EndIndex, finalArrayIndex, nomDetailsDto, item, index.PeriodCount);
            }

            return finalArrayIndex;
        }

        private static void GetTradeValuesForDeliveryDate(int finalArrayIndex, NominationDetailsDto? nominationDetailsDto, NominationDetailsDto? item, int periodCount, int itemIndex)
        {
            for (int dtoIndex = finalArrayIndex; dtoIndex <= periodCount; dtoIndex++, itemIndex++)
            {
                nominationDetailsDto?.GetType()?.GetProperty($"QH{dtoIndex}")?.SetValue(nominationDetailsDto, item?.GetType()?.GetProperty($"QH{itemIndex}")?.GetValue(item));
            }

        }

        private static void GetTradeValuesForDeliveryDateRawTrade(int finalArrayIndex, RawTradeDto? nominationDetailsDto, RawTradeDto? item, int periodCount, int itemIndex)
        {
            for (int dtoIndex = finalArrayIndex; dtoIndex <= periodCount; dtoIndex++, itemIndex++)
            {
                nominationDetailsDto?.GetType()?.GetProperty($"QH{dtoIndex}")?.SetValue(nominationDetailsDto, item?.GetType()?.GetProperty($"QH{itemIndex}")?.GetValue(item));
            }

        }

        private static int GetTradeValuesForDayMinusOne(int startIndex, int endIndex, int finalArrayIndex, NominationDetailsDto? nominationDetailsDto, NominationDetailsDto? item)
        {
            for (int index = startIndex; index <= endIndex; index++, finalArrayIndex++)
            {
                nominationDetailsDto?.GetType()?.GetProperty($"QH{finalArrayIndex}")?.SetValue(nominationDetailsDto, item?.GetType()?.GetProperty($"QH{index}")?.GetValue(item));
            }

            return finalArrayIndex;
        }

        private static int GetTradeValuesForDayMinusOneRawTrade(int startIndex, int endIndex, int finalArrayIndex, RawTradeDto? nominationDetailsDto, RawTradeDto? item)
        {
            for (int index = startIndex; index <= endIndex; index++, finalArrayIndex++)
            {
                nominationDetailsDto?.GetType()?.GetProperty($"QH{finalArrayIndex}")?.SetValue(nominationDetailsDto, item?.GetType()?.GetProperty($"QH{index}")?.GetValue(item));
            }

            return finalArrayIndex;
        }

        private static int GetPeakTradeValues(int startIndex, int endIndex, int finalArrayIndex, NominationDetailsDto? nominationDetailsDto, NominationDetailsDto? item, int periodCount)
        {
            for (int index = startIndex; index <= endIndex; index++, finalArrayIndex++)
            {
                nominationDetailsDto?.GetType()?.GetProperty($"QH{finalArrayIndex}")?.SetValue(nominationDetailsDto, ServiceConstants.ZeroValue);
            }
            int itemIndex = 1;
            for (int dtoIndex = finalArrayIndex; dtoIndex <= periodCount; dtoIndex++, itemIndex++)
            {
                nominationDetailsDto?.GetType()?.GetProperty($"QH{dtoIndex}")?.SetValue(nominationDetailsDto, item?.GetType()?.GetProperty($"QH{itemIndex}")?.GetValue(item));
            }

            return finalArrayIndex;
        }

        private static int GetPeakTradeValuesRawTrade(int startIndex, int endIndex, int finalArrayIndex, RawTradeDto? nominationDetailsDto, RawTradeDto? item, int periodCount)
        {
            for (int index = startIndex; index <= endIndex; index++, finalArrayIndex++)
            {
                nominationDetailsDto?.GetType()?.GetProperty($"QH{finalArrayIndex}")?.SetValue(nominationDetailsDto, ServiceConstants.ZeroValue);
            }
            int itemIndex = 1;
            for (int dtoIndex = finalArrayIndex; dtoIndex <= periodCount; dtoIndex++, itemIndex++)
            {
                nominationDetailsDto?.GetType()?.GetProperty($"QH{dtoIndex}")?.SetValue(nominationDetailsDto, item?.GetType()?.GetProperty($"QH{itemIndex}")?.GetValue(item));
            }

            return finalArrayIndex;
        }

        private static int GetPeakTradeValuesForDayMinusOne(int startIndex, int endIndex, int finalArrayIndex, NominationDetailsDto? nominationDetailsDto, NominationDetailsDto? item, int periodCount)
        {
            for (int index = startIndex; index <= endIndex; index++, finalArrayIndex++)
            {
                nominationDetailsDto?.GetType()?.GetProperty($"QH{finalArrayIndex}")?.SetValue(nominationDetailsDto, item?.GetType()?.GetProperty($"QH{index}")?.GetValue(item));
            }
            int itemIndex = 1;
            for (int dtoIndex = finalArrayIndex; dtoIndex <= periodCount; dtoIndex++, itemIndex++)
            {
                nominationDetailsDto?.GetType()?.GetProperty($"QH{dtoIndex}")?.SetValue(nominationDetailsDto, ServiceConstants.ZeroValue);
            }

            return finalArrayIndex;
        }

        private static int GetPeakTradeValuesForDayMinusOneRawTrade(int startIndex, int endIndex, int finalArrayIndex, RawTradeDto? nominationDetailsDto, RawTradeDto? item, int periodCount)
        {
            for (int index = startIndex; index <= endIndex; index++, finalArrayIndex++)
            {
                nominationDetailsDto?.GetType()?.GetProperty($"QH{finalArrayIndex}")?.SetValue(nominationDetailsDto, item?.GetType()?.GetProperty($"QH{index}")?.GetValue(item));
            }
            int itemIndex = 1;
            for (int dtoIndex = finalArrayIndex; dtoIndex <= periodCount; dtoIndex++, itemIndex++)
            {
                nominationDetailsDto?.GetType()?.GetProperty($"QH{dtoIndex}")?.SetValue(nominationDetailsDto, ServiceConstants.ZeroValue);
            }

            return finalArrayIndex;
        }



        /// <summary>
        /// Get QH index ranges to fetch from deliverydate-1
        /// </summary>
        /// <param name="granularity"></param>
        /// <param name="offset"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentException"></exception>
        public static (int startIndex, int endIndex) GetQHIndexRange(Granularity granularity, double offset)
        {
            int startIndex = 0;
            int endIndex = 0;

            switch (granularity)
            {
                case Granularity.QHR:
                    startIndex = (int)(96 - (offset * 4) + 1);
                    endIndex = 96;
                    break;
                case Granularity.HHR:
                    startIndex = (int)(48 - (offset * 2) + 1);
                    endIndex = 48;
                    break;
                case Granularity.HR:
                    startIndex = (int)(24 - offset + 1);
                    endIndex = 24;
                    break;
                default:
                    throw new ArgumentException("Invalid granularity");
            }

            return (startIndex, endIndex);
        }

        /// <summary>
        /// Get the offset by timezone
        /// </summary>
        /// <param name="timeZoneId"></param>
        /// <param name="dateTime"></param>
        /// <returns></returns>
        public static TimeSpan GetOffsetByTimeZone(string timeZoneId, DateTime dateTime)
        {
            TimeZoneInfo timeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZoneId);
            TimeSpan offset = timeZone.GetUtcOffset(dateTime);
            return offset;
        }

        public static DataTable CreateDTWithNominationData(IEnumerable<NominationDetailsDto> cptyAggPositionData)
        {
            var dataTable = new DataTable();
            dataTable.Columns.Add("NominationRunId", typeof(int));
            dataTable.Columns.Add("NominationDefinitionId", typeof(int));
            dataTable.Columns.Add("NominationDefinitionName", typeof(string));
            dataTable.Columns.Add("TimeZone", typeof(string));
            dataTable.Columns.Add("DeliveryDate", typeof(DateTime));
            dataTable.Columns.Add("AggPosReferenceId", typeof(int));
            dataTable.Columns.Add("AggPosReferenceName", typeof(string));
            dataTable.Columns.Add("ContributingTradeHeaderIds", typeof(string));
            dataTable.Columns.Add("PeriodCount", typeof(int));
            dataTable.Columns.Add("TradeType", typeof(string));
            dataTable.Columns.Add("TransactionType", typeof(string));
            dataTable.Columns.Add("Granularity", typeof(string));
            dataTable.Columns.Add("Entity", typeof(string));
            dataTable.Columns.Add("Counterparty", typeof(string));
            dataTable.Columns.Add("FromMarketOperator", typeof(string));
            dataTable.Columns.Add("ToMarketOperator", typeof(string));
            dataTable.Columns.Add("CapacityType", typeof(string));
            dataTable.Columns.Add("CapacityIdentification", typeof(string));
            dataTable.Columns.Add("Interconnector", typeof(string));
            for (int i = 1; i <= maxQHIndex; i++)
            {
                dataTable.Columns.Add($"QH{i}", typeof(decimal));
            }

            foreach (var item in cptyAggPositionData)
            {
                var row = dataTable.NewRow();
                row["NominationRunId"] = item.NominationRunId;
                row["NominationDefinitionId"] = item.NominationDefinitionId;
                row["NominationDefinitionName"] = item.NominationDefinitionName;
                row["TimeZone"] = item.TimeZone;
                row["DeliveryDate"] = item.DeliveryDate;
                row["AggPosReferenceId"] = item.AggPosReferenceId;
                row["AggPosReferenceName"] = item.AggPosReferenceName;
                row["ContributingTradeHeaderIds"] = item.ContributingTradeHeaderIds;
                row["PeriodCount"] = item.PeriodCount;
                row["TradeType"] = item.TradeType;
                row["TransactionType"] = item.TransactionType;
                row["Granularity"] = item.Granularity;
                row["Entity"] = item.Entity;
                row["Counterparty"] = item.Counterparty;
                row["FromMarketOperator"] = item.FromMarketOperator;
                row["ToMarketOperator"] = item.ToMarketOperator;
                row["CapacityType"] = string.IsNullOrEmpty(item.CapacityType) ? DBNull.Value : item.CapacityType;
                row["CapacityIdentification"] = string.IsNullOrEmpty(item.CapacityIdentification) ? DBNull.Value : item.CapacityIdentification;
                row["Interconnector"] = string.IsNullOrEmpty(item.Interconnector) ? DBNull.Value : item.Interconnector;
                for (int i = 1; i <= maxQHIndex; i++)
                {
                    row[$"QH{i}"] = typeof(NominationDetailsDto).GetProperty($"QH{i}").GetValue(item) ?? DBNull.Value;
                }
                dataTable.Rows.Add(row);
            }

            return dataTable;
        }


        public static DataTable CreateDTWithAggPosReferences(IEnumerable<NominationDetailsDto>? cptyAggPositionData)
        {

            var dataTable = new DataTable();
            dataTable.Locale = CultureInfo.InvariantCulture;
            dataTable.Columns.Add(ServiceConstants.AggPosReferenceName, typeof(string));

            if (cptyAggPositionData != null && cptyAggPositionData.Any())
            {
                foreach (var item in cptyAggPositionData)
                {
                    var row = dataTable.NewRow();
                    row[ServiceConstants.AggPosReferenceName] = item.AggPosReferenceName;
                    dataTable.Rows.Add(row);
                }
            }

            return dataTable;
        }

        /// <summary>
        /// Get aligne batch request model based on delivery date, market operators, trade types and nomination run id
        /// </summary>
        /// <param name="deliveryDate"></param>
        /// <param name="marketOperators"></param>
        /// <param name="tradeTypes"></param>
        /// <param name="nominationRunId"></param>
        /// <returns></returns>
        public static AligneBatchRequestModel GetAligneBatchRequestModel(DateTime? deliveryDate, string marketOperator, string tradeTypes, int nominationRunId, bool? isAuto)
        {
            var batchName = GetAligneBatchName(tradeTypes);
            return new AligneBatchRequestModel
            {
                FromDate = deliveryDate.Value.AddDays(-1),
                ToDate = deliveryDate.Value,
                BatchName = batchName,
                MarketOperator = !string.IsNullOrEmpty(marketOperator) && batchName != BatchNames.TransBatch ? marketOperator : string.Empty,
                NominationRunId = nominationRunId,
                IsAuto = isAuto
            };
        }

        /// <summary>
        /// Get aligne batch name based on trade types
        /// </summary>
        /// <param name="tradeTypes"></param>
        /// <returns></returns>
        public static string GetAligneBatchName(string tradeTypes)
        {
            if (string.IsNullOrEmpty(tradeTypes))
            {
                return BatchNames.PowerTransBatch;
            }

            var tradeTypeList = tradeTypes.Split(',').Select(t => t.Trim()).ToList();

            if (tradeTypeList.Count == 1)
            {
                if (tradeTypeList.Contains(AligneConstants.PowerTradeType))
                {
                    return BatchNames.PowerBatch;
                }
                else if (tradeTypeList.Contains(AligneConstants.TransTradeType))
                {
                    return BatchNames.TransBatch;
                }
            }
            return BatchNames.PowerTransBatch;
        }

        /// <summary>
        /// Check if the flow is UK flow
        /// </summary>
        /// <param name="fromMarketOperator"></param>
        /// <param name="toMarketOperator"></param>
        /// <returns></returns>
        public static bool IsUkFlow(string? fromMarketOperator, string? toMarketOperator)
        {
            return fromMarketOperator == AligneConstants.UKMarketOperator || toMarketOperator == AligneConstants.UKMarketOperator;
        }

        public static void SetPrecisionForVolumes(int precision, object obj)
        {
            if (obj != null)
            {
                Type type = obj.GetType();
                PropertyInfo[] properties = type.GetProperties();

                foreach (PropertyInfo property in properties)
                {
                    if (property.PropertyType == typeof(double?) && property.Name != "TotalVolume")
                    {
                        double value = Convert.ToDouble(property.GetValue(obj), CultureInfo.InvariantCulture);
                        double roundedValue = Math.Round(value, precision);
                        property.SetValue(obj, roundedValue);
                    }
                }
            }
        }

        private static bool ColumnExists(this SqlDataReader reader, string columnName)
        {
            try
            {
                reader.GetOrdinal(columnName);
                return true;
            }
            catch (IndexOutOfRangeException)
            {
                return false;
            }
        }
    }
}
