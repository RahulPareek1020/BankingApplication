﻿using Microsoft.Extensions.Logging;

namespace Shell.Energy.STPower.Shared;

/// <summary>
/// Interface for App Logger
/// </summary>
public interface IAppLogger
{
    void LogInformation(string message);
    void LogWarning(string message);
    void LogError(string message);
    void LogDebug(string message);
    void LogTrace(string message);
    void LogCritical(string message);
}

/// <summary>
/// Wrapper class for ILogger
/// </summary>
public class AppLogger : IAppLogger
{
    private readonly ILogger<AppLogger> _logger;

    public AppLogger(ILogger<AppLogger> logger)
    {
        _logger = logger;
    }

    public void LogInformation(string message)
    {
        message = RemoveMaliciousContent(message);
        _logger.LogInformation(message);
    }

    public void LogWarning(string message)
    {
        message = RemoveMaliciousContent(message);
        _logger.LogWarning(message);
    }

    public void LogError(string message)
    {
        message = RemoveMaliciousContent(message);
        _logger.LogError(message);
    }
    public void LogDebug(string message)
    {
        message = RemoveMaliciousContent(message);
        _logger.LogDebug(message);
    }

    public void LogTrace(string message)
    {
        message = RemoveMaliciousContent(message);
        _logger.LogTrace(message);
    }
    public void LogCritical(string message)
    {
        message = RemoveMaliciousContent(message);
        _logger.LogCritical(message);
    }

    //Validating and sanitizing the data
    private static string RemoveMaliciousContent(string message)
    {
        return message.Replace('\n', '_').Replace('\r', '_');
    }
}
