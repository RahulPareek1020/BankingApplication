﻿namespace Shell.Energy.STPower.Shared.Messages
{
    /// <summary>
    /// Class to hold the response messages
    /// </summary>
    public static class ResponseMessages
    {
        public static readonly string InternalError = "Internal server error";
        public static readonly string InvalidInputParameters = "Invalid/Missing input parameters";
        public static readonly string NoDataFound = "No data found to send nomination to powertrak";
        public static readonly string MissingData = "Data missing to send nomination to powertrak";
        public static readonly string InvalidTimezone = "Invalid timezone configured for the nomination";
        public static readonly string NoDataFoundForNomRun = "No data found for the nomination run";
        public static readonly string NoConfigFoundForNomDef = "No master config found";
        public static readonly string VnetAPIUrlNotConfigured= "VNet API URL is not configured";
        public static readonly string ValidAligneXmlResponse = "<results><msg type=\"199\">Aligne batch request sent</msg></results>";
        public static readonly string AuthorizationHeaderNotPresent = "Authorization header is not present with the request";
        public static readonly string NoMarketConfigFoundForNomDef = "No market config found";
    }
}
