﻿namespace Shell.Energy.STPower.Shared.Messages
{
    /// <summary>
    /// Class to hold the log messages
    /// </summary>
    public static class LogMessages
    {
        public static readonly string ExecuteReaderNull = "Failed to execute reader. Reader is null.";
        public static readonly string DataReaderError = "An error occurred while reading data";
        public static readonly string PowerTrakTransformDataSuccess = "ETRM data successfully converted to PowerTrak XML format";
        public static readonly string PowerTrakTransformDataEmpty = "Empty PowerTrak XML content";
        public static readonly string SendNewTokenRequestToPowertrak = "Sending request to get token to GMSL";
        public static readonly string GetGMSLTokenSuccess = "Successfully retrieved token from GMSL";
        public static readonly string SendPowerTradeRequest = "Sending power trade request to GMSL API";
        public static readonly string StartedETRMProcessing = "Started processing ETRM data";
        public static readonly string TransformingData = "Transforming ETRM data";
        public static readonly string UsingExistingGMSLToken = "Using existing valid GMSL token";
        public static readonly string AligneServerHealthCheckStarted = "Checking Aligne server health";
        public static readonly string AligneServerHealthCheckSuccess = "Aligne server health check successful";
        public static readonly string AligneServerHealthCheckFailed = "Aligne server health check failed";
        public static readonly string AligneConfigError = "Aligne server details are not configured properly";
        public static readonly string SendNominationError = "Error occured while sending nomination to powertrak";
        public static readonly string GMSLTokenNull = "GMSL token is null/empty";
    }
}
