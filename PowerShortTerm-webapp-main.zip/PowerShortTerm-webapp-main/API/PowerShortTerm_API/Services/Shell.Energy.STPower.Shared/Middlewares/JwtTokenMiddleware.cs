﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using Shell.Energy.STPower.Shared.Constants;

namespace Shell.Energy.STPower.Shared.Middlewares
{
    public class JwtTokenMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IConfiguration _configuration;
        private readonly IServiceScopeFactory _serviceScopeFactory;

        public JwtTokenMiddleware(RequestDelegate next, IConfiguration configuration, IServiceScopeFactory serviceScopeFactory)
        {
            _next = next;
            _configuration = configuration;
            _serviceScopeFactory = serviceScopeFactory;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            using (var scope = _serviceScopeFactory.CreateScope())
            {
                var _logger = scope.ServiceProvider.GetRequiredService<IAppLogger>();
                var env = _configuration.GetSection("STPowerEnv")?.Value;

                _logger.LogInformation($"Calling JwtTokenMiddleware");
                ArgumentNullException.ThrowIfNull(context);

                var authorizationHeader = context.Request.Headers[CommonConstants.Authorization].FirstOrDefault();

                var tokenParts = authorizationHeader?.Split(" ");
                var token = tokenParts?[tokenParts.Length - 1];

                if (string.IsNullOrEmpty(token))
                {
                    await _next(context);
                    return;
                }

                try
                {
                    var jwtToken = new JwtSecurityTokenHandler().ReadJwtToken(token);
                    bool tokenExpired = jwtToken.ValidTo < DateTime.UtcNow;
                    if (tokenExpired)
                    {
                        SetUnauthorizedResponse(context, _logger, $"Invalid token. Token has been expired.");
                        return;
                    }

                    bool invalidIssuer = string.IsNullOrEmpty(jwtToken.Issuer);
                    var azpClaim = jwtToken.Claims.FirstOrDefault(c => c.Type == CommonConstants.Azp)?.Value;

                    if (!invalidIssuer
                        && jwtToken.Issuer == _configuration.GetSection(CommonConstants.JwtIssuer).Value
                        && !string.IsNullOrEmpty(azpClaim) && !string.IsNullOrEmpty(env))
                    {
                        ProcessClaims(context, azpClaim, jwtToken, _logger, _configuration, env);
                    }
                    else
                    {
                        SetUnauthorizedResponse(context, _logger, $"Either issuer {jwtToken.Issuer} is invalid OR azpClaim is null");
                        return;
                    }
                }
                catch (SecurityTokenValidationException stvEx)
                {
                    SetUnauthorizedResponse(context, _logger, $"An error occured while generating the token: {stvEx.Message}");
                    return;
                }
                catch (SecurityTokenMalformedException stmEx)
                {
                    SetUnauthorizedResponse(context, _logger, $"Token is not in valid format: {stmEx.Message}");
                    return;
                }
            }
            await _next(context);
        }

        private static void ProcessClaims(HttpContext context, string azpClaim, JwtSecurityToken jwtToken, IAppLogger _logger, IConfiguration _config, string env)
        {
            if (azpClaim.StartsWith(CommonConstants.SNE_M2M_, StringComparison.OrdinalIgnoreCase))
            {
                SetPrincipal(context, CommonConstants.M2M, String.Empty);
            }
            else if (azpClaim.StartsWith(CommonConstants.SNE_, StringComparison.OrdinalIgnoreCase))
            {
                ProcessSneRoles(jwtToken, context, _logger, _config, env);
            }
            else
            {
                SetUnauthorizedResponse(context, _logger, $"Invalid azp claim");
            }
        }

        private static void SetUnauthorizedResponse(HttpContext context, IAppLogger _logger, string message)
        {
            context.Response.StatusCode = StatusCodes.Status401Unauthorized;
            _logger.LogError(message);
        }

        private static void ProcessSneRoles(JwtSecurityToken jwtToken, HttpContext context, IAppLogger _logger, IConfiguration _config, string env)
        {
            var realmAccess = jwtToken.Claims.FirstOrDefault(c => c.Type == CommonConstants.RealmAccess);
            if (realmAccess is not null)
            {
                var realmAccessClaim = JObject.Parse(realmAccess.Value);
                var userRoles = realmAccessClaim[CommonConstants.Roles]?.ToList();
                var role = string.Empty;
                var userName = jwtToken.Claims.FirstOrDefault(x => x.Type == CommonConstants.Name)?.Value;

                if (userRoles != null && userRoles.Count > 0 && !string.IsNullOrEmpty(GetUserRole(userRoles, _config, env, out role)))
                {
                    SetPrincipal(context, role, userName ?? String.Empty);
                }
                else
                {
                    SetUnauthorizedResponse(context, _logger, $"Token does not contain any valid SNE role");
                    return;
                }
            }
            else
            {
                SetUnauthorizedResponse(context, _logger, $"Token does not contain realm_access section");
                return;
            }
        }

        private static void SetPrincipal(HttpContext context, string role, string userName)
        {
            var claims = new List<Claim>
            {
               new(ClaimTypes.Role, role)
            };

            if (!string.IsNullOrEmpty(userName))
            {
                claims.Add(new(ClaimTypes.Name, userName));
            }

            var identity = new ClaimsIdentity(claims, CommonConstants.Jwt);
            context.User = new ClaimsPrincipal(identity);
        }

        private static string GetUserRole(List<JToken>? userRoles, IConfiguration _configuration, string env, out string role)
        {
            var knownEnvSuffixes = _configuration.GetSection("SSO-KnownEnvSuffixes")?.Value?.Split(',') ?? [];
            List<string> filteredRoles = [];

            if (userRoles != null)
            {
                if (env.ToUpperInvariant().Equals("prod", StringComparison.OrdinalIgnoreCase))
                {
                    filteredRoles = userRoles.Where(
                        role => role.ToString().StartsWith("SNE_", StringComparison.OrdinalIgnoreCase)
                        && !knownEnvSuffixes.Any(suffix => role.ToString().EndsWith(suffix, StringComparison.OrdinalIgnoreCase)))
                        .Select(r => r.ToString()).ToList();
                }
                else
                {
                    filteredRoles = userRoles.Where(
                        role => role.ToString().StartsWith("SNE_", StringComparison.OrdinalIgnoreCase)
                        && role.ToString().EndsWith($"_{env}", StringComparison.OrdinalIgnoreCase))
                        .Select(r => r.ToString()).ToList();
                }
            }

            role = filteredRoles.Count > 0 ? filteredRoles[0] : string.Empty;

            return role;
        }
    }
}