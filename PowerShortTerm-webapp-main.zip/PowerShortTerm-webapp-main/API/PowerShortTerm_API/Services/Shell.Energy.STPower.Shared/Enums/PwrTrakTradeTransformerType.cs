﻿namespace Shell.Energy.STPower.Shared.Enums
{
    /// <summary>
    /// Enum for Power Trak Trade Transformer Type
    /// </summary>
    public enum PwrTrakTradeTransformerType
    {
        PowerTransTradeTransformer = 1
    }
}
