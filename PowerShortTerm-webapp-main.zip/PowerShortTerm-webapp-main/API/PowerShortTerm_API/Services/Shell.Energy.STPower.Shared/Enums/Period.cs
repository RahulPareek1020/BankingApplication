﻿namespace Shell.Energy.STPower.Shared.Enums
{
    /// <summary>
    /// Enum for Period
    /// </summary>
    public enum Period
    {
        Hourly = 24,
        HalfHourly = 48,
        Quarterly = 96
    }
}
