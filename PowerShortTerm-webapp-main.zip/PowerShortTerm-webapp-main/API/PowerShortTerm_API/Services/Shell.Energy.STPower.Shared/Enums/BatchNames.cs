﻿namespace Shell.Energy.STPower.Shared.Constants
{
    /// <summary>
    /// Contains constant values related to a day.
    /// </summary>
    public static class BatchNames
    {
        public static readonly string PowerBatch = "PWTRAK4_DAGG_RUNP";
        public static readonly string TransBatch = "PWTRAK4_DAGG_RUNT";
        public static readonly string PowerTransBatch = "PWTRAK4_DAGG_RUNPT";
    }
}
