﻿namespace Shell.Energy.STPower.Shared.Constants
{
    /// <summary>
    /// Contains constant values related to a day.
    /// </summary>
    public static class DayConstants
    {
        public static readonly int MinutesPerQuarterHour = 15;
        public static readonly int MinutesPerHalfHour = 30;
        public static readonly int MinutesPerHour = 60;
    }
}
