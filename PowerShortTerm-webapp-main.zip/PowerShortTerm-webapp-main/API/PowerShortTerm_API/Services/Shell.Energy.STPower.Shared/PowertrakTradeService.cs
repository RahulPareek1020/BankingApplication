using Microsoft.Data.SqlClient;
using Shell.Energy.STPower.Data.Constants;
using Shell.Energy.STPower.Data.Dto;
using Shell.Energy.STPower.Data.Models;
using Shell.Energy.STPower.Data.Repository;
using Shell.Energy.STPower.Shared.Messages;
using Shell.Energy.STPower.Shared.PowerTrak;
using System.Data;
using System.Globalization;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace Shell.Energy.STPower.Shared
{
    /// <summary>
    /// Service class for fetching and updating trade statuses in the database.
    /// </summary>
    public class PowertrakTradeService : IPowertrakTradeService
    {
        private readonly ISqlDataRepository _sqlDataRepository;
        private readonly IPowerTrakSender _powerTrakTradeSender;
        private readonly IAppLogger _logger;
        private readonly int _tokenExpInMin = 10;
        private readonly int _tokenExpOffsetInSec = -30;
        private readonly string _nominationRunIdCol = "NominationRunId";
        private readonly string _nominationDefIdSPParam = "@NominationDefinitionId";
        private readonly string _deliveryDateSPParam = "@DeliveryDate";
        private readonly string _isAutoSPParam = "@IsAuto";
        private readonly string _initiatedBy = "@InitiatedBy";

        public PowertrakTradeService(ISqlDataRepository sqlDataRepository, IPowerTrakSender powerTrakTradeSender, IAppLogger logger)
        {
            _sqlDataRepository = sqlDataRepository;
            _powerTrakTradeSender = powerTrakTradeSender;
            _logger = logger;
        }

        /// <summary>
        /// Get Nomination Header Data
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<NominationHeader>> GetNominationHeaderData()
        {
            var nomHeaderList = new List<NominationHeader>();
            _logger.LogInformation($"Getting nomination header data from SQL DB");
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(ServiceConstants.GetNomHeaderSPName))
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return nomHeaderList;
                }

                try
                {
                    // Read the Data
                    while (reader.Read())
                    {
                        var nominationHeader = new NominationHeader
                        {
                            NominationRunId = reader.IsDBNull(reader.GetOrdinal(_nominationRunIdCol)) ? (int?)null : reader.GetInt32(reader.GetOrdinal(_nominationRunIdCol)),
                            NominationDefinitionId = reader.GetInt32(reader.GetOrdinal("NominationDefinitionId")),
                            NominationDefinitionName = reader["NominationDefinitionName"]?.ToString() ?? string.Empty,
                            DeliveryDate = reader.IsDBNull(reader.GetOrdinal("DeliveryDate")) ? (DateTime?)null : reader.GetDateTime(reader.GetOrdinal("DeliveryDate")),
                            ProcessStepName = reader["ProcessStepName"]?.ToString() ?? string.Empty,
                            ProcessStepStatus = reader["ProcessStepStatus"]?.ToString() ?? string.Empty,
                            Reason = reader["Reason"]?.ToString() ?? string.Empty,
                            LastModificationTime = reader.IsDBNull(reader.GetOrdinal("lastModificationTime")) ? (DateTime?)null : reader.GetDateTime(reader.GetOrdinal("lastModificationTime")),
                            InitiatedBy = reader["InitiatedBy"]?.ToString() ?? string.Empty,
                        };

                        // Store Data
                        nomHeaderList.Add(nominationHeader);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }

            _logger.LogInformation("Successfully fetched nomination header list");

            return nomHeaderList;
        }

        /// <summary>
        /// Get Nomination Details By Run Id
        /// </summary>
        /// <param name="runId"></param>
        /// <returns></returns>
        public async Task<IEnumerable<NominationDetailsDto>> GetNominationDetailsByRunIdAsync(int runId)
        {
            bool isAgg = false;
            var nominationDetailsDtoList = new List<NominationDetailsDto>();
            _logger.LogInformation($"Started fetching nomination details data based on run id {runId} from SQL DB");
            var parameters = new SqlParameter[]
                {
                    new SqlParameter(ServiceConstants.NominationId, SqlDbType.NVarChar) { Value = runId }
                };
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(
                ServiceConstants.GetNomDetailsByRunIdSPName, parameters) as SqlDataReader)
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return nominationDetailsDtoList;
                }
                try
                {
                    while (reader.Read())
                    {
                        var nominationDetails = TradeHelper.GetNominationDetailFromReader(reader, isAgg);
                        var nominationDetailsDto = ModelToDtoConverter.ConvertToNominationDetailsDto(nominationDetails);
                        nominationDetailsDtoList.Add(nominationDetailsDto);
                    }
                    if (nominationDetailsDtoList.Count > 0)
                    {
                        int precision = nominationDetailsDtoList.Select(x => x.NominationDefinitionPrecision).Max();
                        foreach (var obj in nominationDetailsDtoList)
                        {
                            TradeHelper.SetPrecisionForVolumes(precision, obj);
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }

            _logger.LogInformation($"Successfully fetched nomination details list based on run id {runId} from SQL DB");
            return nominationDetailsDtoList;
        }

        /// <summary>
        /// Get trades By aggregated position reference Id
        /// </summary>
        /// <param name="aggPosRefId"></param>
        /// <returns></returns>
        public async Task<IEnumerable<RawTradeDto>> GetRawTradesByAggPosOrRunIdAsync(int? aggPosRefId, int? runId)
        {
            var tradeDtoList = new List<RawTradeDto>();
            if (aggPosRefId != null)
            {
                _logger.LogInformation($"Started fetching trades based on aggregates position reference Id {aggPosRefId} from SQL DB");
            }
            else
            {
                _logger.LogInformation($"Started fetching trades based on nomination run Id {runId} from SQL DB");
            }

            var parameters = new SqlParameter[]
                {
                    new SqlParameter("@AggPosRefId", SqlDbType.Int) { Value = aggPosRefId!=null?aggPosRefId:DBNull.Value },
                    new SqlParameter(ServiceConstants.NominationId, SqlDbType.Int) { Value = runId!=null?runId:DBNull.Value }
                };
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(
                ServiceConstants.GetNomTradeDetailsByAggPosOrRunIdSPName, parameters) as SqlDataReader)
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return tradeDtoList;
                }
                try
                {
                    while (reader.Read())
                    {
                        var trade = TradeHelper.GetRawTradeFromReader(reader);
                        var tradeDto = ModelToDtoConverter.ConvertToRawTradeDto(trade);
                        tradeDtoList.Add(tradeDto);
                    }
                    if (tradeDtoList.Count > 0)
                    {
                        int precision = tradeDtoList.Select(x => x.NominationDefinitionPrecision).Max();
                        foreach (var obj in tradeDtoList)
                        {
                            TradeHelper.SetPrecisionForVolumes(precision, obj);
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }

            _logger.LogInformation($"Successfully fetched trades based on nomination run Id {runId} from SQL DB");
            return tradeDtoList;
        }

        /// <summary>
        /// Get Mapping Rule Details from DB
        /// </summary>
        /// <returns></returns>

        public async Task<IEnumerable<MappingRuleDetailsDto>> GetMappingRuleDetails()
        {
            var mappingRuleDetailsDtoList = new List<MappingRuleDetailsDto>();
            _logger.LogInformation($"Getting mapping rule details from SQL DB");
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(ServiceConstants.GetMappingRuleDetailsSPName))
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return mappingRuleDetailsDtoList;
                }

                try
                {
                    // Read the Data
                    while (reader.Read())
                    {
                        var mappingRuleDetails = new MappingRuleDetails
                        {
                            NominationDefinitionId = TradeHelper.GetInt32(reader, "NominationDefinitionId"),
                            NominationDefinitionName = TradeHelper.GetString(reader, "NominationDefinitionName"),
                            MappingRulesMaster = TradeHelper.GetMappingRulesMasterFromReader(reader),
                            MappingRulesType = TradeHelper.GetMappingRulesType(reader),
                            MappingRulesInput = TradeHelper.GetMappingRulesInput(reader),
                            MappingRulesOutput = TradeHelper.GetMappingRulesOutput(reader)
                        };
                        var mappingRuleDetailsDto = ModelToDtoConverter.ConvertToMappingRuleDetailsDto(mappingRuleDetails);
                        // Store Data
                        mappingRuleDetailsDtoList.Add(mappingRuleDetailsDto);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }

            _logger.LogInformation("Successfully fetched mapping rule details");

            return mappingRuleDetailsDtoList;
        }

        /// <summary>
        /// Get Aggregated Counterparty Positions with filters
        /// </summary>
        /// <param name="nominationDefinitionId"></param>
        /// <param name="deliveryDate"></param>
        /// <returns></returns>
        public async Task<IEnumerable<NominationDetailsDto>> GetAggregatedCptyPositionsWithFilters(int nominationDefinitionId, DateTime deliveryDate)
        {
            var nominationDetailsDtoList = new List<NominationDetailsDto>();
            bool isAgg = true;
            _logger.LogInformation($"Started applying filters for the nomination and aggregating counterparty positions for NomDefId: {nominationDefinitionId} and DeliveryDate: {deliveryDate} from SQL DB");
            var parameters = new SqlParameter[]
                {
                    new SqlParameter(_nominationDefIdSPParam, SqlDbType.Int) { Value = nominationDefinitionId },
                    new SqlParameter(_deliveryDateSPParam, SqlDbType.DateTime) { Value = deliveryDate }
                };
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(
                ServiceConstants.GetCounterpartyAggregationsSPName, parameters) as SqlDataReader)
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return nominationDetailsDtoList;
                }
                try
                {
                    while (reader.Read())
                    {
                        var nominationDetails = TradeHelper.GetNominationDetailFromReader(reader, isAgg);
                        var nominationDetailsDto = ModelToDtoConverter.ConvertToNominationDetailsDto(nominationDetails);
                        nominationDetailsDtoList.Add(nominationDetailsDto);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }

            _logger.LogInformation($"Successfully applied filters for the nomination and aggregated {nominationDetailsDtoList.Count} counterparty positions for NomDefId: {nominationDefinitionId} and DeliveryDate: {deliveryDate} from SQL DB");
            return nominationDetailsDtoList;
        }

        /// <summary>
        /// Save Nomination Data in DB
        /// </summary>
        /// <param name="cptyAggPositionData"></param>
        /// <returns></returns>
        public async Task<int?> SaveNominationDataWithOffsetInDB(IEnumerable<NominationDetailsDto> cptyAggPositionData)
        {
            DataTable dataTable = TradeHelper.CreateDTWithNominationData(cptyAggPositionData);
            var parameters = new SqlParameter[]
            {
                new SqlParameter
                {
                ParameterName = "@NominationDetails",
                SqlDbType = SqlDbType.Structured,
                TypeName = "dbo.NominationDetailsDtoType",
                Value = dataTable
                }
            };
            int? nominationRunId = null;
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(
                ServiceConstants.SaveNominationDataSPName, parameters) as SqlDataReader)
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return null;
                }
                try
                {
                    if (reader.Read())
                    {
                        nominationRunId = TradeHelper.GetInt32(reader, _nominationRunIdCol);
                        _logger.LogInformation($"Successfully saved the nomination data in SQL DB with NominationRunId: {nominationRunId}");
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
                return nominationRunId;
            }
        }

        /// <summary>
        /// Update Nomination Batch Run Status
        /// </summary>
        /// <param name="nominationRunId"></param>
        /// <param name="stepId"></param>
        /// <param name="status"></param>
        /// <param name="startDateTime"></param>
        /// <param name="endDateTime"></param>
        /// <returns></returns>
        public async Task UpdateNominationBatchRunStatusAsync(int nominationRunId, int stepId, string status, string reason, DateTime? startDateTime, DateTime? endDateTime)
        {
            try
            {
                // Log the start of the operation
                _logger.LogInformation($"Updating Nomination Batch Run Status for NominationRunId: {nominationRunId}");

                // Define the parameters for the stored procedure
                var parameters = new[]
                {
            new SqlParameter(ServiceConstants.NominationId, SqlDbType.Int) { Value = nominationRunId },
            new SqlParameter("@StepId", SqlDbType.Int) { Value = stepId },
            new SqlParameter("@Status", SqlDbType.NVarChar, 200) { Value = status },
            new SqlParameter("@Reason", SqlDbType.NVarChar, 200) { Value = reason },
            new SqlParameter("@StartDateTime", SqlDbType.DateTime) { Value = (object)startDateTime ?? DBNull.Value },
            new SqlParameter("@EndDateTime", SqlDbType.DateTime) { Value = (object)endDateTime ?? DBNull.Value }
        };

                // Execute the stored procedure
                await _sqlDataRepository.ExecuteReaderAsync("UpdateNominationBatchRunStatus", parameters, true);

                // Log the successful update
                _logger.LogInformation($"Successfully updated Nomination Batch Run Status for NominationRunId: {nominationRunId}");
            }
            catch (Exception ex)
            {
                // Log the error
                _logger.LogError($"Error updating Nomination Batch Run Status for NominationRunId: {nominationRunId}. Exception: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Retrieve token and send nomination to powertrak
        /// </summary>
        /// <param name="nominationDefinitionId"></param>
        /// <param name="deliveryDate"></param>
        /// <returns></returns>
        public async Task<XElement> SendNominationToPowertrak(string powertrakRequestXmlMessage, PowerTrakConfig powerTrakConfig)
        {
            try
            {
                var gmslToken = await RetrieveToken(powerTrakConfig);
                if (string.IsNullOrEmpty(gmslToken))
                {
                    _logger.LogError(LogMessages.GMSLTokenNull);
                    throw new Exception("GMSL token is null or empty");
                }

                var response = await _powerTrakTradeSender.SubmitPowerTrades(XElement.Parse(powertrakRequestXmlMessage), gmslToken, powerTrakConfig);
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError($"{LogMessages.SendNominationError}: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Retrieves the GMSL token.
        /// </summary>
        /// <param name="context">The orchestration context.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        private async Task<string> RetrieveToken(PowerTrakConfig powerTrakConfig)
        {
            var retrieveGMSLToken = await _powerTrakTradeSender.GetJwtString(powerTrakConfig);
            if (retrieveGMSLToken is null)
            {
                return string.Empty;
            }
            return retrieveGMSLToken;
        }

        public async Task<XElement> GetPowertrakStatusReport(PowerTrakConfig powerTrakConfig,string correlationId)
        {
            try
            {
                var gmslToken = await RetrieveToken(powerTrakConfig);
                if (string.IsNullOrEmpty(gmslToken))
                {
                    _logger.LogError(LogMessages.GMSLTokenNull);
                    throw new Exception("GMSL token is null or empty");
                }

                var response = await _powerTrakTradeSender.GetStatusReport(correlationId, gmslToken, powerTrakConfig);
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError($"{LogMessages.SendNominationError}: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Update the trade statuses in the database.
        /// </summary>
        /// <param name="statusList"></param>
        public async void UpdatePowertrakTradeStatuses(IEnumerable<TradeStatusDto> statusList)
        {
            try
            {
                if (statusList == null || !statusList.Any())
                {
                    return;
                }

                var tradeStatusDataTable = CreateTradeStatusDataTable(statusList);
                var parameters = new SqlParameter[]
                {
                new SqlParameter
                {
                ParameterName = "@TradeStatuses",
                SqlDbType = SqlDbType.Structured,
                TypeName = "dbo.PowertrakTradeStatusType",
                Value = tradeStatusDataTable
                }
                };
                await _sqlDataRepository.ExecuteReaderAsync(ServiceConstants.UpdatePowertrakTradeStatusSPName, parameters);
                _logger.LogInformation("Successfully updated trade statuses in the database.");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error updating trade statuses in the database: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Create a DataTable from the list of trade statuses.
        /// </summary>
        /// <param name="statusList"></param>
        /// <returns></returns>
        private static DataTable CreateTradeStatusDataTable(IEnumerable<TradeStatusDto> statusList)
        {
            var tradeStatusDataTable = new DataTable();
            tradeStatusDataTable.Locale = CultureInfo.InvariantCulture;
            tradeStatusDataTable.Columns.Add("Reference", typeof(string));
            tradeStatusDataTable.Columns.Add("NominationRunId", typeof(int)); 
            tradeStatusDataTable.Columns.Add("StatusCode", typeof(string));
            tradeStatusDataTable.Columns.Add("StatusMessage", typeof(string));

            foreach (var status in statusList)
            {
                tradeStatusDataTable.Rows.Add(status.Reference, status.NominationRunId, status.Result, status.Text);
            }

            return tradeStatusDataTable;
        }
        /// <summary>
        /// Update Nomination Batch Run Response
        /// </summary>
        /// <param name="powertrakApiResponse"></param>
        /// <param name="nominationRunId"></param>
        /// <returns></returns>
        public async Task UpdateNominationBatchRunResponse(XElement powertrakApiResponse, int nominationRunId)
        {
            try
            {
                // Log the start of the operation
                _logger.LogInformation($"Updating Nomination Batch Run Response for NominationRunId: {nominationRunId}");

                var serializer = new XmlSerializer(typeof(PowerTrakResponse));
                PowerTrakResponse? powerTrakResponse;
                using (MemoryStream ms = new MemoryStream())
                {
                    powertrakApiResponse?.Save(ms);
                    ms.Position = 0;
                    powerTrakResponse = serializer.Deserialize(ms) as PowerTrakResponse;
                }
                var parameters = new List<SqlParameter>
                {
                    new SqlParameter(ServiceConstants.NominationId, SqlDbType.Int) { Value = nominationRunId }
                };

                if (powerTrakResponse != null)
                {
                    if (powerTrakResponse.ValidationResult?.CorrelationId != null)
                    {
                        parameters.Add(new SqlParameter("@CorrelationId", SqlDbType.VarChar) { Value = powerTrakResponse.ValidationResult?.CorrelationId });
                    }

                    if (powerTrakResponse.ValidationResult?.Errors != null && powerTrakResponse.ValidationResult?.Errors?.Length > 0)
                    {
                        parameters.Add(new SqlParameter("@ErrorList", SqlDbType.NVarChar) { Value = string.Join(',', powerTrakResponse.ValidationResult.Errors) });
                    }
                }

                // Execute the stored procedure
                await _sqlDataRepository.ExecuteReaderAsync(ServiceConstants.UpdateNominationBatchRunResponseSPName, parameters.ToArray(), true);

                // Log the successful update
                _logger.LogInformation($"Successfully updated Nomination Batch Run Response for NominationRunId: {nominationRunId}");
            }
            catch (Exception ex)
            {
                // Log the error
                _logger.LogError($"Error updating Nomination Batch Run Response for NominationRunId: {nominationRunId}. Exception: {ex.Message}");
                throw;
            }
        }

        public async Task<string> GetMarketOperators(int nominationDefinitionId)
        {
            string marketOperatorName = string.Empty;
            _logger.LogInformation($"Started fetching marketoperator for NomDefId: {nominationDefinitionId}  from SQL DB");
            var parameters = new SqlParameter[]
            {
                new SqlParameter(_nominationDefIdSPParam, SqlDbType.Int) { Value = nominationDefinitionId }
            };
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(
                ServiceConstants.GetMarketOperatorSPName, parameters) as SqlDataReader)
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return string.Empty;
                }
                try
                {
                    while (await reader.ReadAsync())
                    {
                        marketOperatorName = TradeHelper.GetString(reader, "MarketOperator");
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }

            _logger.LogInformation($"Successfully fetched marketoperator for NomDefId: {nominationDefinitionId} from SQL DB");
            return marketOperatorName;
        }

        public async Task<string> GetTradeTypes(int nominationDefinitionId, DateTime deliveryDate)
        {
            string tradeTypes = string.Empty;
            _logger.LogInformation($"Started fetching tradetypes for NomDefId: {nominationDefinitionId} and DeliveryDate: {deliveryDate} from SQL DB");
            var parameters = new SqlParameter[]
                {
                    new SqlParameter(_nominationDefIdSPParam, SqlDbType.Int) { Value = nominationDefinitionId },
                    new SqlParameter(_deliveryDateSPParam, SqlDbType.DateTime) { Value = deliveryDate }
                };
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(
                ServiceConstants.GetTradeTypeSPName, parameters) as SqlDataReader)
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return tradeTypes;
                }
                try
                {
                    while (await reader.ReadAsync())
                    {
                        tradeTypes = TradeHelper.GetString(reader, "TradeTypes");
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }

            _logger.LogInformation($"Successfully fetched tradetypes for NomDefId: {nominationDefinitionId} and DeliveryDate: {deliveryDate} from SQL DB");
            return tradeTypes;
        }

        public async Task<int?> InsertNominationBatchRun(int nominationDefinitionId, DateTime deliveryDate, string? initiatedBy, bool? isAuto = true)
        {
            int? nominationRunId = 0;
            _logger.LogInformation($"Started inserting new nomination batch run for NomDefId: {nominationDefinitionId} and DeliveryDate: {deliveryDate} in SQL DB");
            var parameters = new SqlParameter[]
                {
                    new SqlParameter(_nominationDefIdSPParam, SqlDbType.Int) { Value = nominationDefinitionId },
                    new SqlParameter(_deliveryDateSPParam, SqlDbType.DateTime) { Value = deliveryDate },
                    new SqlParameter(_isAutoSPParam, SqlDbType.Bit) { Value = isAuto },
                    new SqlParameter(_initiatedBy, SqlDbType.Text) { Value = initiatedBy }
                };
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(
                ServiceConstants.InsertNominationRunSPName, parameters) as SqlDataReader)
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return nominationRunId;
                }
                try
                {
                    while (await reader.ReadAsync())
                    {
                        nominationRunId = TradeHelper.GetInt32(reader, _nominationRunIdCol);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }

            _logger.LogInformation($"Successfully inserted new nomination batch run with id: {nominationRunId} for NomDefId: {nominationDefinitionId} and DeliveryDate: {deliveryDate} in SQL DB");
            return nominationRunId;
        }

        public async Task<NominationStatus> GetNominationStatusByRunIdAsync(int? runId)
        {
            var nominationStatus = new NominationStatus();
            var parameters = new SqlParameter[]
                {
                    new SqlParameter(ServiceConstants.NominationId, SqlDbType.Int) { Value = runId!=null?runId:DBNull.Value }
                };
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(
                ServiceConstants.GetNominationStatusByRunIdSPName, parameters) as SqlDataReader)
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return nominationStatus;
                }
                try
                {
                    while (await reader.ReadAsync())
                    {
                        nominationStatus.ProcessStep = TradeHelper.GetString(reader, "ProcessStep");
                        if (await reader.IsDBNullAsync(reader.GetOrdinal(ServiceConstants.DeliveryDate)))
                        {
                            nominationStatus.DeliveryDate = (DateTime?)null;
                        }
                        else
                        {
                            nominationStatus.DeliveryDate = reader.GetDateTime(reader.GetOrdinal(ServiceConstants.DeliveryDate));
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }

            _logger.LogInformation($"Successfully fetched status based on nomination run Id {runId} from SQL DB");
            return nominationStatus;
        }

        /// <summary>
        /// Get Aggregated Counterparty Positions with filters
        /// </summary>
        /// <param name="nominationDefinitionId"></param>
        /// <param name="deliveryDate"></param>
        /// <returns></returns>
        public async Task<IEnumerable<NominationDetailsDto>> GetAggregatedCptyPositionsByRunIdWithFilters(int nominationRunId)
        {
            var nominationDetailsDtoList = new List<NominationDetailsDto>();
            const bool isAgg = true;
            _logger.LogInformation($"Started aggregating counterparty positions for NomRunId: {nominationRunId} from SQL DB");
            var parameters = new SqlParameter[]
                {
                    new SqlParameter("@NominationRunId", SqlDbType.Int) { Value = nominationRunId }
                };
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(
                ServiceConstants.GetAggregatedCptyPositionsByRunIdSPName, parameters) as SqlDataReader)
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return nominationDetailsDtoList;
                }
                try
                {
                    while (await reader.ReadAsync())
                    {
                        var nominationDetails = TradeHelper.GetNominationDetailFromReader(reader, isAgg);
                        var nominationDetailsDto = ModelToDtoConverter.ConvertToNominationDetailsDto(nominationDetails);
                        nominationDetailsDtoList.Add(nominationDetailsDto);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }
            if (nominationDetailsDtoList.Count > 0)
            {
                int precision = nominationDetailsDtoList.Select(x => x.NominationDefinitionPrecision).Max();
                foreach (var obj in nominationDetailsDtoList)
                {
                    TradeHelper.SetPrecisionForVolumes(precision, obj);
                }
            }

            _logger.LogInformation($"Successfully aggregated counterparty positions for NomRunId: {nominationRunId} from SQL DB");
            return nominationDetailsDtoList;
        }

        /// <summary>
        /// Save Nomination Data in DB
        /// </summary>
        /// <param name="cptyAggPositionData"></param>
        /// <returns></returns>
        public async Task SaveNominationPositionsInDB(IEnumerable<NominationDetailsDto> cptyAggPositionData)
        {
            DataTable dataTable = TradeHelper.CreateDTWithNominationData(cptyAggPositionData);
            var parameters = new SqlParameter[]
            {
                new SqlParameter
                {
                ParameterName = "@NominationDetails",
                SqlDbType = SqlDbType.Structured,
                TypeName = "dbo.NominationDetailsDtoType",
                Value = dataTable
                }
            };
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(
                ServiceConstants.SaveNominationPositionsSPName, parameters) as SqlDataReader)
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                }
            }
        }
        /// <summary>
        /// Get Nominations in Readt status from DB
        /// </summary>
        /// <returns></returns>

        public async Task<NominationReady> GetReadyNominations()
        {
            var nominationRunIds = new List<int?>();
            var readyNominations = new NominationReady();
            _logger.LogInformation($"Getting nominations in ready state from SQL DB");
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(ServiceConstants.GetReadyNominationsSPName))
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return readyNominations;
                }

                try
                {
                    // Read the Data
                    while (reader.Read())
                    {
                        var nominationRunId = TradeHelper.GetInt32(reader, "NominationRunId");
                        // Store Data
                        nominationRunIds.Add(nominationRunId);
                    }
                    readyNominations.NominationRunIDs = nominationRunIds;
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }

            _logger.LogInformation("Successfully fetched nominations in ready status");

            return readyNominations;
        }

        public async Task InsertNominationRunOtel(int nominationRunId, string traceId, string spanId)
        {
            _logger.LogInformation($"Started inserting OTEL ids for NominationRunId: {nominationRunId} in SQL DB");
            var parameters = new SqlParameter[]
                {
                    new SqlParameter(ServiceConstants.NominationId, SqlDbType.Int) { Value = nominationRunId },
                    new SqlParameter("@TraceId", SqlDbType.VarChar) { Value = traceId },
                    new SqlParameter("@SpanId", SqlDbType.VarChar) { Value = spanId }
                };
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(
                ServiceConstants.InsertNominationRunOtelSPName, parameters) as SqlDataReader)
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return;
                }
            }
            _logger.LogInformation($"Successfully inserted OTEL ids for NominationRunId: {nominationRunId} in SQL DB");
        }

        public async Task<NominationRunOtelIds> GetNominationRunTraceSpanId(int nominationRunId)
        {
            NominationRunOtelIds nominationRunOtelIds = new NominationRunOtelIds();
            _logger.LogInformation($"Started fetching OTEL Ids for NominationRunId:{nominationRunId} from SQL DB");
            var parameters = new SqlParameter[]
                {
                    new SqlParameter(ServiceConstants.NominationId, SqlDbType.Int) { Value = nominationRunId }
                };
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(
                ServiceConstants.GetNomRunTraceSpanIdsSPName, parameters) as SqlDataReader)
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return nominationRunOtelIds;
                }
                try
                {
                    while (await reader.ReadAsync())
                    {
                        nominationRunOtelIds = new NominationRunOtelIds
                        { SpanId = TradeHelper.GetString(reader, "SpanId"), TraceId = TradeHelper.GetString(reader, "TraceId") };
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }

            _logger.LogInformation($"Successfully fetched OTEL Ids for NominationRunId:{nominationRunId} from SQL DB");
            return nominationRunOtelIds;
        }

        public async Task<string> GetPowerTrakEnv(int nominationRunId)
        {
            string env = string.Empty;
            _logger.LogInformation($"Started fetching environment for NomRunId: {nominationRunId} from SQL DB");
            var parameters = new SqlParameter[]
                {
                    new SqlParameter("@NominationRunId", SqlDbType.Int) { Value = nominationRunId },
                };
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(
                ServiceConstants.GetPowerTrakEnvNameByNomRunIdSPName, parameters) as SqlDataReader)
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return env;
                }
                try
                {
                    while (await reader.ReadAsync())
                    {
                        if (reader.HasRows)
                        {
                            env = reader["Powertrak_Env"]?.ToString() ?? string.Empty;
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }

            _logger.LogInformation($"Successfully fetched environment for NomRunId: {nominationRunId} from SQL DB");
            return env;
        }

        public async Task<IEnumerable<NominationDetailsDto>> GetPreviousAggregationPositions(IEnumerable<NominationDetailsDto>? cptyAggPositionData, int? nominationRunId)
        {
            var nominationDetailsDtoList = new List<NominationDetailsDto>();
            DataTable dataTable = TradeHelper.CreateDTWithAggPosReferences(cptyAggPositionData);
            var parameters = new SqlParameter[]
            {
                new SqlParameter
                {
                ParameterName = "@AggPosReferences",
                SqlDbType = SqlDbType.Structured,
                TypeName = "dbo.AggPosReferenceNameType",
                Value = dataTable
                },
                new SqlParameter("@NominationRunId", SqlDbType.Int) { Value = nominationRunId }
            };
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(
               ServiceConstants.GetPreviousAggregationPositionsSPName, parameters) as SqlDataReader)
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return nominationDetailsDtoList;
                }
                try
                {
                    while (await reader.ReadAsync())
                    {
                        var nominationDetails = TradeHelper.GetNominationDetailFromReader(reader, true);
                        var nominationDetailsDto = ModelToDtoConverter.ConvertToNominationDetailsDto(nominationDetails);
                        nominationDetailsDtoList.Add(nominationDetailsDto);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }
            _logger.LogInformation($"Successfully aggregated positions for Previous NomRunId: {nominationRunId} from SQL DB");
            return nominationDetailsDtoList;
        }

        /// <summary>
        /// Get Correlation Ids from DB
        /// </summary>
        /// <returns></returns>
        public async Task<List<NominationCorrelationId>> GetCorrelationIds()
        {
            var nominationCorrelationIds = new List<NominationCorrelationId>();
            _logger.LogInformation($"Fetching correlationids from SQL DB");
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(ServiceConstants.GetCorrelationIdsSPName))
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return nominationCorrelationIds;
                }

                try
                {
                    // Read the Data
                    while (reader.Read())
                    {
                        var nominationRunId = TradeHelper.GetInt32(reader, _nominationRunIdCol);
                        var correlationId = TradeHelper.GetString(reader, "CorrelationId");
                        var powertrakEnv = TradeHelper.GetString(reader, "PowertrakEnv");
                        // Store Data
                        nominationCorrelationIds.Add(new NominationCorrelationId { NominationRunId = nominationRunId, CorrelationId = correlationId, PowertrakEnv = powertrakEnv });
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }

            _logger.LogInformation("Successfully fetched correlationids");

            return nominationCorrelationIds;
        }
    }
}


