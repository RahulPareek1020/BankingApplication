using Moq;
using Shell.Energy.STPower.Data.Dto;
using Shell.Energy.STPower.Services.TradeTransformer.DTO;
using Shell.Energy.STPower.Services.TradeTransformer.Interfaces;

namespace Shell.Energy.STPower.Services.TradeTransformer.Tests
{
    public class EtrmTradeProcessorTests
    {
        private readonly Mock<IEtrmTradeTransformer> _mockEtrmTradeTransformer;
        private readonly Mock<IPowerTrakXmlTradeMapper> _mockPowerTrakXmlTradeMapper;
        private readonly EtrmTradeProcessor _etrmTradeProcessor;

        public EtrmTradeProcessorTests()
        {
            _mockEtrmTradeTransformer = new Mock<IEtrmTradeTransformer>();
            _mockPowerTrakXmlTradeMapper = new Mock<IPowerTrakXmlTradeMapper>();
            _etrmTradeProcessor = new EtrmTradeProcessor(_mockEtrmTradeTransformer.Object, _mockPowerTrakXmlTradeMapper.Object);
        }

        [Fact]
        public void ConvertEtrmDataToPowerTrakXml_TransformTradeDataReturnsNull_ReturnsNull()
        {
            // Arrange
            IEnumerable<NominationDetailsDto> cptyAggPositionData = new List<NominationDetailsDto>();
            _mockEtrmTradeTransformer.Setup(x => x.TransformTradeData(cptyAggPositionData)).Returns((List<PowerTrakTradeDto>?)null);

            // Act
            var result = _etrmTradeProcessor.ConvertEtrmDataToPowerTrakXml(cptyAggPositionData);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public void ConvertEtrmDataToPowerTrakXml_TransformTradeDataReturnsEmptyList_ReturnsNull()
        {
            // Arrange
            IEnumerable<NominationDetailsDto> cptyAggPositionData = new List<NominationDetailsDto>();
            _mockEtrmTradeTransformer.Setup(x => x.TransformTradeData(cptyAggPositionData)).Returns(new List<PowerTrakTradeDto>());

            // Act
            var result = _etrmTradeProcessor.ConvertEtrmDataToPowerTrakXml(cptyAggPositionData);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public void ConvertEtrmDataToPowerTrakXml_ValidData_ReturnsPowerTrakXmlContent()
        {
            // Arrange
            IEnumerable<NominationDetailsDto> cptyAggPositionData = new List<NominationDetailsDto>
            {
                new NominationDetailsDto { NominationRunId = 1, NominationDefinitionId = 1, DeliveryDate = DateTime.Now }
            };
            var powerTrakTradeDTOs = new List<PowerTrakTradeDto>
            {
                new PowerTrakTradeDto { TradeType = "Type1", TradeDate = DateTime.Now }
            };
            _mockEtrmTradeTransformer.Setup(x => x.TransformTradeData(cptyAggPositionData)).Returns(powerTrakTradeDTOs);
            _mockPowerTrakXmlTradeMapper.Setup(x => x.MapPowerTrakContent(powerTrakTradeDTOs)).Returns("<xml>content</xml>");

            // Act
            var result = _etrmTradeProcessor.ConvertEtrmDataToPowerTrakXml(cptyAggPositionData);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("<xml>content</xml>", result);
        }
    }
}
