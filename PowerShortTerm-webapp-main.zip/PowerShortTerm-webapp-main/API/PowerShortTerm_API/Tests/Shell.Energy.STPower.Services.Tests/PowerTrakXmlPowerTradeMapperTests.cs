using Shell.Energy.STPower.Services.TradeTransformer.DTO;
using Shell.Energy.STPower.Services.TradeTransformer.PwrTrakXmlModels;
using Shell.Energy.STPower.Services.TradeTransformer.XML;
using System.Globalization;

namespace Shell.Energy.STPower.Services.Tests
{
    public class PowerTrakXmlPowerTradeMapperTests
    {
        private readonly PowerTrakXmlPowerTransTradeMapper _mapper;

        public PowerTrakXmlPowerTradeMapperTests()
        {
            _mapper = new PowerTrakXmlPowerTransTradeMapper();
        }

        [Fact]
        public void MapPowerTrakContent_ReturnsCorrectXml()
        {
            // Arrange
            var powerTrakTradeDTOs = CreateSamplePowertrakDtoList();
           // Act
            var result = _mapper.MapPowerTrakContent(powerTrakTradeDTOs);

            // Assert
            Assert.Equal(Resources.SampleXmlRequest, result);
        }

        [Fact]
        public void MapPowerTrakContent_MapsTransTradeModelCorrectly()
        {
            // Arrange
            var powerTrakTradeDTOs = new List<PowerTrakTradeDto>
            {
                new PowerTrakTradeDto
                {
                    TradeType = "PW_TRANS",
                    Reference = "Ref123",
                    FromMarketOperator = "OperatorA",
                    ToMarketOperator = "OperatorB",
                    Interconnector = "Interconnector1",
                    CustomShape = CreateCustomShapeWith96Intervals(),
                    CapacityType = "Type1",
                    CapacityIdentification = "ID1"
                }
            };

            // Act
            var result = _mapper.MapPowerTrakContent(powerTrakTradeDTOs);

            // Assert
            Assert.NotNull(result);
            Assert.Contains("<Trade>", result);
            Assert.Contains("<Reference>Ref123</Reference>", result);
            Assert.Contains("<FromMarketOperator>OperatorA</FromMarketOperator>", result);
            Assert.Contains("<ToMarketOperator>OperatorB</ToMarketOperator>", result);
            Assert.Contains("<MarketOperator>Interconnector1</MarketOperator>", result);
            Assert.Contains("<CapacityType>Type1</CapacityType>", result);
            Assert.Contains("<CapacityIdentification>ID1</CapacityIdentification>", result);
        }

        private List<PowerTrakTradeDto> CreateSamplePowertrakDtoList()
        {
            return new List<PowerTrakTradeDto>
            {
                new PowerTrakTradeDto
                {
                    Reference = "Ref1",
                    TradeType="PW_TRADE",
                    TransactionType = "Type1",
                    Counterparty = "Counterparty1",
                    FromMarketOperator = "Operator1",
                    CustomShape = CreateCustomShapeWith96Intervals(),
                    ClientName = "Shell",
                    TradeDate = DateTime.ParseExact("2024-08-14", "yyyy-MM-dd", CultureInfo.InvariantCulture)
                }
            };
        }

        [Fact]
        public void MapPowerTrakContent_EmptyList_ReturnsNull()
            {
                // Arrange
                var powerTrakTradeDTOs = new List<PowerTrakTradeDto>();

                // Act
                var result = _mapper.MapPowerTrakContent(powerTrakTradeDTOs);

                // Assert
                Assert.Null(result);
            }

        [Fact]
        public void MapPowerTrakContent_MapsTradeModelClientShellCorrectly()
        {
            // Arrange
            var powerTrakTradeDTOs = new List<PowerTrakTradeDto>
            {
                new PowerTrakTradeDto
                {
                    TradeType = "PW_TRANS",
                    Reference = "Ref123",
                    FromMarketOperator = "OperatorA",
                    ToMarketOperator = "OperatorB",
                    Interconnector = "Interconnector1",
                    CustomShape = CreateCustomShapeWith96Intervals(),
                    ClientName= "Shell",
                    CapacityType = "Type1",
                    CapacityIdentification = "ID1"
                }
            };

            // Act
            var result = _mapper.MapPowerTrakContent(powerTrakTradeDTOs);

            // Assert
            Assert.NotNull(result);
            Assert.Contains("<Trade>", result);
            Assert.Contains("Client=\"Shell\"", result);
            Assert.Contains("<Reference>Ref123</Reference>", result);
            Assert.Contains("<FromMarketOperator>OperatorA</FromMarketOperator>", result);
            Assert.Contains("<ToMarketOperator>OperatorB</ToMarketOperator>", result);
            Assert.Contains("<MarketOperator>Interconnector1</MarketOperator>", result);
            Assert.Contains("<CapacityType>Type1</CapacityType>", result);
            Assert.Contains("<CapacityIdentification>ID1</CapacityIdentification>", result);
        }

        [Fact]
        public void MapPowerTrakContent_MapsTradeModelClientShellGermanyCorrectly()
        {
            // Arrange
            var powerTrakTradeDTOs = new List<PowerTrakTradeDto>
            {
                new PowerTrakTradeDto
                {
                    TradeType = "PW_TRANS",
                    Reference = "Ref123",
                    FromMarketOperator = "OperatorA",
                    ToMarketOperator = "OperatorB",
                    Interconnector = "Interconnector1",
                    CustomShape = CreateCustomShapeWith96Intervals(),
                    ClientName= "Shell Germany",
                    CapacityType = "Type1",
                    CapacityIdentification = "ID1"
                }
            };

            // Act
            var result = _mapper.MapPowerTrakContent(powerTrakTradeDTOs);

            // Assert
            Assert.NotNull(result);
            Assert.Contains("<Trade>", result);
            Assert.Contains("Client=\"Shell Germany\"", result);
            Assert.Contains("<Reference>Ref123</Reference>", result);
            Assert.Contains("<FromMarketOperator>OperatorA</FromMarketOperator>", result);
            Assert.Contains("<ToMarketOperator>OperatorB</ToMarketOperator>", result);
            Assert.Contains("<MarketOperator>Interconnector1</MarketOperator>", result);
            Assert.Contains("<CapacityType>Type1</CapacityType>", result);
            Assert.Contains("<CapacityIdentification>ID1</CapacityIdentification>", result);
        }

        private CustomShape CreateCustomShapeWith96Intervals()
        {
            var customShape = new CustomShape();
            customShape.Interval = new List<Interval>();

            for (int i = 0; i < 96; i++)
            {
                customShape.Interval.Add(new Interval
                {
                    StartDateTime = DateTime.Parse("2024-08-14"),
                    EndDateTime = DateTime.Parse("2024-08-14"),
                    Volume = i+1 // Initialize with default value, you can set it to any value you need
                });
            }

            return customShape;
        }
    }
}
