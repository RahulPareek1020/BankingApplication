using Shell.Energy.STPower.Services.TradeTransformer.XML;
using Shell.Energy.STPower.Shared.Enums;
using Shell.Energy.STPower.Shared.Exceptions;

namespace Shell.Energy.STPower.Services.Tests
{
    public class PowerTrakXmlTradeMapperTests
    {
        [Fact]
        public void Constructor_InitializesCorrectMapper_ForPowerTradeTransformer()
        {
            // Arrange
            var transformerType = PwrTrakTradeTransformerType.PowerTransTradeTransformer;

            // Act
            var mapper = new PowerTrakXmlTradeMapper(transformerType);

            // Assert
            Assert.IsType<PowerTrakXmlPowerTransTradeMapper>(mapper.PowerTrakTradeMapper);
        }

        [Fact]
        public void Constructor_ThrowsNotFoundException_ForUnsupportedType()
        {
            // Arrange
            var unsupportedType = (PwrTrakTradeTransformerType)999;

            // Act & Assert
            var exception = Assert.Throws<NotFoundException>(() => new PowerTrakXmlTradeMapper(unsupportedType));
            Assert.Equal($"TradeTransformerType {unsupportedType} is not supported.", exception.Message);
        }
    }
}
