using Shell.Energy.STPower.Data.Dto;
using Shell.Energy.STPower.Services.TradeTransformer.TradeTransformers;

namespace Shell.Energy.STPower.Services.TradeTransformer.Tests
{
    public class PowerTransTradeTransformerStrategyTests
    {
        private readonly PowerTransTradeTransformerStrategy _strategy;

        public PowerTransTradeTransformerStrategyTests()
        {
            _strategy = new PowerTransTradeTransformerStrategy();
        }

        [Fact]
        public void TransformTrade_ReturnsTransformedData()
        {
            // Arrange
            var sampleData = new List<NominationDetailsDto>
            {
                new NominationDetailsDto
                {
                    FromMarketOperator = "OperatorA",
                    ToMarketOperator = "OperatorB",
                    TransactionType = "TypeA",
                    AggPosReferenceName = "Ref123",
                    DeliveryDate = new DateTime(2023, 1, 1),
                    Counterparty = "CounterpartyA",
                    Entity = "EntityA",
                    Granularity = "15",
                    TimeZone= "Europe/London",
                    TradeType = "TradeA",
                    CapacityType = "CapacityA",
                    CapacityIdentification = "Cap123",
                    Interconnector = "InterconnectorA"
                }
            };

            // Act
            var result = _strategy.TransformTrade(sampleData);

            // Assert
            Assert.NotNull(result);
            Assert.Single(result);
            var transformedTrade = result.First();
            Assert.Equal("OperatorA", transformedTrade.FromMarketOperator);
            Assert.Equal("OperatorB", transformedTrade.ToMarketOperator);
            Assert.Equal("TypeA", transformedTrade.TransactionType);
            Assert.Equal("Ref123", transformedTrade.Reference);
            Assert.Equal(new DateTime(2023, 1, 1), transformedTrade.TradeDate);
            Assert.Equal("CounterpartyA", transformedTrade.Counterparty);
            Assert.Equal("EntityA", transformedTrade.Entity);
            Assert.Equal("15", transformedTrade.Granularity);
            Assert.Equal("TradeA", transformedTrade.TradeType);
            Assert.Equal("CapacityA", transformedTrade.CapacityType);
            Assert.Equal("Cap123", transformedTrade.CapacityIdentification);
            Assert.Equal("InterconnectorA", transformedTrade.Interconnector);
        }

        [Fact]
        public void TransformTrade_ReturnsEmptyListForEmptyInput()
        {
            // Arrange
            var emptyData = new List<NominationDetailsDto>();

            // Act
            var result = _strategy.TransformTrade(emptyData);

            // Assert
            Assert.NotNull(result);
            Assert.Empty(result);
        }
    }
}
