using Shell.Energy.STPower.Data.Dto;

namespace Shell.Energy.STPower.Data.Tests.Dto
{
    public class RawTradeDtoTests
    {
        [Fact]
        public void RawTradeDto_DefaultValues()
        {
            // Arrange
            var dto = new RawTradeDto();

            // Assert
            Assert.Equal(0, dto.RawTradeHeaderId);
            Assert.Equal(0, dto.NominationRunId);
            Assert.Equal(0, dto.AggPosReferenceId);
            Assert.Null(dto.AggPosReference);
            Assert.Null(dto.TradeReference);
            Assert.Null(dto.TradeType);
            Assert.Null(dto.TransactionType);
            Assert.Null(dto.Entity);
            Assert.Null(dto.Counterparty);
            Assert.Null(dto.FromMarketoperator);
            Assert.Null(dto.ToMarketoperator);
            Assert.Null(dto.CapacityType);
            Assert.Null(dto.CapacityIdentification);
            Assert.Null(dto.Interconnector);
            Assert.Equal(default(DateTime), dto.DeliveryDate);
            for (int i = 1; i <= 96; i++)
            {
                Assert.Null((double?)dto?.GetType()?.GetProperty($"QH{i}")?.GetValue(dto));
            }
            Assert.Null(dto.DelDateStart);
            Assert.Null(dto.DelDateEnd);
            Assert.Null(dto.Cdy1Attr1);
            Assert.Null(dto.PwrNomsOverrideType);
            Assert.Null(dto.PwrNomsOverrideInput);
            Assert.Null(dto.PwrNomsOverrideFreeform);
            Assert.Null(dto.AuxSoCpty);
            Assert.Null(dto.CptyNoms);
            Assert.Null(dto.PeakWorkaround);
            Assert.Equal(0.0, dto.InsNumRec);
        }

        [Fact]
        public void RawTradeDto_SetAndGetProperties()
        {
            // Arrange
            var dto = new RawTradeDto
            {
                RawTradeHeaderId = 1,
                NominationRunId = 2,
                AggPosReferenceId = 3,
                AggPosReference = "TestReference",
                TradeReference = "TestTradeReference",
                TradeType = "TestTradeType",
                TransactionType = "TestTransactionType",
                Entity = "TestEntity",
                Counterparty = "TestCounterparty",
                FromMarketoperator = "TestFromOperator",
                ToMarketoperator = "TestToOperator",
                CapacityType = "TestCapacityType",
                CapacityIdentification = "TestCapacityId",
                Interconnector = "TestInterconnector",
                DeliveryDate = new DateTime(2023, 1, 2),
                DelDateStart = new DateTime(2023, 1, 3),
                DelDateEnd = new DateTime(2023, 1, 4),
                Cdy1Attr1 = "TestCdy1Attr1",
                PwrNomsOverrideType = "TestOverrideType",
                PwrNomsOverrideInput = "TestOverrideInput",
                PwrNomsOverrideFreeform = "TestOverrideFreeform",
                AuxSoCpty = "TestAuxSoCpty",
                CptyNoms = "TestCptyNoms",
                PeakWorkaround = "TestPeakWorkaround",
                InsNumRec = 5
            };

            for (int i = 1; i <= 96; i++)
            {
                dto?.GetType()?.GetProperty($"QH{i}")?.SetValue(dto, (double?)i);
            }

            // Assert
            Assert.Equal(1, dto.RawTradeHeaderId);
            Assert.Equal(2, dto.NominationRunId);
            Assert.Equal(3, dto.AggPosReferenceId);
            Assert.Equal("TestReference", dto.AggPosReference);
            Assert.Equal("TestTradeReference", dto.TradeReference);
            Assert.Equal("TestTradeType", dto.TradeType);
            Assert.Equal("TestTransactionType", dto.TransactionType);
            Assert.Equal("TestEntity", dto.Entity);
            Assert.Equal("TestCounterparty", dto.Counterparty);
            Assert.Equal("TestFromOperator", dto.FromMarketoperator);
            Assert.Equal("TestToOperator", dto.ToMarketoperator);
            Assert.Equal("TestCapacityType", dto.CapacityType);
            Assert.Equal("TestCapacityId", dto.CapacityIdentification);
            Assert.Equal("TestInterconnector", dto.Interconnector);
            Assert.Equal(new DateTime(2023, 1, 2), dto.DeliveryDate);
            for (int i = 1; i <= 96; i++)
            {
                Assert.Equal(i, (double?)dto?.GetType()?.GetProperty($"QH{i}")?.GetValue(dto));
            }
            Assert.Equal(new DateTime(2023, 1, 3), dto.DelDateStart);
            Assert.Equal(new DateTime(2023, 1, 4), dto.DelDateEnd);
            Assert.Equal("TestCdy1Attr1", dto.Cdy1Attr1);
            Assert.Equal("TestOverrideType", dto.PwrNomsOverrideType);
            Assert.Equal("TestOverrideInput", dto.PwrNomsOverrideInput);
            Assert.Equal("TestOverrideFreeform", dto.PwrNomsOverrideFreeform);
            Assert.Equal("TestAuxSoCpty", dto.AuxSoCpty);
            Assert.Equal("TestCptyNoms", dto.CptyNoms);
            Assert.Equal("TestPeakWorkaround", dto.PeakWorkaround);
            Assert.Equal(5, dto.InsNumRec);
        }
    }
}
