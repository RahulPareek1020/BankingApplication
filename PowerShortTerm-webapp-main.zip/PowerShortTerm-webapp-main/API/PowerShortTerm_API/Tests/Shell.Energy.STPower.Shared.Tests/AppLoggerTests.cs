using Microsoft.Extensions.Logging;
using Moq;

namespace Shell.Energy.STPower.Shared.Tests
{
    public class AppLoggerTests
    {
        private readonly Mock<ILogger<AppLogger>> _mockLogger;
        private readonly AppLogger _appLogger;

        public AppLoggerTests()
        {
            _mockLogger = new Mock<ILogger<AppLogger>>();
            _appLogger = new AppLogger(_mockLogger.Object);
        }

        [Theory]
        [InlineData("Information message", LogLevel.Information)]
        [InlineData("Warning message", LogLevel.Warning)]
        [InlineData("Error message", LogLevel.Error)]
        [InlineData("Debug message", LogLevel.Debug)]
        [InlineData("Trace message", LogLevel.Trace)]
        [InlineData("Critical message", LogLevel.Critical)]
        public void LogMessage_LogsCorrectly(string message, LogLevel logLevel)
        {
            // Act
            switch (logLevel)
            {
                case LogLevel.Information:
                    _appLogger.LogInformation(message);
                    break;
                case LogLevel.Warning:
                    _appLogger.LogWarning(message);
                    break;
                case LogLevel.Error:
                    _appLogger.LogError(message);
                    break;
                case LogLevel.Debug:
                    _appLogger.LogDebug(message);
                    break;
                case LogLevel.Trace:
                    _appLogger.LogTrace(message);
                    break;
                case LogLevel.Critical:
                    _appLogger.LogCritical(message);
                    break;
            }

            // Assert
            _mockLogger.Verify(
                logger => logger.Log(
                    logLevel,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().Contains(message.Replace('\n', '_').Replace('\r', '_'))),
                    null,
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()),
                Times.Once);
        }
    }
}
