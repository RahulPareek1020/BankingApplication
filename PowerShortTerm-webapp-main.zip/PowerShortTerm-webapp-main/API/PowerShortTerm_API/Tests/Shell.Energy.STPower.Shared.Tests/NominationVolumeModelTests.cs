using Shell.Energy.STPower.Data.Models;

namespace Shell.Energy.STPower.Data.Tests.Dto
{
    public class NominationVolumeTests
    {
        [Fact]
        public void NominationVolume_DefaultValues()
        {
            // Arrange
            var volume = new NominationVolume();

            // Assert
            Assert.Equal(0, volume.QH1);
            Assert.Equal(0, volume.QH2);
            Assert.Equal(0, volume.QH3);
            Assert.Equal(0, volume.QH4);
            Assert.Equal(0, volume.QH5);
            Assert.Equal(0, volume.QH6);
            Assert.Equal(0, volume.QH7);
            Assert.Equal(0, volume.QH8);
            Assert.Equal(0, volume.QH9);
            Assert.Equal(0, volume.QH10);
            Assert.Equal(0, volume.QH11);
            Assert.Equal(0, volume.QH12);
            Assert.Equal(0, volume.QH13);
            Assert.Equal(0, volume.QH14);
            Assert.Equal(0, volume.QH15);
            Assert.Equal(0, volume.QH16);
            Assert.Equal(0, volume.QH17);
            Assert.Equal(0, volume.QH18);
            Assert.Equal(0, volume.QH19);
            Assert.Equal(0, volume.QH20);
            Assert.Equal(0, volume.QH21);
            Assert.Equal(0, volume.QH22);
            Assert.Equal(0, volume.QH23);
            Assert.Equal(0, volume.QH24);
            Assert.Equal(0, volume.QH25);
            Assert.Equal(0, volume.QH26);
            Assert.Equal(0, volume.QH27);
            Assert.Equal(0, volume.QH28);
            Assert.Equal(0, volume.QH29);
            Assert.Equal(0, volume.QH30);
            Assert.Equal(0, volume.QH31);
            Assert.Equal(0, volume.QH32);
            Assert.Equal(0, volume.QH33);
            Assert.Equal(0, volume.QH34);
            Assert.Equal(0, volume.QH35);
            Assert.Equal(0, volume.QH36);
            Assert.Equal(0, volume.QH37);
            Assert.Equal(0, volume.QH38);
            Assert.Equal(0, volume.QH39);
            Assert.Equal(0, volume.QH40);
            Assert.Equal(0, volume.QH41);
            Assert.Equal(0, volume.QH42);
            Assert.Equal(0, volume.QH43);
            Assert.Equal(0, volume.QH44);
            Assert.Equal(0, volume.QH45);
            Assert.Equal(0, volume.QH46);
            Assert.Equal(0, volume.QH47);
            Assert.Equal(0, volume.QH48);
            Assert.Equal(0, volume.QH49);
            Assert.Equal(0, volume.QH50);
            Assert.Equal(0, volume.QH51);
            Assert.Equal(0, volume.QH52);
            Assert.Equal(0, volume.QH53);
            Assert.Equal(0, volume.QH54);
            Assert.Equal(0, volume.QH55);
            Assert.Equal(0, volume.QH56);
            Assert.Equal(0, volume.QH57);
            Assert.Equal(0, volume.QH58);
            Assert.Equal(0, volume.QH59);
            Assert.Equal(0, volume.QH60);
            Assert.Equal(0, volume.QH61);
            Assert.Equal(0, volume.QH62);
            Assert.Equal(0, volume.QH63);
            Assert.Equal(0, volume.QH64);
            Assert.Equal(0, volume.QH65);
            Assert.Equal(0, volume.QH66);
            Assert.Equal(0, volume.QH67);
            Assert.Equal(0, volume.QH68);
            Assert.Equal(0, volume.QH69);
            Assert.Equal(0, volume.QH70);
            Assert.Equal(0, volume.QH71);
            Assert.Equal(0, volume.QH72);
            Assert.Equal(0, volume.QH73);
            Assert.Equal(0, volume.QH74);
            Assert.Equal(0, volume.QH75);
            Assert.Equal(0, volume.QH76);
            Assert.Equal(0, volume.QH77);
            Assert.Equal(0, volume.QH78);
            Assert.Equal(0, volume.QH79);
            Assert.Equal(0, volume.QH80);
            Assert.Equal(0, volume.QH81);
            Assert.Equal(0, volume.QH82);
            Assert.Equal(0, volume.QH83);
            Assert.Equal(0, volume.QH84);
            Assert.Equal(0, volume.QH85);
            Assert.Equal(0, volume.QH86);
            Assert.Equal(0, volume.QH87);
            Assert.Equal(0, volume.QH88);
            Assert.Equal(0, volume.QH89);
            Assert.Equal(0, volume.QH90);
            Assert.Equal(0, volume.QH91);
            Assert.Equal(0, volume.QH92);
            Assert.Equal(0, volume.QH93);
            Assert.Equal(0, volume.QH94);
            Assert.Equal(0, volume.QH95);
            Assert.Equal(0, volume.QH96);
        }

        [Fact]
        public void NominationVolume_SetAndGetProperties()
        {
            // Arrange
            var volume = new NominationVolume
            {
                QH1 = 1,
                QH2 = 2,
                QH3 = 3,
                QH4 = 4,
                QH5 = 5,
                QH6 = 6,
                QH7 = 7,
                QH8 = 8,
                QH9 = 9,
                QH10 = 10,
                QH11 = 11,
                QH12 = 12,
                QH13 = 13,
                QH14 = 14,
                QH15 = 15,
                QH16 = 16,
                QH17 = 17,
                QH18 = 18,
                QH19 = 19,
                QH20 = 20,
                QH21 = 21,
                QH22 = 22,
                QH23 = 23,
                QH24 = 24,
                QH25 = 25,
                QH26 = 26,
                QH27 = 27,
                QH28 = 28,
                QH29 = 29,
                QH30 = 30,
                QH31 = 31,
                QH32 = 32,
                QH33 = 33,
                QH34 = 34,
                QH35 = 35,
                QH36 = 36,
                QH37 = 37,
                QH38 = 38,
                QH39 = 39,
                QH40 = 40,
                QH41 = 41,
                QH42 = 42,
                QH43 = 43,
                QH44 = 44,
                QH45 = 45,
                QH46 = 46,
                QH47 = 47,
                QH48 = 48,
                QH49 = 49,
                QH50 = 50,
                QH51 = 51,
                QH52 = 52,
                QH53 = 53,
                QH54 = 54,
                QH55 = 55,
                QH56 = 56,
                QH57 = 57,
                QH58 = 58,
                QH59 = 59,
                QH60 = 60,
                QH61 = 61,
                QH62 = 62,
                QH63 = 63,
                QH64 = 64,
                QH65 = 65,
                QH66 = 66,
                QH67 = 67,
                QH68 = 68,
                QH69 = 69,
                QH70 = 70,
                QH71 = 71,
                QH72 = 72,
                QH73 = 73,
                QH74 = 74,
                QH75 = 75,
                QH76 = 76,
                QH77 = 77,
                QH78 = 78,
                QH79 = 79,
                QH80 = 80,
                QH81 = 81,
                QH82 = 82,
                QH83 = 83,
                QH84 = 84,
                QH85 = 85,
                QH86 = 86,
                QH87 = 87,
                QH88 = 88,
                QH89 = 89,
                QH90 = 90,
                QH91 = 91,
                QH92 = 92,
                QH93 = 93,
                QH94 = 94,
                QH95 = 95,
                QH96 = 96
            };

            // Assert
            Assert.Equal(1, volume.QH1);
            Assert.Equal(2, volume.QH2);
            Assert.Equal(3, volume.QH3);
            Assert.Equal(4, volume.QH4);
            Assert.Equal(5, volume.QH5);
            Assert.Equal(6, volume.QH6);
            Assert.Equal(7, volume.QH7);
            Assert.Equal(8, volume.QH8);
            Assert.Equal(9, volume.QH9);
            Assert.Equal(10, volume.QH10);
            Assert.Equal(11, volume.QH11);
            Assert.Equal(12, volume.QH12);
            Assert.Equal(13, volume.QH13);
            Assert.Equal(14, volume.QH14);
            Assert.Equal(15, volume.QH15);
            Assert.Equal(16, volume.QH16);
            Assert.Equal(17, volume.QH17);
            Assert.Equal(18, volume.QH18);
            Assert.Equal(19, volume.QH19);
            Assert.Equal(20, volume.QH20);
            Assert.Equal(21, volume.QH21);
            Assert.Equal(22, volume.QH22);
            Assert.Equal(23, volume.QH23);
            Assert.Equal(24, volume.QH24);
            Assert.Equal(25, volume.QH25);
            Assert.Equal(26, volume.QH26);
            Assert.Equal(27, volume.QH27);
            Assert.Equal(28, volume.QH28);
            Assert.Equal(29, volume.QH29);
            Assert.Equal(30, volume.QH30);
            Assert.Equal(31, volume.QH31);
            Assert.Equal(32, volume.QH32);
            Assert.Equal(33, volume.QH33);
            Assert.Equal(34, volume.QH34);
            Assert.Equal(35, volume.QH35);
            Assert.Equal(36, volume.QH36);
            Assert.Equal(37, volume.QH37);
            Assert.Equal(38, volume.QH38);
            Assert.Equal(39, volume.QH39);
            Assert.Equal(40, volume.QH40);
            Assert.Equal(41, volume.QH41);
            Assert.Equal(42, volume.QH42);
            Assert.Equal(43, volume.QH43);
            Assert.Equal(44, volume.QH44);
            Assert.Equal(45, volume.QH45);
            Assert.Equal(46, volume.QH46);
            Assert.Equal(47, volume.QH47);
            Assert.Equal(48, volume.QH48);
            Assert.Equal(49, volume.QH49);
            Assert.Equal(50, volume.QH50);
            Assert.Equal(51, volume.QH51);
            Assert.Equal(52, volume.QH52);
            Assert.Equal(53, volume.QH53);
            Assert.Equal(54, volume.QH54);
            Assert.Equal(55, volume.QH55);
            Assert.Equal(56, volume.QH56);
            Assert.Equal(57, volume.QH57);
            Assert.Equal(58, volume.QH58);
            Assert.Equal(59, volume.QH59);
            Assert.Equal(60, volume.QH60);
            Assert.Equal(61, volume.QH61);
            Assert.Equal(62, volume.QH62);
            Assert.Equal(63, volume.QH63);
            Assert.Equal(64, volume.QH64);
            Assert.Equal(65, volume.QH65);
            Assert.Equal(66, volume.QH66);
            Assert.Equal(67, volume.QH67);
            Assert.Equal(68, volume.QH68);
            Assert.Equal(69, volume.QH69);
            Assert.Equal(70, volume.QH70);
            Assert.Equal(71, volume.QH71);
            Assert.Equal(72, volume.QH72);
            Assert.Equal(73, volume.QH73);
            Assert.Equal(74, volume.QH74);
            Assert.Equal(75, volume.QH75);
            Assert.Equal(76, volume.QH76);
            Assert.Equal(77, volume.QH77);
            Assert.Equal(78, volume.QH78);
            Assert.Equal(79, volume.QH79);
            Assert.Equal(80, volume.QH80);
            Assert.Equal(81, volume.QH81);
            Assert.Equal(82, volume.QH82);
            Assert.Equal(83, volume.QH83);
            Assert.Equal(84, volume.QH84);
            Assert.Equal(85, volume.QH85);
            Assert.Equal(86, volume.QH86);
            Assert.Equal(87, volume.QH87);
            Assert.Equal(88, volume.QH88);
            Assert.Equal(89, volume.QH89);
            Assert.Equal(90, volume.QH90);
            Assert.Equal(91, volume.QH91);
            Assert.Equal(92, volume.QH92);
            Assert.Equal(93, volume.QH93);
            Assert.Equal(94, volume.QH94);
            Assert.Equal(95, volume.QH95);
            Assert.Equal(96, volume.QH96);
        }
    }
}
