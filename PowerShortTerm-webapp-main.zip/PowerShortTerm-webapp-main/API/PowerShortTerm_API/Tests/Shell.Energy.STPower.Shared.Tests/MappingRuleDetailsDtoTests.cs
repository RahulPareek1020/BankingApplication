using Shell.Energy.STPower.Data.Dto;

namespace Shell.Energy.STPower.Data.Tests.Dto
{
    public class MappingRuleDetailsDtoTests
    {
        [Fact]
        public void MappingRuleDetailsDto_DefaultValues()
        {
            // Arrange
            var dto = new MappingRuleDetailsDto();

            // Assert
            Assert.Equal(0, dto.MappingMasterId);
            Assert.Equal(0, dto.NominationDefinitionId);
            Assert.Null(dto.NominationDefinitionName);
            Assert.Null(dto.MappingMasterName);
            Assert.Null(dto.MappingMasterCreatedDate);
            Assert.Null(dto.MappingMasterModifiedDate);
            Assert.Null(dto.MappingMasterStatus);
            Assert.Equal(0, dto.MappingTypeId);
            Assert.Null(dto.MappingTypeName);
            Assert.Null(dto.MappingTypeCreatedDate);
            Assert.Null(dto.MappingTypeModifiedDate);
            Assert.Null(dto.MappingTypeStatus);
            Assert.Equal(0, dto.MappingInputId);
            Assert.Null(dto.MappingInputField);
            Assert.Null(dto.MappingInputValue);
            Assert.Null(dto.MappingInputStartDate);
            Assert.Null(dto.MappingInputEndDate);
            Assert.Equal(default(DateTime), dto.MappingInputCreatedDate);
            Assert.Null(dto.MappingInputModifiedDate);
            Assert.Null(dto.MappingInputStatus);
            Assert.Equal(0, dto.MappingOutputId);
            Assert.Null(dto.MappingOutputValue);
            Assert.Null(dto.MappingOutputStartDate);
            Assert.Null(dto.MappingOutputEndDate);
            Assert.Equal(default(DateTime), dto.MappingOutputCreatedDate);
            Assert.Null(dto.MappingOutputModifiedDate);
            Assert.Null(dto.MappingOutputStatus);
        }

        [Fact]
        public void MappingRuleDetailsDto_SetAndGetProperties()
        {
            // Arrange
            var dto = new MappingRuleDetailsDto
            {
                MappingMasterId = 1,
                NominationDefinitionId = 2,
                NominationDefinitionName = "TestNominationName",
                MappingMasterName = "TestMappingMasterName",
                MappingMasterCreatedDate = new DateTime(2023, 1, 1),
                MappingMasterModifiedDate = new DateTime(2023, 1, 2),
                MappingMasterStatus = "Active",
                MappingTypeId = 3,
                MappingTypeName = "TestMappingTypeName",
                MappingTypeCreatedDate = new DateTime(2023, 1, 3),
                MappingTypeModifiedDate = new DateTime(2023, 1, 4),
                MappingTypeStatus = "Active",
                MappingInputId = 4,
                MappingInputField = "TestInputField",
                MappingInputValue = "TestInputValue",
                MappingInputStartDate = new DateTime(2023, 1, 5),
                MappingInputEndDate = new DateTime(2023, 1, 6),
                MappingInputCreatedDate = new DateTime(2023, 1, 7),
                MappingInputModifiedDate = new DateTime(2023, 1, 8),
                MappingInputStatus = "Active",
                MappingOutputId = 5,
                MappingOutputValue = "TestOutputValue",
                MappingOutputStartDate = new DateTime(2023, 1, 9),
                MappingOutputEndDate = new DateTime(2023, 1, 10),
                MappingOutputCreatedDate = new DateTime(2023, 1, 11),
                MappingOutputModifiedDate = new DateTime(2023, 1, 12),
                MappingOutputStatus = "Active"
            };

            // Assert
            Assert.Equal(1, dto.MappingMasterId);
            Assert.Equal(2, dto.NominationDefinitionId);
            Assert.Equal("TestNominationName", dto.NominationDefinitionName);
            Assert.Equal("TestMappingMasterName", dto.MappingMasterName);
            Assert.Equal(new DateTime(2023, 1, 1), dto.MappingMasterCreatedDate);
            Assert.Equal(new DateTime(2023, 1, 2), dto.MappingMasterModifiedDate);
            Assert.Equal("Active", dto.MappingMasterStatus);
            Assert.Equal(3, dto.MappingTypeId);
            Assert.Equal("TestMappingTypeName", dto.MappingTypeName);
            Assert.Equal(new DateTime(2023, 1, 3), dto.MappingTypeCreatedDate);
            Assert.Equal(new DateTime(2023, 1, 4), dto.MappingTypeModifiedDate);
            Assert.Equal("Active", dto.MappingTypeStatus);
            Assert.Equal(4, dto.MappingInputId);
            Assert.Equal("TestInputField", dto.MappingInputField);
            Assert.Equal("TestInputValue", dto.MappingInputValue);
            Assert.Equal(new DateTime(2023, 1, 5), dto.MappingInputStartDate);
            Assert.Equal(new DateTime(2023, 1, 6), dto.MappingInputEndDate);
            Assert.Equal(new DateTime(2023, 1, 7), dto.MappingInputCreatedDate);
            Assert.Equal(new DateTime(2023, 1, 8), dto.MappingInputModifiedDate);
            Assert.Equal("Active", dto.MappingInputStatus);
            Assert.Equal(5, dto.MappingOutputId);
            Assert.Equal("TestOutputValue", dto.MappingOutputValue);
            Assert.Equal(new DateTime(2023, 1, 9), dto.MappingOutputStartDate);
            Assert.Equal(new DateTime(2023, 1, 10), dto.MappingOutputEndDate);
            Assert.Equal(new DateTime(2023, 1, 11), dto.MappingOutputCreatedDate);
            Assert.Equal(new DateTime(2023, 1, 12), dto.MappingOutputModifiedDate);
            Assert.Equal("Active", dto.MappingOutputStatus);
        }
    }
}
