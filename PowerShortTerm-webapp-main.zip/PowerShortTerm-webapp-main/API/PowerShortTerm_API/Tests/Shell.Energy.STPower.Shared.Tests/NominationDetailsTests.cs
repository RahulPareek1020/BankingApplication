using Shell.Energy.STPower.Data.Models;

namespace Shell.Energy.STPower.Data.Tests.Models
{
    public class NominationDetailsTests
    {
        [Fact]
        public void NominationDetails_DefaultValues()
        {
            // Arrange
            var details = new NominationDetails();

            // Assert
            Assert.Equal(0, details.NominationRunId);
            Assert.Equal(0, details.NominationDefinitionId);
            Assert.Null(details.NominationDefinitionName);
            Assert.Equal(default(DateTime), details.DeliveryDate);
            Assert.Equal(0, details.AggPosReferenceId);
            Assert.Null(details.AggPosReferenceName);
            Assert.Null(details.TradeType);
            Assert.Null(details.TransactionType);
            Assert.Null(details.Granularity);
            Assert.Null(details.Entity);
            Assert.Null(details.ClientName);
            Assert.Null(details.Counterparty);
            Assert.Null(details.FromMarketOperator);
            Assert.Null(details.ToMarketOperator);
            Assert.Null(details.CapacityType);
            Assert.Null(details.CapacityIdentification);
            Assert.Null(details.Interconnector);
            Assert.Null(details.NominationVolume);
        }

        [Fact]
        public void NominationDetails_SetAndGetProperties()
        {
            // Arrange
            var details = new NominationDetails
            {
                NominationRunId = 1,
                NominationDefinitionId = 2,
                NominationDefinitionName = "TestName",
                DeliveryDate = new DateTime(2023, 1, 1),
                AggPosReferenceId = 3,
                AggPosReferenceName = "TestReference",
                TradeType = "TestTrade",
                TransactionType = "TestTransaction",
                Granularity = "TestGranularity",
                Entity = "TestEntity",
                ClientName = "Shell",
                Counterparty = "TestCounterparty",
                FromMarketOperator = "TestFromOperator",
                ToMarketOperator = "TestToOperator",
                CapacityType = "TestCapacityType",
                CapacityIdentification = "TestCapacityId",
                Interconnector = "TestInterconnector",
                NominationVolume = new NominationVolume()
            };

            // Assert
            Assert.Equal(1, details.NominationRunId);
            Assert.Equal(2, details.NominationDefinitionId);
            Assert.Equal("TestName", details.NominationDefinitionName);
            Assert.Equal(new DateTime(2023, 1, 1), details.DeliveryDate);
            Assert.Equal(3, details.AggPosReferenceId);
            Assert.Equal("TestReference", details.AggPosReferenceName);
            Assert.Equal("TestTrade", details.TradeType);
            Assert.Equal("TestTransaction", details.TransactionType);
            Assert.Equal("TestGranularity", details.Granularity);
            Assert.Equal("TestEntity", details.Entity);
            Assert.Equal("Shell", details.ClientName);
            Assert.Equal("TestCounterparty", details.Counterparty);
            Assert.Equal("TestFromOperator", details.FromMarketOperator);
            Assert.Equal("TestToOperator", details.ToMarketOperator);
            Assert.Equal("TestCapacityType", details.CapacityType);
            Assert.Equal("TestCapacityId", details.CapacityIdentification);
            Assert.Equal("TestInterconnector", details.Interconnector);
            Assert.NotNull(details.NominationVolume);
        }
    }
}
