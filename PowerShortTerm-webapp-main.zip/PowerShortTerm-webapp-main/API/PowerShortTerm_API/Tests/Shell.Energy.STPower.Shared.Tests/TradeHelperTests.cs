using Shell.Energy.STPower.Data.Dto;
using Shell.Energy.STPower.Shared.Constants;
using Shell.Energy.STPower.Shared.Enums;
using Shell.Energy.STPower.Shared.Model;

namespace Shell.Energy.STPower.Shared.Tests
{
    public class TradeHelperTests
    {
        [Theory]
        [InlineData("2023-10-29", Granularity.QHR, "Central European Standard Time", 100)] // Last Sunday of October (long day)
        [InlineData("2023-03-26", Granularity.QHR, "Central European Standard Time", 92)]  // Last Sunday of March (short day)
        [InlineData("2023-10-28", Granularity.QHR, "Central European Standard Time", 96)]  // Normal day
        [InlineData("2023-10-29", Granularity.HHR, "Central European Standard Time", 50)]  // Last Sunday of October (long day)
        [InlineData("2023-03-26", Granularity.HHR, "Central European Standard Time", 46)]  // Last Sunday of March (short day)
        [InlineData("2023-10-28", Granularity.HHR, "Central European Standard Time", 48)]  // Normal day
        [InlineData("2023-10-29", Granularity.HR, "Central European Standard Time", 25)]   // Last Sunday of October (long day)
        [InlineData("2023-03-26", Granularity.HR, "Central European Standard Time", 23)]   // Last Sunday of March (short day)
        [InlineData("2023-10-28", Granularity.HR, "Central European Standard Time", 24)]   // Normal day
        public void GetDLSPeriodCount_ReturnsCorrectPeriodCount(string date, Granularity granularity, string timezone, int expectedPeriodCount)
        {
            // Arrange
            DateTime dateTime = DateTime.Parse(date);

            // Act
            int periodCount = TradeHelper.GetDLSPeriodCount(dateTime, granularity, timezone);

            // Assert
            Assert.Equal(expectedPeriodCount, periodCount);
        }

        [Theory]
        [InlineData("2023-10-29", Granularity.QHR, "Greenwich Standard Time", 96)] // Last Sunday of October (long day)
        [InlineData("2023-03-26", Granularity.QHR, "Greenwich Standard Time", 96)]  // Last Sunday of March (short day)
        [InlineData("2023-10-28", Granularity.QHR, "Greenwich Standard Time", 96)]  // Normal day
        [InlineData("2023-10-29", Granularity.HHR, "Greenwich Standard Time", 48)]  // Last Sunday of October (long day)
        [InlineData("2023-03-26", Granularity.HHR, "Greenwich Standard Time", 48)]  // Last Sunday of March (short day)
        [InlineData("2023-10-28", Granularity.HHR, "Greenwich Standard Time", 48)]  // Normal day
        [InlineData("2023-10-29", Granularity.HR, "Greenwich Standard Time", 24)]   // Last Sunday of October (long day)
        [InlineData("2023-03-26", Granularity.HR, "Greenwich Standard Time", 24)]   // Last Sunday of March (short day)
        [InlineData("2023-10-28", Granularity.HR, "Greenwich Standard Time", 24)]   // Normal day
        public void GetDLSPeriodCount_ReturnsCorrectPeriodCount_ZeroOffset(string date, Granularity granularity, string timezone, int expectedPeriodCount)
        {
            // Arrange
            DateTime dateTime = DateTime.Parse(date);

            // Act
            int periodCount = TradeHelper.GetDLSPeriodCount(dateTime, granularity, timezone);

            // Assert
            Assert.Equal(expectedPeriodCount, periodCount);
        }

        [Fact]
        public void GetDLSPeriodCount_InvalidGranularity_ThrowsArgumentException()
        {
            // Arrange
            DateTime dateTime = DateTime.Now;
            Granularity invalidGranularity = (Granularity)999;
            string timezone = "Central European Standard Time";

            // Act & Assert
            Assert.Throws<ArgumentException>(() => TradeHelper.GetDLSPeriodCount(dateTime, invalidGranularity, timezone));
        }

        [Fact]
        public void GetTradeDataBasedOnTimeZone_ReturnsCorrectData()
        {
            // Arrange
            var mockData = new List<NominationDetailsDto>
            {
                new NominationDetailsDto
                {
                    NominationRunId = 1,
                    NominationDefinitionId = 1,
                    NominationDefinitionName = "Test Nomination",
                    DeliveryDate = DateTime.Parse("2023-10-28"),
                    AggPosReferenceId = 1,
                    AggPosReferenceName = "AggPosRef1",
                    TimeZone = "Central European Standard Time",
                    ContributingTradeHeaderIds = "1",
                    TradeType = "PW_TRADE",
                    TransactionType = "Buy",
                    Granularity = "15",
                    Entity = "Entity1",
                    Counterparty = "Counterparty1",
                    FromMarketOperator = "MarketOperator1",
                    ToMarketOperator = "MarketOperator2",
                    CapacityType = "Type1",
                    CapacityIdentification = "CapId1",
                    Interconnector = "Interconnector1",
                    QH1 = 50,
                    QH2 = 50,
                    QH3 = 50,
                    QH4 = 50,
                    QH5 = 50,
                    QH6 = 50,
                    QH7 = 50,
                    QH8 = 50,
                    QH9 = 50,
                    QH10 = 50,
                    QH11 = 50,
                    QH12 = 50,
                    QH13 = 50,
                    QH14 = 50,
                    QH15 = 50
                }
            };

            var expectedData = new List<NominationDetailsDto>
            {
                new NominationDetailsDto
                {
                    NominationRunId = 1,
                    NominationDefinitionId = 1,
                    NominationDefinitionName = "Test Nomination",
                    DeliveryDate = DateTime.Parse("2023-10-28"),
                    AggPosReferenceId = 1,
                    AggPosReferenceName = "AggPosRef1",
                    TimeZone = "Central European Standard Time",
                    ContributingTradeHeaderIds = "1",
                    TradeType = "PW_TRADE",
                    TransactionType = "Buy",
                    Granularity = "15",
                    Entity = "Entity1",
                    Counterparty = "Counterparty1",
                    FromMarketOperator = "MarketOperator1",
                    ToMarketOperator = "MarketOperator2",
                    CapacityType = "Type1",
                    CapacityIdentification = "CapId1",
                    Interconnector = "Interconnector1",
                    QH1 = 0,
                    QH2 = 0,
                    QH3 = 0,
                    QH4 = 0,
                    QH5 = 0,
                    QH6 = 0,
                    QH7 = 0,
                    QH8 = 0,
                    QH9 = 50,
                    QH10 = 50,
                    QH11 = 50,
                    QH12 = 50,
                    QH13 = 50,
                    QH14 = 50,
                    QH15 = 50
                }
            };

            // Act
            var result = TradeHelper.GetTradeDataBasedOnTimeZone(mockData, DateTime.Parse("2023-10-28"));

            // Assert
            Assert.Equal(expectedData.Count, result.Count());
            Assert.Equal(expectedData.First().NominationRunId, result.First().NominationRunId);
            Assert.Equal(expectedData.First().NominationDefinitionId, result.First().NominationDefinitionId);
            Assert.Equal(expectedData.First().NominationDefinitionName, result.First().NominationDefinitionName);
            Assert.Equal(expectedData.First().DeliveryDate, result.First().DeliveryDate);
            Assert.Equal(expectedData.First().AggPosReferenceId, result.First().AggPosReferenceId);
            Assert.Equal(expectedData.First().AggPosReferenceName, result.First().AggPosReferenceName);
            Assert.Equal(expectedData.First().TimeZone, result.First().TimeZone);
            Assert.Equal(expectedData.First().ContributingTradeHeaderIds, result.First().ContributingTradeHeaderIds);
            Assert.Equal(expectedData.First().TradeType, result.First().TradeType);
            Assert.Equal(expectedData.First().TransactionType, result.First().TransactionType);
            Assert.Equal(expectedData.First().Granularity, result.First().Granularity);
            Assert.Equal(expectedData.First().Entity, result.First().Entity);
            Assert.Equal(expectedData.First().Counterparty, result.First().Counterparty);
            Assert.Equal(expectedData.First().FromMarketOperator, result.First().FromMarketOperator);
            Assert.Equal(expectedData.First().ToMarketOperator, result.First().ToMarketOperator);
            Assert.Equal(expectedData.First().CapacityType, result.First().CapacityType);
            Assert.Equal(expectedData.First().CapacityIdentification, result.First().CapacityIdentification);
            Assert.Equal(expectedData.First().Interconnector, result.First().Interconnector);
            Assert.Equal(expectedData.First().QH1, result.First().QH1);
            Assert.Equal(expectedData.First().QH2, result.First().QH2);
            Assert.Equal(expectedData.First().QH3, result.First().QH3);
            Assert.Equal(expectedData.First().QH4, result.First().QH4);
            Assert.Equal(expectedData.First().QH5, result.First().QH5);
            Assert.Equal(expectedData.First().QH6, result.First().QH6);
            Assert.Equal(expectedData.First().QH7, result.First().QH7);
            Assert.Equal(expectedData.First().QH8, result.First().QH8);
            Assert.Equal(expectedData.First().QH9, result.First().QH9);
            Assert.Equal(expectedData.First().QH10, result.First().QH10);
            Assert.Equal(expectedData.First().QH11, result.First().QH11);
            Assert.Equal(expectedData.First().QH12, result.First().QH12);
            Assert.Equal(expectedData.First().QH13, result.First().QH13);
            Assert.Equal(expectedData.First().QH14, result.First().QH14);
            Assert.Equal(expectedData.First().QH15, result.First().QH15);
        }

        [Fact]
        public void GetTradeDataBasedOnTimeZonePeakTradeDm1_ReturnsCorrectData()
        {
            // Arrange
            var mockData = new List<NominationDetailsDto>
            {
                new NominationDetailsDto
                {
                    NominationRunId = 1,
                    NominationDefinitionId = 1,
                    NominationDefinitionName = "Test Nomination",
                    DeliveryDate = DateTime.Parse("2023-10-27"),
                    AggPosReferenceId = 1,
                    AggPosReferenceName = "AggPosRef1",
                    TimeZone = "Central European Standard Time",
                    ContributingTradeHeaderIds = "1",
                    TradeType = "PW_TRADE",
                    TransactionType = "Buy",
                    Granularity = "15",
                    Entity = "Entity1",
                    Counterparty = "Counterparty1",
                    FromMarketOperator = "MarketOperator1",
                    ToMarketOperator = "MarketOperator2",
                    CapacityType = "Type1",
                    CapacityIdentification = "CapId1",
                    Interconnector = "Interconnector1",
                    QH1 = 50,
                    QH2 = 50,
                    QH3 = 50,
                    QH4 = 50,
                    QH5 = 50,
                    QH6 = 50,
                    QH7 = 50,
                    QH8 = 50,
                    QH9 = 50,
                    QH10 = 50,
                    QH11 = 50,
                    QH12 = 50,
                    QH13 = 50,
                    QH14 = 50,
                    QH15 = 50,
                      QH89= 50,
                    QH90 = 50,
                    QH91 = 50,
                     QH92= 50,
                    QH93 = 50,
                    QH94 = 50,
                    QH95 = 50,
                    QH96 = 50,
                    QH97 = 50,
                    QH98 = 50,
                    QH99 = 50,
                    QH100 = 50,
                }
            };

            var expectedData = new List<NominationDetailsDto>
            {
                new NominationDetailsDto
                {
                    NominationRunId = 1,
                    NominationDefinitionId = 1,
                    NominationDefinitionName = "Test Nomination",
                    DeliveryDate = DateTime.Parse("2023-10-28"),
                    AggPosReferenceId = 1,
                    AggPosReferenceName = "AggPosRef1",
                    TimeZone = "Central European Standard Time",
                    ContributingTradeHeaderIds = "1",
                    TradeType = "PW_TRADE",
                    TransactionType = "Buy",
                    Granularity = "15",
                    Entity = "Entity1",
                    Counterparty = "Counterparty1",
                    FromMarketOperator = "MarketOperator1",
                    ToMarketOperator = "MarketOperator2",
                    CapacityType = "Type1",
                    CapacityIdentification = "CapId1",
                    Interconnector = "Interconnector1",
                    QH1 = 50,
                    QH2 = 50,
                    QH3 = 50,
                    QH4 = 50,
                    QH5 = 50,
                    QH6 = 50,
                    QH7 = 50,
                    QH8 = 50,
                    QH9 = 0,
                    QH10 = 0,
                    QH11 = 0,
                    QH12 = 0,
                    QH13 = 0,
                    QH14 = 0,
                    QH15 = 0,
                    QH16 = 0,
                    QH17= 0,
                    QH18 = 0,
                    QH19 = 0,
                    QH20 = 0,
                    QH21 = 0,
                     QH89= 0,
                    QH90 = 0,
                    QH91 = 0,
                     QH92= 0,
                    QH93 = 0,
                    QH94 = 0,
                    QH95 = 0,
                    QH96 = 0
                }
            };

            // Act
            var result = TradeHelper.GetTradeDataBasedOnTimeZone(mockData, DateTime.Parse("2023-10-28"));

            // Assert
            Assert.Equal(expectedData.Count, result.Count());
            Assert.Equal(expectedData.First().NominationRunId, result.First().NominationRunId);
            Assert.Equal(expectedData.First().NominationDefinitionId, result.First().NominationDefinitionId);
            Assert.Equal(expectedData.First().NominationDefinitionName, result.First().NominationDefinitionName);
            Assert.Equal(expectedData.First().DeliveryDate, result.First().DeliveryDate);
            Assert.Equal(expectedData.First().AggPosReferenceId, result.First().AggPosReferenceId);
            Assert.Equal(expectedData.First().AggPosReferenceName, result.First().AggPosReferenceName);
            Assert.Equal(expectedData.First().TimeZone, result.First().TimeZone);
            Assert.Equal(expectedData.First().ContributingTradeHeaderIds, result.First().ContributingTradeHeaderIds);
            Assert.Equal(expectedData.First().TradeType, result.First().TradeType);
            Assert.Equal(expectedData.First().TransactionType, result.First().TransactionType);
            Assert.Equal(expectedData.First().Granularity, result.First().Granularity);
            Assert.Equal(expectedData.First().Entity, result.First().Entity);
            Assert.Equal(expectedData.First().Counterparty, result.First().Counterparty);
            Assert.Equal(expectedData.First().FromMarketOperator, result.First().FromMarketOperator);
            Assert.Equal(expectedData.First().ToMarketOperator, result.First().ToMarketOperator);
            Assert.Equal(expectedData.First().CapacityType, result.First().CapacityType);
            Assert.Equal(expectedData.First().CapacityIdentification, result.First().CapacityIdentification);
            Assert.Equal(expectedData.First().Interconnector, result.First().Interconnector);
            Assert.Equal(expectedData.First().QH1, result.First().QH1);
            Assert.Equal(expectedData.First().QH2, result.First().QH2);
            Assert.Equal(expectedData.First().QH3, result.First().QH3);
            Assert.Equal(expectedData.First().QH4, result.First().QH4);
            Assert.Equal(expectedData.First().QH5, result.First().QH5);
            Assert.Equal(expectedData.First().QH6, result.First().QH6);
            Assert.Equal(expectedData.First().QH7, result.First().QH7);
            Assert.Equal(expectedData.First().QH8, result.First().QH8);
            Assert.Equal(expectedData.First().QH9, result.First().QH9);
            Assert.Equal(expectedData.First().QH10, result.First().QH10);
            Assert.Equal(expectedData.First().QH11, result.First().QH11);
            Assert.Equal(expectedData.First().QH12, result.First().QH12);
            Assert.Equal(expectedData.First().QH13, result.First().QH13);
            Assert.Equal(expectedData.First().QH14, result.First().QH14);
            Assert.Equal(expectedData.First().QH15, result.First().QH15);
        }

        [Fact]
        public void GetTradeDataBasedOnTimeZonePeakTrade_ReturnsCorrectData()
        {
            // Arrange
            var mockData = new List<NominationDetailsDto>
            {
                new NominationDetailsDto
                {
                    NominationRunId = 1,
                    NominationDefinitionId = 1,
                    NominationDefinitionName = "Test Nomination",
                    DeliveryDate = DateTime.Parse("2023-10-27"),
                    AggPosReferenceId = 1,
                    AggPosReferenceName = "AggPosRef1",
                    TimeZone = "Central European Standard Time",
                    ContributingTradeHeaderIds = "1",
                    TradeType = "PW_TRADE",
                    TransactionType = "Buy",
                    Granularity = "15",
                    Entity = "Entity1",
                    Counterparty = "Counterparty1",
                    FromMarketOperator = "MarketOperator1",
                    ToMarketOperator = "MarketOperator2",
                    CapacityType = "Type1",
                    CapacityIdentification = "CapId1",
                    Interconnector = "Interconnector1",
                    QH1 = 50,
                    QH2 = 50,
                    QH3 = 50,
                    QH4 = 50,
                    QH5 = 50,
                    QH6 = 50,
                    QH7 = 50,
                    QH8 = 50,
                    QH9 = 50,
                    QH10 = 50,
                    QH11 = 50,
                    QH12 = 50,
                    QH13 = 50,
                    QH14 = 50,
                    QH15 = 50,
                      QH89= 50,
                    QH90 = 50,
                    QH91 = 50,
                     QH92= 50,
                    QH93 = 50,
                    QH94 = 50,
                    QH95 = 50,
                    QH96 = 50,
                    QH97 = 50,
                    QH98 = 50,
                    QH99 = 50,
                    QH100 = 50,
                }
            };

            var expectedData = new List<NominationDetailsDto>
            {
                new NominationDetailsDto
                {
                    NominationRunId = 1,
                    NominationDefinitionId = 1,
                    NominationDefinitionName = "Test Nomination",
                    DeliveryDate = DateTime.Parse("2023-10-28"),
                    AggPosReferenceId = 1,
                    AggPosReferenceName = "AggPosRef1",
                    TimeZone = "Central European Standard Time",
                    ContributingTradeHeaderIds = "1",
                    TradeType = "PW_TRADE",
                    TransactionType = "Buy",
                    Granularity = "15",
                    Entity = "Entity1",
                    Counterparty = "Counterparty1",
                    FromMarketOperator = "MarketOperator1",
                    ToMarketOperator = "MarketOperator2",
                    CapacityType = "Type1",
                    CapacityIdentification = "CapId1",
                    Interconnector = "Interconnector1",
                    QH1 = 50,
                    QH2 = 50,
                    QH3 = 50,
                    QH4 = 50,
                    QH5 = 50,
                    QH6 = 50,
                    QH7 = 50,
                    QH8 = 50,
                    QH9 = 0,
                    QH10 = 0,
                    QH11 = 0,
                    QH12 = 0,
                    QH13 = 0,
                    QH14 = 0,
                    QH15 = 0,
                    QH16 = 0,
                    QH17= 0,
                    QH18 = 0,
                    QH19 = 0,
                    QH20 = 0,
                    QH21 = 0,
                     QH89= 0,
                    QH90 = 0,
                    QH91 = 0,
                     QH92= 0,
                    QH93 = 0,
                    QH94 = 0,
                    QH95 = 0,
                    QH96 = 0
                }
            };

            // Act
            var result = TradeHelper.GetTradeDataBasedOnTimeZone(mockData, DateTime.Parse("2023-10-28"));

            // Assert
            Assert.Equal(expectedData.Count, result.Count());
            Assert.Equal(expectedData.First().NominationRunId, result.First().NominationRunId);
            Assert.Equal(expectedData.First().NominationDefinitionId, result.First().NominationDefinitionId);
            Assert.Equal(expectedData.First().NominationDefinitionName, result.First().NominationDefinitionName);
            Assert.Equal(expectedData.First().DeliveryDate, result.First().DeliveryDate);
            Assert.Equal(expectedData.First().AggPosReferenceId, result.First().AggPosReferenceId);
            Assert.Equal(expectedData.First().AggPosReferenceName, result.First().AggPosReferenceName);
            Assert.Equal(expectedData.First().TimeZone, result.First().TimeZone);
            Assert.Equal(expectedData.First().ContributingTradeHeaderIds, result.First().ContributingTradeHeaderIds);
            Assert.Equal(expectedData.First().TradeType, result.First().TradeType);
            Assert.Equal(expectedData.First().TransactionType, result.First().TransactionType);
            Assert.Equal(expectedData.First().Granularity, result.First().Granularity);
            Assert.Equal(expectedData.First().Entity, result.First().Entity);
            Assert.Equal(expectedData.First().Counterparty, result.First().Counterparty);
            Assert.Equal(expectedData.First().FromMarketOperator, result.First().FromMarketOperator);
            Assert.Equal(expectedData.First().ToMarketOperator, result.First().ToMarketOperator);
            Assert.Equal(expectedData.First().CapacityType, result.First().CapacityType);
            Assert.Equal(expectedData.First().CapacityIdentification, result.First().CapacityIdentification);
            Assert.Equal(expectedData.First().Interconnector, result.First().Interconnector);
            Assert.Equal(expectedData.First().QH1, result.First().QH1);
            Assert.Equal(expectedData.First().QH2, result.First().QH2);
            Assert.Equal(expectedData.First().QH3, result.First().QH3);
            Assert.Equal(expectedData.First().QH4, result.First().QH4);
            Assert.Equal(expectedData.First().QH5, result.First().QH5);
            Assert.Equal(expectedData.First().QH6, result.First().QH6);
            Assert.Equal(expectedData.First().QH7, result.First().QH7);
            Assert.Equal(expectedData.First().QH8, result.First().QH8);
            Assert.Equal(expectedData.First().QH9, result.First().QH9);
            Assert.Equal(expectedData.First().QH10, result.First().QH10);
            Assert.Equal(expectedData.First().QH11, result.First().QH11);
            Assert.Equal(expectedData.First().QH12, result.First().QH12);
            Assert.Equal(expectedData.First().QH13, result.First().QH13);
            Assert.Equal(expectedData.First().QH14, result.First().QH14);
            Assert.Equal(expectedData.First().QH15, result.First().QH15);
        }

        [Fact]
        public void GetQHIndexRange_ReturnsCorrectRange()
        {
            // Arrange
            var granularity = Granularity.QHR;
            var offset = 1.0;

            // Act
            var (startIndex, endIndex) = TradeHelper.GetQHIndexRange(granularity, offset);

            // Assert
            Assert.Equal(93, startIndex);
            Assert.Equal(96, endIndex);
        }

        [Fact]
        public void GetOffsetByTimeZone_ReturnsCorrectOffset()
        {
            // Arrange
            var timeZoneId = "Central European Standard Time";
            var dateTime = DateTime.Parse("2023-10-28");

            // Act
            var offset = TradeHelper.GetOffsetByTimeZone(timeZoneId, dateTime);

            // Assert
            Assert.Equal(TimeSpan.FromHours(2), offset);
        }

        [Fact]
        public void GetVolumeProperties_ReturnsCorrectProperties()
        {
            // Arrange
            var trade = new NominationDetailsDto
            {
                QH1 = 10,
                QH2 = 20,
                QH3 = 30
            };
            var periodCount = 3;

            // Act
            var result = TradeHelper.GetVolumeProperties(trade, periodCount);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(3, result.Length);
            Assert.Contains(result, p => p.Name == "QH1");
            Assert.Contains(result, p => p.Name == "QH2");
            Assert.Contains(result, p => p.Name == "QH3");
        }

        [Fact]
        public void GetVolumeArray_ReturnsCorrectArray()
        {
            // Arrange
            var trade = new NominationDetailsDto
            {
                QH1 = 10,
                QH2 = 20,
                QH3 = 30
            };
            var properties = TradeHelper.GetVolumeProperties(trade, 3);

            // Act
            var result = TradeHelper.GetVolumeArray(properties, trade);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(3, result.Count);
            Assert.Equal(10, result[0]);
            Assert.Equal(20, result[1]);
            Assert.Equal(30, result[2]);
        }

        [Fact]
        public void GetAligneBatchRequestModel_ReturnsCorrectModel()
        {
            // Arrange
            var deliveryDate = DateTime.Now;
            var marketOperator = "BE-ELI";
            var tradeTypes = "PW_TRADE";
            var nominationRunId = 1;

            // Act
            var result = TradeHelper.GetAligneBatchRequestModel(deliveryDate, marketOperator, tradeTypes, nominationRunId, true);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(deliveryDate.AddDays(-1), result.FromDate);
            Assert.Equal(deliveryDate, result.ToDate);
            Assert.Equal("PWTRAK4_DAGG_RUNP", result.BatchName);
            Assert.Equal("BE-ELI", result.MarketOperator);
            Assert.Equal(nominationRunId, result.NominationRunId);
        }

        [Fact]
        public void GetBatchName_ReturnsCorrectBatchName()
        {
            // Act & Assert
            Assert.Equal(BatchNames.PowerBatch, TradeHelper.GetAligneBatchName("PW_TRADE"));
            Assert.Equal(BatchNames.TransBatch, TradeHelper.GetAligneBatchName("PW_TRANS"));
            Assert.Equal(BatchNames.PowerTransBatch, TradeHelper.GetAligneBatchName("PW_TRADE,PW_TRANS"));
            Assert.Equal(BatchNames.PowerTransBatch, TradeHelper.GetAligneBatchName(string.Empty));
        }


        [Fact]
        public void CreateDTWithNominationData_ReturnsCorrectDataTable()
        {
            // Arrange
            var mockData = new List<NominationDetailsDto>
            {
                new NominationDetailsDto
                {
                    NominationRunId = 1,
                    NominationDefinitionId = 1,
                    NominationDefinitionName = "Test Nomination",
                    DeliveryDate = DateTime.Parse("2023-10-28"),
                    AggPosReferenceId = 1,
                    AggPosReferenceName = "AggPosRef1",
                    TimeZone = "Central European Standard Time",
                    ContributingTradeHeaderIds = "1",
                    TradeType = "PW_TRADE",
                    TransactionType = "Buy",
                    Granularity = "15",
                    Entity = "Entity1",
                    Counterparty = "Counterparty1",
                    FromMarketOperator = "MarketOperator1",
                    ToMarketOperator = "MarketOperator2",
                    CapacityType = "Type1",
                    CapacityIdentification = "CapId1",
                    Interconnector = "Interconnector1",
                    QH1 = 50,
                    QH2 = 50,
                    QH3 = 50,
                    QH4 = 50,
                    QH5 = 50,
                    QH6 = 50,
                    QH7 = 50,
                    QH8 = 50,
                    QH9 = 50,
                    QH10 = 50,
                    QH11 = 50,
                    QH12 = 50,
                    QH13 = 50,
                    QH14 = 50,
                    QH15 = 50
                }
            };

            // Act
            var result = TradeHelper.CreateDTWithNominationData(mockData);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.Rows.Count);
            Assert.Equal(Convert.ToDecimal(50), result.Rows[0]["QH1"]);
            Assert.Equal(Convert.ToDecimal(50), result.Rows[0]["QH2"]);
            Assert.Equal(Convert.ToDecimal(50), result.Rows[0]["QH3"]);
        }

        [Fact]
        public void GetAligneBatchRequestModel_ReturnsCorrectModel_WithAuto()
        {
            // Arrange
            var deliveryDate = DateTime.Now;
            var marketOperator = "BE-ELI";
            var tradeTypes = "PW_TRADE";
            var nominationRunId = 1;
            var isAuto = true;

            // Act
            var result = TradeHelper.GetAligneBatchRequestModel(deliveryDate, marketOperator, tradeTypes, nominationRunId, isAuto);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(deliveryDate.AddDays(-1), result.FromDate);
            Assert.Equal(deliveryDate, result.ToDate);
            Assert.Equal("PWTRAK4_DAGG_RUNP", result.BatchName);
            Assert.Equal("BE-ELI", result.MarketOperator);
            Assert.Equal(nominationRunId, result.NominationRunId);
            Assert.Equal(isAuto, result.IsAuto);
        }

        [Fact]
        public void GetAligneBatchRequestModel_ReturnsCorrectModel_WithoutAuto()
        {
            // Arrange
            var deliveryDate = DateTime.Now;
            var marketOperator = "BE-ELI";
            var tradeTypes = "PW_TRADE";
            var nominationRunId = 1;
            var isAuto = false;

            // Act
            var result = TradeHelper.GetAligneBatchRequestModel(deliveryDate, marketOperator, tradeTypes, nominationRunId, isAuto);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(deliveryDate.AddDays(-1), result.FromDate);
            Assert.Equal(deliveryDate, result.ToDate);
            Assert.Equal("PWTRAK4_DAGG_RUNP", result.BatchName);
            Assert.Equal("BE-ELI", result.MarketOperator);
            Assert.Equal(nominationRunId, result.NominationRunId);
            Assert.Equal(isAuto, result.IsAuto);
        }

        [Fact]
        public void GetAligneBatchRequestModel_ReturnsCorrectModel_WithNullAuto()
        {
            // Arrange
            var deliveryDate = DateTime.Now;
            var marketOperator = "BE-ELI";
            var tradeTypes = "PW_TRADE";
            var nominationRunId = 1;
            bool? isAuto = null;

            // Act
            var result = TradeHelper.GetAligneBatchRequestModel(deliveryDate, marketOperator, tradeTypes, nominationRunId, isAuto);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(deliveryDate.AddDays(-1), result.FromDate);
            Assert.Equal(deliveryDate, result.ToDate);
            Assert.Equal("PWTRAK4_DAGG_RUNP", result.BatchName);
            Assert.Equal("BE-ELI", result.MarketOperator);
            Assert.Equal(nominationRunId, result.NominationRunId);
            Assert.Equal(isAuto, result.IsAuto);
        }

        [Fact]
        public void GetAligneBatchRequestModel_PowerTrans_ReturnsCorrectModel()
        {
            // Arrange
            var deliveryDate = DateTime.Now; 
            var marketOperator = "BE-ELI";
            var tradeTypes = "PW_TRADE,PW_TRANS";
            var nominationRunId = 1;
            bool? isAuto = true;

            // Act
            var result = TradeHelper.GetAligneBatchRequestModel(deliveryDate, marketOperator, tradeTypes, nominationRunId, isAuto);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(deliveryDate.AddDays(-1), result.FromDate);
            Assert.Equal(deliveryDate, result.ToDate);
            Assert.Equal("PWTRAK4_DAGG_RUNPT", result.BatchName);
            Assert.Equal("BE-ELI", result.MarketOperator);
            Assert.Equal(nominationRunId, result.NominationRunId);
            Assert.Equal(isAuto, result.IsAuto);
        }

        [Fact]
        public void GetAligneBatchRequestModel_Trans_ReturnsCorrectModel()
        {
            // Arrange
            var deliveryDate = DateTime.Now; 
            var marketOperator = "BE-ELI";
            var tradeTypes = "PW_TRANS";
            var nominationRunId = 1;
            bool? isAuto = true;

            // Act
            var result = TradeHelper.GetAligneBatchRequestModel(deliveryDate, marketOperator, tradeTypes, nominationRunId, isAuto);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(deliveryDate.AddDays(-1), result.FromDate);
            Assert.Equal(deliveryDate, result.ToDate);
            Assert.Equal("PWTRAK4_DAGG_RUNT", result.BatchName);
            Assert.Equal("", result.MarketOperator);
            Assert.Equal(nominationRunId, result.NominationRunId);
            Assert.Equal(isAuto, result.IsAuto);
        }
    }
}
