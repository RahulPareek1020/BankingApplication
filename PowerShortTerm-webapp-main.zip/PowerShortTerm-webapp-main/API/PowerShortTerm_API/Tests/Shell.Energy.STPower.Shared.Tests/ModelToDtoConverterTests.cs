using Shell.Energy.STPower.Data.Models;

namespace Shell.Energy.STPower.Shared.Tests
{
    public class ModelToDtoConverterTests
    {
        [Fact]
        public void ConvertToNominationDetailsDto_NullInput_ThrowsArgumentNullException()
        {
            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => ModelToDtoConverter.ConvertToNominationDetailsDto(null));
        }

        [Fact]
        public void ConvertToNominationDetailsDto_ValidInput_ReturnsCorrectDto()
        {
            // Arrange
            var nominationDetails = new NominationDetails
            {
                NominationRunId = 1,
                NominationDefinitionId = 2,
                NominationDefinitionName = "Test",
                AggPosReferenceId = 3,
                AggPosReferenceName = "TestRef",
                TradeType = "Type",
                TransactionType = "TransType",
                FromMarketOperator = "FromOp",
                ToMarketOperator = "ToOp",
                CapacityType = "CapType",
                CapacityIdentification = "CapId",
                DeliveryDate = DateTime.Now,
                Granularity = "15",
                Entity = "Entity",
                ClientName = "Shell",
                Counterparty = "Counterparty",
                Interconnector = "Interconnector",
                TimeZone="Europe/London",
                NominationVolume = new NominationVolume
                {
                    QH1 = 1,
                    QH2 = 2,
                    QH3 = 3,
                    QH4 = 4,
                    QH5 = 5,
                    QH6 = 6,
                    QH7 = 7,
                    QH8 = 8,
                    QH9 = 9,
                    QH10 = 10,
                    QH11 = 11,
                    QH12 = 12,
                    QH13 = 13,
                    QH14 = 14,
                    QH15 = 15,
                    QH16 = 16,
                    QH17 = 17,
                    QH18 = 18,
                    QH19 = 19,
                    QH20 = 20,
                    QH21 = 21,
                    QH22 = 22,
                    QH23 = 23,
                    QH24 = 24,
                    QH25 = 25,
                    QH26 = 26,
                    QH27 = 27,
                    QH28 = 28,
                    QH29 = 29,
                    QH30 = 30,
                    QH31 = 31,
                    QH32 = 32,
                    QH33 = 33,
                    QH34 = 34,
                    QH35 = 35,
                    QH36 = 36,
                    QH37 = 37,
                    QH38 = 38,
                    QH39 = 39,
                    QH40 = 40,
                    QH41 = 41,
                    QH42 = 42,
                    QH43 = 43,
                    QH44 = 44,
                    QH45 = 45,
                    QH46 = 46,
                    QH47 = 47,
                    QH48 = 48,
                    QH49 = 49,
                    QH50 = 50,
                    QH51 = 51,
                    QH52 = 52,
                    QH53 = 53,
                    QH54 = 54,
                    QH55 = 55,
                    QH56 = 56,
                    QH57 = 57,
                    QH58 = 58,
                    QH59 = 59,
                    QH60 = 60,
                    QH61 = 61,
                    QH62 = 62,
                    QH63 = 63,
                    QH64 = 64,
                    QH65 = 65,
                    QH66 = 66,
                    QH67 = 67,
                    QH68 = 68,
                    QH69 = 69,
                    QH70 = 70,
                    QH71 = 71,
                    QH72 = 72,
                    QH73 = 73,
                    QH74 = 74,
                    QH75 = 75,
                    QH76 = 76,
                    QH77 = 77,
                    QH78 = 78,
                    QH79 = 79,
                    QH80 = 80,
                    QH81 = 81,
                    QH82 = 82,
                    QH83 = 83,
                    QH84 = 84,
                    QH85 = 85,
                    QH86 = 86,
                    QH87 = 87,
                    QH88 = 88,
                    QH89 = 89,
                    QH90 = 90,
                    QH91 = 91,
                    QH92 = 92,
                    QH93 = 93,
                    QH94 = 94,
                    QH95 = 95,
                    QH96 = 96
                }
            };

            // Act
            var result = ModelToDtoConverter.ConvertToNominationDetailsDto(nominationDetails);

            // Assert
            Assert.Equal(nominationDetails.NominationRunId, result.NominationRunId);
            Assert.Equal(nominationDetails.NominationDefinitionId, result.NominationDefinitionId);
            Assert.Equal(nominationDetails.NominationDefinitionName, result.NominationDefinitionName);
            Assert.Equal(nominationDetails.AggPosReferenceId, result.AggPosReferenceId);
            Assert.Equal(nominationDetails.AggPosReferenceName, result.AggPosReferenceName);
            Assert.Equal(nominationDetails.TradeType, result.TradeType);
            Assert.Equal(nominationDetails.TransactionType, result.TransactionType);
            Assert.Equal(nominationDetails.FromMarketOperator, result.FromMarketOperator);
            Assert.Equal(nominationDetails.ToMarketOperator, result.ToMarketOperator);
            Assert.Equal(nominationDetails.CapacityType, result.CapacityType);
            Assert.Equal(nominationDetails.CapacityIdentification, result.CapacityIdentification);
            Assert.Equal(nominationDetails.DeliveryDate, result.DeliveryDate);
            Assert.Equal(nominationDetails.Granularity, result.Granularity);
            Assert.Equal(nominationDetails.Entity, result.Entity);
            Assert.Equal(nominationDetails.ClientName, result.ClientName);
            Assert.Equal(nominationDetails.Counterparty, result.Counterparty);
            Assert.Equal(nominationDetails.Interconnector, result.Interconnector);
            Assert.Equal(nominationDetails.NominationVolume.QH1, result.QH1);
            Assert.Equal(nominationDetails.NominationVolume.QH2, result.QH2);
            // ... (continue for all QH properties)
            Assert.Equal(nominationDetails.NominationVolume.QH96, result.QH96);
        }

        [Fact]
        public void ConvertToRawTradeDto_NullInput_ThrowsArgumentNullException()
        {
            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => ModelToDtoConverter.ConvertToRawTradeDto(null));
        }

        [Fact]
        public void ConvertToRawTradeDto_ValidInput_ReturnsCorrectDto()
        {
            // Arrange
            var rawTrade = new RawTrade
            {
                RawTradeHeaderId = 1,
                NominationRunId = 2,
                AggPosReferenceId = 3,
                AggPosReference = "TestRef",
                TradeReference = "TradeRef",
                TradeType = "Type",
                TransactionType = "TransType",
                Entity = "Entity",
                Counterparty = "Counterparty",
                FromMarketoperator = "FromOp",
                ToMarketoperator = "ToOp",
                CapacityType = "CapType",
                CapacityIdentification = "CapId",
                Interconnector = "Interconnector",
                DeliveryDate = DateTime.Now,
                DelDateStart = DateTime.Now,
                DelDateEnd = DateTime.Now,
                Cdy1Attr1 = "Attr1",
                PwrNomsOverrideType = "OverrideType",
                PwrNomsOverrideInput = "OverrideInput",
                PwrNomsOverrideFreeform = "OverrideFreeform",
                AuxSoCpty = "AuxCpty",
                CptyNoms = "CptyNoms",
                PeakWorkaround = "Workaround",
                InsNumRec = 1,
                RawTradeVolume = new NominationVolume
                {
                    QH1 = 1,
                    QH2 = 2,
                    QH3 = 3,
                    QH4 = 4,
                    QH5 = 5,
                    QH6 = 6,
                    QH7 = 7,
                    QH8 = 8,
                    QH9 = 9,
                    QH10 = 10,
                    QH11 = 11,
                    QH12 = 12,
                    QH13 = 13,
                    QH14 = 14,
                    QH15 = 15,
                    QH16 = 16,
                    QH17 = 17,
                    QH18 = 18,
                    QH19 = 19,
                    QH20 = 20,
                    QH21 = 21,
                    QH22 = 22,
                    QH23 = 23,
                    QH24 = 24,
                    QH25 = 25,
                    QH26 = 26,
                    QH27 = 27,
                    QH28 = 28,
                    QH29 = 29,
                    QH30 = 30,
                    QH31 = 31,
                    QH32 = 32,
                    QH33 = 33,
                    QH34 = 34,
                    QH35 = 35,
                    QH36 = 36,
                    QH37 = 37,
                    QH38 = 38,
                    QH39 = 39,
                    QH40 = 40,
                    QH41 = 41,
                    QH42 = 42,
                    QH43 = 43,
                    QH44 = 44,
                    QH45 = 45,
                    QH46 = 46,
                    QH47 = 47,
                    QH48 = 48,
                    QH49 = 49,
                    QH50 = 50,
                    QH51 = 51,
                    QH52 = 52,
                    QH53 = 53,
                    QH54 = 54,
                    QH55 = 55,
                    QH56 = 56,
                    QH57 = 57,
                    QH58 = 58,
                    QH59 = 59,
                    QH60 = 60,
                    QH61 = 61,
                    QH62 = 62,
                    QH63 = 63,
                    QH64 = 64,
                    QH65 = 65,
                    QH66 = 66,
                    QH67 = 67,
                    QH68 = 68,
                    QH69 = 69,
                    QH70 = 70,
                    QH71 = 71,
                    QH72 = 72,
                    QH73 = 73,
                    QH74 = 74,
                    QH75 = 75,
                    QH76 = 76,
                    QH77 = 77,
                    QH78 = 78,
                    QH79 = 79,
                    QH80 = 80,
                    QH81 = 81,
                    QH82 = 82,
                    QH83 = 83,
                    QH84 = 84,
                    QH85 = 85,
                    QH86 = 86,
                    QH87 = 87,
                    QH88 = 88,
                    QH89 = 89,
                    QH90 = 90,
                    QH91 = 91,
                    QH92 = 92,
                    QH93 = 93,
                    QH94 = 94,
                    QH95 = 95,
                    QH96 = 96
                }
            };

            // Act
            var result = ModelToDtoConverter.ConvertToRawTradeDto(rawTrade);

            // Assert
            Assert.Equal(rawTrade.RawTradeHeaderId, result.RawTradeHeaderId);
            Assert.Equal(rawTrade.NominationRunId, result.NominationRunId);
            Assert.Equal(rawTrade.AggPosReferenceId, result.AggPosReferenceId);
            Assert.Equal(rawTrade.AggPosReference, result.AggPosReference);
            Assert.Equal(rawTrade.TradeReference, result.TradeReference);
            Assert.Equal(rawTrade.TradeType, result.TradeType);
            Assert.Equal(rawTrade.TransactionType, result.TransactionType);
            Assert.Equal(rawTrade.Entity, result.Entity);
            Assert.Equal(rawTrade.Counterparty, result.Counterparty);
            Assert.Equal(rawTrade.FromMarketoperator, result.FromMarketoperator);
            Assert.Equal(rawTrade.ToMarketoperator, result.ToMarketoperator);
            Assert.Equal(rawTrade.CapacityType, result.CapacityType);
            Assert.Equal(rawTrade.CapacityIdentification, result.CapacityIdentification);
            Assert.Equal(rawTrade.Interconnector, result.Interconnector);
            Assert.Equal(rawTrade.DeliveryDate, result.DeliveryDate);
            Assert.Equal(rawTrade.DelDateStart, result.DelDateStart);
            Assert.Equal(rawTrade.DelDateEnd, result.DelDateEnd);
            Assert.Equal(rawTrade.Cdy1Attr1, result.Cdy1Attr1);
            Assert.Equal(rawTrade.PwrNomsOverrideType, result.PwrNomsOverrideType);
            Assert.Equal(rawTrade.PwrNomsOverrideInput, result.PwrNomsOverrideInput);
            Assert.Equal(rawTrade.PwrNomsOverrideFreeform, result.PwrNomsOverrideFreeform);
            Assert.Equal(rawTrade.AuxSoCpty, result.AuxSoCpty);
            Assert.Equal(rawTrade.CptyNoms, result.CptyNoms);
            Assert.Equal(rawTrade.PeakWorkaround, result.PeakWorkaround);
            Assert.Equal(rawTrade.InsNumRec, result.InsNumRec);
            for (int i = 1; i <= 96; i++)
            {
                string propertyName = $"QH{i}";
                Assert.Equal(
                    rawTrade.RawTradeVolume.GetType().GetProperty(propertyName).GetValue(rawTrade.RawTradeVolume),
                    result.GetType().GetProperty(propertyName).GetValue(result)
                );
            }
        }
    }
}
