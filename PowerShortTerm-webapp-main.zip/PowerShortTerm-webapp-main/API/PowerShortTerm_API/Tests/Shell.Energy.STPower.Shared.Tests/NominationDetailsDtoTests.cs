using Shell.Energy.STPower.Data.Dto;

namespace Shell.Energy.STPower.Data.Tests.Dto
{
    public class NominationDetailsDtoTests
    {
        [Fact]
        public void NominationDetailsDto_DefaultValues()
        {
            // Arrange
            var dto = new NominationDetailsDto();

            // Assert
            Assert.Equal(0, dto.NominationRunId);
            Assert.Equal(0, dto.NominationDefinitionId);
            Assert.Null(dto.NominationDefinitionName);
            Assert.Equal(default(DateTime), dto.DeliveryDate);
            Assert.Equal(0, dto.AggPosReferenceId);
            Assert.Null(dto.AggPosReferenceName);
            Assert.Null(dto.TradeType);
            Assert.Null(dto.TransactionType);
            Assert.Null(dto.Granularity);
            Assert.Null(dto.Entity);
            Assert.Null(dto.ClientName);
            Assert.Null(dto.TimeZone);
            Assert.Null(dto.Counterparty);
            Assert.Null(dto.FromMarketOperator);
            Assert.Null(dto.ToMarketOperator);
            Assert.Null(dto.CapacityType);
            Assert.Null(dto.CapacityIdentification);
            Assert.Null(dto.Interconnector);
            for (int i = 1; i <= 96; i++)
            {
                Assert.Null((decimal?)dto.GetType().GetProperty($"QH{i}").GetValue(dto));
            }
        }

        [Fact]
        public void NominationDetailsDto_SetAndGetProperties()
        {
            // Arrange
            var dto = new NominationDetailsDto
            {
                NominationRunId = 1,
                NominationDefinitionId = 2,
                NominationDefinitionName = "TestName",
                DeliveryDate = new DateTime(2023, 1, 1),
                AggPosReferenceId = 3,
                AggPosReferenceName = "TestReference",
                TradeType = "TestTrade",
                TransactionType = "TestTransaction",
                Granularity = "TestGranularity",
                Entity = "TestEntity",
                ClientName = "Shell",
                TimeZone="CET",
                Counterparty = "TestCounterparty",
                FromMarketOperator = "TestFromOperator",
                ToMarketOperator = "TestToOperator",
                CapacityType = "TestCapacityType",
                CapacityIdentification = "TestCapacityId",
                Interconnector = "TestInterconnector"
            };

            for (int i = 1; i <= 96; i++)
            {
                dto?.GetType()?.GetProperty($"QH{i}")?.SetValue(dto, (double?)i);
            }

            // Assert
            Assert.Equal(1, dto.NominationRunId);
            Assert.Equal(2, dto.NominationDefinitionId);
            Assert.Equal("TestName", dto.NominationDefinitionName);
            Assert.Equal(new DateTime(2023, 1, 1), dto.DeliveryDate);
            Assert.Equal(3, dto.AggPosReferenceId);
            Assert.Equal("TestReference", dto.AggPosReferenceName);
            Assert.Equal("TestTrade", dto.TradeType);
            Assert.Equal("TestTransaction", dto.TransactionType);
            Assert.Equal("TestGranularity", dto.Granularity);
            Assert.Equal("TestEntity", dto.Entity);
            Assert.Equal("Shell", dto.ClientName);
            Assert.Equal("TestCounterparty", dto.Counterparty);
            Assert.Equal("TestFromOperator", dto.FromMarketOperator);
            Assert.Equal("TestToOperator", dto.ToMarketOperator);
            Assert.Equal("TestCapacityType", dto.CapacityType);
            Assert.Equal("TestCapacityId", dto.CapacityIdentification);
            Assert.Equal("TestInterconnector", dto.Interconnector);
            Assert.Equal("CET", dto.TimeZone);
            for (int i = 1; i <= 96; i++)
            {
                Assert.Equal(i, (double?)dto?.GetType()?.GetProperty($"QH{i}")?.GetValue(dto));
            }
        }
    }
}
