using Microsoft.Data.SqlClient;
using Moq;
using Shell.Energy.STPower.Data.Constants;
using Shell.Energy.STPower.Data.Dto;
using Shell.Energy.STPower.Data.Repository;
using Shell.Energy.STPower.Shared.PowerTrak;
using System.Data;
using System.Xml.Linq;

namespace Shell.Energy.STPower.Shared.Tests;

public class PowertrakTradeServiceTests
{
    private readonly Mock<ISqlDataRepository> _mockSqlDataRepository;
    private readonly Mock<IAppLogger> _mockLogger;
    private readonly PowertrakTradeService _service;
    private readonly Mock<IPowerTrakSender> _powertrakTradeSender;

    public PowertrakTradeServiceTests()
    {
        _mockSqlDataRepository = new Mock<ISqlDataRepository>();
        _mockLogger = new Mock<IAppLogger>();
        _powertrakTradeSender = new Mock<IPowerTrakSender>();
        _service = new PowertrakTradeService(_mockSqlDataRepository.Object, _powertrakTradeSender.Object, _mockLogger.Object);
    }

    [Fact]
    public async Task GetNominationHeaderData_ReturnsData_WhenReaderIsNotNull()
    {
        // Arrange
        var mockDataReader = new Mock<IDataReader>();
        mockDataReader.SetupSequence(r => r.Read())
            .Returns(true)
            .Returns(false);
        mockDataReader.Setup(r => r["NominationDefinitionName"]).Returns("Test Nomination");
        mockDataReader.Setup(r => r.GetDateTime(It.IsAny<int>())).Returns(DateTime.Now);
        mockDataReader.Setup(r => r["ProcessStepName"]).Returns("Powertrak");
        mockDataReader.Setup(r => r["ProcessStepStatus"]).Returns("Test Status");
        mockDataReader.Setup(r => r["Reason"]).Returns("Test Reason");
        mockDataReader.Setup(r => r.GetDateTime(It.IsAny<int>())).Returns(DateTime.Now);

        _mockSqlDataRepository.Setup(repo => repo.ExecuteReaderAsync(ServiceConstants.GetNomHeaderSPName, null, false, false))
            .ReturnsAsync(mockDataReader.Object);

        // Act
        var result = await _service.GetNominationHeaderData();

        // Assert
        Assert.NotNull(result);
        Assert.Single(result);
        var nominationHeader = Assert.Single(result);
        Assert.Equal("Test Nomination", nominationHeader.NominationDefinitionName);
        Assert.Equal("Powertrak", nominationHeader.ProcessStepName);
        Assert.Equal("Test Status", nominationHeader.ProcessStepStatus);
        Assert.Equal("Test Reason", nominationHeader.Reason);
    }

    [Fact]
    public async Task GetNominationHeaderData_ReturnsEmptyList_WhenReaderIsNull()
    {
        // Arrange
        _mockSqlDataRepository.Setup(repo => repo.ExecuteReaderAsync(ServiceConstants.GetNomHeaderSPName, null, false, false))
            .ReturnsAsync((IDataReader?)null);

        // Act
        var result = await _service.GetNominationHeaderData();

        // Assert
        Assert.NotNull(result);
        Assert.Empty(result);
    }

    [Fact]
    public async Task GetNominationHeaderData_LogsError_WhenExceptionIsThrown()
    {
        // Arrange
        var mockDataReader = new Mock<IDataReader>();
        mockDataReader.Setup(r => r.Read()).Throws(new Exception("Test Exception"));

        _mockSqlDataRepository.Setup(repo => repo.ExecuteReaderAsync(ServiceConstants.GetNomHeaderSPName, null, false, false))
            .ReturnsAsync(mockDataReader.Object);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<Exception>(() => _service.GetNominationHeaderData());
        Assert.Equal("Test Exception", exception.Message);
        _mockLogger.Verify(logger => logger.LogError(It.Is<string>(s => s.Contains("An error occurred while reading data"))), Times.Once);
    }

    [Fact]
    public async Task GetNominationDetailsByRunIdAsync_ReturnsEmptyList_WhenReaderIsNull()
    {
        // Arrange
        _mockSqlDataRepository.Setup(repo => repo.ExecuteReaderAsync(ServiceConstants.GetNomDetailsByRunIdSPName, It.IsAny<SqlParameter[]>(), false, false))
             .ReturnsAsync((IDataReader?)null);

        // Act
        var result = await _service.GetNominationDetailsByRunIdAsync(1);

        // Assert
        Assert.NotNull(result);
        Assert.Empty(result);
    }

    [Fact]
    public async Task GetTradeNominationDetailsByRunIdAsync_ReturnsEmptyList_WhenReaderIsNull()
    {
        // Arrange
        _mockSqlDataRepository.Setup(repo => repo.ExecuteReaderAsync(ServiceConstants.GetNomTradeDetailsByAggPosOrRunIdSPName, It.IsAny<SqlParameter[]>(), false, false))
             .ReturnsAsync((IDataReader?)null);

        // Act
        var result = await _service.GetRawTradesByAggPosOrRunIdAsync(1, null);

        // Assert
        Assert.NotNull(result);
        Assert.Empty(result);
    }

    [Fact]
    public async Task GetMappingRuleDetails_ReturnsData_WhenReaderIsNotNull()
    {
        // Arrange
        var mockDataReader = new Mock<IDataReader>();
        mockDataReader.SetupSequence(r => r.Read())
            .Returns(true)
            .Returns(false);
        mockDataReader.Setup(r => r["NominationDefinitionName"]).Returns("Test Nomination");
        mockDataReader.Setup(r => r["MappingMasterName"]).Returns("Master Rule");
        mockDataReader.Setup(r => r["MappingTypeName"]).Returns("Type Rule");
        mockDataReader.Setup(r => r["MappingInputField"]).Returns("Input field");
        mockDataReader.Setup(r => r["MappingOutputValue"]).Returns("Output value");

        _mockSqlDataRepository.Setup(repo => repo.ExecuteReaderAsync(ServiceConstants.GetMappingRuleDetailsSPName, null, false, false))
            .ReturnsAsync(mockDataReader.Object);

        // Act
        var result = await _service.GetMappingRuleDetails();

        // Assert
        Assert.NotNull(result);
        Assert.Single(result);
        var mappingRuleDetails = Assert.Single(result);
        Assert.Equal("Test Nomination", mappingRuleDetails.NominationDefinitionName);
        Assert.Equal("Master Rule", mappingRuleDetails.MappingMasterName);
        Assert.Equal("Type Rule", mappingRuleDetails.MappingTypeName);
        Assert.Equal("Input field", mappingRuleDetails.MappingInputField);
        Assert.Equal("Output value", mappingRuleDetails.MappingOutputValue);
    }

    [Fact]
    public async Task GetMappingRuleDetails_ReturnsEmptyList_WhenReaderIsNull()
    {
        // Arrange
        _mockSqlDataRepository.Setup(repo => repo.ExecuteReaderAsync(ServiceConstants.GetMappingRuleDetailsSPName, null, false, false))
            .ReturnsAsync((IDataReader?)null);

        // Act
        var result = await _service.GetMappingRuleDetails();

        // Assert
        Assert.NotNull(result);
        Assert.Empty(result);
    }

    [Fact]
    public async Task GetMappingRuleDetails_LogsError_WhenExceptionIsThrown()
    {
        // Arrange
        var mockDataReader = new Mock<IDataReader>();
        mockDataReader.Setup(r => r.Read()).Throws(new Exception("Test Exception"));

        _mockSqlDataRepository.Setup(repo => repo.ExecuteReaderAsync(ServiceConstants.GetMappingRuleDetailsSPName, null, false, false))
            .ReturnsAsync(mockDataReader.Object);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<Exception>(() => _service.GetMappingRuleDetails());
        Assert.Equal("Test Exception", exception.Message);
        _mockLogger.Verify(logger => logger.LogError(It.Is<string>(s => s.Contains("An error occurred while reading data"))), Times.Once);
    }

    [Fact]
    public async Task GetAggregatedCptyPositionsWithFilters_ReturnsEmptyList_WhenReaderIsNull()
    {
        // Arrange
        _mockSqlDataRepository.Setup(repo => repo.ExecuteReaderAsync(ServiceConstants.GetCounterpartyAggregationsSPName, It.IsAny<SqlParameter[]>(), false, false))
            .ReturnsAsync((IDataReader?)null);

        // Act
        var result = await _service.GetAggregatedCptyPositionsWithFilters(1, DateTime.Now);

        // Assert
        Assert.NotNull(result);
        Assert.Empty(result);
    }

    [Fact]
    public async Task SaveNominationDataInDB_ReturnsNull_WhenReaderIsNull()
    {
        // Arrange
        _mockSqlDataRepository.Setup(repo => repo.ExecuteReaderAsync(ServiceConstants.SaveNominationDataSPName, It.IsAny<SqlParameter[]>(), false, false))
            .ReturnsAsync((IDataReader?)null);

        // Act
        var result = await _service.SaveNominationDataWithOffsetInDB(new List<NominationDetailsDto>());

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public async Task UpdateNominationBatchRunStatusAsync_CallsExecuteNonQueryAsync_WithCorrectParameters()
    {
        // Arrange
        var nominationRunId = 1;
        var stepId = 2;
        var status = "Completed";
        var startDateTime = DateTime.Now;
        var endDateTime = DateTime.Now.AddHours(1);

        _mockSqlDataRepository.Setup(repo => repo.ExecuteReaderAsync(ServiceConstants.UpdateNominationBatchRunStatusSPName, It.IsAny<SqlParameter[]>(), true, false));

        // Act
        await _service.UpdateNominationBatchRunStatusAsync(nominationRunId, stepId, status, "", startDateTime, endDateTime);

        // Assert
        _mockSqlDataRepository.Verify(repo => repo.ExecuteReaderAsync(ServiceConstants.UpdateNominationBatchRunStatusSPName, It.Is<SqlParameter[]>(parameters =>
            (int)parameters[0].Value == nominationRunId &&
            (int)parameters[1].Value == stepId &&
            (string)parameters[2].Value == status &&
             (string)parameters[3].Value == "" &&
            (DateTime?)parameters[4].Value == startDateTime &&
            (DateTime?)parameters[5].Value == endDateTime
        ), true, false), Times.Once);
    }

    [Fact]
    public async Task UpdateNominationBatchRunResponseAsync_CallsExecuteNonQueryAsync_WithCorrectParameters()
    {
        // Arrange
        var nominationRunId = 1;
        var correlationId = "2f6f4884-6666-44b2-a66a-7517de3745e8";

        _mockSqlDataRepository.Setup(repo => repo.ExecuteReaderAsync(ServiceConstants.UpdateNominationBatchRunResponseSPName, It.IsAny<SqlParameter[]>(), true, false));

        // Act
        await _service.UpdateNominationBatchRunResponse(XElement.Parse(Resources.SampleXmlResponseXML), nominationRunId);

        // Assert
        _mockSqlDataRepository.Verify(repo => repo.ExecuteReaderAsync(ServiceConstants.UpdateNominationBatchRunResponseSPName, It.Is<SqlParameter[]>(parameters =>
            (int)parameters[0].Value == nominationRunId &&
            (string)parameters[1].Value == correlationId
        ), true, false), Times.Once);
    }

    [Fact]
    public async Task UpdateNominationBatchRunResponseAsync_CallsExecuteNonQueryAsync_WithErrors()
    {
        // Arrange
        var nominationRunId = 1;
        var errorList = "Error Message";

        _mockSqlDataRepository.Setup(repo => repo.ExecuteReaderAsync(ServiceConstants.UpdateNominationBatchRunResponseSPName, It.IsAny<SqlParameter[]>(), true, false));

        // Act
        await _service.UpdateNominationBatchRunResponse(XElement.Parse(Resources.SampleXmlResponseWithError), nominationRunId);

        // Assert
        _mockSqlDataRepository.Verify(repo => repo.ExecuteReaderAsync(ServiceConstants.UpdateNominationBatchRunResponseSPName, It.Is<SqlParameter[]>(parameters =>
            (int)parameters[0].Value == nominationRunId &&
            (string)parameters[1].Value == errorList
        ), true, false), Times.Once);
    }

}
