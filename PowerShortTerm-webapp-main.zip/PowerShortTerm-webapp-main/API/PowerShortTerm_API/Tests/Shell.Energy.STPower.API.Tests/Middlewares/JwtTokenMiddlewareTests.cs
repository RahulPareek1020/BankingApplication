﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using Newtonsoft.Json.Linq;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Middlewares;

namespace Shell.Energy.STPower.API.Tests.Middlewares
{
    public class JwtTokenMiddlewareTests
    {
        private readonly Mock<RequestDelegate> _nextMock;
        private readonly Mock<IConfiguration> _configurationMock;
        private readonly JwtTokenMiddleware _middleware;
        private readonly Mock<IAppLogger> _loggerMock;
        private readonly Mock<IServiceProvider> _serviceProviderMock;
        private readonly Mock<IServiceScope> _serviceScopeMock;
        private readonly Mock<IServiceScopeFactory> _serviceScopeFactoryMock;
        public static readonly List<string> OtherRoles = ["OtherRole"];
        public static readonly List<string> SNEUserRoles = ["SNE_USER", "SNE_USER_DEV"];

        public JwtTokenMiddlewareTests()
        {
            _serviceScopeFactoryMock = new Mock<IServiceScopeFactory>();
            _serviceScopeMock = new Mock<IServiceScope>();
            _serviceProviderMock = new Mock<IServiceProvider>();
            _loggerMock = new Mock<IAppLogger>();
            _configurationMock = new Mock<IConfiguration>();
            _nextMock = new Mock<RequestDelegate>();

            _serviceProviderMock.Setup(p => p.GetService(typeof(IAppLogger))).Returns(_loggerMock.Object);
            _serviceScopeMock.Setup(s => s.ServiceProvider).Returns(_serviceProviderMock.Object);
            _serviceScopeFactoryMock.Setup(f => f.CreateScope()).Returns(_serviceScopeMock.Object);

            _configurationMock.Setup(c => c.GetSection("STPowerEnv").Value).Returns("DEV");

            _middleware = new JwtTokenMiddleware(_nextMock.Object, _configurationMock.Object, _serviceScopeFactoryMock.Object);
        }

        [Fact]
        public async Task InvokeAsync_InvalidToken_ReturnsUnauthorized()
        {
            var context = new DefaultHttpContext();
            context.Request.Headers.Authorization = "Bearer invalid_token";

            await _middleware.InvokeAsync(context);

            Assert.Equal(StatusCodes.Status401Unauthorized, context.Response.StatusCode);
        }

        [Fact]
        public async Task InvokeAsync_ValidTokenWithM2MRole_SetsPrincipal()
        {
            var token = CreateJwtToken("SNE_M2M_DEV");
            var context = new DefaultHttpContext();
            context.Request.Headers.Authorization = $"Bearer {token}";

            _configurationMock.Setup(c => c.GetSection("Jwt:Issuer").Value).Returns("issuer");

            await _middleware.InvokeAsync(context);

            Assert.Equal("M2M", context.User.FindFirst(ClaimTypes.Role)?.Value);
        }

        [Fact]
        public async Task InvokeAsync_ValidTokenWithUserRole_SetsPrincipal()
        {
            var token = CreateJwtToken("SNE_DEV", SNEUserRoles);
            var context = new DefaultHttpContext();
            context.Request.Headers.Authorization = $"Bearer {token}";

            _configurationMock.Setup(c => c.GetSection("Jwt:Issuer").Value).Returns("issuer");

            await _middleware.InvokeAsync(context);

            Assert.Equal("SNE_USER_DEV", context.User.FindFirst(ClaimTypes.Role)?.Value);
        }

        [Fact]
        public async Task InvokeAsync_ValidTokenWithNoMatchingRole_ReturnsUnauthorized()
        {
            var token = CreateJwtToken("SNE_123", OtherRoles);
            var context = new DefaultHttpContext();
            context.Request.Headers.Authorization = $"Bearer {token}";

            _configurationMock.Setup(c => c.GetSection("Jwt:Issuer").Value).Returns("issuer");

            await _middleware.InvokeAsync(context);

            Assert.Equal(StatusCodes.Status401Unauthorized, context.Response.StatusCode);
        }

        [Fact]
        public async Task InvokeAsync_ExpiredToken_ReturnsUnauthorized()
        {
            var token = CreateExpiredJwtToken("SNE_123", OtherRoles);
            var context = new DefaultHttpContext();
            context.Request.Headers.Authorization = $"Bearer {token}";

            _configurationMock.Setup(c => c.GetSection("Jwt:Issuer").Value).Returns("issuer");

            await _middleware.InvokeAsync(context);

            Assert.Equal(StatusCodes.Status401Unauthorized, context.Response.StatusCode);
        }

        private static string CreateJwtToken(string azpClaim, List<string>? roles = null)
        {
            var claims = new List<Claim>
            {
                new Claim("azp", azpClaim),
                new Claim(JwtRegisteredClaimNames.Iss, "issuer")
            };

            if (roles != null)
            {
                var realmAccess = new JObject
                {
                    ["roles"] = new JArray(roles)
                };
                claims.Add(new Claim("realm_access", realmAccess.ToString()));
            }

            var expirationTime = DateTime.UtcNow.AddHours(1);

            var token = new JwtSecurityToken(
                claims: claims,
                expires: expirationTime
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private static string CreateExpiredJwtToken(string azpClaim, List<string>? roles = null)
        {
            var claims = new List<Claim>
            {
                new Claim("azp", azpClaim),
                new Claim(JwtRegisteredClaimNames.Iss, "issuer")
            };

            if (roles != null)
            {
                var realmAccess = new JObject
                {
                    ["roles"] = new JArray(roles)
                };
                claims.Add(new Claim("realm_access", realmAccess.ToString()));
            }

            var expirationTime = DateTime.UtcNow.AddHours(-1);

            var token = new JwtSecurityToken(
                claims: claims,
                expires: expirationTime
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}