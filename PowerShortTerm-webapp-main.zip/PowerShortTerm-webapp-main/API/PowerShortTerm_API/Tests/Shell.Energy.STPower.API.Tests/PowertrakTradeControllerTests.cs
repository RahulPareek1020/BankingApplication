using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.OpenApi.Any;
using Moq;
using PowerShortTerm_API.Controllers;
using Shell.Energy.STPower.Data.Dto;
using Shell.Energy.STPower.Data.Models;
using Shell.Energy.STPower.Services.TradeTransformer.Interfaces;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Messages;
using Shell.Energy.STPower.Shared.Model;
using Shell.Energy.STPower.Shared.PowerTrak;
using Shell.SNE.Common.OpenTelemetry;
using System.Xml.Linq;

namespace Shell.Energy.STPower.API.Tests
{
    public class PowertrakTradeControllerTests
    {
        private readonly Mock<IAppLogger> _mockLogger;
        private readonly Mock<IPowertrakTradeService> _mockPowertrakTradeService;
        private readonly Mock<ITransformTradeDataService> _mockTradeTransformerService;
        private readonly Mock<HttpClient> _mockHttpClient;
        private readonly Mock<IConfiguration> _mockConfiguration;
        private readonly Mock<IDateTimeProvider> _mockTimeProvider;
        private readonly Mock<ITelemetryActivity> _mockTelemetryActivity;

        private readonly PowertrakTradeController _controller;
        private readonly DefaultHttpContext mockHttpContext;
        private readonly AuthorizationHeaderModel _authorizationHeaderModel;
        private readonly string _authorizationHeaderValue;

        public PowertrakTradeControllerTests()
        {
            _mockLogger = new Mock<IAppLogger>();
            _mockPowertrakTradeService = new Mock<IPowertrakTradeService>();
            _mockTradeTransformerService = new Mock<ITransformTradeDataService>();
            _mockHttpClient = new Mock<HttpClient>();
            _mockConfiguration = new Mock<IConfiguration>();
            _mockTimeProvider = new Mock<IDateTimeProvider>();
            _mockTelemetryActivity = new Mock<ITelemetryActivity>();
            _authorizationHeaderValue = "Bearer sample-token";

            var mockSectionUAT = new Mock<IConfigurationSection>();
            var mockSectionPROD = new Mock<IConfigurationSection>();

            mockSectionUAT.Setup(x => x.Key).Returns("PowerTrakConfiguration-UAT");
            mockSectionUAT.Setup(x => x["BaseUrl"]).Returns("https://example.com/uat");
            mockSectionUAT.Setup(x => x["AuthenticationUrlPath"]).Returns("/auth/uat");
            mockSectionUAT.Setup(x => x["Role"]).Returns("/uat/Admin");
            mockSectionUAT.Setup(x => x["Password"]).Returns("passwordUAT");
            mockSectionUAT.Setup(x => x["StatusReportUrlPath"]).Returns("/status/report/uat");
            mockSectionUAT.Setup(x => x["SubmitPowerTradesUrlPath"]).Returns("/submit/uat");
            mockSectionUAT.Setup(x => x["Username"]).Returns("userUAT");

            mockSectionPROD.Setup(x => x.Key).Returns("PowerTrakConfiguration-PROD");
            mockSectionPROD.Setup(x => x["BaseUrl"]).Returns("https://example.com/prod");
            mockSectionPROD.Setup(x => x["AuthenticationUrlPath"]).Returns("/auth/prod");
            mockSectionPROD.Setup(x => x["Role"]).Returns("/prod/Admin");
            mockSectionPROD.Setup(x => x["Password"]).Returns("passwordProd");
            mockSectionPROD.Setup(x => x["StatusReportUrlPath"]).Returns("/status/report/prod");
            mockSectionPROD.Setup(x => x["SubmitPowerTradesUrlPath"]).Returns("/submit/prod");
            mockSectionPROD.Setup(x => x["Username"]).Returns("userProd");

            var sections = new List<IConfigurationSection> { mockSectionUAT.Object, mockSectionPROD.Object };
            _mockConfiguration.Setup(x => x.GetChildren()).Returns(sections);

            _mockPowertrakTradeService.Setup(service => service.GetPowerTrakEnv(It.IsAny<int>()))
               .ReturnsAsync("UAT");

            _authorizationHeaderModel = new AuthorizationHeaderModel
            {
                Authorization = "Bearer your_token_here"
            };

            mockHttpContext = new DefaultHttpContext();
            mockHttpContext.Request.Headers.Authorization = _authorizationHeaderValue;
            _controller = new PowertrakTradeController(_mockLogger.Object, _mockPowertrakTradeService.Object, _mockTradeTransformerService.Object, 
                _mockConfiguration.Object, _mockHttpClient.Object, _mockTimeProvider.Object,_mockTelemetryActivity.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = mockHttpContext
                }
            };
        }

        [Fact]
        public async Task GetNominationHeaders_ReturnsData_WhenServiceReturnsData()
        {
            // Arrange
            var mockData = new List<NominationHeader>
            {
                new NominationHeader { NominationDefinitionId = 1,NominationDefinitionName = "Test Nomination", ProcessStepName="Powertrak",ProcessStepStatus = "Test Status", Reason = "Test Reason",
                }
            };
            _mockPowertrakTradeService.Setup(service => service.GetNominationHeaderData())
                .ReturnsAsync(mockData);

            // Act
            var result = await _controller.GetNominationHeaders();

            // Assert
            Assert.IsType<OkObjectResult>(result.Result);
            var objectResult = result.Result as OkObjectResult;
            Assert.NotNull(objectResult);
            Assert.IsAssignableFrom<IEnumerable<NominationHeader>>(objectResult.Value);
        }

        [Fact]
        public async Task GetNominationHeaders_LogsInformation_WhenCalled()
        {
            // Arrange
            _mockPowertrakTradeService.Setup(service => service.GetNominationHeaderData())
                .ReturnsAsync(new List<NominationHeader>());

            // Act
            await _controller.GetNominationHeaders();

            // Assert
            _mockLogger.Verify(logger => logger.LogInformation("Started fetching nomination headers."), Times.Once);
            _mockLogger.Verify(logger => logger.LogInformation("Successfully fetched nomination headers."), Times.Once);
        }

        [Fact]
        public async Task GetNominationHeaders_ThrowsException_WhenServiceFails()
        {
            // Arrange
            var exceptionMessage = "Test Exception";
            _mockPowertrakTradeService.Setup(service => service.GetNominationHeaderData())
                .ThrowsAsync(new Exception(exceptionMessage));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<Exception>(() => _controller.GetNominationHeaders());
            Assert.Equal(exceptionMessage, exception.Message);
        }

        [Fact]
        public async Task GetNominationDetails_ReturnsData_WhenServiceReturnsData()
        {
            // Arrange
            var mockData = new List<NominationDetails>
            {
                new NominationDetails { NominationRunId = 1, NominationDefinitionId = 1, NominationDefinitionName = "Elia", DeliveryDate = DateTime.Parse("2025-08-14T00:00:00"), AggPosReferenceId = 5, AggPosReferenceName = "Buy_SEEL_TESSENDERLO GROUP NV_Elia_2024-08-14",
                    TradeType = "PW_TRADE", TransactionType = "Buy", Granularity = "15", Entity = "SEEL", Counterparty = "TESSENDERLO GROUP NV", FromMarketOperator = "Elia", ToMarketOperator = "Elia",
                    CapacityType = null, CapacityIdentification = null, Interconnector = null,
                    NominationVolume = new NominationVolume() { QH1 = 50,
                        QH2 = 50, QH3 = 50, QH4 = 50, QH5 = 50, QH6 = 50, QH7 = 50, QH8 = 50, QH9 = 50, QH10 = 50, QH11 = 50, QH12 = 50, QH13 = 50, QH14 = 50, QH15 = 50, QH16 = 50,
                        QH17 = 50, QH18 = 50, QH19 = 50, QH20 = 50, QH21 = 50, QH22 = 50, QH23 = 50, QH24 = 50, QH25 = 50, QH26 = 50, QH27 = 50, QH28 = 50, QH29 = 50, QH30 = 50, QH31 = 50, QH32 = 50, QH33 = 50, QH34 = 50,
                        QH35 = 50, QH36 = 50, QH37 = 50, QH38 = 50, QH39 = 50, QH40 = 50, QH41 = 50, QH42 = 50, QH43 = 50, QH44 = 50, QH45 = 50, QH46 = 50, QH47 = 50, QH48 = 50, QH49 = 50, QH50 = 50, QH51 = 50, QH52 = 50,
                        QH53 = 50, QH54 = 50, QH55 = 50, QH56 = 50, QH57 = 50, QH58 = 50, QH59 = 50, QH60 = 50, QH61 = 50, QH62 = 50, QH63 = 50, QH64 = 50, QH65 = 50, QH66 = 50, QH67 = 50, QH68 = 50, QH69 = 50, QH70 = 50,
                        QH71 = 50, QH72 = 50, QH73 = 100, QH74 = 100, QH75 = 100, QH76 = 50, QH77 = 100, QH78 = 100, QH79 = 100, QH80 = 100, QH81 = 100, QH82 = 100, QH83 = 100, QH84 = 100, QH85 = 100, QH86 = 100, QH87 = 100,
                        QH88 = 100, QH89 = 100, QH90 = 100, QH91 = 100, QH92 = 100, QH93 = 100, QH94 = 100, QH95 = 100, QH96 = 100 } }
            };
            var runId = 1;
            _mockPowertrakTradeService.Setup(service => service.GetNominationDetailsByRunIdAsync(It.IsAny<int>()))
                .ReturnsAsync(mockData.Select(ModelToDtoConverter.ConvertToNominationDetailsDto));


            // Act
            var result = await _controller.GetNominationDetails(runId);

            // Assert
            Assert.IsType<OkObjectResult>(result.Result);
            var objectResult = result.Result as OkObjectResult;
            Assert.NotNull(objectResult);
            Assert.IsAssignableFrom<IEnumerable<NominationDetailsDto>>(objectResult.Value);
        }

        [Fact]
        public async Task GetNominationDetails_LogsInformation_WhenCalled()
        {
            var runId = 1;
            _mockPowertrakTradeService.Setup(service => service.GetNominationDetailsByRunIdAsync(runId))
                .ReturnsAsync(new List<NominationDetails>().Select(ModelToDtoConverter.ConvertToNominationDetailsDto));

            // Act
            await _controller.GetNominationDetails(runId);

            // Assert
            _mockLogger.Verify(logger => logger.LogInformation($"Started fetching nomination details for RunId: {runId}"), Times.Once);
            _mockLogger.Verify(logger => logger.LogInformation($"Successfully fetched nomination details for RunId: {runId}"), Times.Once);
        }

        [Fact]
        public async Task GetNominationDetails_LogsError_WhenExceptionIsThrown()
        {
            // Arrange
            var exceptionMessage = "Test Exception";
            var runId = 1;
            _mockPowertrakTradeService.Setup(service => service.GetNominationDetailsByRunIdAsync(runId))
                .ThrowsAsync(new Exception(exceptionMessage));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<Exception>(() => _controller.GetNominationDetails(runId));
            Assert.Equal("Test Exception", exception.Message);
        }

        [Fact]
        public async Task GetNominationTradeDetails_ReturnsData_WhenServiceReturnsData()
        {
            // Arrange
            var mockData = new List<RawTradeDto>
    {
        GetSampleRawTradesDto()
    };
            int? aggPosRefId = 1;
            int? nominationRunId = null;
            _mockPowertrakTradeService.Setup(service => service.GetRawTradesByAggPosOrRunIdAsync(aggPosRefId, nominationRunId))
                .ReturnsAsync(mockData);

            // Act
            var result = await _controller.GetNominationTradeDetails(aggPosRefId, nominationRunId);

            // Assert
            Assert.IsType<OkObjectResult>(result.Result);
            var objectResult = result.Result as OkObjectResult;
            Assert.NotNull(objectResult);
            Assert.IsAssignableFrom<IEnumerable<RawTradeDto>>(objectResult.Value);
        }

        [Fact]
        public async Task GetNominationTradeDetails_LogsInformation_WhenCalled()
        {
            // Arrange
            int? aggPosRefId = 1;
            int? nominationRunId = null;
            var mockData = GetSampleRawTradesDto();
            List<RawTradeDto> mockRawTrades = new List<RawTradeDto>();
            mockRawTrades.Add(mockData);
            _mockPowertrakTradeService.Setup(service => service.GetRawTradesByAggPosOrRunIdAsync(aggPosRefId, nominationRunId))
                .ReturnsAsync(new List<RawTradeDto>(mockRawTrades));

            // Act
            await _controller.GetNominationTradeDetails(aggPosRefId, nominationRunId);

            // Assert
            _mockLogger.Verify(logger => logger.LogInformation("Started fetching raw trades"), Times.Once);
            _mockLogger.Verify(logger => logger.LogInformation("Successfully fetched raw trades"), Times.Once);
        }

        [Fact]
        
        public async Task GetNominationTradeDetails_LogsError_WhenExceptionIsThrown()
        {
            // Arrange
            var exceptionMessage = "Test Exception";
            int? aggPosRefId = 1;
            int? nominationRunId = null;
            _mockPowertrakTradeService.Setup(service => service.GetRawTradesByAggPosOrRunIdAsync(aggPosRefId, nominationRunId))
                .ThrowsAsync(new Exception(exceptionMessage));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<Exception>(() => _controller.GetNominationTradeDetails(aggPosRefId, nominationRunId));
            Assert.Equal("Test Exception", exception.Message);
        }

        [Fact]
        public async Task GetNominationTradeDetails_ReturnsBadRequest_WhenNoParametersProvided()
        {
            // Act
            var result = await _controller.GetNominationTradeDetails(null, null);

            // Assert
            Assert.IsType<ObjectResult>(result.Result);
            var objectResult = result.Result as ObjectResult;
            Assert.Equal(400, objectResult.StatusCode);
            Assert.Equal(ResponseMessages.InvalidInputParameters, objectResult.Value);
        }

        [Fact]
        public async Task GetMappingRuleDetails_ReturnsData_WhenServiceReturnsData()
        {
            // Arrange
            var mockData = new List<MappingRuleDetailsDto> { GetSampleMappingRuleDetailsDto() };
            _mockPowertrakTradeService.Setup(service => service.GetMappingRuleDetails())
                .ReturnsAsync(mockData);

            // Act
            var result = await _controller.GetMappingRuleDetails();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnValue = Assert.IsType<List<MappingRuleDetailsDto>>(okResult.Value);
            Assert.Equal(mockData, returnValue);
        }

        [Fact]
        public async Task GetMappingRuleDetails_LogsInformation_WhenCalled()
        {
            // Act
            await _controller.GetMappingRuleDetails();

            // Assert
            _mockLogger.Verify(logger => logger.LogInformation("Started fetching mapping rule details."), Times.Once);
            _mockLogger.Verify(logger => logger.LogInformation("Successfully fetched mapping rule details."), Times.Once);
        }

        [Fact]
        public async Task GetMappingRuleDetails_LogsError_WhenExceptionIsThrown()
        {
            // Arrange
            var exceptionMessage = "Test exception";
            _mockPowertrakTradeService.Setup(service => service.GetMappingRuleDetails())
                .ThrowsAsync(new Exception(exceptionMessage));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<Exception>(() => _controller.GetMappingRuleDetails());
            Assert.Equal("Test exception", exception.Message);
        }

        private static NominationDetailsDto GetSampleNominationDetailsDto()
        {
            return new NominationDetailsDto
            {
                NominationRunId = 1,
                NominationDefinitionId = 1,
                NominationDefinitionName = "Elia",
                DeliveryDate = DateTime.UtcNow.AddDays(1).Date,
                ContributingTradeHeaderIds="",
                PeriodCount=96,
                AggPosReferenceId = 5,
                AggPosReferenceName = "Buy_SEEL_TESSENDERLO GROUP NV_Elia_2024-08-14",
                TradeType = "PW_TRADE",
                TransactionType = "Buy",
                Granularity = "15",
                Entity = "SEEL",
                TimeZone= "Central European Standard Time",
                Counterparty = "TESSENDERLO GROUP NV",
                FromMarketOperator = "Elia",
                ToMarketOperator = "Elia",
                CapacityType = null,
                CapacityIdentification = null,
                Interconnector = null,
                QH1 = 0,
                QH2 = 0,
                QH3 = 0,
                QH4 = 0,
                QH5 = 0,
                QH6 = 0,
                QH7 = 0,
                QH8 = 0,
                QH9 = 50,
                QH10 = 50,
                QH11 = 50,
                QH12 = 50,
                QH13 = 50,
                QH14 = 50,
                QH15 = 50,
                QH16 = 50,
                QH17 = 50,
                QH18 = 50,
                QH19 = 50,
                QH20 = 50,
                QH21 = 50,
                QH22 = 50,
                QH23 = 50,
                QH24 = 50,
                QH25 = 50,
                QH26 = 50,
                QH27 = 50,
                QH28 = 50,
                QH29 = 50,
                QH30 = 50,
                QH31 = 50,
                QH32 = 50,
                QH33 = 50,
                QH34 = 50,
                QH35 = 50,
                QH36 = 50,
                QH37 = 50,
                QH38 = 50,
                QH39 = 50,
                QH40 = 50,
                QH41 = 50,
                QH42 = 50,
                QH43 = 50,
                QH44 = 50,
                QH45 = 50,
                QH46 = 50,
                QH47 = 50,
                QH48 = 50,
                QH49 = 50,
                QH50 = 50,
                QH51 = 50,
                QH52 = 50,
                QH53 = 50,
                QH54 = 50,
                QH55 = 50,
                QH56 = 50,
                QH57 = 50,
                QH58 = 50,
                QH59 = 50,
                QH60 = 50,
                QH61 = 50,
                QH62 = 50,
                QH63 = 50,
                QH64 = 50,
                QH65 = 50,
                QH66 = 50,
                QH67 = 50,
                QH68 = 50,
                QH69 = 50,
                QH70 = 50,
                QH71 = 50,
                QH72 = 50,
                QH73 = 100,
                QH74 = 100,
                QH75 = 100,
                QH76 = 50,
                QH77 = 100,
                QH78 = 100,
                QH79 = 100,
                QH80 = 100,
                QH81 = 100,
                QH82 = 100,
                QH83 = 100,
                QH84 = 100,
                QH85 = 100,
                QH86 = 100,
                QH87 = 100,
                QH88 = 100,
                QH89 = 100,
                QH90 = 100,
                QH91 = 100,
                QH92 = 100,
                QH93 = 100,
                QH94 = 100,
                QH95 = 100,
                QH96 = 100
            };
        }

        private static RawTradeDto GetSampleRawTradesDto()
        {
            return new RawTradeDto
            {
                NominationRunId = 1,
                DeliveryDate = DateTime.Parse("2025-08-14T00:00:00"),
                AggPosReferenceId = 1,
                AggPosReference = "Buy_SEEL_TESSENDERLO GROUP NV_Elia_2024-08-14",
                TradeType = "PW_TRADE",
                TransactionType = "Buy",
                Entity = "SEEL",
                TimeZone = "Central European Standard Time",
                Counterparty = "TESSENDERLO GROUP NV",
                FromMarketoperator = "Elia",
                ToMarketoperator = "Elia",
                CapacityType = "",
                CapacityIdentification = "",
                Interconnector = "",
                NomDeliveryDate = DateTime.Parse("2025-08-14T00:00:00"),
                QH1 = 0,
                QH2 = 0,
                QH3 = 0,
                QH4 = 0,
                QH5 = 0,
                QH6 = 0,
                QH7 = 0,
                QH8 = 0,
                QH9 = 0,
                QH10 = 0,
                QH11 = 0,
                QH12 = 0,
                QH13 = 0,
                QH14 = 0,
                QH15 = 0,
                QH16 = 0,
                QH17 = 0,
                QH18 = 0,
                QH19 = 0,
                QH20 = 0,
                QH21 = 0,
                QH22 = 0,
                QH23 = 0,
                QH24 = 0,
                QH25 = 0,
                QH26 = 0,
                QH27 = 0,
                QH28 = 0,
                QH29 = 0,
                QH30 = 0,
                QH31 = 0,
                QH32 = 0,
                QH33 = 0,
                QH34 = 0,
                QH35 = 0,
                QH36 = 0,
                QH37 = 0,
                QH38 = 0,
                QH39 = 0,
                QH40 = 0,
                QH41 = 0,
                QH42 = 0,
                QH43 = 0,
                QH44 = 0,
                QH45 = 0,
                QH46 = 0,
                QH47 = 0,
                QH48 = 0,
                QH49 = 0,
                QH50 = 0,
                QH51 = 0,
                QH52 = 0,
                QH53 = 0,
                QH54 = 0,
                QH55 = 0,
                QH56 = 0,
                QH57 = 0,
                QH58 = 0,
                QH59 = 0,
                QH60 = 0,
                QH61 = 0,
                QH62 = 0,
                QH63 = 0,
                QH64 = 0,
                QH65 = 0,
                QH66 = 0,
                QH67 = 0,
                QH68 = 0,
                QH69 = 0,
                QH70 = 0,
                QH71 = 0,
                QH72 = 0,
                QH73 = 0,
                QH74 = 0,
                QH75 = 0,
                QH76 = 0,
                QH77 = 0,
                QH78 = 0,
                QH79 = 0,
                QH80 = 0,
                QH81 = 0,
                QH82 = 0,
                QH83 = 0,
                QH84 = 0,
                QH85 = 0,
                QH86 = 0,
                QH87 = 0,
                QH88 = 0,
                QH89 = 0,
                QH90 = 0,
                QH91 = 0,
                QH92 = 0,
                QH93 = 0,
                QH94 = 0,
                QH95 = 0,
                QH96 = 0
            };
        }

        private static MappingRuleDetailsDto GetSampleMappingRuleDetailsDto()
        {
            return new MappingRuleDetailsDto
            {
                MappingMasterId = 1,
                NominationDefinitionId = 2,
                NominationDefinitionName = "Sample Nomination",
                MappingMasterName = "Sample Mapping Master",
                MappingMasterCreatedDate = DateTime.UtcNow.AddDays(-10),
                MappingMasterModifiedDate = DateTime.UtcNow.AddDays(-5),
                MappingMasterStatus = "Active",
                MappingTypeId = 3,
                MappingTypeName = "Sample Mapping Type",
                MappingTypeCreatedDate = DateTime.UtcNow.AddDays(-20),
                MappingTypeModifiedDate = DateTime.UtcNow.AddDays(-15),
                MappingTypeStatus = "Active",
                MappingInputId = 4,
                MappingInputField = "Sample Input Field",
                MappingInputValue = "Sample Input Value",
                MappingInputStartDate = DateTime.UtcNow.AddDays(-30),
                MappingInputEndDate = DateTime.UtcNow.AddDays(30),
                MappingInputCreatedDate = DateTime.UtcNow.AddDays(-40),
                MappingInputModifiedDate = DateTime.UtcNow.AddDays(-35),
                MappingInputStatus = "Active",
                MappingOutputId = 5,
                MappingOutputValue = "Sample Output Value",
                MappingOutputStartDate = DateTime.UtcNow.AddDays(-50),
                MappingOutputEndDate = DateTime.UtcNow.AddDays(50),
                MappingOutputCreatedDate = DateTime.UtcNow.AddDays(-60),
                MappingOutputModifiedDate = DateTime.UtcNow.AddDays(-55),
                MappingOutputStatus = "Active"
            };
        }
        private static RawTradeDto GetSampleRawTradeDto()
        {
            return new RawTradeDto
            {
                RawTradeHeaderId = 1,
                NominationRunId = 123,
                AggPosReferenceId = 1,
                AggPosReference = "AggPosRef123",
                TradeReference = "TradeRef123",
                TradeType = "TypeA",
                TransactionType = "Buy",
                Entity = "EntityA",
                Counterparty = "CounterpartyA",
                FromMarketoperator = "MarketOperatorA",
                ToMarketoperator = "MarketOperatorB",
                CapacityType = "TypeB",
                CapacityIdentification = "CapId123",
                Interconnector = "InterconnectorA",
                DeliveryDate = DateTime.UtcNow.AddDays(1),
                QH1 = 10.5,
                QH2 = 11.5,
                QH3 = 12.5,
                QH4 = 13.5,
                QH5 = 14.5,
                QH6 = 15.5,
                QH7 = 16.5,
                QH8 = 17.5,
                QH9 = 18.5,
                QH10 = 19.5,
                QH11 = 20.5,
                QH12 = 21.5,
                QH13 = 22.5,
                QH14 = 23.5,
                QH15 = 24.5,
                QH16 = 25.5,
                QH17 = 26.5,
                QH18 = 27.5,
                QH19 = 28.5,
                QH20 = 29.5,
                QH21 = 30.5,
                QH22 = 31.5,
                QH23 = 32.5,
                QH24 = 33.5,
                QH25 = 34.5,
                QH26 = 35.5,
                QH27 = 36.5,
                QH28 = 37.5,
                QH29 = 38.5,
                QH30 = 39.5,
                QH31 = 40.5,
                QH32 = 41.5,
                QH33 = 42.5,
                QH34 = 43.5,
                QH35 = 44.5,
                QH36 = 45.5,
                QH37 = 46.5,
                QH38 = 47.5,
                QH39 = 48.5,
                QH40 = 49.5,
                QH41 = 50.5,
                QH42 = 51.5,
                QH43 = 52.5,
                QH44 = 53.5,
                QH45 = 54.5,
                QH46 = 55.5,
                QH47 = 56.5,
                QH48 = 57.5,
                QH49 = 58.5,
                QH50 = 59.5,
                QH51 = 60.5,
                QH52 = 61.5,
                QH53 = 62.5,
                QH54 = 63.5,
                QH55 = 64.5,
                QH56 = 65.5,
                QH57 = 66.5,
                QH58 = 67.5,
                QH59 = 68.5,
                QH60 = 69.5,
                QH61 = 70.5,
                QH62 = 71.5,
                QH63 = 72.5,
                QH64 = 73.5,
                QH65 = 74.5,
                QH66 = 75.5,
                QH67 = 76.5,
                QH68 = 77.5,
                QH69 = 78.5,
                QH70 = 79.5,
                QH71 = 80.5,
                QH72 = 81.5,
                QH73 = 82.5,
                QH74 = 83.5,
                QH75 = 84.5,
                QH76 = 85.5,
                QH77 = 86.5,
                QH78 = 87.5,
                QH79 = 88.5,
                QH80 = 89.5,
                QH81 = 90.5,
                QH82 = 91.5,
                QH83 = 92.5,
                QH84 = 93.5,
                QH85 = 94.5,
                QH86 = 95.5,
                QH87 = 96.5,
                QH88 = 97.5,
                QH89 = 98.5,
                QH90 = 99.5,
                QH91 = 100.5,
                QH92 = 101.5,
                QH93 = 102.5,
                QH94 = 103.5,
                QH95 = 104.5,
                QH96 = 105.5,
                DelDateStart = DateTime.UtcNow.AddDays(1),
                DelDateEnd = DateTime.UtcNow.AddDays(2),
                Cdy1Attr1 = "Attr1",
                PwrNomsOverrideType = "OverrideTypeA",
                PwrNomsOverrideInput = "OverrideInputA",
                PwrNomsOverrideFreeform = "OverrideFreeformA",
                AuxSoCpty = "AuxSoCptyA",
                CptyNoms = "CptyNomsA",
                PeakWorkaround = "PeakWorkaroundA",
                InsNumRec = 1
            };
        }

        private static NominationStatus GetNominationStatusDto()
        {
            return new NominationStatus
            {
                ProcessStep = "Nomination Initiated",
                DeliveryDate = DateTime.UtcNow.AddDays(1).Date
            };
        }

        [Fact]
        public async Task GetNominationStatus_ReturnsData_WhenServiceReturnsData()
        {
            // Arrange
            var nominationRunId = 1;
            var nominationStatus = new NominationStatus();
            nominationStatus.ProcessStep = "Completed";
            _mockPowertrakTradeService.Setup(s => s.GetNominationStatusByRunIdAsync(nominationRunId))
                                      .ReturnsAsync(nominationStatus);

            // Act
            var result = await _controller.GetNominationStatus(nominationRunId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            Assert.Equal(nominationStatus.ProcessStep, okResult.Value);
        }

        [Fact]
        public async Task GetNominationStatus_ReturnsBadRequest_WhenInvalidParametersProvided()
        {
            // Act
            var result = await _controller.GetNominationStatus(null);

            // Assert
            var statusCodeResult = Assert.IsType<ObjectResult>(result.Result);
            Assert.Equal(400, statusCodeResult.StatusCode);
        }

        [Fact]
        public async Task GetNominationStatus_ReturnsBadRequest_WhenNoDataFound()
        {
            // Arrange
            var nominationRunId = 1;
            var nominationStatus = new NominationStatus();
            nominationStatus.ProcessStep = string.Empty;
            _mockPowertrakTradeService.Setup(s => s.GetNominationStatusByRunIdAsync(nominationRunId))
                                      .ReturnsAsync(nominationStatus);

            // Act
            var result = await _controller.GetNominationStatus(nominationRunId);

            // Assert
            var statusCodeResult = Assert.IsType<ObjectResult>(result.Result);
            Assert.Equal(400, statusCodeResult.StatusCode);
        }

        [Fact]
        public async Task GetNominationStatus_LogsError_WhenExceptionIsThrown()
        {
            // Arrange
            var nominationRunId = 1;
            _mockPowertrakTradeService.Setup(s => s.GetNominationStatusByRunIdAsync(nominationRunId))
                                      .ThrowsAsync(new Exception("Test exception"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<Exception>(() => _controller.GetNominationStatus(nominationRunId));
            Assert.Equal("Test exception", exception.Message);
        }

        [Fact]
        public async Task GetCounterpartyAggPositions_ReturnsData_WhenServiceReturnsData()
        {
            // Arrange
            var nominationRunId = 1;
            var mockData = new List<NominationDetailsDto> { GetSampleNominationDetailsDto() };
            var nominationStatusMockData =  GetNominationStatusDto();
            _mockPowertrakTradeService.Setup(s => s.GetAggregatedCptyPositionsByRunIdWithFilters(nominationRunId))
                                      .ReturnsAsync(mockData);
            _mockPowertrakTradeService.Setup(s => s.GetNominationStatusByRunIdAsync(1))
                                       .ReturnsAsync(nominationStatusMockData);
            // Act
            var result = await _controller.GetCounterpartyAggPositions(nominationRunId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnValue = Assert.IsType<List<NominationDetailsDto>>(okResult.Value);
            Assert.Equal(1, returnValue?.FirstOrDefault()?.NominationRunId);
            Assert.Equal("Elia", returnValue?.FirstOrDefault()?.NominationDefinitionName);
        }

        [Fact]
        public async Task GetCounterpartyAggPositions_ReturnsBadRequest_WhenInvalidParametersProvided()
        {
            // Act
            var result = await _controller.GetCounterpartyAggPositions(null);

            // Assert
            var statusCodeResult = Assert.IsType<ObjectResult>(result.Result);
            Assert.Equal(400, statusCodeResult.StatusCode);
        }

        [Fact]
        public async Task GetCounterpartyAggPositions_ReturnsBadRequest_WhenNoDataFound()
        {
            // Arrange
            var nominationRunId = 1;
            _mockPowertrakTradeService.Setup(s => s.GetAggregatedCptyPositionsByRunIdWithFilters(nominationRunId))
                                      .ReturnsAsync(new List<NominationDetailsDto>());

            // Act
            var result = await _controller.GetCounterpartyAggPositions(nominationRunId);

            // Assert
            var statusCodeResult = Assert.IsType<ObjectResult>(result.Result);
            Assert.Equal(400, statusCodeResult.StatusCode);
        }

        [Fact]
        public async Task GetCounterpartyAggPositions_LogsError_WhenExceptionIsThrown()
        {
            // Arrange
            var nominationRunId = 1;
            _mockPowertrakTradeService.Setup(s => s.GetAggregatedCptyPositionsByRunIdWithFilters(nominationRunId))
                                      .ThrowsAsync(new Exception("Test exception"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<Exception>(() => _controller.GetCounterpartyAggPositions(nominationRunId));
            Assert.Equal("Test exception", exception.Message);
            
        }

        [Fact]
        public async Task SendNomPositionsToPowertrak_ReturnsData_WhenServiceReturnsData()
        {
            // Arrange
            var nominationRunId = 1;
            var sampleNominationDetails = new List<NominationDetailsDto> { GetSampleNominationDetailsDto() };
            var nominationStatusMockData = GetNominationStatusDto();
            _mockPowertrakTradeService.Setup(s => s.GetNominationStatusByRunIdAsync(1))
                                       .ReturnsAsync(nominationStatusMockData);
            _mockPowertrakTradeService.Setup(s => s.GetAggregatedCptyPositionsByRunIdWithFilters(nominationRunId))
                                      .ReturnsAsync(sampleNominationDetails);
            _mockPowertrakTradeService.Setup(s => s.SaveNominationPositionsInDB(sampleNominationDetails))
                                      .Returns(Task.CompletedTask);
            _mockTradeTransformerService.Setup(s => s.ConvertTradeMessageToPowerTrakFormat(It.IsAny<IEnumerable<NominationDetailsDto>>()))
                                        .Returns("SampleXmlRequest");

            _mockPowertrakTradeService.Setup(s => s.SendNominationToPowertrak("SampleXmlRequest", It.IsAny<PowerTrakConfig>()))
                                      .ReturnsAsync(XElement.Parse(Resources.SampleXmlResponseXML));

            // Act
            var result = await _controller.SendNomPositionsToPowertrak(nominationRunId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var resultVal = Assert.IsType<string>(okResult.Value);
            Assert.Equal(Resources.SampleXmlResponse, resultVal);
        }

        [Fact]
        public async Task SendNomPositionsToPowertrak_ReturnsBadRequest_WhenInvalidParametersProvided()
        {
            // Act
            var result = await _controller.SendNomPositionsToPowertrak(null);

            // Assert
            var statusCodeResult = Assert.IsType<ObjectResult>(result.Result);
            Assert.Equal(400, statusCodeResult.StatusCode);
        }

        [Fact]
        public async Task SendNomPositionsToPowertrak_ReturnsBadRequest_WhenNoDataFound()
        {
            // Arrange
            var nominationRunId = 1;
            _mockPowertrakTradeService.Setup(s => s.GetAggregatedCptyPositionsByRunIdWithFilters(nominationRunId))
                                      .ReturnsAsync(new List<NominationDetailsDto>());

            // Act
            var result = await _controller.SendNomPositionsToPowertrak(nominationRunId);

            // Assert
            var statusCodeResult = Assert.IsType<ObjectResult>(result.Result);
            Assert.Equal(400, statusCodeResult.StatusCode);
        }

        [Fact]
        public async Task SendNomPositionsToPowertrak_LogsError_WhenExceptionIsThrown()
        {
            // Arrange
            var nominationRunId = 1;
            _mockPowertrakTradeService.Setup(s => s.GetAggregatedCptyPositionsByRunIdWithFilters(nominationRunId))
                                      .ThrowsAsync(new Exception("Test exception"));

            // Act & Assert
            var exception = await Assert.ThrowsAsync<Exception>(() => _controller.SendNomPositionsToPowertrak(nominationRunId));
            Assert.Equal("Test exception", exception.Message);
        }

        [Fact]
        public async Task GetNominationHeaders_ReturnsOkResult_WhenDataIsFetchedSuccessfully()
        {
            // Arrange
            var mockData = new List<NominationHeader> { new NominationHeader { NominationDefinitionId = 1, NominationDefinitionName = "Test" } };
            _mockPowertrakTradeService.Setup(service => service.GetNominationHeaderData()).ReturnsAsync(mockData);

            // Act
            var result = await _controller.GetNominationHeaders();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnValue = Assert.IsType<List<NominationHeader>>(okResult.Value);
            Assert.Equal(mockData, returnValue);
        }

        [Fact]
        public async Task GetNominationDetails_ReturnsOkResult_WhenDataIsFetchedSuccessfully()
        {
            // Arrange
            var mockData = new List<NominationDetailsDto> { new NominationDetailsDto { NominationRunId = 1, NominationDefinitionId = 1 } };
            _mockPowertrakTradeService.Setup(service => service.GetNominationDetailsByRunIdAsync(It.IsAny<int>())).ReturnsAsync(mockData);

            // Act
            var result = await _controller.GetNominationDetails(1);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnValue = Assert.IsType<List<NominationDetailsDto>>(okResult.Value);
            Assert.Equal(mockData, returnValue);
        }

        [Fact]
        public async Task GetNominationTradeDetails_ReturnsOkResult_WhenDataIsFetchedSuccessfully()
        {
            // Arrange
            var mockData = new List<RawTradeDto> { GetSampleRawTradesDto() };


            _mockPowertrakTradeService.Setup(service => service.GetRawTradesByAggPosOrRunIdAsync(It.IsAny<int?>(), It.IsAny<int?>())).ReturnsAsync(mockData);

            // Act
            var result = await _controller.GetNominationTradeDetails(1, null);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnValue = Assert.IsType<List<RawTradeDto>>(okResult.Value);
        }

        [Fact]
        public async Task GetMappingRuleDetails_ReturnsOkResult_WhenDataIsFetchedSuccessfully()
        {
            // Arrange
            var mockData = new List<MappingRuleDetailsDto> { new MappingRuleDetailsDto { MappingMasterId = 1, NominationDefinitionId = 1 } };
            _mockPowertrakTradeService.Setup(service => service.GetMappingRuleDetails()).ReturnsAsync(mockData);

            // Act
            var result = await _controller.GetMappingRuleDetails();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnValue = Assert.IsType<List<MappingRuleDetailsDto>>(okResult.Value);
            Assert.Equal(mockData, returnValue);
        }

        [Fact]
        public async Task GetCounterpartyAggPositions_ReturnsOkResult_WhenDataIsFetchedSuccessfully()
        {
            // Arrange
            var mockData = new List<NominationDetailsDto>
            {
                new NominationDetailsDto
                {
                    NominationRunId = 1,
                    NominationDefinitionId = 1,
                    NominationDefinitionName = "Test Nomination",
                    DeliveryDate = DateTime.Parse("2023-10-28"),
                    AggPosReferenceId = 1,
                    AggPosReferenceName = "AggPosRef1",
                    TimeZone = "Central European Standard Time",
                    ContributingTradeHeaderIds = "1",
                    TradeType = "PW_TRADE",
                    TransactionType = "Buy",
                    Granularity = "15",
                    Entity = "Entity1",
                    Counterparty = "Counterparty1",
                    FromMarketOperator = "MarketOperator1",
                    ToMarketOperator = "MarketOperator2",
                    CapacityType = "Type1",
                    CapacityIdentification = "CapId1",
                    Interconnector = "Interconnector1",
                    QH1 = 50,
                    QH2 = 50,
                    QH3 = 50,
                    QH4 = 50,
                    QH5 = 50,
                    QH6 = 50,
                    QH7 = 50,
                    QH8 = 50,
                    QH9 = 50,
                    QH10 = 50,
                    QH11 = 50,
                    QH12 = 50,
                    QH13 = 50,
                    QH14 = 50,
                    QH15 = 50
                }
            };
            _mockPowertrakTradeService.Setup(service => service.GetAggregatedCptyPositionsByRunIdWithFilters(It.IsAny<int>())).ReturnsAsync(mockData);
            var nominationStatusMockData = GetNominationStatusDto();
            nominationStatusMockData.DeliveryDate = DateTime.Parse("2023-10-28");
            _mockPowertrakTradeService.Setup(s => s.GetNominationStatusByRunIdAsync(1))
                                       .ReturnsAsync(nominationStatusMockData);
            // Act
            var result = await _controller.GetCounterpartyAggPositions(1);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnValue = Assert.IsType<List<NominationDetailsDto>>(okResult.Value);
            Assert.Equal((double?)50, returnValue?.FirstOrDefault()?.QH15);
            Assert.Equal(1, returnValue?.FirstOrDefault()?.NominationRunId);
            Assert.Equal("Test Nomination", returnValue?.FirstOrDefault()?.NominationDefinitionName);
        }

        [Fact]
        public async Task SendNomPositionsToPowertrak_ReturnsOkResult_WhenDataIsFetchedSuccessfully()
        {
            // Arrange
            var mockData = new List<NominationDetailsDto>
            {
                new NominationDetailsDto
                {
                    NominationRunId = 1,
                    NominationDefinitionId = 1,
                    NominationDefinitionName = "Test Nomination",
                    DeliveryDate = DateTime.UtcNow.AddDays(1).Date,
                    AggPosReferenceId = 1,
                    AggPosReferenceName = "AggPosRef1",
                    TimeZone = "Central European Standard Time",
                    ContributingTradeHeaderIds = "1",
                    TradeType = "PW_TRADE",
                    TransactionType = "Buy",
                    Granularity = "15",
                    Entity = "Entity1",
                    Counterparty = "Counterparty1",
                    FromMarketOperator = "MarketOperator1",
                    ToMarketOperator = "MarketOperator2",
                    CapacityType = "Type1",
                    CapacityIdentification = "CapId1",
                    Interconnector = "Interconnector1",
                    QH1 = 50,
                    QH2 = 50,
                    QH3 = 50,
                    QH4 = 50,
                    QH5 = 50,
                    QH6 = 50,
                    QH7 = 50,
                    QH8 = 50,
                    QH9 = 50,
                    QH10 = 50,
                    QH11 = 50,
                    QH12 = 50,
                    QH13 = 50,
                    QH14 = 50,
                    QH15 = 50
                }
            };

            var nominationStatusMockData = GetNominationStatusDto();
            _mockPowertrakTradeService.Setup(s => s.GetNominationStatusByRunIdAsync(1))
                                       .ReturnsAsync(nominationStatusMockData);
            _mockPowertrakTradeService.Setup(service => service.GetAggregatedCptyPositionsByRunIdWithFilters(It.IsAny<int>())).ReturnsAsync(mockData);
            _mockPowertrakTradeService.Setup(service => service.SaveNominationPositionsInDB(It.IsAny<IEnumerable<NominationDetailsDto>>())).Returns(Task.CompletedTask);
            _mockTradeTransformerService.Setup(service => service.ConvertTradeMessageToPowerTrakFormat(It.IsAny<IEnumerable<NominationDetailsDto>>())).Returns("SampleXmlRequest");
            _mockPowertrakTradeService.Setup(service => service.SendNominationToPowertrak(It.IsAny<string>(), It.IsAny<PowerTrakConfig>())).ReturnsAsync(new XElement("Response"));

            // Act
            var result = await _controller.SendNomPositionsToPowertrak(1);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnValue = Assert.IsType<string>(okResult.Value);
            Assert.NotNull(returnValue);
        }

        [Fact]
        public async Task GetNominationReadyRuns_ReturnsOkResult_WhenDataIsFetchedSuccessfully()
        {
            // Arrange
            var mockData =  new NominationReady { NominationRunIDs = [20,20] } ;
            _mockPowertrakTradeService.Setup(service => service.GetReadyNominations()).ReturnsAsync(mockData);

            // Act
            var result = await _controller.GetReadyNominations();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            var returnValue = Assert.IsType<NominationReady>(okResult.Value);
            Assert.Equal(mockData, returnValue);
        }

        [Fact]
        public async Task GetCounterpartyAggPositions_ReturnsBadRequest_WhenNoTradesFound()
        {
            // Arrange
            var nominationRunId = 1;
            var mockData = new List<NominationDetailsDto>();
            var nominationStatusMockData = GetNominationStatusDto();
            nominationStatusMockData.DeliveryDate = DateTime.UtcNow;

            _mockPowertrakTradeService.Setup(s => s.GetAggregatedCptyPositionsByRunIdWithFilters(nominationRunId))
                                      .ReturnsAsync(mockData);
            _mockPowertrakTradeService.Setup(s => s.GetNominationStatusByRunIdAsync(nominationRunId))
                                      .ReturnsAsync(nominationStatusMockData);

            // Act
            var result = await _controller.GetCounterpartyAggPositions(nominationRunId);

            // Assert
            var statusCodeResult = Assert.IsType<ObjectResult>(result.Result);
            Assert.Equal(400, statusCodeResult.StatusCode);
            Assert.Equal(ResponseMessages.NoDataFound, statusCodeResult.Value);

            _mockLogger.Verify(logger => logger.LogError(ResponseMessages.NoDataFound), Times.Once);
            _mockPowertrakTradeService.Verify(service => service.UpdateNominationBatchRunStatusAsync(
                nominationRunId,
                It.Is<int>(id => id == 7), // _nomNoTradesStepId
                It.Is<string>(status => status == "No Trades Found"), // _noTradesFoundError
                It.Is<string>(reason => reason == ""),
                It.IsAny<DateTime>(),
                It.IsAny<DateTime>()
            ), Times.Once);
        }
        [Fact]
        public async Task UpdatePowertrakStatus_ReturnsOk_WhenStatusesAreUpdated()
        {
            // Arrange
            var correlationIds = new List<NominationCorrelationId>
    {
        new NominationCorrelationId { PowertrakEnv = "UAT", NominationRunId = 1, CorrelationId = "corr-1" },
        new NominationCorrelationId { PowertrakEnv = "PROD", NominationRunId = 2, CorrelationId = "corr-2" }
    };
            var gmslStatusResponse = XElement.Parse(Resources.SampleStatusReport);
            _mockPowertrakTradeService.Setup(s => s.GetCorrelationIds()).ReturnsAsync(correlationIds);
            _mockPowertrakTradeService.Setup(s => s.GetPowertrakStatusReport(It.IsAny<PowerTrakConfig>(), It.IsAny<string>()))
                .ReturnsAsync(gmslStatusResponse);
            // PowertrakHelper.GetTradeStatuses expects a string, so we can mock static if needed, but here we just let it run.

            // Act
            var result = await _controller.UpdatePowertrakStatus();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            Assert.Equal("1, 2", okResult.Value);
            _mockLogger.Verify(l => l.LogInformation("Started fetching correlationids."), Times.Once);
            _mockLogger.Verify(l => l.LogInformation("Successfully fetched correlationids."), Times.Once);
            _mockLogger.Verify(l => l.LogInformation(It.Is<string>(s => s.Contains("Fetching powertrak status report"))), Times.Once);
            _mockPowertrakTradeService.Verify(s => s.UpdatePowertrakTradeStatuses(It.IsAny<List<TradeStatusDto>>()), Times.Once);
        }

        [Fact]
        public async Task UpdatePowertrakStatus_ReturnsNotFound_WhenNoCorrelationIds()
        {
            // Arrange
            _mockPowertrakTradeService.Setup(s => s.GetCorrelationIds()).ReturnsAsync(new List<NominationCorrelationId>());

            // Act
            var result = await _controller.UpdatePowertrakStatus();

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result.Result);
            Assert.Equal("No correlationids found.",notFoundResult.Value);
        }

        [Fact]
        public async Task UpdatePowertrakStatus_LogsErrorAndThrows_WhenExceptionOccurs()
        {
            // Arrange
            var ex = new Exception("Test error");
            _mockPowertrakTradeService.Setup(s => s.GetCorrelationIds()).ThrowsAsync(ex);

            // Act & Assert
            var thrown = await Assert.ThrowsAsync<Exception>(() => _controller.UpdatePowertrakStatus());
            Assert.Equal("Test error", thrown.Message);
            _mockLogger.Verify(l => l.LogError(It.Is<string>(msg => msg.Contains("An error occurred while fetching correlationids"))), Times.Once);
        }

        [Fact]
        public async Task UpdatePowertrakStatus_LogsError_WhenPowertrakConfigIsNull()
        {
            // Arrange
            var correlationIds = new List<NominationCorrelationId>
    {
        new NominationCorrelationId { PowertrakEnv = "NONEXISTENT", NominationRunId = 1, CorrelationId = "corr-1" }
    };
            _mockPowertrakTradeService.Setup(s => s.GetCorrelationIds()).ReturnsAsync(correlationIds);

            // Act
            var result = await _controller.UpdatePowertrakStatus();

            // Assert
            var okResult = Assert.IsType<NotFoundObjectResult>(result.Result);
            Assert.Equal("No correlationids found.", okResult.Value);
            _mockLogger.Verify(l => l.LogError(It.Is<string>(msg => msg.Contains("PowertrakConfig is null or empty"))), Times.Once);
        }

    }
}
