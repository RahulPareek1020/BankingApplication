using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using Shell.Energy.SNE.WebJobs.NomScheduler;
using Shell.Energy.STPower.Data.DTO;
using Shell.Energy.STPower.Data.Integration.DataAccess;
using Shell.Energy.STPower.Data.Integration.Services;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Auth;
using System.Net;

namespace Shell.Energy.SNE.WebJobs.NominationScheduler.Tests
{
    public class NomSchedulerServiceTests
    {
        private readonly Mock<ILogger<NomSchedulerService>> _loggerMock;
        private readonly Mock<IAppLogger> _appLoggerMock;
        private readonly Mock<IConfiguration> _configurationMock;
        private readonly Mock<HttpMessageHandler> _httpMessageHandlerMock;
        private readonly Mock<IHttpClientFactory> _httpClientHandlerMock;
        private readonly Mock<ISqlDataRepository> _sqlDataRepositoryMock;
        private readonly HttpClient _httpClient;
        private readonly NomSchedulerService _nomSchedulerService;
        private readonly Mock<IPowertrakTradeService> _powertrakTradeServiceMock;
        private readonly Mock<ITokenService> _tokenServiceMock;

        public NomSchedulerServiceTests()
        {
            _loggerMock = new Mock<ILogger<NomSchedulerService>>();
            _configurationMock = new Mock<IConfiguration>();
            _httpMessageHandlerMock = new Mock<HttpMessageHandler>();
            _sqlDataRepositoryMock = new Mock<ISqlDataRepository>();
            _appLoggerMock = new Mock<IAppLogger>();
            _httpClientHandlerMock = new Mock<IHttpClientFactory>();
            _powertrakTradeServiceMock = new Mock<IPowertrakTradeService>();
            _tokenServiceMock = new Mock<ITokenService>();
            _nomSchedulerService = new NomSchedulerService(_loggerMock.Object, _configurationMock.Object, _powertrakTradeServiceMock.Object, _httpClientHandlerMock.Object, _tokenServiceMock.Object);
        }

        [Fact]
        public async Task ProcessAndSendNominationData_SuccessfulApiCall_LogsInformation()
        {
            try
            {
                var apiUrl = "http://example.com/api/";
                var env = "DEV";
                var configurationSectionMock = new Mock<IConfigurationSection>();
                configurationSectionMock
               .Setup(x => x.Value)
               .Returns(apiUrl);

                var configurationSectionMockenv = new Mock<IConfigurationSection>();
                configurationSectionMock
               .Setup(x => x.Value)
               .Returns(env);

                _configurationMock.Setup(c => c.GetSection("SNEAPIURL-DEV").Value).Returns(apiUrl);
                _configurationMock.Setup(c => c.GetSection("STPowerEnv").Value).Returns(env);

                _httpMessageHandlerMock
                    .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK));
                var httpClient = new HttpClient();

                _httpClientHandlerMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);
                var result = new List<NominationScheduleDto>();
                result.Add(new NominationScheduleDto
                {
                    NominationDefinitionId = 1,
                    DaysOffsetMax = 1,
                    DaysOffsetMin = 1,
                });
                _powertrakTradeServiceMock.Setup(x => x.GetNominationsForSchedule(1)).ReturnsAsync(result);

                string token = "sampleToken";
                _tokenServiceMock.Setup(x => x.GenerateToken()).ReturnsAsync(token);
                await _nomSchedulerService.CallAligneBatchAsync(1);

#pragma warning disable CS8602 // Dereference of a possibly null reference.
                _loggerMock.Verify(
                    x => x.Log(
                        LogLevel.Information,
                        It.IsAny<EventId>(),
                        It.Is<It.IsAnyType>((v, t) => v != null && v.ToString().Contains("Successfully called the SNE API")),
                        It.IsAny<Exception>(),
                        It.Is<Func<It.IsAnyType, Exception?, string>>((v, t) => true)),
                    Times.Once);
#pragma warning restore CS8602 // Dereference of a possibly null reference.
            }
            catch (Exception)
            {
                throw;
            }
        }

        [Fact]
        public async Task ProcessAndSendNominationData_FailedApiCall_LogsInformation()
        {
            try
            {
                var apiUrl = "http://example.com/api/";
                var env = "DEV";
                var configurationSectionMock = new Mock<IConfigurationSection>();
                configurationSectionMock
               .Setup(x => x.Value)
               .Returns(apiUrl);

                var configurationSectionMockenv = new Mock<IConfigurationSection>();
                configurationSectionMock
               .Setup(x => x.Value)
               .Returns(env);

                _configurationMock.Setup(c => c.GetSection("SNEAPIURL-DEV").Value).Returns(apiUrl);
                _configurationMock.Setup(c => c.GetSection("STPowerEnv").Value).Returns(env);

                _httpMessageHandlerMock
                    .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK));
                var httpClient = new HttpClient();

                _httpClientHandlerMock.Setup(x => x.CreateClient(It.IsAny<string>()));
                var result = new List<NominationScheduleDto>();
                result.Add(new NominationScheduleDto
                {
                    NominationDefinitionId = 1,
                    DaysOffsetMax = 1,
                    DaysOffsetMin = 1,
                });
                _powertrakTradeServiceMock.Setup(x => x.GetNominationsForSchedule(1)).ReturnsAsync(result);

                await _nomSchedulerService.CallAligneBatchAsync(1);

#pragma warning disable CS8602 // Dereference of a possibly null reference.
                _loggerMock.Verify(
                    x => x.Log(
                        LogLevel.Error,
                        It.IsAny<EventId>(),
                        It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("An error occurred while calling SNE API")),
                        It.IsAny<Exception>(),
                        It.Is<Func<It.IsAnyType, Exception?, string>>((v, t) => true)),
                    Times.AtLeastOnce);
#pragma warning restore CS8602 // Dereference of a possibly null reference.
            }
            catch (Exception)
            {

                throw;
            }
        }

        [Fact]
        public async Task ProcessAndSendNominationData_NominationForSchedule_LogsInformation()
        {
            try
            {
                var apiUrl = "http://example.com/api/";
                var env = "DEV";
                var configurationSectionMock = new Mock<IConfigurationSection>();
                configurationSectionMock
               .Setup(x => x.Value)
               .Returns(apiUrl);

                var configurationSectionMockenv = new Mock<IConfigurationSection>();
                configurationSectionMock
               .Setup(x => x.Value)
               .Returns(env);

                _configurationMock.Setup(c => c.GetSection("SNEAPIURL-DEV").Value).Returns(apiUrl);
                _configurationMock.Setup(c => c.GetSection("STPowerEnv").Value).Returns(env);

                _httpMessageHandlerMock
                    .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK));
                var httpClient = new HttpClient();

                _httpClientHandlerMock.Setup(x => x.CreateClient(It.IsAny<string>()));

                await _nomSchedulerService.CallAligneBatchAsync(1);

#pragma warning disable CS8602 // Dereference of a possibly null reference.
                _loggerMock.Verify(
                    x => x.Log(
                        LogLevel.Information,
                        It.IsAny<EventId>(),
                        It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("No nominations associated to schedule id")),
                        It.IsAny<Exception>(),
                        It.Is<Func<It.IsAnyType, Exception?, string>>((v, t) => true)),
                    Times.Once);
#pragma warning restore CS8602 // Dereference of a possibly null reference.
            }
            catch (Exception)
            {

                throw;
            }
        }

    }
}
