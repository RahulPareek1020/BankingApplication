using Microsoft.Extensions.Configuration;
using Moq;
using NUnit.Framework;
using Shell.Energy.STPower.Data.Common.Model;
using Shell.Energy.STPower.Data.Integration.DataAccess;
using Shell.Energy.STPower.Data.Integration.Services;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Enums;
using System.Data;
using Assert = Xunit.Assert;

namespace Shell.Energy.STPower.Data.Integration.Tests.Services
{
    [TestFixture]
    public class AligneTradeServiceTests
    {
        private Mock<IRepository>? _aligneRepositoryMock;
        private Mock<IConfiguration> _configurationMock;
        private Mock<IAppLogger>? _loggerAligneRawTradeMock;
        private AligneTradeService? _aligneTradeService;




        public AligneTradeServiceTests()
        {
            _aligneRepositoryMock = new Mock<IRepository>();
            _configurationMock = new Mock<IConfiguration>();
            _loggerAligneRawTradeMock = new Mock<IAppLogger>();
            _aligneTradeService = new AligneTradeService(
                _aligneRepositoryMock.Object,
                _loggerAligneRawTradeMock.Object,
                _configurationMock.Object
                );
        }

        [Fact]
        public async Task FetchAligneRawTrades_ShouldReturnListOfAligneRawTrades()
        {
            List<AligneRawTrade> expectedTrades = new List<AligneRawTrade>()
            { new AligneRawTrade()};

            _aligneRepositoryMock?.Setup(x => x.GetAligneRawTradesData(1)).Returns(Task.FromResult(expectedTrades));

            if (_aligneTradeService != null)
            {  // Act
                var result = await _aligneTradeService.FetchAligneRawTrades(1);

                // Assert
                Assert.Equal(expectedTrades.Count, result.Count);
            }
        }

        [Fact]
        public async Task UpdateBatchRunStatus()
        {
            DateTime? batchRunDate = DateTime.Now.Date;
            long batchRunTime = 1124;
            string status = "COMPLETE";
            int rowCount = 2104;
            long batchRunId = 1;
            List<AligneRawTrade> expectedTrades = new List<AligneRawTrade>()
            { new AligneRawTrade()};

            _aligneRepositoryMock?.Setup(x => x.InsertBatchRunStatus(batchRunDate, batchRunTime, batchRunId, status, rowCount)).Returns(Task.FromResult(expectedTrades));

            // Act
            try
            {
                if (_aligneTradeService != null)
                    await _aligneTradeService.InsertBatchRunStatus(batchRunDate, batchRunTime, batchRunId, status, rowCount);
                Assert.True(true);
            }
            catch (Exception)
            {

                Assert.True(false);
            }
        }

        [Fact]
        public async Task UpdateErrorRecords()
        {
            //Arrange
            DataTable errorRecordsDataTable = new DataTable();
            errorRecordsDataTable.Columns.Add("REFEREMCE", typeof(string));
            errorRecordsDataTable.Columns.Add("DELIVERYDATE", typeof(DateTime));
            errorRecordsDataTable.Columns.Add("BATCH_RUN_DATE", typeof(DateTime));
            errorRecordsDataTable.Columns.Add("BATCH_RUN_TIME", typeof(Decimal));
            errorRecordsDataTable.Columns.Add("STATUS", typeof(string));


            DataRow row = errorRecordsDataTable.NewRow();
            row["REFEREMCE"] = "12345678";
            row["DELIVERYDATE"] = "2024-11-29";
            row["BATCH_RUN_DATE"] = "2024-11-29";
            row["BATCH_RUN_TIME"] = "1104";
            row["STATUS"] = Status.INCOMPLETE.ToString();
            errorRecordsDataTable.Rows.Add(row);
            List<AligneRawTrade> expectedTrades = new List<AligneRawTrade>()
            { new AligneRawTrade(){
            BatchRunDate = DateTime.Now.Date} };

            _aligneRepositoryMock?.Setup(x => x.InsertErrorRecords(errorRecordsDataTable));

            // Act
            try
            {
                if (_aligneTradeService != null)
                    await _aligneTradeService.InsertErrorRecords(expectedTrades);
                Assert.True(true);
            }
            catch (Exception)
            {

                Assert.True(false);
            }
        }
    }
}
