using Autofac.Extras.Moq;
using Microsoft.Extensions.Configuration;
using Moq;
using NUnit.Framework;
using Shell.Energy.STPower.Data.Common.Model;
using Shell.Energy.STPower.Data.Integration.DataAccess;
using Shell.Energy.STPower.Shared;
using System.Data;
using Assert = Xunit.Assert;
using Status = Shell.Energy.STPower.Shared.Enums.Status;

namespace Shell.Energy.STPower.Data.Integration.Tests.DataAccess
{
    [TestFixture]
    public class RepositoryTests
    {
        private Mock<IConfiguration> _configurationMockAligne;
        private Mock<IAppLogger> _loggerMock;
        private Repository _repositoryAligne;
        private Mock<ISqlDataRepository> _sqlDataRepository;


        public RepositoryTests()
        {

            _loggerMock = new Mock<IAppLogger>();
            _configurationMockAligne = new Mock<IConfiguration>();
            _sqlDataRepository = new Mock<ISqlDataRepository>();
            _repositoryAligne = new Repository(_configurationMockAligne.Object, _loggerMock.Object, _sqlDataRepository.Object);

        }


        [Fact]
        public async Task GetAligneRawTradeData()
        {
            // Arrange
            var expectedData = new List<AligneRawTrade>
            {
                new AligneRawTrade
                {
                    Reference = "12345678"
                }
            };

            using (var mock = AutoMock.GetLoose())
            {
                mock.Mock<IRepository>().Setup(x => x.GetAligneRawTradesData(1))
                     .Returns(Task.FromResult(expectedData));

                var repository = mock.Create<IRepository>();

                var result = await repository.GetAligneRawTradesData(1);
                Assert.Equal(result, expectedData);
                Assert.Equal("12345678",result[0].Reference );
            }
        }

        [Fact]
        public async Task UpdateBatchRunStatus()
        {

            // Arrange
            DateTime? batchRunDate = DateTime.Now.Date;
            long batchRunTime = 1124;
            string status = "COMPLETE";
            long batchRunId = 1;
            int rowCount = 2104;
            var expectedData = new List<AligneRawTrade>
            {
                new AligneRawTrade
                {
                    Reference = "12345678"
                }
            };

            using (var mock = AutoMock.GetLoose())
            {
                mock.Mock<IRepository>().Setup(x => x.InsertBatchRunStatus(batchRunDate, batchRunTime, batchRunId, status, rowCount))
                     .Returns(Task.CompletedTask);

                var repository = mock.Create<IRepository>();
                try
                {
                    await repository.InsertBatchRunStatus(batchRunDate, batchRunTime, batchRunId, status, rowCount);
                    Assert.True(true);
                }
                catch (Exception)
                {

                    Assert.True(false);
                }
            }
        }


        [Fact]
        public async Task UpdateErrorRecords()
        {
            DataTable errorRecordsDataTable = new DataTable();
            errorRecordsDataTable.Columns.Add("REFEREMCE", typeof(string));
            errorRecordsDataTable.Columns.Add("DELIVERYDATE", typeof(DateTime));
            errorRecordsDataTable.Columns.Add("BATCH_RUN_DATE", typeof(DateTime));
            errorRecordsDataTable.Columns.Add("BATCH_RUN_TIME", typeof(Decimal));
            errorRecordsDataTable.Columns.Add("STATUS", typeof(string));


            DataRow row = errorRecordsDataTable.NewRow();
            row["REFEREMCE"] = "12345678";
            row["DELIVERYDATE"] = "2024-11-29";
            row["BATCH_RUN_DATE"] = "2024-11-29";
            row["BATCH_RUN_TIME"] = "1104";
            row["STATUS"] = Status.INCOMPLETE.ToString();
            errorRecordsDataTable.Rows.Add(row);


            using (var mock = AutoMock.GetLoose())
            {
                mock.Mock<IRepository>().Setup(x => x.InsertErrorRecords(errorRecordsDataTable))
                     .Returns(Task.CompletedTask);

                var repository = mock.Create<IRepository>();
                try
                {
                    await repository.InsertErrorRecords(errorRecordsDataTable);
                    Assert.True(true);
                }
                catch (Exception)
                {

                    Assert.True(false);
                }
            }
        }
    }
}
