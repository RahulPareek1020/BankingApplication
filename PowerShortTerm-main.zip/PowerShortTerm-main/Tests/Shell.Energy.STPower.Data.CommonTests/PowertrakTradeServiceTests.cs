using NSubstitute;
using Shell.Energy.STPower.Data.Common.Constants;
using Shell.Energy.STPower.Data.Integration.DataAccess;
using Shell.Energy.STPower.Data.Integration.Services;
using Shell.Energy.STPower.Shared;

namespace Shell.Energy.STPower.Data.Integration.Tests.Services
{
    public class PowertrakTradeServiceTests
    {
        private readonly ISqlDataRepository _sqlDataRepository;
        private readonly IAppLogger _logger;
        private readonly PowertrakTradeService _powertrakTradeService;

        public PowertrakTradeServiceTests()
        {
            _sqlDataRepository = Substitute.For<ISqlDataRepository>();
            _logger = Substitute.For<IAppLogger>();
            _powertrakTradeService = new PowertrakTradeService(_sqlDataRepository, _logger);
        }

        [Fact]
        public async Task GetCorrelationIds_ShouldReturnListOfCorrelationIds()
        {
            // Arrange
            string query = AggSqlQueries.SelectCorrelationId;
            List<string> expectedCorrelationIds = new List<string> { "id1", "id2" };
            _sqlDataRepository.ExecuteSqlQuery<string>(query).Returns(expectedCorrelationIds);

            // Act
            var result = await _powertrakTradeService.GetCorrelationIds();

            // Assert
            Assert.Equal(expectedCorrelationIds.Count, result.Count);
            Assert.Equal(expectedCorrelationIds, result);
        }
    }
}