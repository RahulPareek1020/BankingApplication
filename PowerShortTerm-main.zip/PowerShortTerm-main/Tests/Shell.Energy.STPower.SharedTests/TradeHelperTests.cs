using Newtonsoft.Json;
using Shell.Energy.STPower.Shared.Constants;
using Shell.Energy.STPower.Shared.Enums;
using Shell.Energy.STPower.Shared.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace Shell.Energy.STPower.Shared.Tests
{
	public class TradeHelperTests
	{
		[Fact]
		public void TestGetTradePeriodCount()
		{
			Assert.Equal(24, TradeHelper.GetPeriodCount(Granularity.HR));
			Assert.Equal(48, TradeHelper.GetPeriodCount(Granularity.HHR));
			Assert.Equal(96, TradeHelper.GetPeriodCount(Granularity.QHR));
		}

		[Fact]
		public void TestGetTradeRepeatCount_ThrowsNotFoundException()
		{
			Assert.Throws<NotFoundException>(() => TradeHelper.GetTradeRepeatCount(20));
		}

		[Fact]
		public void TestGetTradeRepeatCount()
		{
			Assert.Equal(4, TradeHelper.GetTradeRepeatCount(TradeHelper.GetPeriodCount(Granularity.HR)));
			Assert.Equal(2, TradeHelper.GetTradeRepeatCount(TradeHelper.GetPeriodCount(Granularity.HHR)));
			Assert.Equal(1, TradeHelper.GetTradeRepeatCount(TradeHelper.GetPeriodCount(Granularity.QHR)));
		}

		[Fact]
		public void TestProcessMissingTrades()
		{
			var energyValues = new List<decimal> { 1, 2, 3 };
			energyValues = TradeHelper.ProcessMissingTrades(DateTime.Now, DateTime.Now.AddDays(-2), energyValues).ToList();
			Assert.Equal(99, energyValues.Count);
		}

		[Fact]
		public void TestProcessMissingTrades_ReturnsExc()
		{
			var energyValues = new List<decimal> { 1, 2, 3 };
			Assert.Throws<InvalidTradeDataException>(() => TradeHelper.ProcessMissingTrades(DateTime.Now.AddDays(-2), DateTime.Now, energyValues));
		}

		[Fact]
		public void TestIsInterconnectorFlow()
		{
			Assert.True(TradeHelper.IsInterconnectorFlow("TransmissionICMarketOperator", "Elexon"));
			Assert.False(TradeHelper.IsInterconnectorFlow("Operator1", "Operator2"));
		}

		[Fact]
		public void TestGetLocalTimeZoneIdByMarket_Default()
		{
			Assert.Equal("Central European Standard Time", TradeHelper.GetLocalTimeZoneIdByMarket("UnknownMarket"));
		}

		[Fact]
		public void TestGetTopicName()
		{
			Assert.Equal(KafkaTopicNames.ProfileTrans, TradeHelper.GetTopicName(TradeType.TRANSMISSION));
			Assert.Equal(KafkaTopicNames.Delete, TradeHelper.GetTopicName(TradeType.DELETE));
			Assert.Throws<NotFoundException>(() => TradeHelper.GetTopicName((TradeType)999));
		}

		[Fact]
		public void TestDetermineBalancingGroups_BuyTransaction()
		{
			var result = TradeHelper.DetermineBalancingGroups("buy", "CounterParty");
			Assert.Equal(TradeConstants.ShellBalancingGroupId, result.Item1);
			Assert.Equal("CounterParty", result.Item2);
		}

		[Fact]
		public void TestDetermineBalancingGroups_SellTransaction()
		{
			var result = TradeHelper.DetermineBalancingGroups("sell", "CounterParty");
			Assert.Equal("CounterParty", result.Item1);
			Assert.Equal(TradeConstants.ShellBalancingGroupId, result.Item2);
		}

		[Fact]
		public void TestEnrichVolumeArray()
		{
			decimal[] volumeArray = { 1, -2, 3 };
			var enrichedArray = TradeHelper.EnrichVolumeArray(volumeArray);
			Assert.Equal(new decimal[] { -1, 2, -3 }, enrichedArray);
		}

		[Fact]
		public void TestDeleteAllTrailingZeroVolumeRows()
		{
			string[] fileData = { "Row1,1,0", "0,0,0", "Row3,1,0", "0,0,0" };
			string[] expected = { "Row1,1,0", "0,0,0", "Row3,1,0" };
			var result = TradeHelper.DeleteAllTrailingZeroVolumeRows(fileData, 1, 3);
			Assert.Equal(expected, result);
		}

		[Fact]
		public void TestCheckIfAllQHValuesAreZero_True()
		{
			Assert.True(TradeHelper.CheckIfAllQHValuesAreZero("0,0,0", 0, 3));
		}

		[Fact]
		public void TestCheckIfAllQHValuesAreZero_False()
		{
			Assert.False(TradeHelper.CheckIfAllQHValuesAreZero("0,1,0", 0, 3));
		}

		[Fact]
		public void TestValidateAndDeserializeTradeJson_ValidJson()
		{
			string json = "{\"Property\":\"Value\"}";
			var result = TradeHelper.ValidateAndDeserializeTradeJson<Dictionary<string, string>>(json);
			Assert.NotNull(result);
			Assert.Equal("Value", result["Property"]);
		}

		[Fact]
		public void TestValidateAndDeserializeTradeJson_InvalidJson()
		{
			string json = "Invalid Json";
			Assert.Throws<JsonReaderException>(() => TradeHelper.ValidateAndDeserializeTradeJson<Dictionary<string, string>>(json));
		}

		[Fact]
		public void TestValidateAndDeserializeTradeJson_NullJson()
		{
			string json = null;
			Assert.Throws<ArgumentNullException>(() => TradeHelper.ValidateAndDeserializeTradeJson<string>(json));
		}

		[Fact]
		public void TestGenerateZeroVolumeTrades()
		{
			DateTime start = new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc);
			DateTime end = new DateTime(2020, 1, 2, 0, 0, 0, DateTimeKind.Utc);
			var result = TradeHelper.GenerateZeroVolumeTrades(start, end);
			Assert.Equal(96, result.Length); // 24 hours * 4 quarters per hour
			Assert.All(result, volume => Assert.Equal(0m, volume));
		}

		[Fact]
		public void TestGetPowerTrakMarketOp_KnownMarketOperatorBE_ELI()
		{
			string fromMarketOperator = "BE-ELI";
			string expected = "Elia";
			Assert.Equal(expected, TradeHelper.GetPowerTrakMarketOp(fromMarketOperator));
		}

		[Fact]
		public void TestGetPowerTrakMarketOp_KnownMarketOperatorDE_RWE()
		{
			string fromMarketOperator = "DE-RWE";
			string expected = "Amprion";
			Assert.Equal(expected, TradeHelper.GetPowerTrakMarketOp(fromMarketOperator));
		}

		[Fact]
		public void TestGetPowerTrakMarketOp_UnknownMarketOperator()
		{
			string fromMarketOperator = "UnknownOperator";
			string expected = "UnknownOperator";
			Assert.Equal(expected, TradeHelper.GetPowerTrakMarketOp(fromMarketOperator));
		}

		[Fact]
		public void TestGetPowerTrakMarketOp_CaseInsensitive()
		{
			string fromMarketOperator = "be-eli";
			string expected = "Elia";
			Assert.Equal(expected, TradeHelper.GetPowerTrakMarketOp(fromMarketOperator));
		}
	}
}
