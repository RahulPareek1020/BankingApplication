﻿using Shell.Energy.STPower.Shared;
using System;
using System.Globalization;
using Xunit;

namespace Shell.Energy.GBShortTerm.ServiceHelperTests
{
	public class DateTimeHelperTests
    {
        [Fact]
        public void SummerZoneDateTimeTests()
        {
            string localTimeZoneId = "Central European Standard Time";
            var result = DateTimeHelper.ConvertToUtcFromTimeZone(new DateTime(2023, 5, 23,0,0,0,DateTimeKind.Utc),localTimeZoneId);
            Assert.Equal(DateTime.Parse("2023-05-22T22:00:00",CultureInfo.InvariantCulture), result);
        }

        [Fact]
        public void WinterZoneDateTimeTests()
        {
            string localTimeZoneId = "Central European Standard Time";
            var result = DateTimeHelper.ConvertToUtcFromTimeZone(new DateTime(2023, 11, 23, 0, 0, 0, DateTimeKind.Utc),localTimeZoneId);
            Assert.Equal(DateTime.Parse("2023-11-22T23:00:00", CultureInfo.InvariantCulture), result);
        }

		[Fact]
		public void TrimMillisecondsFromTimeTests()
		{
            var date = new DateTime(2023, 11, 23, 2, 5, 56,DateTimeKind.Utc).AddTicks(1);
			var result = DateTimeHelper.TrimMillisecondsFromTime(date);
			Assert.Equal(DateTime.Parse("2023-11-23T02:05:56", CultureInfo.InvariantCulture), result);
		}
	}
}
