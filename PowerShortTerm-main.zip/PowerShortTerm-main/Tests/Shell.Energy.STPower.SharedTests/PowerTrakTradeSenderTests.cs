using Moq;
using Moq.Protected;
using Shell.Energy.STPower.Shared.PowerTrak;
using Microsoft.Extensions.Options;
using System.Net.Http;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using System.Xml.Linq;
using Assert = Xunit.Assert;
using Xunit;
using System;

namespace Shell.Energy.STPower.Shared.Tests
{

	public class PowerTrakTradeSenderTests
    {
        private Mock<IHttpClientFactory> _httpClientFactoryMock;
        private Mock<IAppLogger> _loggerMock;
        private PowerTrakConfig _powerTrakConfig;
        private PowerTrakTradeSender _powerTrakTradeSender;

        
        public PowerTrakTradeSenderTests()
        {
            _httpClientFactoryMock = new Mock<IHttpClientFactory>();
            var httpClientMock = new Mock<HttpClient>();
            _httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClientMock.Object);

            _loggerMock = new Mock<IAppLogger>();

            _powerTrakConfig = new PowerTrakConfig
            {
                BaseUrl = new System.Uri("http://example.com"),
                SubmitPowerTradesUrlPath = "/api/trades",
                AuthenticationUrlPath = "/api/auth",
                Username = "test",
                Password = "password",
                Role = "role"
            };

            var optionsMock = new Mock<IOptions<PowerTrakConfig>>();
            optionsMock.Setup(ap => ap.Value).Returns(_powerTrakConfig);

            _powerTrakTradeSender = new PowerTrakTradeSender(_httpClientFactoryMock.Object, optionsMock.Object, _loggerMock.Object);
        }

		[Fact]
		public async Task SubmitPowerTrades_ValidPowerTrades_ShouldCallApiAndReturnResult()
        {
            // Arrange
            var handlerMock = new Mock<HttpMessageHandler>();
            handlerMock.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent("<Response>Success</Response>"),
                })
                .Verifiable();

            var httpClient = new HttpClient(handlerMock.Object);
            _httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

            XElement powerTrades = new XElement("Trades");

            // Act
            var result = await _powerTrakTradeSender.SubmitPowerTrades(powerTrades,"samplejwt");

            // Assert
            Assert.NotNull(result);
            handlerMock.Protected().Verify(
                "SendAsync",
                Times.Exactly(1), // one for submitting trades
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>()
            );
        }

		[Fact]
		public async Task SubmitPowerTrades_InvalidPowerTrades_ShouldThrowException()
		{
			// Arrange
			var handlerMock = new Mock<HttpMessageHandler>();
			handlerMock.Protected()
				.Setup<Task<HttpResponseMessage>>(
					"SendAsync",
					ItExpr.IsAny<HttpRequestMessage>(),
					ItExpr.IsAny<CancellationToken>()
				)
				.ReturnsAsync(new HttpResponseMessage
				{
					StatusCode = HttpStatusCode.BadRequest,
					Content = new StringContent("<Response>Error</Response>"),
				})
				.Verifiable();

			var httpClient = new HttpClient(handlerMock.Object);
			_httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

			XElement powerTrades = new XElement("InvalidTrades");

			// Act & Assert
			await Assert.ThrowsAsync<Exception>(() => _powerTrakTradeSender.SubmitPowerTrades(powerTrades,"samplejwt"));
		}

		[Fact]
		public async Task GetJwtString_ValidCredentials_ShouldReturnJwtString()
		{
			// Arrange
			var expectedJwt = "valid.jwt.token";
			var handlerMock = new Mock<HttpMessageHandler>();
			handlerMock.Protected()
				.Setup<Task<HttpResponseMessage>>(
					"SendAsync",
					ItExpr.IsAny<HttpRequestMessage>(),
					ItExpr.IsAny<CancellationToken>()
				)
				.ReturnsAsync(new HttpResponseMessage
				{
					StatusCode = HttpStatusCode.OK,
					Content = new StringContent(expectedJwt),
				})
				.Verifiable();

			var httpClient = new HttpClient(handlerMock.Object);
			_httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

			// Act
			var jwtString = await _powerTrakTradeSender.GetJwtString();

			// Assert
			Assert.Equal(expectedJwt, jwtString);
		}

		[Fact]
		public async Task GetJwtString_InvalidCredentials_ShouldThrowException()
		{
			// Arrange
			var handlerMock = new Mock<HttpMessageHandler>();
			handlerMock.Protected()
				.Setup<Task<HttpResponseMessage>>(
					"SendAsync",
					ItExpr.IsAny<HttpRequestMessage>(),
					ItExpr.IsAny<CancellationToken>()
				)
				.ReturnsAsync(new HttpResponseMessage
				{
					StatusCode = HttpStatusCode.Unauthorized,
					Content = new StringContent("Unauthorized"),
				})
				.Verifiable();

			var httpClient = new HttpClient(handlerMock.Object);
			_httpClientFactoryMock.Setup(x => x.CreateClient(It.IsAny<string>())).Returns(httpClient);

			// Act & Assert
			await Assert.ThrowsAsync<Exception>(() => _powerTrakTradeSender.GetJwtString());
		}

	}
}
