using Moq;
using NSubstitute;
using Shell.Energy.STPower.Integration.PwrTrak.Adapter.Tests;
using Shell.Energy.STPower.Service.PowerTrak.TradeTransformer.Interfaces;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Enums;
using Shell.Energy.STPower.Shared.Exceptions;

namespace Shell.Energy.STPower.Integration.PwrTrak.Adapter.Functions.Tests
{
	public class TransformETRMtoNominationXMLActivityTests
	{
		private readonly TransformETRMtoNominationXMLActivity _activity;
		private ITransformTradeDataService _transformDataService;
		private readonly Mock<IAppLogger> _loggerMock = new Mock<IAppLogger>();
		

		public TransformETRMtoNominationXMLActivityTests()
		{
			
			_transformDataService = Substitute.For<ITransformTradeDataService>();
			_activity = new TransformETRMtoNominationXMLActivity(_transformDataService, _loggerMock.Object);
		}
		[Fact]
		public async Task Run_WhenConvertEtrmToBelvisFormatThrowsInvalidTradeDataException_ReturnsNull()
		{
			var kafkaMessage = new KafkaSNEMessage { Message = "ValidMessage", MessageTradeType = Shared.Enums.TradeType.BASELOAD, Market = "ValidMarket" };
			_transformDataService.When(x => x.ConvertTradeMessageToPowerTrakFormat(kafkaMessage.Message, kafkaMessage.MessageTradeType)).Do(x => { throw new InvalidTradeDataException(); });
			var result = await _activity.Run(kafkaMessage);
			Assert.Null(result);
		}

		[Fact]
		public async Task Run_WhenConvertEtrmToBelvisFormatThrowsNotFoundException_ReturnsNull()
		{
			var kafkaMessage = new KafkaSNEMessage { Message = "ValidMessage", MessageTradeType = TradeType.TRANSMISSION, Market = "ValidMarket" };
			_transformDataService.When(x => x.ConvertTradeMessageToPowerTrakFormat(kafkaMessage.Message, kafkaMessage.MessageTradeType)).Do(x => { throw new NotFoundException(); });
			var result = await _activity.Run(kafkaMessage);
			Assert.Null(result);
		}

		[Fact]
		public async Task Run_WhenKafkaMessageIsValid_ReturnsBelvisMessageDto()
		{
			var kafkaMessage = new KafkaSNEMessage { Message = "ValidMessage", MessageTradeType = TradeType.PROFILE, Market = "ValidMarket" };
			_transformDataService.ConvertTradeMessageToPowerTrakFormat(kafkaMessage.Message, kafkaMessage.MessageTradeType).Returns("<xml><PowerTrak</xml>");
			var result = await _activity.Run(kafkaMessage);
			Assert.Equal("<xml><PowerTrak</xml>", result);
		}

		[Fact]
		public async Task Run_WhenConvertEtrmToBelvisFormat_ReturnsNull()
		{
			var kafkaMessage = new KafkaSNEMessage { Message = "", MessageTradeType = Shared.Enums.TradeType.BASELOAD, Market = "ValidMarket" };
			var result = await _activity.Run(kafkaMessage);
			Assert.Equal(string.Empty, result);
		}

		[Fact]
		public async Task Run_WhenConvertEtrmToBelvisFormat2_ReturnsNull()
		{
			var kafkaMessage = new KafkaSNEMessage { Message = PowerTrakResource.KafkaPowerMessage, MessageTradeType = Shared.Enums.TradeType.PROFILETRANS };
			var result = await _activity.Run(kafkaMessage);
			Assert.Equal(string.Empty, result);
		}
	}
}
