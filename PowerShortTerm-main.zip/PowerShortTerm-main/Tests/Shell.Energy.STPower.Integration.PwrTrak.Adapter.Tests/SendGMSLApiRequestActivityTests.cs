using System.Xml.Linq;
using NSubstitute;
using Shell.Energy.STPower.Shared;

namespace Shell.Energy.STPower.Integration.PwrTrak.Adapter.Functions.Tests
{
    public class SendGMSLApiRequestActivityTests
    {
        private readonly IPowerTrakTradeSender _powerTrakTradeSender = Substitute.For<IPowerTrakTradeSender>();
        private readonly IAppLogger _logger = Substitute.For<IAppLogger>();
        private readonly SendGMSLApiRequestActivity _activity;

        public SendGMSLApiRequestActivityTests()
        {
            _activity = new SendGMSLApiRequestActivity(_powerTrakTradeSender, _logger);
        }

        [Fact]
        public async Task RunAsync_SuccessfulRequest_LogsStartAndCompletion()
        {
            // Arrange
            string xmlContent = "<Trade></Trade>";
            var expectedResult = XElement.Parse("<Response></Response>");
			_powerTrakTradeSender.SubmitPowerTrades(Arg.Any<XElement>(), Arg.Any<string>()).Returns(expectedResult);

            // Act
            var result = await _activity.RunAsync(new GMSLApiRequestDto(xmlContent,""));

            // Assert
            await _powerTrakTradeSender.Received(1).SubmitPowerTrades(Arg.Any<XElement>(), Arg.Any<string>());
        }

        [Fact]
        public async Task RunAsync_ReturnNull()
        {
            // Arrange
            string xmlContent = "<Trade></Trade>";
			_powerTrakTradeSender.SubmitPowerTrades(Arg.Any<XElement>(), Arg.Any<string>()).Returns(Task.FromResult<XElement>(null));

			// Act
			var result = await _activity.RunAsync(new GMSLApiRequestDto(xmlContent, ""));

			// Assert
			Assert.Null(result);
		}
    }
}
