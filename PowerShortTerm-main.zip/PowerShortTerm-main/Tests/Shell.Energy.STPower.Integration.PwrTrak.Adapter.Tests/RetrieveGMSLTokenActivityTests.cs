using Microsoft.AspNetCore.Http;
using NSubstitute;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.PowerTrak;

namespace Shell.Energy.STPower.Integration.PwrTrak.Adapter.Functions.Tests
{
    public class RetrieveGMSLTokenActivityTests
    {
        private readonly IPowerTrakTradeSender _powerTrakTradeSender = Substitute.For<IPowerTrakTradeSender>();
        private readonly IAppLogger _logger = Substitute.For<IAppLogger>();
        private readonly RetrieveGMSLTokenActivity _sut;

        public RetrieveGMSLTokenActivityTests()
        {
            _sut = new RetrieveGMSLTokenActivity(_powerTrakTradeSender, _logger);
        }

        [Fact]
        public async Task RunAsync_ShouldReturnJwtToken()
        {
            // Arrange
            var expectedToken = "jwtToken";
            _powerTrakTradeSender.GetJwtString().Returns(Task.FromResult(expectedToken));
            var mockHttpRequest = Substitute.For<HttpRequest>();

            // Act
            var result = await _sut.RunAsync(mockHttpRequest);

            // Assert
            Assert.Equal(expectedToken, result);
        }

        [Fact]
        public async Task RunAsync_ShouldReturnNull()
        {
			// Arrange
			_powerTrakTradeSender.GetJwtString().Returns(Task.FromResult<string>(null));
			var mockHttpRequest = Substitute.For<HttpRequest>();

			// Act
			var result = await _sut.RunAsync(mockHttpRequest);

			// Assert
			Assert.Null(result);
		}
    }
}
