using Shell.Energy.STPower.Service.KafkaConsumer;
using Shell.Energy.STPower.Shared;
using NSubstitute;
using Shell.Energy.STPower.Shared.Constants;

namespace Shell.Energy.STPower.Integration.PwrTrak.Adapter.Functions.Tests
{
	public class KafkaConsumerActivityTests
	{
		private KafkaConsumerActivity _kafkaConsumerActivity;
		private IEtrmConsumer _etrmConsumer;
		private IAppLogger _logger;

		public KafkaConsumerActivityTests()
		{
			_etrmConsumer = Substitute.For<IEtrmConsumer>();
			_logger = Substitute.For<IAppLogger>();
			_kafkaConsumerActivity = new KafkaConsumerActivity(_logger, _etrmConsumer);
		}

		[Fact]
		public async Task GetKafkaMessagesAsync_WhenConsumeMessageThrowsException_ThrowsException()
		{
			var topicName = "ValidTopicName";
			_etrmConsumer.When(x => x.ConsumeMessage(topicName)).Do(x => { throw new Exception(); });
			await Assert.ThrowsAsync<Exception>(() => _kafkaConsumerActivity.GetKafkaMessagesAsync(topicName));
		}

		[Fact]
		public async Task GetKafkaMessagesAsync_WhenTopicNameIsValid_ReturnsMessages()
		{
			var topicName = TradeHelper.GetTopicName(Shell.Energy.STPower.Shared.Enums.TradeType.BASELOAD);
			_etrmConsumer.ConsumeMessage(topicName).Returns("ValidMessages");
			var result = await _kafkaConsumerActivity.GetKafkaMessagesAsync(topicName);
			Assert.Equal("ValidMessages", result);
		}
		[Fact]
	    public async Task GetKafkaMessagesAsync_WhenTopicNameIsNull_ReturnsEmpty()
	    {
			var result= await _kafkaConsumerActivity.GetKafkaMessagesAsync(null);
			Assert.NotNull(result);
	        Assert.Empty(result);
	    }

	    [Fact]
	    public async Task GetKafkaMessagesAsync_WhenTopicNameIsEmpty_ReturnsEmpty()
	    {
			var result = await _kafkaConsumerActivity.GetKafkaMessagesAsync(string.Empty);
			Assert.NotNull(result);
			Assert.Empty(result);
		}

	    [Fact]
	    public async Task GetKafkaMessagesAsync_LogsStartedAndCompletedProcessing()
	    {
	        var topicName = "TestTopic";
	        _etrmConsumer.ConsumeMessage(topicName).Returns("TestMessages");

	        await _kafkaConsumerActivity.GetKafkaMessagesAsync(topicName);

	        Received.InOrder(() =>
	        {
	            _logger.LogInformation($"KafkaConsumerActivity {LogMessages.StartedProcessing} for topic {topicName}");
	            _logger.LogInformation($"KafkaConsumerActivity {LogMessages.CompletedProcessing} for topic {topicName}");
	        });
	    }
	}
}
