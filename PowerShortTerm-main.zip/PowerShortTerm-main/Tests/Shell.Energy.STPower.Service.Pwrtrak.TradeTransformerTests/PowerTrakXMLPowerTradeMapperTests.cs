using Shell.Energy.STPower.Service.PowerTrak.TradeTransformer.DTO;
using Shell.Energy.STPower.Service.PowerTrak.TradeTransformer.PwrTrakXMLModels;
using Shell.Energy.STPower.Service.PowerTrak.TradeTransformer.XML;
using System.Globalization;

namespace Shell.Energy.STPower.Service.PowerTrak.TradeTransformer.Tests.XML
{
    public class PowerTrakXMLPowerTradeMapperTests
    {
        [Fact]
        public void MapPowerTrakContent_WithValidInput_ShouldReturnValidXML()
        {
            // Arrange
            var mapper = new PowerTrakXmlPowerTradeMapper();
            var tradeDate = DateTime.UtcNow;
			var powerTrakTradeDTOs = new List<PowerTrakTradeDto>
			{
				new PowerTrakTradeDto
				{
					Reference = "Ref1",
					TransactionType = "Buy",
					Counterparty = "Counterparty1",
					FromMarketOperator = "Operator1",
					CustomShape = new CustomShape
					{
						Interval = new List<Interval>
						{
							new Interval
							{
								StartDateTime = tradeDate,
								EndDateTime = tradeDate.AddMinutes(15),
								Volume = 1
							}
						}
					},
					TradeDate = tradeDate
				}
			};

			// Act
			var result = mapper.MapPowerTrakContent(powerTrakTradeDTOs).Replace("\r\n","");

            // Assert
            Assert.Contains("<PowerTrak", result);
            Assert.Contains("<Reference>Ref1</Reference>", result);
            Assert.Contains("<TransactionType>Buy</TransactionType>", result);
            Assert.Contains("<Counterparty>Counterparty1</Counterparty>", result);
            Assert.Contains("<MarketOperator>Operator1</MarketOperator>", result);
            Assert.Contains("<CustomShape>", result);
            Assert.Contains($"<TradeDate>{tradeDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)}</TradeDate>", result);
        }

        [Fact]
        public void MapPowerTrakContent_WithEmptyList_ShouldReturnEmptyTradesXML()
        {
            // Arrange
            var mapper = new PowerTrakXmlPowerTradeMapper();
            var powerTrakTradeDTOs = new List<PowerTrakTradeDto>();

            // Act
            var result = mapper.MapPowerTrakContent(powerTrakTradeDTOs);

            // Assert
            Assert.Contains("<Trades />", result);
        }
    }
}
