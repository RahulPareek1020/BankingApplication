using NSubstitute;
using Shell.Energy.STPower.Service.PowerTrak.TradeTransformer.DTO;
using Shell.Energy.STPower.Service.PowerTrak.TradeTransformer.Interfaces;

namespace Shell.Energy.STPower.Service.PowerTrak.TradeTransformer.Tests
{
	public class ETRMTradeProcessorTests
    {
        private readonly IEtrmTradeTransformer _etrmTradeTransformer = Substitute.For<IEtrmTradeTransformer>();
        private readonly IPowerTrakXmlTradeMapper _powerTrakXMLTradeMapper = Substitute.For<IPowerTrakXmlTradeMapper>();
        private readonly EtrmTradeProcessor _etrmTradeProcessor;

        public ETRMTradeProcessorTests()
        {
            _etrmTradeProcessor = new EtrmTradeProcessor(_etrmTradeTransformer, _powerTrakXMLTradeMapper);
        }

        [Fact]
        public void ConvertETRMDataToPowerTrakXml_WithValidTradeData_ShouldReturnXMLContent()
        {
            // Arrange
            string tradeData = "validTradeData";
            var powerTrakTradeDTOs = new List<PowerTrakTradeDto> { new PowerTrakTradeDto() };
            string expectedXMLContent = "<PowerTrakXML></PowerTrakXML>";

            _etrmTradeTransformer.TransformTradeData(tradeData).Returns(powerTrakTradeDTOs);
            _powerTrakXMLTradeMapper.MapPowerTrakContent(powerTrakTradeDTOs).Returns(expectedXMLContent);

            // Act
            var result = _etrmTradeProcessor.ConvertEtrmDataToPowerTrakXml(tradeData);

            // Assert
            Assert.Equal(expectedXMLContent, result);
        }

        [Fact]
        public void ConvertETRMDataToPowerTrakXml_WithNoTradeData_ShouldReturnNull()
        {
            // Arrange
            string tradeData = "noTradeData";
            List<PowerTrakTradeDto>? powerTrakTradeDTOs = null;

            _etrmTradeTransformer.TransformTradeData(tradeData).Returns(powerTrakTradeDTOs);

            // Act
            var result = _etrmTradeProcessor.ConvertEtrmDataToPowerTrakXml(tradeData);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public void ConvertETRMDataToPowerTrakXml_WithEmptyTradeDataList_ShouldReturnNull()
        {
            // Arrange
            string tradeData = "emptyTradeDataList";
            var powerTrakTradeDTOs = new List<PowerTrakTradeDto>();

            _etrmTradeTransformer.TransformTradeData(tradeData).Returns(powerTrakTradeDTOs);

            // Act
            var result = _etrmTradeProcessor.ConvertEtrmDataToPowerTrakXml(tradeData);

            // Assert
            Assert.Null(result);
        }
    }
}
