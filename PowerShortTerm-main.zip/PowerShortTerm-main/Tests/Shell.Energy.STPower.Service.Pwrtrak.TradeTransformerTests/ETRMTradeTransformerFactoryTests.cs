using NSubstitute;
using Shell.Energy.STPower.Service.PowerTrak.TradeTransformer.TradeTransformers;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Constants;
using Shell.Energy.STPower.Shared.Enums;
using Shell.Energy.STPower.Shared.Exceptions;

namespace Shell.Energy.STPower.Service.PowerTrak.TradeTransformer.Tests.TradeTransformers
{
	public class ETRMTradeTransformerFactoryTests
    {
		private readonly IAppLogger logger = Substitute.For<IAppLogger>();
		[Fact]
        public void Create_WithPowerTradeTransformerType_ShouldReturnPowerTransTradeTransformer()
        {
            // Arrange
            var factory = new EtrmTradeTransformerFactory(logger);

            // Act
            var transformer = factory.Create(PwrTrakTradeTransformerType.PowerTradeTransformer);

            // Assert
            Assert.IsType<PowerTransTradeTransformer>(transformer);
        }

        [Fact]
        public void Create_WithUnsupportedTradeTransformerType_ShouldThrowNotFoundException()
        {
            // Arrange
            var factory = new EtrmTradeTransformerFactory(logger);
            var unsupportedType = (PwrTrakTradeTransformerType)999; // Assuming 999 is not a supported type

            // Act & Assert
            var exception = Assert.Throws<NotFoundException>(() => factory.Create(unsupportedType));
            Assert.Contains(ResponseMessages.InvalidTradeTransformerType, exception.Message);
        }
    }
}
