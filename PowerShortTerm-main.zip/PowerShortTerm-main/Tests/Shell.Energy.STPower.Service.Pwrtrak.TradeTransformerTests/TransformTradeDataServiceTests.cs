using Shell.Energy.STPower.Service.PowerTrak.TradeTransformer;
using Shell.Energy.STPower.Service.PowerTrak.TradeTransformer.Interfaces;
using Shell.Energy.STPower.Service.PowerTrak.TradeTransformer.TradeTransformers;
using Shell.Energy.STPower.Shared.Enums;
using Shell.Energy.STPower.Shared.Exceptions;
using Shell.Energy.STPower.Shared;
using NSubstitute;
using Newtonsoft.Json;
using Shell.Energy.STPower.Shared.Constants;

namespace Shell.Energy.STPower.Service.Pwrtrak.TradeTransformerTests
{
	public class TransformTradeDataServiceTests
	{
		private readonly IAppLogger _logger = Substitute.For<IAppLogger>();
		private readonly IEtrmTradeTransformerFactory _tradeTransformerFactory = new EtrmTradeTransformerFactory(Substitute.For<IAppLogger>());
		private readonly TransformTradeDataService _service;

		public TransformTradeDataServiceTests()
		{
			_service = new TransformTradeDataService(_logger, _tradeTransformerFactory);
		}

		[Fact]
		public void ValidInput_ReturnsPowerTrakFormat()
		{
			var message = JsonConvert.DeserializeObject<KafkaSNEMessage>(PwrTrakResource.KafkaPowerMessage);
			var xml = _service.ConvertTradeMessageToPowerTrakFormat(message.Message, message.MessageTradeType);
			Assert.NotNull(xml);
			// Assert
			Assert.Equal(PwrTrakResource.KafkaPowerMessage_Output, xml);
		}

		[Fact]
		public void ValidInputSummer_ReturnsPowerTrakFormat()
		{
			var message = JsonConvert.DeserializeObject<KafkaSNEMessage>(PwrTrakResource.KafkaPowerMessage_Summer);
			var xml = _service.ConvertTradeMessageToPowerTrakFormat(message.Message, message.MessageTradeType);

			Assert.NotNull(xml);
			// Assert
			Assert.Equal(PwrTrakResource.KafkaPowerMessage_SummerOutput, xml);
		}

		[Fact]
		public void ValidInputSummerWith2Counterparties_ReturnsPowerTrakFormat()
		{
			var message = JsonConvert.DeserializeObject<KafkaSNEMessage>(PwrTrakResource.KafkaPowerMessage_Summer_2CounterParties);
			var xml = _service.ConvertTradeMessageToPowerTrakFormat(message.Message, message.MessageTradeType);

			// Assert
			Assert.Equal(PwrTrakResource.KafkaPowerMessage_Summer_2CounterParties_Output, xml);
		}

		[Fact]
		public void InvalidTopicMessage_ThrowsInvalidTradeDataException()
		{
			// Arrange
			string topicMessage = "";
			TradeType tradeType = TradeType.PROFILE;

			// Act & Assert
			var exception = Assert.Throws<InvalidTradeDataException>(() => _service.ConvertTradeMessageToPowerTrakFormat(topicMessage, tradeType));
			Assert.Contains(ResponseMessages.TradeDataGenerationError, exception.Message);
		}

		[Fact]
		public void InvalidMessageValue_ReturnsEmptyString()
		{
			// Arrange
			string topicMessage = PwrTrakResource.KafkaPowerMessage_ValueEmpty;
			TradeType tradeType = TradeType.PROFILE;

			// Act & Assert
			Assert.Null(_service.ConvertTradeMessageToPowerTrakFormat(topicMessage, tradeType));
		}

		[Fact]
		public void EmptyMessageValue_ReturnsEmptyString()
		{
			// Arrange
			string topicMessage = PwrTrakResource.KafkaPowerMessage_Empty;
			TradeType tradeType = TradeType.PROFILE;

			// Act & Assert
			Assert.Null(_service.ConvertTradeMessageToPowerTrakFormat(topicMessage, tradeType));
		}

		[Fact]
		public void UnsupportedTradeType_ThrowsNotFoundException()
		{
			// Arrange
			string topicMessage = "Valid ETRM Data";
			TradeType tradeType = (TradeType)(-1); // Invalid trade type

			// Act & Assert
			var exception = Assert.Throws<NotFoundException>(() => _service.ConvertTradeMessageToPowerTrakFormat(topicMessage, tradeType));
			Assert.Contains(ResponseMessages.InvalidTradeType, exception.Message);
		}
	}
}