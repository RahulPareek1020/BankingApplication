using Shell.Energy.STPower.Service.PowerTrak.TradeTransformer.XML;
using Shell.Energy.STPower.Shared.Enums;
using Shell.Energy.STPower.Shared.Exceptions;

namespace Shell.Energy.STPower.Service.PowerTrak.TradeTransformer.Tests.XML
{
	public class PowerTrakXMLTradeMapperTests
    {
        [Fact]
        public void Constructor_WithPowerTradeTransformerType_ShouldInstantiatePowerTrakXMLPowerTradeMapper()
        {
            // Arrange & Act
            var mapper = new PowerTrakXmlTradeMapper(PwrTrakTradeTransformerType.PowerTradeTransformer);

            // Assert
            Assert.IsType<PowerTrakXmlPowerTradeMapper>(mapper.PowerTrakTradeMapper);
        }

        [Fact]
        public void Constructor_WithUnsupportedTradeTransformerType_ShouldThrowNotFoundException()
        {
            // Arrange, Act & Assert
            var exception = Assert.Throws<NotFoundException>(() => new PowerTrakXmlTradeMapper((PwrTrakTradeTransformerType)999));
            Assert.Contains("TradeTransformerType 999 is not supported.", exception.Message);
        }
    }
}
