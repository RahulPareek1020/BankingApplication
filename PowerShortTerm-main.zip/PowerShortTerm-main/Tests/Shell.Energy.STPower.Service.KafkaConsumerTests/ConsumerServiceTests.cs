﻿using Microsoft.Extensions.Options;
using NSubstitute;
using Shell.Energy.Kafka.Options;
using Shell.Energy.Kafka;
using Shell.Energy.STPower.Service.KafkaConsumer;
using Shell.Energy.STPower.Shared;
using Microsoft.Extensions.Configuration;
using Confluent.Kafka;
using Shell.Energy.Kafka.Models;
using Shell.Energy.STPower.Shared.Enums;
using Shell.Energy.STPower.Service.KafkaProducer.Schema;

namespace Shell.Energy.STPower.Service.KafkaConsumerTests
{
	public class ConsumerServiceTests
	{
		private readonly IKafkaConsumerBuilder<AligneRawTradeSchema_Key, AligneRawTradeSchema> _eventBackboneConsumerBuilder;
        private readonly IAppLogger _logger;
		private readonly KafkaOAuthAppOptions _kafkaOAuthAppOptions;
		private readonly SchemaRegistryAuthenticationOptions _schemaRegistryAuthenticationOptions;

		public ConsumerServiceTests()
		{
			_eventBackboneConsumerBuilder = Substitute.For<IKafkaConsumerBuilder<AligneRawTradeSchema_Key, AligneRawTradeSchema>>();
            _logger = Substitute.For<IAppLogger>();
			_kafkaOAuthAppOptions = new KafkaOAuthAppOptions();
			_schemaRegistryAuthenticationOptions = new SchemaRegistryAuthenticationOptions();
		}

		[Fact]
		public void ConsumerService_Constructor_InitializesDependencies()
		{
			var inMemorySettings = new Dictionary<string, string>
			{{"KafkaConsumer:WaitTimeForMessagesInSeconds", "1"}};

			IConfiguration config = new ConfigurationBuilder()
				.AddInMemoryCollection(inMemorySettings)
				.Build();
			var consumerService = new ConsumerService<AligneRawTradeSchema_Key, AligneRawTradeSchema>(
				_eventBackboneConsumerBuilder,
				Options.Create(_kafkaOAuthAppOptions),
				Options.Create(_schemaRegistryAuthenticationOptions),
				_logger,
				config);

			Assert.NotNull(consumerService);
		}
        

        [Fact]
		public void Consume_ConsumesMessagesFromTopic()
		{
			var inMemorySettings = new Dictionary<string, string>
			{{"KafkaConsumer:WaitTimeForMessagesInSeconds", "1"}};

			IConfiguration config = new ConfigurationBuilder()
				.AddInMemoryCollection(inMemorySettings)
				.Build();
			var consumerService = new ConsumerService<AligneRawTradeSchema_Key, AligneRawTradeSchema>(
				_eventBackboneConsumerBuilder,
				Options.Create(_kafkaOAuthAppOptions),
				Options.Create(_schemaRegistryAuthenticationOptions),
				_logger,
				config);
			var consumer = Substitute.For<IKafkaConsumer<AligneRawTradeSchema_Key, AligneRawTradeSchema>>();
			var topicName = "testTopic";
			var tradeType = TradeType.AligneRawTrade;
			var schema = new AligneRawTradeSchema();

            var consumeResult = new ConsumeResult<AligneRawTradeSchema_Key, AligneRawTradeSchema>
			{
				Message = new Message<AligneRawTradeSchema_Key, AligneRawTradeSchema>
				{
					Key = new AligneRawTradeSchema_Key(),
					Value = schema
				}
			};
			consumer.Receive(Arg.Any<ConsumerTraceMetadata>()).Returns(consumeResult);

			// Act
			var result = consumerService.Consume(consumer, topicName);

			// Assert
			Assert.NotNull(result);
			consumer.Received().Subscribe(topicName);
			consumer.Received().Receive(Arg.Any<ConsumerTraceMetadata>());
		}        
    }

}
