using NSubstitute;
using Shell.Energy.Kafka;
using Shell.Energy.STPower.Service.KafkaConsumer;
using Shell.Energy.STPower.Service.KafkaProducer.Schema;
using Shell.Energy.STPower.Shared.Exceptions;

namespace Shell.Energy.STPower.Service.KafkaConsumerTests
{
    public class ETRMConsumerTests
	{
		private readonly IServiceProvider _serviceProvider;
		private readonly EtrmConsumer _consumer;

		public ETRMConsumerTests()
		{
			_serviceProvider = Substitute.For<IServiceProvider>();
			_consumer = new EtrmConsumer(_serviceProvider);
		}
        [Fact]
        public void ConsumeMessage_ReturnsNull_WhenConsumerServiceIsNull()
        {
            // Arrange
            _serviceProvider
                .GetService(typeof(IConsumerService<AligneRawTradeSchema_Key, AligneRawTradeSchema>))
                .Returns(null);

            // Act
            var result = _consumer.ConsumeMessage("test-topic");

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public void ConsumeMessage_ReturnsConsumedMessage_WhenConsumerServiceIsAvailable()
        {
            // Arrange
            var expectedMessage = "test-message";
            var consumerService = Substitute.For<IConsumerService<AligneRawTradeSchema_Key, AligneRawTradeSchema>>();
            var kafkaConsumer = Substitute.For<IKafkaConsumer<AligneRawTradeSchema_Key, AligneRawTradeSchema>>();

            consumerService.BuildConsumer().Returns(kafkaConsumer);
            consumerService.Consume(kafkaConsumer, "test-topic").Returns(expectedMessage);

            _serviceProvider
                .GetService(typeof(IConsumerService<AligneRawTradeSchema_Key, AligneRawTradeSchema>))
                .Returns(consumerService);

            // Act
            var result = _consumer.ConsumeMessage("test-topic");

            // Assert
            Assert.Equal(expectedMessage, result);
        }
    }
}