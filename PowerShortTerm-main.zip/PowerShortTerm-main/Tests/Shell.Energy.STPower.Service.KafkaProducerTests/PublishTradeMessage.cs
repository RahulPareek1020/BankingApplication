using Moq;
using NUnit.Framework;
using Shell.Energy.STPower.Data.Common.Model;
using Assert = Xunit.Assert;

namespace Shell.Energy.STPower.Service.KafkaProducer.Tests
{
    [TestFixture]
    public class KafkaMessageProducerTests
    {
        private Mock<IServiceProvider>? _serviceProviderMock;
        private Mock<IKafkaMessageProducer>? _kafkaMessageProducerAligneRawTradeMock;


        public KafkaMessageProducerTests()
        {
            _serviceProviderMock = new Mock<IServiceProvider>();
            _kafkaMessageProducerAligneRawTradeMock = new Mock<IKafkaMessageProducer>();
        }

        [Fact]
        public async Task ProduceKafkaMessage_AligneRawTrade()
        {
            // Arrange
            var aligneRawTradeData = new List<AligneRawTrade>();
            AligneRawTrade aligneRawTrade = new AligneRawTrade();
            aligneRawTrade.Reference = "123456";
            aligneRawTradeData.Add(aligneRawTrade);
            // Act
            if (_kafkaMessageProducerAligneRawTradeMock != null)
            {
                await _kafkaMessageProducerAligneRawTradeMock.Object.ProduceKafkaMessage(aligneRawTradeData);
            }

            // Assert
            Assert.Equal("123456", aligneRawTrade.Reference);
        }
    }
}
