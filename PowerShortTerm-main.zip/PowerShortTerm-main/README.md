## Power Short Term Project Status
[![Quality gate](https://sesvc.shell.com/api/project_badges/quality_gate?project=com.shell.PowerShortTerm&token=sqb_6c322006e33ca88e15bf9e62f3993b21ef1743bd)](https://sesvc.shell.com/dashboard?id=com.shell.PowerShortTerm)

[![Bugs](https://sesvc.shell.com/api/project_badges/measure?project=com.shell.PowerShortTerm&token=sqb_6c322006e33ca88e15bf9e62f3993b21ef1743bd&metric=bugs)](https://sesvc.shell.com/dashboard?id=com.shell.PowerShortTerm)
[![Reliability Rating](https://sesvc.shell.com/api/project_badges/measure?project=com.shell.PowerShortTerm&token=sqb_6c322006e33ca88e15bf9e62f3993b21ef1743bd&metric=reliability_rating)](https://sesvc.shell.com/dashboard?id=com.shell.PowerShortTerm)
[![Maintainability Rating](https://sesvc.shell.com/api/project_badges/measure?project=com.shell.PowerShortTerm&token=sqb_6c322006e33ca88e15bf9e62f3993b21ef1743bd&metric=sqale_rating)](https://sesvc.shell.com/dashboard?id=com.shell.PowerShortTerm)
[![Security Rating](https://sesvc.shell.com/api/project_badges/measure?project=com.shell.PowerShortTerm&token=sqb_6c322006e33ca88e15bf9e62f3993b21ef1743bd&metric=security_rating)](https://sesvc.shell.com/dashboard?id=com.shell.PowerShortTerm)
[![Security Hotspots](https://sesvc.shell.com/api/project_badges/measure?project=com.shell.PowerShortTerm&token=sqb_6c322006e33ca88e15bf9e62f3993b21ef1743bd&metric=security_hotspots)](https://sesvc.shell.com/dashboard?id=com.shell.endur-integration-dotnet)
[![Coverage](https://sesvc.shell.com/api/project_badges/measure?project=com.shell.PowerShortTerm&token=sqb_6c322006e33ca88e15bf9e62f3993b21ef1743bd&metric=coverage)](https://sesvc.shell.com/dashboard?id=com.shell.PowerShortTerm)
[![Duplicated Lines (%)](https://sesvc.shell.com/api/project_badges/measure?project=com.shell.PowerShortTerm&token=sqb_6c322006e33ca88e15bf9e62f3993b21ef1743bd&metric=duplicated_lines_density)](https://sesvc.shell.com/dashboard?id=com.shell.PowerShortTerm)



## How to contribute
Refer [Contribute](./CONTRIBUTION.md) page to get more info on how to contribute.