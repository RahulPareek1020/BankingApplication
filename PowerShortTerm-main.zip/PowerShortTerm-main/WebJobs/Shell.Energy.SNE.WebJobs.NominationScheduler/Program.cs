﻿using Hangfire;
using Hangfire.SqlServer;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Shell.Energy.SNE.WebJobs.NomScheduler.Modules;
using Shell.Energy.STPower.Shared.Auth;
using Shell.Energy.STPower.Shared.Modules;
using Shell.Stratos.DotNet.SDK.KeyVault;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Shell.Energy.SNE.WebJobs.NomScheduler
{
    // To learn more about Microsoft Azure WebJobs SDK, please see https://go.microsoft.com/fwlink/?linkid=2250384
    public class Program
    {
        private const string STPowerConnectionStringName = "STPowerConnString";
        // Please set AzureWebJobsStorage connection strings in appsettings.json for this WebJob to run.
        public static async Task Main(string[] args)
        {
            var builder = new HostBuilder()
                .ConfigureWebJobs(b =>
                {
                    b.AddAzureStorageCoreServices()
                     .AddAzureStorageQueues();
                })
                .ConfigureAppConfiguration((context, config) =>
                {
                    config.AddUserSecrets<Program>().AddEnvironmentVariables()
                        .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                    .Build();
                    var env = context.Configuration.GetSection("Environment")?.Value;
                    config.AddKeyVault<Program>(env);
                    config.AddEnvironmentVariables();
                })
                .ConfigureServices((hostContext, services) =>
                {
                    var env = hostContext.Configuration.GetSection("STPowerEnv")?.Value;

                    services.AddHangfire(configuration => configuration
                        .SetDataCompatibilityLevel(CompatibilityLevel.Version_170)
                        .UseSimpleAssemblyNameTypeSerializer()
                        .UseRecommendedSerializerSettings()
                        .UseSqlServerStorage(hostContext.Configuration.GetConnectionString($"{STPowerConnectionStringName}-{env}"), new SqlServerStorageOptions
                        {
                            CommandBatchMaxTimeout = TimeSpan.FromMinutes(5),
                            SlidingInvisibilityTimeout = TimeSpan.FromMinutes(5),
                            QueuePollInterval = TimeSpan.Zero,
                            UseRecommendedIsolationLevel = true,
                            DisableGlobalLocks = true
                        }));
                    services.AddSneCore();
                    services.AddStratosKeyVault();
                    services.Configure<LoggerFilterOptions>(options =>
                    {
                        LoggerFilterRule toRemove = options.Rules?.FirstOrDefault(rule => rule.ProviderName
                        == "Microsoft.Extensions.Logging.ApplicationInsights.ApplicationInsightsLoggerProvider");

                        if (toRemove is not null)
                        {
                            options.Rules?.Remove(toRemove);
                        }
                    });
                    services.Configure<KestrelServerOptions>(options =>
                    {
                        options.AllowSynchronousIO = true;
                    });               
                    services.AddTransient<ITokenService, TokenService>();
                })
                .ConfigureLogging((context, b) =>
                {
                    b.SetMinimumLevel(LogLevel.Information);
                    b.AddConsole();
                });
            var host = builder.Build();

            using (host)
            {
                using (var scope = host.Services.CreateScope())
                {
                    await RecurringJobService.ScheduleRecurringJobs(scope.ServiceProvider);
                }
                await host.RunAsync();
            }
        }
    }
}


