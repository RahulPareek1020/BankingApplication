﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Shell.Energy.STPower.Data.Integration.Services;
using Shell.Energy.STPower.Shared.Auth;
using Shell.Energy.STPower.Shared.Constants;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace Shell.Energy.SNE.WebJobs.NomScheduler
{
    /// <summary>
    /// Class to call aligne batch based on delivery dates nad nomination definition id
    /// </summary>
    public class NomSchedulerService : INomSchedulerService
    {
        private readonly ILogger<NomSchedulerService> _logger;
        private readonly IConfiguration _configuration;
        private readonly string _apiurlConfig = CommonConstants.SNEAPIURL;
        private readonly IPowertrakTradeService _powertrakTradeService;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ITokenService _tokenService;

        public NomSchedulerService(
            ILogger<NomSchedulerService> logger, 
            IConfiguration config, 
            IPowertrakTradeService powertrakTradeService, 
            IHttpClientFactory httpClientFactory, 
            ITokenService tokenService)
        {
            _logger = logger;
            _configuration = config;
            _powertrakTradeService = powertrakTradeService;
            _httpClientFactory = httpClientFactory;
            _tokenService = tokenService;
        }

        /// <summary>
        /// Call Aligne batch based on schedule id
        /// </summary>
        /// <param name="scheduleId"></param>
        /// <returns></returns>
        public async Task CallAligneBatchAsync(int scheduleId)
        {
            try
            {
                _logger.LogInformation("Scheduler: CallAligneBatchAsync started for Cron Expression Id: {0}", scheduleId);
                var nominationScheduleList = await _powertrakTradeService.GetNominationsForSchedule(scheduleId);

                if (nominationScheduleList != null && nominationScheduleList.Count > 0)
                {
                    foreach (var nominationSchedule in nominationScheduleList)
                    {
                        await CallAligneBatchBasedOnDeliveryDates(nominationSchedule.DaysOffsetMin, nominationSchedule.DaysOffsetMax, nominationSchedule.NominationDefinitionId);
                    }
                }
                else
                {
                    _logger.LogInformation(CommonConstants.LogNominationExcepMessage, scheduleId);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, CommonConstants.LogErrorCronMessage, scheduleId, ex.Message);
            }
        }

        /// <summary>
        /// Call Aligne batch based on delivery dates and offsets
        /// </summary>
        /// <param name="minDate"></param>
        /// <param name="maxDate"></param>
        /// <param name="nomDefId"></param>
        /// <returns></returns>
        private async Task CallAligneBatchBasedOnDeliveryDates(int minDate, int maxDate, int nomDefId)
        {
            try
            {
                _logger.LogInformation("Scheduler: Call vnet api started for nomination definition Id: {NomDefId} with date offsets min:{Min} and max:{Max}",nomDefId,minDate,maxDate);
                var londonTimeZone = TimeZoneInfo.FindSystemTimeZoneById(CommonConstants.LondonTimeZone);
                var deliveryDate = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, londonTimeZone);
                var env = _configuration?.GetSection(CommonConstants.STPowerEnv)?.Value.ToUpperInvariant();
                var sneApiUrl = new Uri(_configuration?.GetSection($"{_apiurlConfig}-{env}")?.Value + CommonConstants.RunAligneBatchAsync);
                var client = _httpClientFactory.CreateClient();

                for (int deliveryDateCounter = minDate; deliveryDateCounter <= maxDate; deliveryDateCounter++)
                {
                    await ProcessDeliveryDate(client, sneApiUrl, deliveryDate, deliveryDateCounter, nomDefId);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, CommonConstants.LogErrorMessage, nomDefId, ex.Message);
                throw;
            }
        }

        private async Task ProcessDeliveryDate(HttpClient client, Uri sneApiUrl, DateTime deliveryDate, int deliveryDateCounter, int nomDefId)
        {
            try
            {                
                var reqDeliveryDate = deliveryDate.AddDays(deliveryDateCounter);
                _logger.LogInformation("Scheduler: Call vnet api started for nomination definition Id: {NomDefId} with delDate:{ReqDeliveryDate}", nomDefId,reqDeliveryDate);
                var relativeUri = $"{CommonConstants.NominationDefinitionId}{nomDefId}{CommonConstants.DeliveryDate}{reqDeliveryDate.Date:yyyy-MM-dd}";
                var requestUri = new Uri(sneApiUrl, relativeUri);
                var request = new HttpRequestMessage(HttpMethod.Get, requestUri);
                var token = await _tokenService.GenerateToken();

                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

                var response = await client.SendAsync(request);

                _logger.LogInformation(CommonConstants.LogMessage, nomDefId, reqDeliveryDate);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, CommonConstants.LogErrorMessage, nomDefId, ex.Message);
                throw;
            }
        }
    }
}
