﻿using Hangfire;
using Hangfire.Storage;
using Microsoft.Extensions.DependencyInjection;
using Shell.Energy.STPower.Data.Integration.Services;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Constants;
using System;
using System.Threading.Tasks;

namespace Shell.Energy.SNE.WebJobs.NomScheduler
{
    /// <summary>
    /// Class to schedule recurring jobs based on cron expressions
    /// </summary>
    public static class RecurringJobService
    {
        public static async Task ScheduleRecurringJobs(IServiceProvider serviceProvider)
        {
            var logger = serviceProvider.GetRequiredService<IAppLogger>();
            try
            {
                var recurringJobs = serviceProvider.GetRequiredService<IRecurringJobManager>();
                var nominationSchedulerJobService = serviceProvider.GetRequiredService<INomSchedulerService>();
                var powerTrakTradeService = serviceProvider.GetRequiredService<IPowertrakTradeService>();

                RecurringJobOptions options = new()
                {
                    TimeZone = TimeZoneInfo.FindSystemTimeZoneById(CommonConstants.LondonTimeZone)
                };

                // Fetch all existing recurring jobs

                logger.LogInformation("Deleting all existing recurring jobs...started");
                var existingJobs = JobStorage.Current?.GetConnection()?.GetRecurringJobs();

                // Remove all existing recurring jobs
                if (existingJobs != null)
                {
                    foreach (var job in existingJobs)
                    {
                        recurringJobs.RemoveIfExists(job.Id);
                    }
                }
                logger.LogInformation("Deleting all existing recurring jobs...completed");

                //Fetch all cron expressions/schedules from DB
                var cronExpressions = await powerTrakTradeService.GetAllNominationSchedules();

                foreach (var cronExpression in cronExpressions)
                {
                    // Schedule jobs with the specified cron expressions
                    var scheduleId = $"{CommonConstants.Schedule}{cronExpression.CronExpressionId}";
                    var cronExpressionValue = cronExpression.CronExpressionValue;
                    recurringJobs.AddOrUpdate(scheduleId, () => nominationSchedulerJobService.CallAligneBatchAsync(cronExpression.CronExpressionId), cronExpressionValue, options);
                }
            }
            catch (Exception ex)
            {
                logger.LogError($"Scheduler: {CommonConstants.LogHandfireErrorMessage}{ex.Message}");
                throw;
            }
        }
    }
}
