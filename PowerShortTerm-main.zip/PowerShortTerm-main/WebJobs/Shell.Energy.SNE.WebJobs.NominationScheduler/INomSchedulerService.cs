﻿using System.Threading.Tasks;

namespace Shell.Energy.SNE.WebJobs.NomScheduler
{
    /// <summary>
    /// Interface for Nomination Scheduler Service
    /// </summary>
    public interface INomSchedulerService
    {
        Task CallAligneBatchAsync(int scheduleId);
    }
}
