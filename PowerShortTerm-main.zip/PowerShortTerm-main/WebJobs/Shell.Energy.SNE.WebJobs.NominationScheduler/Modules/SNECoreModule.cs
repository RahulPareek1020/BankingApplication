﻿using Hangfire;
using Microsoft.Extensions.DependencyInjection;
using Shell.Energy.STPower.Data.Integration.DataAccess;
using Shell.Energy.STPower.Data.Integration.Services;
using Shell.Energy.STPower.Shared;

namespace Shell.Energy.SNE.WebJobs.NomScheduler.Modules
{
    /// <summary>
    /// DI class for adding core modules
    /// </summary>
    public static class SneCoreModule
    {
        public static IServiceCollection AddSneCore(this IServiceCollection collection)
        {
            collection.AddHangfireServer();
            collection.AddScoped<IAppLogger, AppLogger>();
            collection.AddSingleton<INomSchedulerService, NomSchedulerService>();
            collection.AddScoped<ISqlDataRepository, SqlDataRepository>();
            collection.AddTransient<IPowertrakTradeService, PowertrakTradeService>();
            collection.AddHttpClient();
            return collection;
        }
    }
}
