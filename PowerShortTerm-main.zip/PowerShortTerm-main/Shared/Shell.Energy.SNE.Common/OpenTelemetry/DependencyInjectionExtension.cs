﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Caching.Memory;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.DependencyInjection;
using Shell.Energy.SNE.Common.Interfaces;

namespace Shell.Energy.SNE.Common.OpenTelemetry
{
    /// <summary>
    /// Service collection extension to register services related to otel configurations
    /// </summary>
    public static class DependencyInjectionExtension
    {
        /// <summary>
        /// configuring / registering services related to open telemetry 
        /// </summary>
        /// <param name="serviceCollection"></param>
        /// <param name="configuration"></param>
        /// <param name="serviceName"></param>
        /// <param name="otlpClientName"></param>
        /// <returns></returns>
        public static IServiceCollection ConfigureOpenTelemetryDependencies(this IServiceCollection serviceCollection, IConfiguration configuration, string serviceName, string otlpClientName)
        {
            var openTelemetrySettings = configuration.GetSection(OpenTelemetrySettings.SectionName).Get<OpenTelemetrySettings>();
            // Register OpenTelemetrySettings as a singleton
            serviceCollection.AddSingleton(openTelemetrySettings!);
            //open telemetry custom attributes set up 
            CustomAttributes otelCustomAttributes = configuration.GetRequiredSection(CustomAttributes.SectionName).Get<CustomAttributes>();
            serviceCollection.AddSingleton(otelCustomAttributes!);
            serviceCollection.AddMemoryCache();
            serviceCollection.AddSingleton<ICacheWrapper, MemoryCacheWrapper>();
            serviceCollection.AddTransient<AuthenticationHandler>();
            serviceCollection.AddHttpClient("TokenClient", client =>
            {
                client.BaseAddress = openTelemetrySettings!.TokenEndPoint;
            });
            serviceCollection.AddHttpClient(otlpClientName).AddHttpMessageHandler<AuthenticationHandler>();
            serviceCollection.AddSingleton<TokenManager>();
            serviceCollection.AddSingleton(provider =>
            {
                return new ActivitySource(serviceName);
            });
            
            serviceCollection.AddScoped<ITelemetryActivity, TelemetryActivity>();
            return serviceCollection;
        }
        /// <summary>
        /// Get the service name and version
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static (string ServiceName, string ServiceVersion) GetServiceNameAndVersion(this Type type)
        {
            var assemblyName = type.Assembly.GetName();
            var serviceName = assemblyName.Name!;
            var serviceVersion = assemblyName.Version!.ToString();

            return (serviceName, serviceVersion);
        }
    }
}
