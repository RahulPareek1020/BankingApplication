﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Shell.Energy.SNE.Common.Interfaces;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Shell.Energy.SNE.Common.OpenTelemetry
{
    /// <summary>
    /// Class to manage tokens from otel collector
    /// Manages tokens in cache and expires based on expiry set by otel collector
    /// </summary>
    public class TokenManager
    {
        private const string TOKEN_KEY = "AUTH_TOKEN";
        private readonly ICacheWrapper _memoryCache;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly OpenTelemetrySettings _settings;
        private readonly ILogger<TokenManager> _logger;
        /// <summary>
        /// constructor method to initalize instances of httpclientFactory, memorycache, logger and opentelemetrysettings object
        /// </summary>
        /// <param name="httpClientFactory"></param>
        /// <param name="memoryCache"></param>
        /// <param name="openTelemetrySettings"></param>
        /// <param name="logger"></param>
        public TokenManager(IHttpClientFactory httpClientFactory, ICacheWrapper memoryCache, OpenTelemetrySettings openTelemetrySettings, ILogger<TokenManager> logger)
        {
            _httpClientFactory = httpClientFactory;
            _memoryCache = memoryCache;
            _settings = openTelemetrySettings;
            _logger = logger;   
        }
        /// <summary>
        /// Setting token received in memory cache and setting expiry
        /// </summary>
        /// <param name="key"></param>
        /// <param name="token"></param>
        /// <param name="expiresInSeconds"></param>
        public void SetToken(string key, TokenResponse token, int expiresInSeconds)
        {
            _memoryCache.Set(key, token, DateTimeOffset.Now.AddSeconds(expiresInSeconds));
        }
        /// <summary>
        /// gets token from memory cache
        /// </summary>
        /// <returns></returns>
        public TokenResponse GetToken()
        {
            return _memoryCache.Get<TokenResponse>(TOKEN_KEY) as TokenResponse ?? new TokenResponse();
        }
        /// <summary>
        /// checks if token has expired from memory
        /// </summary>
        /// <returns></returns>
        public bool IsTokenExpired()
        {
            return _memoryCache.Get<TokenResponse>(TOKEN_KEY) == null;
        }
        /// <summary>
        /// fetch token from otel collectory and deserialize to tokenresponse type
        /// </summary>
        /// <returns></returns>
        public async Task<TokenResponse?> GetRefreshTokenAsync()
        {
            var client = _httpClientFactory.CreateClient("TokenClient");
            
            var request = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress + "/token")
            {
                Content = new FormUrlEncodedContent(new[]
                {
                new KeyValuePair<string, string>("grant_type", _settings.GrantType!),
                new KeyValuePair<string, string>("audience", _settings.Audience!),
                new KeyValuePair<string, string>("client_id", _settings.ClientId!),
                new KeyValuePair<string, string>("client_secret", _settings.ClientSecret!)
            })
            };
            request.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/x-www-form-urlencoded");
            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                var tokenDeserialized = JsonSerializer.Deserialize<TokenResponse>(content);
                SetToken(TOKEN_KEY, tokenDeserialized!, tokenDeserialized!.ExpiresIn);
                return tokenDeserialized;
            }
            _logger.LogError($"Token not received as response was not success status code {response.ReasonPhrase!.ToString()}");
            return null;
        }
    }
}
