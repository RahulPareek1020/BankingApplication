﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Shell.Energy.SNE.Common.OpenTelemetry
{
    /// <summary>
    /// Object representing token information
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class TokenResponse
    {
        /// <summary>
        /// access token
        /// </summary>
        [JsonPropertyName("access_token")]
        public string AccessToken { get; set; } = string.Empty;
        /// <summary>
        /// Indicates token type
        /// </summary>
        [JsonPropertyName("token_type")]
        public string TokenType { get; set; } = string.Empty;
        /// <summary>
        /// specifies token validity
        /// </summary>
        [JsonPropertyName("expires_in")]
        public int ExpiresIn { get; set; }
        /// <summary>
        /// specifies token refresh validity
        /// </summary>
        [JsonPropertyName("refresh_expires_in")]
        public int RefreshExpiresIn { get; set; }
        /// <summary>
        /// specifies any policy
        /// </summary>
        [JsonPropertyName("not-before-policy")]
        public int NotBeforePolicy { get; set; }
        /// <summary>
        /// specifies scope
        /// </summary>
        [JsonPropertyName("scope")]
        public string Scope { get; set; } = string.Empty;
    }
}
