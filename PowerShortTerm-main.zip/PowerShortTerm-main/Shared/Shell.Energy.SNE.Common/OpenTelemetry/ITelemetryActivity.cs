﻿using OpenTelemetry;
using OpenTelemetry.Context.Propagation;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shell.Energy.SNE.Common.OpenTelemetry
{
    /// <summary>
    /// interface defining the activity methods
    /// </summary>
    public interface ITelemetryActivity : IDisposable
    {
        /// <summary>
        /// Parent activity
        /// </summary>
        /// <param name="activityName"></param>
        void StartProducerActivity(string activityName);
        /// <summary>
        /// Child activity wrt a different component
        /// </summary>
        /// <param name="activityName"></param>
        /// <param name="parentContext"></param>
        void StartConsumerActivity(string activityName, PropagationContext parentContext, ActivityKind activityKind);
        /// <summary>
        /// child activity within the same component
        /// </summary>
        /// <param name="activityName"></param>
        /// <param name="parentContext"></param>
        //void StartInternalConsumerActivity(string activityName, ActivityContext parentContext);
        /// <summary>
        /// context of the current activity
        /// </summary>
        ActivityContext Context { get; }
        /// <summary>
        /// context of parent activity if exists
        /// </summary>
        public ActivityContext? ParentContext { get;}
        /// <summary>
        /// Represents an object that holds custom attribute names from the configuration.
        /// </summary>
        public CustomAttributes CustomAttributes { get; }
        /// <summary>
        /// Baggage of the current activity
        /// </summary>
        //public Baggage Baggage { get; }
        /// <summary>
        /// dispose the current activity
        /// </summary>
        void Dispose();
        /// <summary>
        /// add event with tags if any to the current activity
        /// </summary>
        /// <param name="eventName"></param>
        /// <param name="eventAttributes"></param>
        void AddEvent(string eventName, IDictionary<string, object?>? eventAttributes = null);
        /// <summary>
        /// add tags to the current activity
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        void AddTag(string key, object? value);
        /// <summary>
        /// Add baggage to the current activity
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        void AddBaggage(string key, string value);
        /// <summary>
        /// Set propagation context to current activity
        /// </summary>
        /// <param name="existingContexts"></param>
        void SetPropagationContext(IDictionary<string, object> existingContexts, ActivityContext activityContext);
        /// <summary>
        /// propagation context  for dictionary type of string key and string value
        /// </summary>
        /// <param name="existingContexts"></param>
        /// <param name="activityContext"></param>
        public void SetPropagationContext(IDictionary<string, string> existingContexts, ActivityContext activityContext);
        void StopActivity();
        bool IsStopped { get; }


    }
}
