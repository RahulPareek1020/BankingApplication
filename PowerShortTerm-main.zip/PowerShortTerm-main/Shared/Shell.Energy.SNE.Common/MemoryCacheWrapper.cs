﻿using Microsoft.Extensions.Caching.Memory;
using Shell.Energy.SNE.Common.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shell.Energy.SNE.Common
{
    /// <summary>
    /// A wrapper class for the IMemoryCache interface.
    /// </summary>
    public class MemoryCacheWrapper : ICacheWrapper
    {
        private readonly IMemoryCache _memoryCache;
        /// <summary>
        /// Initializes a new instance of the <see cref="MemoryCacheWrapper"/> class.
        /// </summary>
        /// <param name="memoryCache">The memory cache instance to wrap.</param>
        public MemoryCacheWrapper(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
        }
        /// <summary>
        /// Sets a cache entry with the specified key, value, and absolute expiration time.
        /// </summary>
        /// <typeparam name="TItem">The type of the value to cache.</typeparam>
        /// <param name="key">The key of the cache entry.</param>
        /// <param name="value">The value to cache.</param>
        /// <param name="absoluteExpiration">The absolute expiration time for the cache entry.</param>
        public void Set<TItem>(object key, TItem value, DateTimeOffset absoluteExpiration)
        {
            _memoryCache.Set(key, value, absoluteExpiration);
        }
        /// <summary>
        /// Gets the cached value for the specified key.
        /// </summary>
        /// <typeparam name="TItem">The type of the cached value.</typeparam>
        /// <param name="key">The key of the cache entry.</param>
        /// <returns>The cached value, or the default value of <typeparamref name="TItem"/> if the key does not exist.</returns>
        public TItem Get<TItem>(object key)
        {
            var value = _memoryCache.Get<TItem>(key);
            if (value == null)
            {
                // Handle the null case as needed, e.g., throw an exception or return a default value
                return default;
            }
            return value;
        }
    }
}
