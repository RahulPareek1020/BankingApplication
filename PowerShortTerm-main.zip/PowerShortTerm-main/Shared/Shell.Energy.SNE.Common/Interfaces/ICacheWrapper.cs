﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shell.Energy.SNE.Common.Interfaces
{
    /// <summary>
    /// Defines methods for setting and getting cache entries.
    /// </summary>
    public interface ICacheWrapper
    {
        /// <summary>
        /// Sets a cache entry with the specified key, value, and absolute expiration time.
        /// </summary>
        /// <typeparam name="TItem">The type of the value to cache.</typeparam>
        /// <param name="key">The key of the cache entry.</param>
        /// <param name="value">The value to cache.</param>
        /// <param name="absoluteExpiration">The absolute expiration time for the cache entry.</param>
        void Set<TItem>(object key, TItem value, DateTimeOffset absoluteExpiration);
        /// <summary>
        /// Gets the cached value for the specified key.
        /// </summary>
        /// <typeparam name="TItem">The type of the cached value.</typeparam>
        /// <param name="key">The key of the cache entry.</param>
        /// <returnsItem"/> if the key does not exist.</returns>
        TItem Get<TItem>(object key);
    }
}
