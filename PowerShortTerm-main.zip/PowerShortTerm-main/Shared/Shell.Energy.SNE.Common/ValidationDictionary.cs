﻿using System.Diagnostics.CodeAnalysis;

namespace Shell.Energy.SNE.Common
{
    /// <summary>
    /// Model class for holding the validation messages and status of the validation
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class ValidationDictionary
    {
        /// <summary>
        /// Error message is of dictionary type.
        /// Containing the name of the schema's property as a key and error message related to that as value.
        /// </summary>
        public Dictionary<string, string> ErrorMessage { get; set; }

        /// <summary>
        /// Schema's property and data is valid or not.
        /// </summary>
        public bool IsValid { get; set; }
    }
}
