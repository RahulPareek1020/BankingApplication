﻿namespace Shell.Energy.SNE.Common
{
    /// <summary>
    /// Represents state of the transaction
    /// </summary>
    public enum OperationState
    {
        /// <summary>
        /// OperationState -> Success
        /// </summary>
        Success,

        /// <summary>
        /// OperationState -> Error
        /// </summary>
        Error
    }

}
