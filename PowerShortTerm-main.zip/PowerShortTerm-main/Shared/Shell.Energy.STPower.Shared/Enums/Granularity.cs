﻿namespace Shell.Energy.STPower.Shared.Enums
{
    /// <summary>
    /// Enum for Granularity
    /// </summary>
    public enum Granularity
    {
        QHR = 1,
        HHR = 2,
        HR = 3
    }
}
