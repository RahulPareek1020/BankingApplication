﻿namespace Shell.Energy.STPower.Shared.Enums
{
    /// <summary>
    /// Enum for Deal Types
    /// </summary>
    public enum DealType
    {
        STD,
        TRANS
    }
}
