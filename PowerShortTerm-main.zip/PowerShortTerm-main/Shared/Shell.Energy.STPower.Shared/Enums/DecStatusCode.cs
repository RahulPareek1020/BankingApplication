﻿namespace Shell.Energy.STPower.Shared.Enums
{
    public enum DecStatusCode
    {
        PROCESSED = 1,
        FAILED = 2,
        PENDING = 3
    }
}