﻿namespace Shell.Energy.STPower.Shared.Enums
{
    /// <summary>
    /// Enum for topic to trade mapping
    /// </summary>
    public enum Status
    {
       COMPLETE,
       INCOMPLETE
    }
}
