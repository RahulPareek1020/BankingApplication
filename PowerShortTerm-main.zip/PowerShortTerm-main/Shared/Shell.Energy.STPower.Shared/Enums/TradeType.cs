﻿namespace Shell.Energy.STPower.Shared.Enums
{
    /// <summary>
    /// Enum for topic to trade mapping
    /// </summary>
    public enum TradeType
    {
        BASELOAD = 1,
        PROFILE = 2,
        TRANSMISSION = 3,
        DELETE = 4,
        PROFILETRANS = 5,
        POWERTRAK = 6,
        AligneRawTrade=7
    }
}
