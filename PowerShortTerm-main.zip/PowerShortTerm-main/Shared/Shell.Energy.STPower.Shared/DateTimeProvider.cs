﻿namespace Shell.Energy.STPower.Shared;

public class DateTimeProvider : IDateTimeProvider
{
    public DateTime Now => DateTime.Now;
}
