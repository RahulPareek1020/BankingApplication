﻿namespace Shell.Energy.STPower.Shared.Constants
{
    /// <summary>
    /// Constants for response messages
    /// </summary>
    public static class ResponseMessages
    {
        public static readonly string InvalidTradeType = "Invalid TradeType";
        public static readonly string InvalidTradeTypeFile = "Invalid TradeType/File";
        public static readonly string InvalidFileContent = "Invalid file content";
        public static readonly string InvalidFileFormat= "Invalid file format";
        public static readonly string ProcessingError = "Error while processing the request";
        public static readonly string TradeDataGenerationError = "Trade data could not be generated";
        public static readonly string BelvisMessageGenerationSuccess = "Belvis content generated successfully";
        public static readonly string IncorrectDataSequence = "Incorrect data : Data is not in sequence of delivery Dates";
        public static readonly string InvalidTradeData = "Invalid trade data";
        public static readonly string InvalidTradeTransformerType = "Invalid trade transformer type";
        public static readonly string InvalidTopic = "Invalid topic";
        public static readonly string MissingQueryParameter = "One or more query parameters are missing or empty.";
        public static readonly string MissingAppConfigurations = "One or more app configurations are missing or empty.";
        public static readonly string InvalidAccessTokenEntityOp = "AccessToken entity Operation not found";
        public static readonly string NoMessages= "No messages consumed";
        public static readonly string NoTopicsConfigured = "No topics confgiured";
        public static readonly string SaveTradeSuccess = "Successfully saved aligne_raw_trades";
    }
}
