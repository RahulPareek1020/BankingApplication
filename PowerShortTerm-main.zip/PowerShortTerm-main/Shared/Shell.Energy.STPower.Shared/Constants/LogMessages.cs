﻿namespace Shell.Energy.STPower.Shared.Constants
{
    /// <summary>
    /// Constants used for logging
    /// </summary>
    public static class LogMessages
    {
        public static readonly string StartedProcessing = "started processing a request";
        public static readonly string CompletedProcessing = "completed processing a request";
        public static readonly string SendPowerTradeRequest = "Sending power trade request to GMSL API";
        public static readonly string ExecuteReaderNull = "Failed to execute reader. Reader is null.";
        public static readonly string DataReaderError = "An error occurred while reading data";
        public static readonly string StatusUpdated = "Status updated to nomination sending";
        public static readonly string SendtoPowertrak = "Nomination sent to powertrak NominationRunId : ";
        public static readonly string TrackerSuccessMessage = "Successfully called the SNE API to fetch and update PowerTrak status";
        public static readonly string TrackerFailureMessage = "Failed to call the SNE API to fetch and update PowerTrak status";
        public static readonly string StatusAPIConfigMissing= "SNE StatusAPI Url configuration value is missing or null.";
    }

}
