﻿namespace Shell.Energy.STPower.Shared.Constants
{
    public static class CommonConstants
    {
        public static readonly string StateManagementTableName = "alignepocresponse";
        public static readonly string LondonTimeZone = "Europe/London";
        public static readonly string STPowerEnv = "STPowerEnv";
        public static readonly string SendNominationToPowertrak = "send-nomination-to-powertrak";
        public static readonly string NominationDefinitionId = "?nominationDefinitionId=";
        public static readonly string DeliveryDate = "&DeliveryDate=";
        public static readonly string LogMessage = "Successfully called the SNE API with nominationDefinitionId: {NominationDefinitionId} and deliverydate: {DeliveryDate}";
        public static readonly string LogErrorMessage = "An error occurred while calling SNE API NomDefId : {NominationDefinitionId} : {message}";
        public static readonly string LogErrorCronMessage = "An error occurred while calling SNE API  cron expression id : {ScheduleId} : {message} ";
        public static readonly string LogHandfireErrorMessage = "An error occurred hanfire schedule jobs : ";
        public static readonly string LogSuccessMessage = "Successfully called the SNE API";
        public static readonly string SNEAPIURL = "SNEAPIURL";
        public static readonly string Schedule = "Schedule_";
        public static readonly string LogNominationExcepMessage = "No nominations associated to schedule id : {ScheduleId} ";
        public static readonly string GetReadyNominations = "get-ready-nominations";
        public static readonly string LogMessageReadyNom = "Successfully called the SNE API to fetch ready nominations";
        public static readonly string SendNominationPosToPowertrak = "send-nom-positions-to-powertrak";
        public static readonly string NominationRunId = "?nominationRunId=";
        public static readonly string RunAligneBatchAsync = "run-aligne-batch-async";
        public static readonly string ClientId = "ClientId";
        public static readonly string ClientSecret = "ClientSecret";
        public static readonly string SSODepUrl = "SSO-DEP-Url";
        public static readonly string SSOM2M = "SSOM2M";
        public static readonly string AccessToken = "access_token";
        public static readonly string SNEStatusAPIUrl = "SNEStatusAPIUrl";
    }
}
