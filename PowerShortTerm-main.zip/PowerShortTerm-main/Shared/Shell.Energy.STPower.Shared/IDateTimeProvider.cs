﻿namespace Shell.Energy.STPower.Shared;

public interface IDateTimeProvider
{
    DateTime Now { get; }
}
