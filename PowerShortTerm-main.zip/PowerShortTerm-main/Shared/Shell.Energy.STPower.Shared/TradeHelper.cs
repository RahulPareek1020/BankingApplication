﻿using Shell.Energy.STPower.Shared.Constants;
using Shell.Energy.STPower.Shared.Enums;
using Shell.Energy.STPower.Shared.Exceptions;
using System.Data;
using System.Data.Common;

namespace Shell.Energy.STPower.Shared
{
    public static class TradeHelper
    {
        /// <summary>
        /// GetNullableDateTime value from reader
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="columnName"></param>
        /// <returns></returns>
        public static DateTime? GetNullableDateTime(this IDataReader reader, string columnName)
        {
            if(reader == null)
            {
                return null;
            }
            return reader.IsDBNull(reader.GetOrdinal(columnName)) ? (DateTime?)null : reader.GetDateTime(reader.GetOrdinal(columnName));
        }

        /// <summary>
        /// GetNullablTimespan value from reader
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="columnName"></param>
        /// <returns></returns>
        public static TimeSpan? GetNullableTimeSpan(this DbDataReader reader, string columnName)
        {
            if (reader == null)
            {
                return null;
            }
            return reader.IsDBNull(reader.GetOrdinal(columnName)) ? null : TimeSpan.FromTicks(reader.GetInt64(reader.GetOrdinal(columnName)));
        }

        public static decimal? GetNullableDecimal(this IDataReader reader, string columnName)
        {
            if (reader == null)
            {
                return null;
            }
            return reader.IsDBNull(reader.GetOrdinal(columnName)) ? (decimal?)null : reader.GetDecimal(reader.GetOrdinal(columnName));
        }

        public static double? GetNullableDouble(this IDataReader reader, string columnName)
        {
            if (reader == null)
            {
                return null;
            }
            return reader.IsDBNull(reader.GetOrdinal(columnName)) ? (double?)null : reader.GetDouble(reader.GetOrdinal(columnName));
        }

    }
}