﻿using System.Text;

namespace Shell.Energy.STPower.Shared
{
    public class ApiHelper
    {
        private const string BearerToken = "Bearer";
        private const string applicationJson = "application/json";

        /// <summary>
        /// Send a request to the Belvis API using OAuth token for authentication
        /// </summary>
        /// <param name="apiUrl"></param>
        /// <param name="urlPath"></param>
        /// <param name="belvisMessage"></param>
        /// <param name="token"></param>
        /// <param name="queryParam"></param>
        /// <returns></returns>
        public async Task<string> SendBelvisAPIRequest(string apiUrl, string urlPath,string belvisMessage, string token, string queryParam)
        {
            var client = new HttpClient();

            // Set the bearer token
            client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue(BearerToken, token);

            // Set the base address
            client.BaseAddress = new Uri(apiUrl);

            // Set the request URI with query parameters
            var requestUri = new UriBuilder(client.BaseAddress)
            {
                Path = urlPath,
                Query = queryParam
            }.Uri;

            // Send the POST request
            var response = await client.PostAsync(requestUri, new StringContent(belvisMessage, Encoding.UTF8, applicationJson));

            if (response.IsSuccessStatusCode)
            {
                // Get the response content
                var responseContent = await response.Content.ReadAsStringAsync();
                return (responseContent);
            }
            else
            {
                //throw exception if the status code is not success
                throw new Exception(response.StatusCode.ToString());
            }
        }
    }
}
