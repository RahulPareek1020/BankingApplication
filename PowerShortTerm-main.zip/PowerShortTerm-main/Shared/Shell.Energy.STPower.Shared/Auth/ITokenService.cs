﻿namespace Shell.Energy.STPower.Shared.Auth
{
    public interface ITokenService
    {
        Task<string> GenerateToken();
    }
}
