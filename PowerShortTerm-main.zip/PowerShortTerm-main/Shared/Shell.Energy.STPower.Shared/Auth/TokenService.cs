﻿using System.Text.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Shell.Energy.STPower.Shared.Constants;

namespace Shell.Energy.STPower.Shared.Auth
{
    public class TokenService : ITokenService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<TokenService> _logger;

        public TokenService(IConfiguration configuration, ILogger<TokenService> logger)
        {
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<string> GenerateToken()
        {
            string jwt = string.Empty;

            try
            {
                var env = _configuration.GetSection(CommonConstants.STPowerEnv)?.Value?.ToUpperInvariant() ?? string.Empty;
                string ssoDepUrl = _configuration.GetSection(CommonConstants.SSODepUrl)?.Value ?? string.Empty;
                string clientId = _configuration.GetSection($"{CommonConstants.SSOM2M}-{env}").GetRequiredSection(CommonConstants.ClientId).Value ?? string.Empty;
                string clientSecret = _configuration.GetSection($"{CommonConstants.SSOM2M}-{env}").GetRequiredSection(CommonConstants.ClientSecret).Value ?? string.Empty;

                using (var _httpClient = new HttpClient())
                {
                    var content = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("client_id", clientId),
                        new KeyValuePair<string, string>("client_secret", clientSecret),
                        new KeyValuePair<string, string>("grant_type", "client_credentials")
                    });

                    var response = await _httpClient.PostAsync(new Uri(ssoDepUrl), content);
                    if (response.IsSuccessStatusCode)
                    {
                        var token_ResponseContent = await response.Content.ReadAsStringAsync();
                        var tokenResponseParse = JObject.Parse(token_ResponseContent);
                        jwt = tokenResponseParse?[CommonConstants.AccessToken]?.ToString() ?? string.Empty;
                    }
                    else
                    {
                        _logger.LogError("Error: {StatusCode} - {ReasonPhrase}", response.StatusCode, response.ReasonPhrase);
                    }
                }
            }
            catch (HttpRequestException httpEx)
            {
                _logger.LogError(httpEx, "HTTP request error. Exception trace: {StackTrace} ", httpEx.Message);
            }
            catch (JsonException jsonEx)
            {
                _logger.LogError(jsonEx, "JSON parsing error. Exception trace: {StackTrace} ", jsonEx.Message);
            }
            return jwt;
        }
    }
}
