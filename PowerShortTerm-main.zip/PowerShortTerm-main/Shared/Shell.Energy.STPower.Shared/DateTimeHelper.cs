﻿namespace Shell.Energy.STPower.Shared
{
    /// <summary>
    /// DateTime helper class
    /// </summary>
    public static class DateTimeHelper
    {
        /// <summary>
        /// Returns datetime based on timezone
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public static DateTime ConvertToUtcFromTimeZone(DateTime time, string localTimeZoneId)
        {
            var timeZone = TimeZoneInfo.FindSystemTimeZoneById(localTimeZoneId);
            DateTime formattedDateTime = DateTime.SpecifyKind(time, DateTimeKind.Unspecified);
            var resultDateTimeUtc = TimeZoneInfo.ConvertTimeToUtc(formattedDateTime, timeZone);
            return resultDateTimeUtc;
        }

        /// <summary>
        /// Returns datetime without milliseconds
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public static DateTime TrimMillisecondsFromTime(DateTime time)
        {
            return time.AddTicks(-(time.Ticks % TimeSpan.TicksPerSecond));
        }
    }
}