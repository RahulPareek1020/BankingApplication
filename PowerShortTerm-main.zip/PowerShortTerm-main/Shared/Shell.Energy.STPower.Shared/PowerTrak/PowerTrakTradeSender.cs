﻿using System.Net.Http.Headers;
using System.Text;
using System.Xml.Linq;
using Microsoft.Extensions.Options;
using Shell.Energy.STPower.Shared.Constants;

namespace Shell.Energy.STPower.Shared.PowerTrak
{
    /// <summary>
    /// Class to send power trades to PowerTrak
    /// </summary>
    public class PowerTrakTradeSender : IPowerTrakTradeSender
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IAppLogger _logger;
        private readonly PowerTrakConfig _powerTrakAuthConfig;
        private const string applicationXML = "application/xml";
        private const string BearerTokenHeaderValue = "Bearer";
        private const string correlationIdQueryParam= "CorrelationId";

        /// <summary>
        /// Constructor to initialise PowerTrakTradeSender
        /// </summary>
        /// <param name="httpClientFactory"></param>
        /// <param name="powerTrakAuthConfig"></param>
        /// <param name="logger"></param>
        public PowerTrakTradeSender(IHttpClientFactory httpClientFactory, IOptions<PowerTrakConfig> powerTrakAuthConfig, IAppLogger logger)
        {
            _httpClientFactory = httpClientFactory;
            _powerTrakAuthConfig = powerTrakAuthConfig.Value;
            _logger = logger;
        }

        /// <summary>
        /// Get JWT token and submit power trades
        /// </summary>
        /// <param name="powerTrades"></param>
        /// <returns></returns>
        public async Task<XElement> SubmitPowerTrades(XElement powerTrades, string jwtString)
        {
            if (string.IsNullOrEmpty(jwtString))
            {
                return null;
            }
            return await SubmitPowerTrades(jwtString, powerTrades);
        }

        /// <summary>
        /// Submit power trades to PowerTrak
        /// </summary>
        /// <param name="jwtString"></param>
        /// <param name="powerTrades"></param>
        /// <returns></returns>
        private async Task<XElement> SubmitPowerTrades(string jwtString, XElement powerTrades)
        {
            _logger.LogInformation(LogMessages.SendPowerTradeRequest);
            // Convert XElement to string and then to byte array to get the size
            var powerTradesString = powerTrades.ToString(SaveOptions.DisableFormatting);
            var powerTradesBytes = Encoding.UTF8.GetBytes(powerTradesString);
            var contentSize = powerTradesBytes.Length/1024.0;

            // Log the content size
            _logger.LogInformation($"Request content length: {contentSize:F2} KB");

            var client = _httpClientFactory.CreateClient();
            var requestUri = new Uri(_powerTrakAuthConfig.BaseUrl, _powerTrakAuthConfig.SubmitPowerTradesUrlPath);
            var requestContent = new StringContent(powerTradesString, Encoding.UTF8, applicationXML);

            var request = new HttpRequestMessage(HttpMethod.Post, requestUri) { Content = requestContent };
            return await CallPowerApi(client, request, jwtString);
        }

        /// <summary>
        /// Get JWT token
        /// </summary>
        /// <returns></returns>
        public async Task<string> GetJwtString()
        {
            var client = _httpClientFactory.CreateClient();
            var requestUri = new Uri(_powerTrakAuthConfig.BaseUrl, _powerTrakAuthConfig.AuthenticationUrlPath);
            var content = new XElement("Credentials",
                new XElement("Role", _powerTrakAuthConfig.Role),
                new XElement("Username", _powerTrakAuthConfig.Username),
                new XElement("Password", _powerTrakAuthConfig.Password)).ToString(SaveOptions.DisableFormatting);

            var request = new HttpRequestMessage(HttpMethod.Post, requestUri) { Content = new StringContent(content, Encoding.UTF8, applicationXML) };
            return await CallApi(client, request);
        }

        /// <summary>
        /// Method to Call Power API
        /// </summary>
        /// <param name="client"></param>
        /// <param name="request"></param>
        /// <param name="jwtString"></param>
        /// <returns></returns>
        private static async Task<XElement> CallPowerApi(HttpClient client, HttpRequestMessage request, string jwtString)
        {
            request.Headers.Authorization = new AuthenticationHeaderValue(BearerTokenHeaderValue, jwtString);
            request.Headers.Accept.Clear();
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue(applicationXML));
            var responseContent = await CallApi(client, request);
            return XElement.Parse(responseContent);
        }

        /// <summary>
        /// Method to call API
        /// </summary>
        /// <param name="client"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        private static async Task<string> CallApi(HttpClient client, HttpRequestMessage request)
        {
            var response = await client.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"{response.StatusCode} {response.ReasonPhrase}");
            }
            return await response.Content.ReadAsStringAsync();
        }

        /// <summary>
        /// Method to get status report
        /// </summary>
        /// <param name="jwtString"></param>
        /// <param name="correlationId"></param>
        /// <returns></returns>
        public async Task<XElement> GetStatusReport(string correlationId,string jwtString)
        {
            var client = _httpClientFactory.CreateClient();
            var requestUri = new Uri(_powerTrakAuthConfig.BaseUrl, $"{_powerTrakAuthConfig.StatusReportUrlPath}?{correlationIdQueryParam}={correlationId}");
            var request = new HttpRequestMessage(HttpMethod.Get, requestUri); 
            Console.WriteLine($"Calling GetStatusReport, correlation ID {correlationId}..."); 
            return await CallPowerApi(client, request, jwtString);
        }
    }
}