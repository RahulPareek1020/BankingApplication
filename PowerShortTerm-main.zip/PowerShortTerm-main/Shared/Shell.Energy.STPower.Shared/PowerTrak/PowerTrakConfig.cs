﻿namespace Shell.Energy.STPower.Shared.PowerTrak
{
    public class PowerTrakConfig
    {
        public string? Username { get; set; }
        public string? Password { get; set; }
        public string? Role { get; set; }
        public Uri? BaseUrl { get; set; }
        public string? AuthenticationUrlPath { get; set; }
        public string? SubmitPowerTradesUrlPath { get; set; }
        public string? StatusReportUrlPath { get; set; }
    }
}