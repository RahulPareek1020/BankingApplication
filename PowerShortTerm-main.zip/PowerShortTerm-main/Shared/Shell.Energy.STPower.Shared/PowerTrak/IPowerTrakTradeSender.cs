﻿using System.Xml.Linq;

namespace Shell.Energy.STPower.Shared.PowerTrak
{
    public interface IPowerTrakTradeSender
    {
        Task<XElement> SubmitPowerTrades(XElement powerTrades, string jwtString);
        Task<string> GetJwtString();
        Task<XElement> GetStatusReport( string correlationId, string jwtString);
    }
}