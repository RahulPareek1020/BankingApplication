﻿namespace Shell.Energy.STPower.Shared
{
    public static class Messages
    {
        public static readonly string FunctionExecutionError = "SNE - Error executing trade uploader function! Error message: {message}";
        public static readonly string FunctionObjectCreationError = "SNE - Error executing Produce Kafka Message function! Error message: {message}";
        public static readonly string TradeMessageUploadedToKafka = "SNE - Trade message with trade id: {tradeID} successfully uploaded to Kafka topic: {strTopicName}";
        public static readonly string ErrorTradeMessageUploadedToKafka = "SNE - Error : Error persisting message to the Kafka log. trade id: {tradeID} - Kafka topic: {strTopicName}";
    }
}