﻿using Microsoft.Extensions.Configuration;
using Shell.Energy.STPower.Data.Common.Model;
using Shell.Energy.STPower.Data.Integration.DataAccess;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Enums;
using System.Data;


namespace Shell.Energy.STPower.Data.Integration.Services
{
    public class AligneTradeService : IAligneTradeService
    {
        private readonly IRepository _aligneRepository;
        private readonly IAppLogger _logger;
        private readonly IConfiguration _configuration;


        public AligneTradeService(IRepository aligneRepository,
       IAppLogger logger,
        IConfiguration configuration
        )
        {
            _logger = logger;
            _aligneRepository = aligneRepository;
            _configuration = configuration;
        }

        /// <summary>
        /// Fetch Aligne Raw Trades from Aligne
        /// </summary>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task<List<AligneRawTrade>> FetchAligneRawTrades(long batchRunId = 0)
        {
            try
            {

                _logger.LogInformation($"Start - Fetch Aligne Raw Trades for run id {batchRunId}");

                var aligneData = await _aligneRepository.GetAligneRawTradesData(batchRunId);

                _logger.LogInformation($"End - Fetch Aligne Raw Trades for run id {batchRunId}");

                return aligneData;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error Occured during Fetch Aligne Raw trades, Exception trace: {ex.StackTrace}, batchRunId:{batchRunId}");
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Update batch run status
        /// </summary>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task InsertBatchRunStatus(DateTime? batchRunDate, long? batchRunTime, long? batchRunId, string status, int rowCount)
        {
            try
            {

                _logger.LogInformation($"Start - Update batch run status");

                await _aligneRepository.InsertBatchRunStatus(batchRunDate, batchRunTime, batchRunId, status, rowCount);

                _logger.LogInformation($"End - Update batch run status");

            }
            catch (Exception ex)
            {
                _logger.LogError($"Error Occured during update batch run status, Exception trace: {ex.StackTrace}");
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Update batch run status
        /// </summary>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task<List<long>> GetBatchRunIds(int? batchRunIdCount)
        {
            try
            {

                _logger.LogInformation($"Start - Fetch batch run ids");

                var batchRunIds = await _aligneRepository.GetBatchRunIds(batchRunIdCount);

                _logger.LogInformation($"End -  Fetch batch run ids");

                return batchRunIds;

            }
            catch (Exception ex)
            {
                _logger.LogError($"Error Occured during  Fetch batch run ids, Exception trace: {ex.StackTrace}");
                throw;
            }
        }
        /// <summary>
        /// Update error records
        /// </summary>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task InsertErrorRecords(IEnumerable<AligneRawTrade> errorRecords)
        {
            try
            {
                DataTable errorRecordsDataTable = new DataTable();
                errorRecordsDataTable.Locale = System.Globalization.CultureInfo.CurrentCulture;
                errorRecordsDataTable.Columns.Add("REFERENCE", typeof(string));
                errorRecordsDataTable.Columns.Add("DELIVERYDATE", typeof(DateTime));
                errorRecordsDataTable.Columns.Add("BATCH_RUN_ID", typeof(string));
                errorRecordsDataTable.Columns.Add("BATCH_RUN_DATE", typeof(DateTime));
                errorRecordsDataTable.Columns.Add("BATCH_RUN_TIME", typeof(Decimal));
                errorRecordsDataTable.Columns.Add("STATUS", typeof(string));

                if (errorRecords != null && errorRecords.Any())
                {
                    foreach (var errorRecord in errorRecords)
                    {
                        DataRow row = errorRecordsDataTable.NewRow();
                        row["REFERENCE"] = errorRecord.Reference;
                        row["DELIVERYDATE"] = errorRecord.DeliveryDate;
                        row["BATCH_RUN_ID"] = errorRecord.BatchRunId;
                        row["BATCH_RUN_DATE"] = errorRecord.BatchRunDate;
                        row["BATCH_RUN_TIME"] = errorRecord.BatchRunTime;
                        row["STATUS"] = Status.INCOMPLETE.ToString();
                        errorRecordsDataTable.Rows.Add(row);
                    }

                }
                _logger.LogInformation($"Start - Update error records");

                await _aligneRepository.InsertErrorRecords(errorRecordsDataTable);

                _logger.LogInformation($"End - Update error records");

            }
            catch (Exception ex)
            {
                _logger.LogError($"Error Occured during update error records, Exception trace: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }
    }
}
