﻿using Shell.Energy.STPower.Data.Common.Model;

namespace Shell.Energy.STPower.Data.Integration.Services
{
    public interface IAligneTradeService
    {
        Task<List<AligneRawTrade>> FetchAligneRawTrades(long batchRunId = 0);
        Task InsertBatchRunStatus(DateTime? batchRunDate, long? batchRunTime, long? batchRunId, string status, int rowCount);
        Task InsertErrorRecords(IEnumerable<AligneRawTrade> errorRecords);
        Task<List<long>> GetBatchRunIds(int? batchRunIdCount);

    }
}
