﻿using Shell.Energy.STPower.Data.Common.Model;
using Shell.Energy.STPower.Data.Dto;
using Shell.Energy.STPower.Data.DTO;
using Shell.Energy.STPower.Service.KafkaProducer.Schema;

namespace Shell.Energy.STPower.Data.Integration.Services
{
    /// <summary>
    /// Interface for Powertrak Trade Service
    /// </summary>
    public interface IPowertrakTradeService
    {
        Task<List<string>> GetCorrelationIds();
        void UpdateTradeStatuses(List<TradeStatusDto> statusList);
        Task<bool> InsertAligneRawTradeDataInDB(IEnumerable<Aligne_Raw_Trade> aligneRawTrades);
        Task<List<CronExpressionDto>> GetAllNominationSchedules();
        Task<List<NominationScheduleDto>> GetNominationsForSchedule(int scheduleId);
        Task<NominationRunOtelIds> GetNominationRunTraceSpanId(int nominationRunId);
    }
}
