﻿using Microsoft.Data.SqlClient;
using Shell.Energy.STPower.Data.Common.Constants;
using Shell.Energy.STPower.Data.Common.Model;
using Shell.Energy.STPower.Data.Dto;
using Shell.Energy.STPower.Data.DTO;
using Shell.Energy.STPower.Data.Integration.Constants;
using Shell.Energy.STPower.Data.Integration.DataAccess;
using Shell.Energy.STPower.Service.KafkaProducer.Schema;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Constants;
using System.Data;
using System.Globalization;

namespace Shell.Energy.STPower.Data.Integration.Services
{
    /// <summary>
    /// Service class for fetching and updating trade statuses in the database.
    /// </summary>
    public class PowertrakTradeService : IPowertrakTradeService
    {
        private readonly ISqlDataRepository _sqlDataRepository;
        private readonly IAppLogger _logger;
        private const int maxQHIndex = 96;


        public PowertrakTradeService(ISqlDataRepository sqlDataRepository,
        IAppLogger logger
        )
        {
            _sqlDataRepository = sqlDataRepository;
            _logger = logger;
        }

        /// <summary>
        /// Get the correlation ids from the database.
        /// </summary>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public Task<List<string>> GetCorrelationIds()
        {
            try
            {

                _logger.LogInformation($"Started fetching correlationIds with powertrakstatus code as null");
                string query = AggSqlQueries.SelectCorrelationId;

                var correlationIdList = _sqlDataRepository.ExecuteSqlQuery<string>(query).ToList();

                _logger.LogInformation($"Successfully fetched correlationIds");

                return Task.FromResult(correlationIdList);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error occured during fetching of correlation id, Exception trace: " + ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Update the trade statuses in the database.
        /// </summary>
        /// <param name="statusList"></param>
        public void UpdateTradeStatuses(List<TradeStatusDto> statusList)
        {
            if (statusList == null || statusList.Count == 0)
            {
                return;
            }

            var tradeStatusDataTable = CreateTradeStatusDataTable(statusList);
            var dynamicParameterDto = new DynamicParameterDto(tradeStatusDataTable, ServiceConstants.DynamicParamStatusName, ServiceConstants.TvpPowertrakStatusName);
            _sqlDataRepository.ExecuteStoredProcedure(ServiceConstants.UpdateStatusSpName, dynamicParameterDto);
        }

        /// <summary>
        /// Create a DataTable from the list of trade statuses.
        /// </summary>
        /// <param name="statusList"></param>
        /// <returns></returns>
        private DataTable CreateTradeStatusDataTable(List<TradeStatusDto> statusList)
        {
            var tradeStatusDataTable = new DataTable();
            var columns = new[] { "Reference", "Result", "Text" };

            foreach (var column in columns)
            {
                tradeStatusDataTable.Columns.Add(column, typeof(string));
            }

            foreach (var status in statusList)
            {
                tradeStatusDataTable.Rows.Add(status.Reference, status.Result, status.Text);
            }

            return tradeStatusDataTable;
        }

        /// <summary>
        /// Insert the aligne raw trade data in the database.
        /// </summary>
        /// <param name="aligneRawTrades"></param>
        /// <returns></returns>
        public async Task<bool> InsertAligneRawTradeDataInDB(IEnumerable<Aligne_Raw_Trade> aligneRawTrades)
        {
            try
            {
                DataTable? dataTable = CreateAligneRawTradeDataTable(aligneRawTrades);
                if (dataTable is null)
                {
                    _logger.LogError("Data is empty");
                    return false;
                }
                var parameters = new SqlParameter[]
                {
                new SqlParameter
                {
                ParameterName = "@AligneRawTrade",
                SqlDbType = SqlDbType.Structured,
                TypeName = "dbo.AligneRawTradeType",
                Value = dataTable
                }
                };
                using var reader = await _sqlDataRepository.ExecuteReaderAsync(
                    ServiceConstants.InsertAligneRawTradeSP, parameters) as SqlDataReader;
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return false;
                }
                return true;
            }

            catch (Exception ex)
            {
                _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                throw;
            }
        }

        public static DataTable? CreateAligneRawTradeDataTable(IEnumerable<Aligne_Raw_Trade> aligneRawTrades)
        {
            if (aligneRawTrades == null)
            {
                return null;
            }

            var dataTable = InitializeDataTable();

            int id = 1;
            foreach (var trade in aligneRawTrades)
            {
                var row = CreateDataRow(dataTable, trade, id++);
                dataTable.Rows.Add(row);
            }

            return dataTable;
        }

        private static DataTable InitializeDataTable()
        {
            var dataTable = new DataTable
            {
                Locale = CultureInfo.InvariantCulture
            };

            // Add columns to the DataTable
            dataTable.Columns.Add("InsNumRec", typeof(int));
            dataTable.Columns.Add("Reference", typeof(string));
            dataTable.Columns.Add("TradeType", typeof(string));
            dataTable.Columns.Add("TransactionType", typeof(string));
            dataTable.Columns.Add("Entity", typeof(string));
            dataTable.Columns.Add("Counterparty", typeof(string));
            dataTable.Columns.Add("FromMarketoperator", typeof(string));
            dataTable.Columns.Add("ToMarketoperator", typeof(string));
            dataTable.Columns.Add("TradeDate", typeof(DateTime));
            dataTable.Columns.Add("DeliveryDate", typeof(DateTime));
            dataTable.Columns.Add("DelDateStart", typeof(DateTime));
            dataTable.Columns.Add("DelDateEnd", typeof(DateTime));
            dataTable.Columns.Add("Cdy1Attr1", typeof(string));
            dataTable.Columns.Add("PwrNomsOverrideType", typeof(string));
            dataTable.Columns.Add("PwrNomsOverrideInput", typeof(string));
            dataTable.Columns.Add("PwrNomsOverrideFreeform", typeof(string));
            dataTable.Columns.Add("AuxSoCpty", typeof(string));
            dataTable.Columns.Add("CptyNoms", typeof(string));
            dataTable.Columns.Add("PeakWorkaround", typeof(string));
            dataTable.Columns.Add("TransDuration", typeof(string));
            dataTable.Columns.Add("TransOasis1", typeof(string));
            dataTable.Columns.Add("TransProvider", typeof(string));
            dataTable.Columns.Add("BatchRunDate", typeof(DateTime));
            dataTable.Columns.Add("BatchRunTime", typeof(int));
            dataTable.Columns.Add("Source", typeof(string));
            dataTable.Columns.Add("BatchRunId", typeof(long));
            dataTable.Columns.Add("ProdCon", typeof(string));
            dataTable.Columns.Add("TotalBatchRowCount", typeof(int));

            for (int i = 1; i <= maxQHIndex; i++)
            {
                dataTable.Columns.Add($"QH{i}", typeof(double));
            }

            return dataTable;
        }

        private static DataRow CreateDataRow(DataTable dataTable, Aligne_Raw_Trade trade, int id)
        {
            var row = dataTable.NewRow();
            row["InsNumRec"] = id;
            row["Reference"] = trade.REFERENCE;
            row["TradeType"] = trade.TRADETYPE;
            row["TransactionType"] = trade.TRANSACTIONTYPE;
            row["Entity"] = trade.ENTITY;
            row["Counterparty"] = trade.COUNTERPARTY;
            row["FromMarketoperator"] = trade.FROMMARKETOPERATOR;
            row["ToMarketoperator"] = trade.TOMARKETOPERATOR;
            row["TradeDate"] = trade.TRADEDATE.HasValue ? trade.TRADEDATE.Value : DBNull.Value;
            row["DeliveryDate"] = trade.DELIVERYDATE.HasValue ? trade.DELIVERYDATE.Value : DBNull.Value;
            row["DelDateStart"] = trade.DEL_DATESTART.HasValue ? trade.DEL_DATESTART.Value : DBNull.Value;
            row["DelDateEnd"] = trade.DEL_DATEEND.HasValue ? trade.DEL_DATEEND.Value : DBNull.Value;
            row["Cdy1Attr1"] = trade.CDY1ATTR1 ?? string.Empty;
            row["PwrNomsOverrideType"] = trade.PWRNOMS_OVERRIDE_TYPE ?? string.Empty;
            row["PwrNomsOverrideInput"] = trade.PWRNOMS_OVERRIDE_INPUT ?? string.Empty;
            row["PwrNomsOverrideFreeform"] = trade.PWRNOMS_OVERRIDE_FREEFORM ?? string.Empty;
            row["AuxSoCpty"] = trade.AUX_SO_CPTY ?? string.Empty;
            row["CptyNoms"] = trade.CPTY_NOMS ?? string.Empty;
            row["PeakWorkaround"] = trade.PEAK_WORKAROUND ?? string.Empty;
            row["TransDuration"] = trade.TRANS_DURATION ?? string.Empty;
            row["TransOasis1"] = trade.TRANS_OASIS1 ?? string.Empty;
            row["TransProvider"] = trade.TRANS_PROVIDER ?? string.Empty;
            row["BatchRunDate"] = trade.BATCH_RUN_DATE.HasValue ? trade.BATCH_RUN_DATE.Value : DBNull.Value;
            row["BatchRunTime"] = trade.BATCH_RUN_TIME.HasValue ? trade.BATCH_RUN_TIME.Value : DBNull.Value;
            row["Source"] = trade.SOURCE ?? string.Empty;
            row["BatchRunId"] = trade.BATCH_RUN_ID.HasValue ? trade.BATCH_RUN_ID.Value : DBNull.Value;
            row["ProdCon"] = trade.PRODCON ?? string.Empty;
            row["TotalBatchRowCount"] = trade.TOTAL_BATCH_ROW_COUNT.HasValue ? trade.TOTAL_BATCH_ROW_COUNT.Value : DBNull.Value;

            for (int i = 1; i <= maxQHIndex; i++)
            {
                row[$"QH{i}"] = typeof(Aligne_Raw_Trade).GetProperty($"QH{i}").GetValue(trade) ?? DBNull.Value;
            }

            return row;
        }

        /// <summary>
        /// Get all nomination schedules
        /// </summary>
        /// 
        /// <returns>List<CronExpressionDto></returns>
        public async Task<List<CronExpressionDto>> GetAllNominationSchedules()
        {
            try
            {
                var cronExpressionDtoList = new List<CronExpressionDto>();
                using (var reader = await _sqlDataRepository.ExecuteReaderAsync(
                    ServiceConstants.GetAllNominationSchedulesSP, null) as SqlDataReader)
                {
                    if (reader == null)
                    {
                        _logger.LogError(LogMessages.ExecuteReaderNull);
                        return cronExpressionDtoList;
                    }
                    try
                    {
                        while (await reader.ReadAsync())
                        {
                            var cronExpressionDto = new CronExpressionDto
                            {
                                CronExpressionId = reader.GetInt32("CRON_EXPRESSION_ID"),
                                CronExpressionValue = reader.GetString("CRON_EXPRESSION_VALUE")
                            };
                            cronExpressionDtoList.Add(cronExpressionDto);
                        }
                        return cronExpressionDtoList;
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                        throw;
                    }
                }
            }

            catch (Exception ex)
            {
                _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Get nominations based on schedule
        /// </summary>
        /// 
        /// <returns>List<NominationScheduleDto></returns>
        public async Task<List<NominationScheduleDto>> GetNominationsForSchedule(int scheduleId)
        {
            try
            {
                var nominationScheduleList = new List<NominationScheduleDto>();
                var parameters = new SqlParameter[] {
                new SqlParameter
                    {
                    ParameterName = "@ScheduleId",
                    SqlDbType = SqlDbType.Int,
                    Value = scheduleId
                    }
                };
                using (var reader = await _sqlDataRepository.ExecuteReaderAsync(
                    ServiceConstants.GetNominationsForScheduleSP, parameters) as SqlDataReader)
                {
                    if (reader == null)
                    {
                        _logger.LogError(LogMessages.ExecuteReaderNull);
                        return nominationScheduleList;
                    }
                    try
                    {
                        while (await reader.ReadAsync())
                        {
                            var nominationSchedule = new NominationScheduleDto
                            {
                                NominationDefinitionId = reader.GetInt32("NOMINATION_DEFINITION_ID"),
                                DaysOffsetMin = reader.GetInt32("DAYS_OFFSET_MIN"),
                                DaysOffsetMax = reader.GetInt32("DAYS_OFFSET_MAX")
                            };
                            nominationScheduleList.Add(nominationSchedule);
                        }
                        return nominationScheduleList;
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                        throw;
                    }
                }
            }

            catch (Exception ex)
            {
                _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                throw;
            }
        }

        public async Task<NominationRunOtelIds> GetNominationRunTraceSpanId(int nominationRunId)
        {
            NominationRunOtelIds nominationRunOtelIds = new NominationRunOtelIds();
            _logger.LogInformation($"Started fetching OTEL Ids for NominationRunId:{nominationRunId} from SQL DB");
            var parameters = new SqlParameter[]
                {
                    new SqlParameter(ServiceConstants.NominationId, SqlDbType.Int) { Value = nominationRunId }
                };
            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(
                ServiceConstants.GetNomRunTraceSpanIdsSPName, parameters) as SqlDataReader)
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return nominationRunOtelIds;
                }
                try
                {
                    while (await reader.ReadAsync())
                    {
                        nominationRunOtelIds = new NominationRunOtelIds
                        { SpanId = reader.GetString("SpanId"), TraceId = reader.GetString("TraceId") };
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }

            _logger.LogInformation($"Successfully fetched OTEL Ids for NominationRunId:{nominationRunId} from SQL DB");
            return nominationRunOtelIds;
        }
    }
}
