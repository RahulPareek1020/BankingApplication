﻿namespace Shell.Energy.STPower.Data.Common.Model
{
    public class NominationRunOtelIds
    {
        public string? TraceId { get; set; }
        public string? SpanId { get; set; }

    }
}
