﻿using System.Text.Json.Serialization;

namespace Shell.Energy.STPower.Data.Common.Model
{
    public class AligneRawTrade
    {
        [JsonPropertyName("REFERENCE")]
        public string? Reference { get; set; }

        [JsonPropertyName("TRADETYPE")]
        public string? TradeType { get; set; }

        [JsonPropertyName("TRANSACTIONTYPE")]
        public string? TransactionType { get; set; }

        [JsonPropertyName("ENTITY")]
        public string? Entity { get; set; }

        [JsonPropertyName("COUNTERPARTY")]
        public string? Counterparty { get; set; }

        [JsonPropertyName("FROMMARKETOPERATOR")]
        public string? FromMarketoperator { get; set; }

        [JsonPropertyName("TOMARKETOPERATOR")]
        public string? ToMarketoperator { get; set; }

        [JsonPropertyName("TRADEDATE")]
        public DateTime? TradeDate { get; set; }

        [JsonPropertyName("DELIVERYDATE")]
        public DateTime DeliveryDate { get; set; }

        [JsonPropertyName("DEL_DATESTART")]
        public DateTime? DelDateStart { get; set; }

        [JsonPropertyName("DEL_DATEEND")]
        public DateTime? DelDateEnd { get; set; }

        [JsonPropertyName("CDY1ATTR1")]
        public string? Cdy1Attr1 { get; set; }

        [JsonPropertyName("PWRNOMS_OVERRIDE_TYPE")]
        public string? PwrNomsOverrideType { get; set; }

        [JsonPropertyName("PWRNOMS_OVERRIDE_INPUT")]
        public string? PwrNomsOverrideInput { get; set; }

        [JsonPropertyName("PWRNOMS_OVERRIDE_FREEFORM")]
        public string? PwrNomsOverrideFreeform { get; set; }

        [JsonPropertyName("AUX_SO_CPTY")]
        public string? AuxSoCpty { get; set; }

        [JsonPropertyName("CPTY_NOMS")]
        public string? CptyNoms { get; set; }

        [JsonPropertyName("PEAK_WORKAROUND")]
        public string? PeakWorkaround { get; set; }

        [JsonPropertyName("TRANS_DURATION")]
        public string? TransDuration { get; set; }

        [JsonPropertyName("TRANS_OASIS1")]
        public string? TransOasis1 { get; set; }

        [JsonPropertyName("TRANS_PROVIDER")]
        public string? TransProvider { get; set; }

        [JsonPropertyName("BATCH_RUN_DATE")]
        public DateTime? BatchRunDate { get; set; }

        [JsonPropertyName("BATCH_RUN_TIME")]
        public long BatchRunTime { get; set; }

        [JsonPropertyName("SOURCE")]
        public string?   Source { get; set; }
        
        [JsonPropertyName("BATCH_RUN_ID")]
        public long BatchRunId { get; set; }

        [JsonPropertyName("PRODCON")]
        public string? ProdCon { get; set; }

        [JsonPropertyName("TOTAL_BATCH_ROW_COUNT")]
        public int? TotalBatchRowCount { get; set; }

        public double QH1 { get; set; }
        public double QH2 { get; set; }
        public double QH3 { get; set; }
        public double QH4 { get; set; }
        public double QH5 { get; set; }
        public double QH6 { get; set; }
        public double QH7 { get; set; }
        public double QH8 { get; set; }
        public double QH9 { get; set; }
        public double QH10 { get; set; }
        public double QH11 { get; set; }
        public double QH12 { get; set; }
        public double QH13 { get; set; }
        public double QH14 { get; set; }
        public double QH15 { get; set; }
        public double QH16 { get; set; }
        public double QH17 { get; set; }
        public double QH18 { get; set; }
        public double QH19 { get; set; }
        public double QH20 { get; set; }
        public double QH21 { get; set; }
        public double QH22 { get; set; }
        public double QH23 { get; set; }
        public double QH24 { get; set; }
        public double QH25 { get; set; }
        public double QH26 { get; set; }
        public double QH27 { get; set; }
        public double QH28 { get; set; }
        public double QH29 { get; set; }
        public double QH30 { get; set; }
        public double QH31 { get; set; }
        public double QH32 { get; set; }
        public double QH33 { get; set; }
        public double QH34 { get; set; }
        public double QH35 { get; set; }
        public double QH36 { get; set; }
        public double QH37 { get; set; }
        public double QH38 { get; set; }
        public double QH39 { get; set; }
        public double QH40 { get; set; }
        public double QH41 { get; set; }
        public double QH42 { get; set; }
        public double QH43 { get; set; }
        public double QH44 { get; set; }
        public double QH45 { get; set; }
        public double QH46 { get; set; }
        public double QH47 { get; set; }
        public double QH48 { get; set; }
        public double QH49 { get; set; }
        public double QH50 { get; set; }
        public double QH51 { get; set; }
        public double QH52 { get; set; }
        public double QH53 { get; set; }
        public double QH54 { get; set; }
        public double QH55 { get; set; }
        public double QH56 { get; set; }
        public double QH57 { get; set; }
        public double QH58 { get; set; }
        public double QH59 { get; set; }
        public double QH60 { get; set; }
        public double QH61 { get; set; }
        public double QH62 { get; set; }
        public double QH63 { get; set; }
        public double QH64 { get; set; }
        public double QH65 { get; set; }
        public double QH66 { get; set; }
        public double QH67 { get; set; }
        public double QH68 { get; set; }
        public double QH69 { get; set; }
        public double QH70 { get; set; }
        public double QH71 { get; set; }
        public double QH72 { get; set; }
        public double QH73 { get; set; }
        public double QH74 { get; set; }
        public double QH75 { get; set; }
        public double QH76 { get; set; }
        public double QH77 { get; set; }
        public double QH78 { get; set; }
        public double QH79 { get; set; }
        public double QH80 { get; set; }
        public double QH81 { get; set; }
        public double QH82 { get; set; }
        public double QH83 { get; set; }
        public double QH84 { get; set; }
        public double QH85 { get; set; }
        public double QH86 { get; set; }
        public double QH87 { get; set; }
        public double QH88 { get; set; }
        public double QH89 { get; set; }
        public double QH90 { get; set; }
        public double QH91 { get; set; }
        public double QH92 { get; set; }
        public double QH93 { get; set; }
        public double QH94 { get; set; }
        public double QH95 { get; set; }
        public double QH96 { get; set; }
    }
}
