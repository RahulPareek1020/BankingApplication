﻿namespace Shell.Energy.STPower.Data.Common.Model
{
    public class NominationReady
    {
        public IEnumerable<int?>? NominationRunIDs { get; set; }
    }
}
