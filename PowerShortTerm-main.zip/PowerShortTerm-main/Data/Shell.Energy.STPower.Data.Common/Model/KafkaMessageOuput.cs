﻿namespace Shell.Energy.STPower.Data.Common.Model
{
    public class KafkaMessageOutput
    {
        public int TotalMessagesSent { get; set; }
        public int TotalRawTradesSent { get; set; }
    }
}
