﻿namespace Shell.Energy.STPower.Data.Integration.Constants
{
    public static class ServiceConstants
    {
        public static readonly string STPowerConnectionStringName = "STPowerConnString";
        public static readonly string IntegrationVNetDBConnectionStringName = "IntegrationVNetDBConnString";
        public static readonly string CptyAggTableName = "COUNTERPARTY_AGGREGATION";
        public static readonly string UpdateStatusSpName = "UpdatePowertrakStatus";
        public static readonly string TvpPowertrakStatusName = "PowertrakTradeStatus";
        public static readonly string DynamicParamStatusName = "@TradeStatuses";
        public static readonly string GetAlignRawTrades = "SNE.GetAligneRawTradesBatchData";
        public static readonly string InsertBatchRunStatus = "SNE.InsertBatchRunStatus";
        public static readonly string InsertErrorRecords = "SNE.InsertErrorRecords";
        public static readonly string Status = "@Status";
        public static readonly string RowCount = "@RowCount";
        public static readonly string BatchRunId = "@BatchRunId";
        public static readonly string BatchRunDate = "@BatchRunDate";
        public static readonly string BatchRunTime = "@BatchRunTime";
        public static readonly string ErrorRecords = "@ErrorRecords";
        public static readonly string ErrorRecordsUdt = "SNE.UT_ERROR_RECORDS";
        public static readonly int ColumnCount = 96;
        public static readonly string InsertAligneRawTradeSP = "InsertAligneRawTrade";
        public static readonly string GetAllNominationSchedulesSP = "GetAllNominationSchedules";
        public static readonly string GetNominationsForScheduleSP = "GetNominationsForSchedule";
        public static readonly string NumberOfRowsSent = "Number of rows sent in one message ";
        public static readonly string TradeMessagesToKafka = "SNE - Trade message successfully uploaded to Kafka topic: ";
        public static readonly string ErrorMessagesToKafka = "SNE - Error : Error persisting message to the Kafka - Kafka topic: ";
        public static readonly string TimeTakenToFetch = "Time taken to fetch Aligne raw trades to Kafka - ";
        public static readonly string ErrorPublish = "Error occured during PublishPowerTrakTradeMessage ";
        public static readonly string MessageSentToKafka = "Message sent to kafka - Total Messages Sent : ";
        public static readonly string TimeTakenToSend = "Time taken to send Aligne raw trades to Kafka - ";
        public static readonly string TotalTimeTakenToSend = "Total Time taken to send  Aligne raw trades to Kafka - ";
        public static readonly string NominationId = "@NominationRunId";
        public static readonly string GetBatchRunIdsForProducerSP = "SNE.GetBatchRunIdsForProducer";
        public static readonly string BatchRunIdCount = "@BatchRunIdCount";
        public static readonly string IsAutoParam = "@IsAuto";
        public static readonly string IsManual = "IsManual";
        public static readonly string IsTrue = "true";
        public static readonly string BatchRunIdCol = "BATCH_RUN_ID";
        public static readonly string GetNomRunTraceSpanIdsSPName = "GetTraceAndSpanIds";
    }


}
