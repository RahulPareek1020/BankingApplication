﻿using Shell.Energy.STPower.Data.Integration.Constants;

namespace Shell.Energy.STPower.Data.Common.Constants
{
    /// <summary>
    /// SQL Queries for Aggregation
    /// </summary>
    public static class AggSqlQueries
    {
        public static readonly string SelectCorrelationId = $"SELECT DISTINCT CorrelationID FROM {ServiceConstants.CptyAggTableName} where PowertrakStatusCode is NULL";
    }
}
