/****** Object:  UserDefinedFunction [SNE].[GetBatchRunDateAndTime]    Script Date: 12/9/2024 9:54:22 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Rohit Harshan
-- Description:	Fetch batch run date and time
-- =============================================
CREATE OR ALTER FUNCTION [SNE].[GetBatchRunDateAndTime] 
(
)
RETURNS @BatchRunDateAndTime TABLE 
(
	BATCH_RUN_DATE DATE,
	BATCH_RUN_TIME DECIMAL(10,2)
)
AS
BEGIN
	-- Fill the table variable with the rows for your result set

	IF NOT EXISTS(SELECT TOP 1 BATCH_RUN_DATE, BATCH_RUN_TIME
	FROM SNE.BATCH_RUN_STATUS
	order by BATCH_RUN_STATUS_ID DESC)
		BEGIN
			INSERT INTO @BatchRunDateAndTime
			SELECT TOP 1 BATCH_RUN_DATE, BATCH_RUN_TIME
			FROM SNE.ALIGNE_RAW_TRADES
			order by BATCH_RUN_DATE,BATCH_RUN_TIME
		END
	ELSE
		BEGIN 
		DECLARE @BatchRunDate date ,
		@BatchRunTime decimal(10,2)
			SELECT TOP 1 @BatchRunDate=BATCH_RUN_DATE, @BatchRunTime= BATCH_RUN_TIME
		FROM SNE.BATCH_RUN_STATUS
		order by BATCH_RUN_STATUS_ID DESC

		INSERT INTO @BatchRunDateAndTime
		SELECT TOP 1 BATCH_RUN_DATE, BATCH_RUN_TIME
		FROM SNE.ALIGNE_RAW_TRADES WHERE (BATCH_RUN_DATE=@BatchRunDate AND BATCH_RUN_TIME>@BatchRunTime) OR (BATCH_RUN_DATE> @BatchRunDate)
		ORDER BY BATCH_RUN_DATE,BATCH_RUN_TIME
		END
	
		RETURN 
END
GO


