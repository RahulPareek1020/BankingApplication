/****** Object:  StoredProcedure [SNE].[InsertErrorRecords]    Script Date: 12/4/2024 4:06:29 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:      <Author, , Name>
-- Create Date: <Create Date, , >
-- Description: <Description, , >
-- =============================================
CREATE OR ALTER PROCEDURE [SNE].[InsertErrorRecords]
(
    @ErrorRecords SNE.UT_ERROR_RECORDS READONLY
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON

    -- Insert statements for procedure here
		INSERT INTO SNE.ERROR_RECORDS(REFERENCE,DELIVERYDATE,BATCH_RUN_DATE,BATCH_RUN_TIME,STATUS)
		SELECT * FROM @ErrorRecords
	
END
GO


