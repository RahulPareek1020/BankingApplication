/****** Object:  StoredProcedure [SNE].[GetAligneRawTradesBatchData]    Script Date: 12/9/2024 9:29:46 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:      Rohit Harshan
-- Create Date: 20/11/2024
-- Description: Fetch Aligne Raw Trades batch data
-- =============================================
CREATE OR ALTER PROCEDURE [SNE].[GetAligneRawTradesBatchData] 
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON

    -- Insert statements for procedure here
    /****** Script for SelectTopNRows command from SSMS  ******/
DECLARE
@BatchRunDate date, @BatchRunTime decimal(10,2)

	SELECT @BatchRunDate= BATCH_RUN_DATE, @BatchRunTime= BATCH_RUN_TIME FROM  SNE.GetBatchRunDateAndTime()

	-- SELECT raw trades based on batch run date and time with acive markets from ALIGNE_MARKET_MASTER

	SELECT [REFERENCE],[TRADETYPE],[TRANSACTIONTYPE],[ENTITY],[COUNTERPARTY],[FROMMARKETOPERATOR],[TOMARKETOPERATOR],[DELIVERYDATE]
		  ,[DEL_DATESTART],[DEL_DATEEND],[CDY1ATTR1],[PWRNOMS_OVERRIDE_TYPE],[PWRNOMS_OVERRIDE_INPUT],[PWRNOMS_OVERRIDE_FREEFORM],[AUX_SO_CPTY]
		  ,[CPTY_NOMS],[PEAK_WORKAROUND],[TRANS_DURATION],[TRANS_OASIS1],[TRANS_PROVIDER],[QH1],[QH2],[QH3],[QH4],[QH5],[QH6],[QH7],[QH8]
		  ,[QH9],[QH10],[QH11],[QH12],[QH13],[QH14],[QH15],[QH16],[QH17],[QH18],[QH19],[QH20],[QH21],[QH22],[QH23],[QH24],[QH25],[QH26],[QH27]
		  ,[QH28],[QH29],[QH30],[QH31],[QH32],[QH33],[QH34],[QH35],[QH36],[QH37],[QH38],[QH39],[QH40],[QH41],[QH42],[QH43],[QH44],[QH45]
		  ,[QH46],[QH47],[QH48],[QH49],[QH50],[QH51],[QH52],[QH53],[QH54],[QH55],[QH56],[QH57],[QH58],[QH59],[QH60],[QH61],[QH62],[QH63]
		  ,[QH64],[QH65],[QH66],[QH67],[QH68],[QH69],[QH70],[QH71],[QH72],[QH73],[QH74],[QH75],[QH76],[QH77],[QH78],[QH79],[QH80],[QH81]
		  ,[QH82],[QH83],[QH84],[QH85],[QH86],[QH87],[QH88],[QH89],[QH90],[QH91],[QH92],[QH93],[QH94],[QH95],[QH96],[BATCH_RUN_DATE]
		  ,[BATCH_RUN_TIME],[SOURCE],[BATCH_RUN_ID]
	  FROM [SNE].[ALIGNE_RAW_TRADES] RT WITH(NOLOCK) INNER JOIN [SNE].[ALIGNE_MARKET_MASTER] M ON M.Marketoperator_Name = RT.FROMMARKETOPERATOR 
	  WHERE 
	  M.STATUS =1  and 
	  BATCH_RUN_DATE = @BatchRunDate and BATCH_RUN_TIME = @BatchRunTime 
END

