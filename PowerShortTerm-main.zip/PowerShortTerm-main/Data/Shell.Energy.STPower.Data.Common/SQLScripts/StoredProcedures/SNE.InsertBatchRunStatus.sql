/****** Object:  StoredProcedure [SNE].[InsertBatchRunStatus]    Script Date: 12/4/2024 4:07:23 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:      Rohit Harshan
-- Create Date: 20/11/2024
-- Description: Update batch run status
-- =============================================
CREATE OR ALTER PROCEDURE [SNE].[InsertBatchRunStatus]
(
@BatchRunDate date,
@BatchRunTime decimal,
@Status VARCHAR(255),
@RowCount int
)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON

    -- Insert statements for procedure here
    /****** Script for SelectTopNRows command from SSMS  ******/

	IF EXISTS (SELECT TOP 1 * FROM SNE.ERROR_RECORDS where BATCH_RUN_DATE= @BatchRunDate AND BATCH_RUN_TIME = @BatchRunTime)
	BEGIN
		INSERT INTO SNE.BATCH_RUN_STATUS(BATCH_RUN_DATE,BATCH_RUN_TIME,STATUS,ROW_COUNT)
		SELECT @BatchRunDate, @BatchRunTime, 'PARTIAL SUCCESS',@RowCount
	END
	ELSE
	BEGIN
		INSERT INTO SNE.BATCH_RUN_STATUS(BATCH_RUN_DATE,BATCH_RUN_TIME,STATUS,ROW_COUNT)
		SELECT @BatchRunDate, @BatchRunTime, @Status,@RowCount
	END

END
GO


