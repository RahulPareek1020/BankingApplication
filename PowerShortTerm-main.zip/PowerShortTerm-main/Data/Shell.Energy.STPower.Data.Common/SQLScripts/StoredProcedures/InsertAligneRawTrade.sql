﻿/****** Object:  StoredProcedure [dbo].[InsertAligneRawTrade]    Script Date: 04/12/2024 10:42:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER PROCEDURE [dbo].[InsertAligneRawTrade]
    @AligneRawTrade AligneRawTradeType READONLY
AS
BEGIN
    SET NOCOUNT ON;
	BEGIN TRANSACTION;
    -- Create a temporary table to store the header IDs, Reference, and Id
    CREATE TABLE #TempAligneRawTradeHeaderIds
    (
        AligneRawTradeHeaderId INT,
        Reference NVARCHAR(MAX),
        InsNumRec INT
    );

    -- Insert into aligne_raw_trade_header and get the inserted ID
    INSERT INTO sne_aligne_raw_trade_header (InsNumRec,Reference, TradeType, TransactionType, Entity, Counterparty, FromMarketoperator, ToMarketoperator, DeliveryDate, TradeDate, Del_DateStart, Del_DateEnd, Cdy1Attr1, PwrNoms_Override_Type, PwrNoms_Override_Input, PwrNoms_Override_Freeform, Aux_So_Cpty, Cpty_Noms, Peak_Workaround, CapacityType, CapacityIdentification, Interconnector, Batch_Run_Date, Batch_Run_Time,Source,Batch_Run_Id)
    OUTPUT INSERTED.Aligne_Raw_Trade_Header_ID, INSERTED.Reference, INSERTED.InsNumRec INTO #TempAligneRawTradeHeaderIds
    SELECT InsNumRec,Reference, TradeType, TransactionType, Entity, Counterparty, FromMarketoperator, ToMarketoperator, DeliveryDate, TradeDate, DelDateStart, DelDateEnd, Cdy1Attr1, PwrNomsOverrideType, PwrNomsOverrideInput, PwrNomsOverrideFreeform, AuxSoCpty, CptyNoms, PeakWorkaround, TransDuration, TransOasis1, TransProvider,BatchRunDate,BatchRunTime,Source,BatchRunId
    FROM @AligneRawTrade A;

    -- Insert into aligne_raw_trade_volume using the retrieved header ID and Reference
    INSERT INTO sne_aligne_raw_trade_volume (Aligne_Raw_Trade_Header_Id, QH1, QH2, QH3, QH4, QH5, QH6, QH7, QH8, QH9, QH10, QH11, QH12, QH13, QH14, QH15, QH16, QH17, QH18, QH19, QH20, QH21, QH22, QH23, QH24, QH25, QH26, QH27, QH28, QH29, QH30, QH31, QH32, QH33, QH34, QH35, QH36, QH37, QH38, QH39, QH40, QH41, QH42, QH43, QH44, QH45, QH46, QH47, QH48, QH49, QH50, QH51, QH52, QH53, QH54, QH55, QH56, QH57, QH58, QH59, QH60, QH61, QH62, QH63, QH64, QH65, QH66, QH67, QH68, QH69, QH70, QH71, QH72, QH73, QH74, QH75, QH76, QH77, QH78, QH79, QH80, QH81, QH82, QH83, QH84, QH85, QH86, QH87, QH88, QH89, QH90, QH91, QH92, QH93, QH94, QH95, QH96)
    SELECT T.AligneRawTradeHeaderId, A.QH1, A.QH2, A.QH3, A.QH4, A.QH5, A.QH6, A.QH7, A.QH8, A.QH9, A.QH10, A.QH11, A.QH12, A.QH13, A.QH14, A.QH15, A.QH16, A.QH17, A.QH18, A.QH19, A.QH20, A.QH21, A.QH22, A.QH23, A.QH24, A.QH25, A.QH26, A.QH27, A.QH28, A.QH29, A.QH30, A.QH31, A.QH32, A.QH33, A.QH34, A.QH35, A.QH36, A.QH37, A.QH38, A.QH39, A.QH40, A.QH41, A.QH42, A.QH43, A.QH44, A.QH45, A.QH46, A.QH47, A.QH48, A.QH49, A.QH50, A.QH51, A.QH52, A.QH53, A.QH54, A.QH55, A.QH56, A.QH57, A.QH58, A.QH59, A.QH60, A.QH61, A.QH62, A.QH63, A.QH64, A.QH65, A.QH66, A.QH67, A.QH68, A.QH69, A.QH70, A.QH71, A.QH72, A.QH73, A.QH74, A.QH75, A.QH76, A.QH77, A.QH78, A.QH79, A.QH80, A.QH81, A.QH82, A.QH83, A.QH84, A.QH85, A.QH86, A.QH87, A.QH88, A.QH89, A.QH90, A.QH91, A.QH92, A.QH93, A.QH94, A.QH95, A.QH96
    FROM #TempAligneRawTradeHeaderIds T
    JOIN @AligneRawTrade A ON T.InsNumRec = A.InsNumRec and T.Reference=A.Reference;

    -- Drop the temporary table
    DROP TABLE #TempAligneRawTradeHeaderIds;
	COMMIT;
END;
