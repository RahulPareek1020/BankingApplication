/****** Object:  UserDefinedTableType [SNE].[UT_ERROR_RECORDS]    Script Date: 12/3/2024 8:10:10 PM ******/
CREATE TYPE [SNE].[UT_ERROR_RECORDS] AS TABLE(
	[REFERENCE] [varchar](255) NULL,
	[DELIVERYDATE] [date] NULL,
	[BATCH_RUN_DATE] [date] NULL,
	[BATCH_RUN_TIME] [decimal](10, 2) NULL,
	[STATUS] [varchar](255) NULL
)
GO


