﻿   CREATE TYPE PowertrakTradeStatus AS TABLE
(
    Reference NVARCHAR(50),
    Result NVARCHAR(50),
    Text NVARCHAR(255)
);