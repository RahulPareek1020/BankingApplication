﻿using Shell.Energy.STPower.Data.Common.Model;
using System.Data;

namespace Shell.Energy.STPower.Data.Integration.DataAccess
{
    public interface IRepository
    {
        Task<List<AligneRawTrade>> GetAligneRawTradesData(long batchRunId = 0);
        Task InsertBatchRunStatus(DateTime? batchRunDate, long? batchRunTime, long? batchRunId, string status, int rowCount);
        Task InsertErrorRecords(DataTable errorRecords);
        Task<List<long>> GetBatchRunIds(int? batchRunIdCount);
    }
}
