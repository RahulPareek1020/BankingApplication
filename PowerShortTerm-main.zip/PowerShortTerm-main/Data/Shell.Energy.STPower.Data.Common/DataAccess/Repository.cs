﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Shell.Energy.STPower.Data.Common.Model;
using Shell.Energy.STPower.Data.Integration.Constants;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Constants;
using System.Data;
using System.Data.Common;
using System.Globalization;

namespace Shell.Energy.STPower.Data.Integration.DataAccess
{
    public class Repository : IRepository
    {
        private readonly IConfiguration _configuration;
        private readonly IAppLogger _logger;
        private readonly ISqlDataRepository _sqlDataRepository;


        public Repository(IConfiguration configuration, IAppLogger logger, ISqlDataRepository sqlDataRepository)
        {
            _logger = logger;
            _configuration = configuration;
            _sqlDataRepository = sqlDataRepository;
        }


        /// <summary>
        /// Fetch Aligne Raw Trades from VNET DB
        /// </summary>
        /// <returns></returns>
        public async Task<List<AligneRawTrade>> GetAligneRawTradesData(long batchRunId = 0)
        {

            var tradeDtoList = new List<AligneRawTrade>();

            _logger.LogInformation($"Getting Aligne raw trades from VNET SQL DB");
            var parameters = new[]
              {
                    new SqlParameter(ServiceConstants.BatchRunId, SqlDbType.VarChar) { Value = batchRunId.ToString(CultureInfo.InvariantCulture) }
               };

            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(ServiceConstants.GetAlignRawTrades, parameters, true) as SqlDataReader)
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return tradeDtoList;
                }

                try
                {
                    // Read the Data
                    while (reader.Read())
                    {
                        var aligneRawTrade = GetRawTradeFromReader(reader);
                        // Store Data
                        tradeDtoList.Add(aligneRawTrade);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }

            _logger.LogInformation("Successfully fetched Aligne raw trades");

            return tradeDtoList;

        }

        /// <summary>
        /// Update batch run status
        /// </summary>
        /// <returns></returns>
        public async Task InsertBatchRunStatus(DateTime? batchRunDate, long? batchRunTime, long? batchRunId, string status, int rowCount)
        {
            try
            {
                _logger.LogInformation($"Update batch run status to DB");

                var parameters = new[]
                {
                    new SqlParameter(ServiceConstants.BatchRunId, SqlDbType.VarChar) { Value = batchRunId?.ToString(CultureInfo.CurrentCulture) },
                    new SqlParameter(ServiceConstants.BatchRunDate, SqlDbType.Date) { Value = batchRunDate },
                    new SqlParameter(ServiceConstants.BatchRunTime, SqlDbType.Decimal) { Value = batchRunTime },
                    new SqlParameter(ServiceConstants.Status, SqlDbType.VarChar) { Value = status },
                    new SqlParameter(ServiceConstants.RowCount, SqlDbType.Int) { Value = rowCount }
                };

                await _sqlDataRepository.ExecuteReaderAsync(ServiceConstants.InsertBatchRunStatus, parameters, true);

                _logger.LogInformation("Successfully updated batch run status to DB");
            }
            catch (Exception ex)
            {

                _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                throw;
            }

        }


        /// <summary>
        /// Update error records
        /// </summary>
        /// <returns></returns>
        public async Task InsertErrorRecords(DataTable errorRecords)
        {
            try
            {
                _logger.LogInformation($"Update error records to DB");

                var parameter = new SqlParameter
                {
                    ParameterName = ServiceConstants.ErrorRecords,
                    SqlDbType = SqlDbType.Structured,
                    TypeName = ServiceConstants.ErrorRecordsUdt,
                    Value = errorRecords
                };
                var parameters = new[]
                {
                    parameter
                };
                await _sqlDataRepository.ExecuteReaderAsync(ServiceConstants.InsertErrorRecords, parameters, true);

                _logger.LogInformation("Successfully update error records to DB");
            }
            catch (Exception ex)
            {

                _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                throw;
            }

        }

        /// <summary>
        /// Fetch batch run ids
        /// </summary>
        /// <returns></returns>
        public async Task<List<long>> GetBatchRunIds(int? batchRunIdCount)
        {

            var batchRunIds = new List<long>();
            var culture = CultureInfo.InvariantCulture;
            bool? isAuto = true;
            if (_configuration?.GetSection(ServiceConstants.IsManual)?.Value == ServiceConstants.IsTrue)
            {
                isAuto = false;
            }

            _logger.LogInformation($"Getting Batch run ids from VNET SQL DB");

            var parameters = new[]
               {
                    new SqlParameter(ServiceConstants.BatchRunIdCount, SqlDbType.Int) { Value = batchRunIdCount },
                    new SqlParameter(ServiceConstants.IsAutoParam, SqlDbType.Bit) { Value = isAuto }

               };

            using (var reader = await _sqlDataRepository.ExecuteReaderAsync(ServiceConstants.GetBatchRunIdsForProducerSP, parameters, true) as SqlDataReader)
            {
                if (reader == null)
                {
                    _logger.LogError(LogMessages.ExecuteReaderNull);
                    return batchRunIds;
                }

                try
                {
                    // Read the Data
                    while (reader.Read())
                    {
                        var batchRunId = !await reader.IsDBNullAsync(ServiceConstants.BatchRunIdCol) && reader.GetString(ServiceConstants.BatchRunIdCol)?.Trim() != string.Empty ? Convert.ToInt64(reader.GetString(ServiceConstants.BatchRunIdCol), culture) : 0;
                        // Store Data
                        batchRunIds.Add(batchRunId);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"{LogMessages.DataReaderError}: {ex.Message}");
                    throw;
                }
            }

            _logger.LogInformation("Successfully fetched Batch run ids");

            return batchRunIds;

        }

        /// <summary>
        /// Method to get Raw Trade from reader
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        public static AligneRawTrade GetRawTradeFromReader(DbDataReader reader)
        {

            var aligneRawTrade = GetNominationVolumeFromReader(reader);
            aligneRawTrade.Reference = reader.GetString("Reference").Trim();
            aligneRawTrade.TradeType = reader.GetString("TradeType").Trim();
            aligneRawTrade.TransactionType = reader.GetString("TransactionType").Trim();
            aligneRawTrade.Entity = reader.GetString("Entity").Trim();
            aligneRawTrade.Counterparty = reader.GetString("Counterparty").Trim();
            aligneRawTrade.FromMarketoperator = reader.GetString("FromMarketOperator").Trim();
            aligneRawTrade.ToMarketoperator = !reader.IsDBNull("ToMarketOperator") ? reader.GetString("ToMarketOperator").Trim() : string.Empty;
            aligneRawTrade.DeliveryDate = reader.GetDateTime("DeliveryDate");
            aligneRawTrade.DelDateStart = reader.GetNullableDateTime("Del_DateStart");
            aligneRawTrade.DelDateEnd = reader.GetNullableDateTime("Del_DateEnd");
            aligneRawTrade.Cdy1Attr1 = !reader.IsDBNull("Cdy1Attr1") ? reader.GetString("Cdy1Attr1").Trim() : string.Empty;
            aligneRawTrade.PwrNomsOverrideType = !reader.IsDBNull("PwrNoms_Override_Type") ? reader.GetString("PwrNoms_Override_Type").Trim() : string.Empty;
            aligneRawTrade.PwrNomsOverrideInput = !reader.IsDBNull("PwrNoms_Override_Input") ? reader.GetString("PwrNoms_Override_Input").Trim() : string.Empty;
            aligneRawTrade.PwrNomsOverrideFreeform = !reader.IsDBNull("PwrNoms_Override_Freeform") ? reader.GetString("PwrNoms_Override_Freeform").Trim() : string.Empty;
            aligneRawTrade.AuxSoCpty = !reader.IsDBNull("Aux_So_Cpty") ? reader.GetString("Aux_So_Cpty").Trim() : string.Empty;
            aligneRawTrade.CptyNoms = !reader.IsDBNull("Cpty_Noms") ? reader.GetString("Cpty_Noms").Trim() : string.Empty;
            aligneRawTrade.PeakWorkaround = !reader.IsDBNull("Peak_Workaround") ? reader.GetString("Peak_Workaround").Trim() : string.Empty;
            aligneRawTrade.TransDuration = !reader.IsDBNull("TRANS_DURATION") ? reader.GetString("TRANS_DURATION").Trim() : string.Empty;
            aligneRawTrade.TransOasis1 = !reader.IsDBNull("TRANS_OASIS1") ? reader.GetString("TRANS_OASIS1").Trim() : string.Empty;
            aligneRawTrade.TransProvider = !reader.IsDBNull("TRANS_PROVIDER") ? reader.GetString("TRANS_PROVIDER").Trim() : string.Empty;
            aligneRawTrade.BatchRunDate = reader.GetNullableDateTime("BATCH_RUN_DATE");
            aligneRawTrade.BatchRunTime = Convert.ToInt64(reader.GetDecimal("BATCH_RUN_TIME"));
            aligneRawTrade.Source = !reader.IsDBNull("SOURCE") ? reader.GetString("SOURCE").Trim() : string.Empty;
            aligneRawTrade.ProdCon = !reader.IsDBNull("PRODCON") ? reader.GetString("PRODCON").Trim() : string.Empty;
            aligneRawTrade.TradeDate = reader.GetNullableDateTime("TRADEDATE");
            var culture = CultureInfo.InvariantCulture;
            aligneRawTrade.BatchRunId = !reader.IsDBNull("BATCH_RUN_ID") && reader.GetString("BATCH_RUN_ID")?.Trim() != string.Empty ? Convert.ToInt64(reader.GetString("BATCH_RUN_ID"), culture) : 0;
            return aligneRawTrade;
        }

        /// <summary>
        /// Get Nomination Volume From Reader
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        private static AligneRawTrade GetNominationVolumeFromReader(IDataReader reader)
        {
            var volume = new AligneRawTrade();
            var endIndex = ServiceConstants.ColumnCount;
            for (int i = 1; i <= endIndex; i++)
            {
                var propertyName = $"QH{i}";
                var property = typeof(AligneRawTrade).GetProperty(propertyName);
                if (property != null)
                {
                    property.SetValue(volume, reader.GetNullableDouble($"QH{i}"));
                }
            }
            return volume;
        }
    }
}
