﻿using Microsoft.Data.SqlClient;
using Shell.Energy.STPower.Data.Dto;
using System.Data;

namespace Shell.Energy.STPower.Data.Integration.DataAccess
{
    /// <summary>
    /// Interface for SQL Data Repository
    /// </summary>
    public interface ISqlDataRepository
    {
        List<T> ExecuteSqlQuery<T>(string sqlQuery, object? parameter = null);
        void ExecuteStoredProcedure(string storedProcedureName, DynamicParameterDto? dynamicParameterDto=null);
        Task<IDataReader> ExecuteReaderAsync(string storedProcedureName, SqlParameter[]? sqlParameters, bool isVnet = false);
    }
}
