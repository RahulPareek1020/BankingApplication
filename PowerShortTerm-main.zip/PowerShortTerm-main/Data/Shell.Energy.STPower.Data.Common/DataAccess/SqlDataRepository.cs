﻿using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Shell.Energy.STPower.Data.Dto;
using Shell.Energy.STPower.Data.Integration.Constants;
using Shell.Energy.STPower.Shared;
using System.Data;
using System.Globalization;

namespace Shell.Energy.STPower.Data.Integration.DataAccess
{
    /// <summary>
    /// Class to interact with SQL database
    /// </summary>
    public class SqlDataRepository : ISqlDataRepository
    {
        private readonly string? _connectionString;
        private readonly string? _connectionVNETString;
        private readonly int _commandTimeout;
        private readonly IAppLogger _logger;

        public SqlDataRepository(IConfiguration configuration, IAppLogger logger)
        {
            _logger = logger;
            var env = configuration?.GetSection("STPowerEnv")?.Value.ToUpperInvariant();
            _connectionString = configuration?.GetConnectionString($"{ServiceConstants.STPowerConnectionStringName}-{env}");
            _connectionVNETString = configuration?.GetConnectionString($"{ServiceConstants.IntegrationVNetDBConnectionStringName}-{env}");
            _commandTimeout = Convert.ToInt32(configuration?.GetSection("commandTimeout").Value, CultureInfo.InvariantCulture);
        }


        /// <summary>
        /// Get/Update data in SQL table
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="sqlQuery"></param>
        /// <param name="parameter"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public List<T> ExecuteSqlQuery<T>(string sqlQuery, object? parameter = null)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                try
                {
                    connection.Open();
                    List<T> queryResult;
                    if (parameter == null)
                    {
                        queryResult = connection.Query<T>(sqlQuery).ToList();
                    }
                    else
                    {
                        queryResult = connection.Query<T>(sqlQuery, parameter).ToList();
                    }
                    connection.Close();
                    return queryResult;
                }
                catch (Exception e)
                {
                    _logger.LogError("Error during ExecuteSqlQuery method execution, Exception trace: " + e.StackTrace);
                    throw;
                }
                finally
                {
                    if (connection.State == ConnectionState.Open)
                    {
                        connection.Close();
                    }
                }
            }
        }

        /// <summary>
        /// Execute stored procedure
        /// </summary>
        /// <param name="storedProcedureName"></param>
        /// <param name="parameters"></param>
        public void ExecuteStoredProcedure(string storedProcedureName, DynamicParameterDto? dynamicParameterDto = null)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                try
                {
                    connection.Open();
                    var dynamicParameters = new DynamicParameters();
                    if (dynamicParameterDto != null && dynamicParameterDto.TableParameter != null)
                    {
                        dynamicParameters.Add(dynamicParameterDto.DynamicParameterName, dynamicParameterDto.TableParameter.AsTableValuedParameter(dynamicParameterDto.TableTypeName));
                    }

                    connection.Execute(storedProcedureName, dynamicParameters, commandType: CommandType.StoredProcedure);
                    connection.Close();
                }
                catch (Exception e)
                {
                    _logger.LogError("Error during ExecuteStoredProcedure method execution, Exception trace: " + e.StackTrace);
                    throw;
                }
                finally
                {
                    if (connection.State == ConnectionState.Open)
                    {
                        connection.Close();
                    }
                }
            }
        }

        /// <summary>
        /// Execute reader asynchronously
        /// </summary>
        /// <param name="storedProcedureName"></param>
        /// <param name="sqlParameters"></param>
        public async Task<IDataReader> ExecuteReaderAsync(string storedProcedureName, SqlParameter[]? sqlParameters, bool isVnet = false)
        {
            string? connectionString = isVnet ? _connectionVNETString : _connectionString;

            var connection = new SqlConnection(connectionString);
            try
            {
                await connection.OpenAsync();
                var command = new SqlCommand(storedProcedureName, connection)
                {
                    CommandType = CommandType.StoredProcedure,
                    CommandTimeout = _commandTimeout
                };
                if (sqlParameters != null && sqlParameters.Length > 0)
                {
                    command.Parameters.AddRange(sqlParameters);
                }
                var reader = await command.ExecuteReaderAsync(CommandBehavior.CloseConnection);
                return reader;
            }
            catch (Exception)
            {
                await connection.CloseAsync();
                throw;
            }
        }
    }
}
