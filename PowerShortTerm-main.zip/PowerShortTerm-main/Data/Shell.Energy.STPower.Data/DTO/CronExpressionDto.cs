﻿namespace Shell.Energy.STPower.Data.DTO
{
    public class CronExpressionDto
    {
        public int CronExpressionId { get; set; }
        public string? CronExpressionValue { get; set; }
    }
}
