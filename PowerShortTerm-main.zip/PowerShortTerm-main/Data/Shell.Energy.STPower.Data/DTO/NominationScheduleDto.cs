﻿namespace Shell.Energy.STPower.Data.DTO
{
    public class NominationScheduleDto
    {
        public int NominationDefinitionId { get; set; }
        public int DaysOffsetMin { get; set; }
        public int DaysOffsetMax { get; set; }
    }
}
