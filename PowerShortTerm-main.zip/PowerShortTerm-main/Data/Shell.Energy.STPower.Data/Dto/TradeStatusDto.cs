﻿namespace Shell.Energy.STPower.Data.Dto
{
    /// <summary>
    /// Dto for the trade status.
    /// </summary>
    public class TradeStatusDto
    {
        public string Reference { get; set; } = string.Empty;
        public string Result { get; set; } = string.Empty;
        public string Text { get; set; } = string.Empty;
    }
}
