﻿using System.Data;

namespace Shell.Energy.STPower.Data.Dto
{
    public class DynamicParameterDto
    {
        public DataTable TableParameter { get; set; }
        public string DynamicParameterName { get; set; }
        public string TableTypeName { get; set; }

        public DynamicParameterDto(DataTable tableParameter, string dynamicParameterName, string tableTypeName)
        {
            TableParameter = tableParameter;
            DynamicParameterName = dynamicParameterName;
            TableTypeName = tableTypeName;
        }
    }
}
