﻿using Azure.Data.Tables;
using Shell.Azure.TableStorage.Query.Filter;

namespace Shell.Azure.TableStorage.Query.QueryBuilder
{
	public sealed class TableQueryOptions<T> where T : ITableEntity
    {
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public int Top { get; set; }

        public string? SelectProperties { get; set; }

        public FilterCondition<T>[]? Filters { get; set; }
    }
}
