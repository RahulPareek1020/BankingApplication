﻿using Azure.Data.Tables;
using Shell.Azure.TableStorage.Query.Filter;
using System.Collections.Generic;
using System.Text;

namespace Shell.Azure.TableStorage.Query.QueryBuilder
{
	internal static class TableUriQueryBuilder
    {

        internal static string Build<T>(TableQueryOptions<T> options) where T : ITableEntity
        {
            if (options == null) return null;

            var result = string.Empty;

            bool first = true;

            if (options.PartitionKey != null)
            {
                result += $"PartitionKey eq '{options.PartitionKey}'";
                first = false;
            }
            if (options.RowKey != null)
            {
                result += first ? $"RowKey eq '{options.RowKey}'" : $" and RowKey eq '{options.RowKey}'";

            }

            if (options.Filters == null) return result;


            if (options.Filters?.Length > 0)
            {
                result += result == string.Empty ? $"{BuildFilterCondition(options.Filters)}" : $" and {BuildFilterCondition(options.Filters)}";
            }

            return result;
        }

        private static string BuildFilterCondition<T>(IReadOnlyList<FilterCondition<T>> filters) where T : ITableEntity
        {
            var sb = new StringBuilder();

            for (var i = 0; i < filters.Count; i++)
            {
                if (filters[i].Conditions == null)
                {
                    sb.Append(filters[i].FilterOperator.Operator);
                    continue;
                }

                if (filters.Count > 1) sb.Append("(");

                for (var j = 0; j < filters[i].Conditions.Length; j++)
                {
                    sb.Append(filters[i].Conditions[j].FilterString);

                    if (j != filters[i].Conditions.Length - 1)
                    {
                        sb.Append(filters[i].FilterOperator.Operator);
                    }
                }

                if (filters.Count > 1) sb.Append(")");
            }

            return sb.ToString();
        }
    }
}
