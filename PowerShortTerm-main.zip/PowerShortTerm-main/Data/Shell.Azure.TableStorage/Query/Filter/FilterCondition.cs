﻿using Azure.Data.Tables;
using Shell.Azure.TableStorage.Query.Compare;

namespace Shell.Azure.TableStorage.Query.Filter
{
	public class FilterCondition<T> where T : ITableEntity
    {
        public FilterOperator FilterOperator { get; set; }

        public CompareCondition<T>[] Conditions { get; set; }

        public FilterCondition(FilterOperator filterOperator)
        {
            FilterOperator = filterOperator;
        }

        public FilterCondition<T>[] Filters { get; set; }
        public FilterCondition() { }
    }
}
