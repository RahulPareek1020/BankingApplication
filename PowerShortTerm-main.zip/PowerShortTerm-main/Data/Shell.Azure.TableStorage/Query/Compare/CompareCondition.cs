﻿using Azure.Data.Tables;
using Shell.Azure.TableStorage.Enum;
using Shell.Azure.TableStorage.Query.Filter;
using System;
using System.Globalization;
using System.Linq.Expressions;
using System.Reflection;

namespace Shell.Azure.TableStorage.Query.Compare
{
	public sealed class CompareCondition<T> : FilterCondition<T> where T : ITableEntity
    {
        internal readonly string FilterString;



        public CompareCondition(Expression<Func<T, object>> propertyName, CompareOperator opertaor, string value)
            : this(propertyName, opertaor, value, TableDataType.String) { }

        public CompareCondition(Expression<Func<T, object>> propertyName, CompareOperator opertaor, bool value)
            : this(propertyName, opertaor, value ? "true" : "false", TableDataType.Boolean) { }

        public CompareCondition(Expression<Func<T, object>> propertyName, CompareOperator opertaor, DateTimeOffset value)
            : this(propertyName, opertaor, value.UtcDateTime.ToString("o"), TableDataType.DateTime) { }

        public CompareCondition(Expression<Func<T, object>> propertyName, CompareOperator opertaor, double value)
            : this(propertyName, opertaor, value.ToString(CultureInfo.InvariantCulture), TableDataType.Double) { }

        public CompareCondition(Expression<Func<T, object>> propertyName, CompareOperator opertaor, int value)
            : this(propertyName, opertaor, value.ToString(CultureInfo.InvariantCulture), TableDataType.Int32) { }

        public CompareCondition(Expression<Func<T, object>> propertyName, CompareOperator opertaor, long value)
            : this(propertyName, opertaor, value.ToString(CultureInfo.InvariantCulture) + "L", TableDataType.Int64) { }

        public CompareCondition(Expression<Func<T, object>> propertyName, CompareOperator opertaor, Guid value)
            : this(propertyName, opertaor, value.ToString(), TableDataType.Guid) { }

        private CompareCondition(Expression<Func<T, object>> propertyName, CompareOperator opertaor, string value, TableDataType dataType)
        {
            string valueString;

            switch (dataType)
            {
                case TableDataType.Boolean:
                case TableDataType.Int32:
                case TableDataType.Int64:
                    valueString = value;
                    break;
                case TableDataType.DateTime:
                    valueString = "datetime'" + value + "'";
                    break;
                case TableDataType.Double:
                    valueString = int.TryParse(value, out var parsedValue) ? parsedValue.ToString(CultureInfo.InvariantCulture) + ".0" : value;
                    break;
                case TableDataType.Guid:
                    valueString = "guid'" + value + "'";
                    break;
                default:
                    if (value.IndexOf('\'') != -1) value = value.Replace("'", "''");
                    valueString = "'" + value + "'";
                    break;
            }

            FilterString = "(" + GetPropertyName(propertyName) + opertaor.Operator + valueString + ")";
        }

        public FilterCondition<T>[] Filters { get; set; }

        private static string GetPropertyName<T>(Expression<Func<T, object>> property)
        {
            LambdaExpression lambda = property;
            MemberExpression memberExpression;

            if (lambda.Body is UnaryExpression)
            {
                UnaryExpression unaryExpression = (UnaryExpression)lambda.Body;
                memberExpression = (MemberExpression)unaryExpression.Operand;
            }
            else
            {
                memberExpression = (MemberExpression)lambda.Body;
            }

            var name = ((PropertyInfo)memberExpression.Member).Name;
            return name;
        }
    }
}
