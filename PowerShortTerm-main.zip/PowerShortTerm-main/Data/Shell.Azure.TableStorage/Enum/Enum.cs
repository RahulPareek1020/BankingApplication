﻿namespace Shell.Azure.TableStorage.Enum
{
	/// <summary>
	/// Enum representing table data type
	/// </summary>
	public enum TableDataType
    {
        String,
        Boolean,
        DateTime,
        Double,
        Guid,
        Int32,
        Int64
    }
}
