﻿namespace Shell.Azure.TableStorage.Extension
{
	/// <summary>
	/// BatchExecution with limiting the operation based on the TableConstants.TableServiceBatchMaximumOperations
	/// </summary>
	internal static class ExtensionBatchExecutionWithLimit
    {
        /// <summary>
        /// Executing as limited batches
        /// </summary>
        /// <param name="table"></param>
        /// <param name="batch"></param>
        /// <returns></returns>
       /* public static async Task<IList<TableResult>> ExecuteBatchAsLimitedBatches(this CloudTable table,
                                                                  TableBatchOperation batch)
        {
            using (TransactionScope scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                try
                {
                    if (IsBatchCountUnderSupportedOperationsLimit(batch))
                    {
                        return await table.ExecuteBatchAsync(batch);
                    }

                    var result = new List<TableResult>();
                    var limitedBatchOperationLists = GetLimitedBatchOperationLists(batch);
                    //foreach (var limitedBatchOperationList in limitedBatchOperationLists)
                    Parallel.ForEach(limitedBatchOperationLists, async limitedBatchOperationList =>
                    {
                        var limitedBatch = CreateLimitedTableBatchOperation(limitedBatchOperationList);
                        var limitedBatchResult = await table.ExecuteBatchAsync(limitedBatch);
                        result.AddRange(limitedBatchResult);
                    });
                    scope.Complete();

                    return result;
                }
                finally
                {
                    scope.Dispose();
                }
            }
        }

        /// <summary>
        /// Checking that 
        /// </summary>
        /// <param name="batch"></param>
        /// <returns></returns>
        private static bool IsBatchCountUnderSupportedOperationsLimit(TableBatchOperation batch)
        {
            return batch.Count <= TableConstants.TableServiceBatchMaximumOperations;
        }

        /// <summary>
        /// Getting Chunk of batch operation
        /// </summary>
        /// <param name="batch"></param>
        /// <returns></returns>
        private static IEnumerable<List<TableOperation>> GetLimitedBatchOperationLists(TableBatchOperation batch)
        {
            return batch.ChunkBy(TableConstants.TableServiceBatchMaximumOperations);
        }

        private static TableBatchOperation CreateLimitedTableBatchOperation(IEnumerable<TableOperation> limitedBatchOperationList)
        {
            var limitedBatch = new TableBatchOperation();
            foreach (var limitedBatchOperation in limitedBatchOperationList)
            {
                limitedBatch.Add(limitedBatchOperation);
            }

            return limitedBatch;
        }

        /// <summary>
        /// Creating a list by chunks based on the chunk size
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source"></param>
        /// <param name="chunkSize"></param>
        /// <returns></returns>
        private static List<List<T>> ChunkBy<T>(this IList<T> source, int chunkSize)
        {
            return source
                .Select((x, i) => new { Index = i, Value = x })
                .GroupBy(x => x.Index / chunkSize)
                .Select(x => x.Select(v => v.Value).ToList())
                .ToList();
        }*/
    }
}
