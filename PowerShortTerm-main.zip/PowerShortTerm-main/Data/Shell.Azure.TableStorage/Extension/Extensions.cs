﻿using System.Collections.Concurrent;
using System.Collections.Generic;

namespace Shell.Azure.TableStorage.Extension
{
	#region Extension for Concurrent Bag Add Range
	/// <summary>
	/// Extension for Concurrent Bag Add Range
	/// </summary>
	internal static class Extensions
    {
        internal static void AddRange<T>(this ConcurrentBag<T> @this, IEnumerable<T> toAdd)
        {
            foreach (var element in toAdd)
            {
                @this.Add(element);
            }
        }
    }
    #endregion
}
