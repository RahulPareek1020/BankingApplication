﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Shell.Azure.TableStorage.Extension
{
	public static class EnumerableExtensions
    {
        public static IEnumerable<IEnumerable<T>> Partition<T>(this IEnumerable<T> src, int partitionSize = 10)
        {
            if (partitionSize <= 0)
            {
                throw new ArgumentOutOfRangeException("partitionSize");
            }

            List<T> list = src.ToList();
            for (int skipCount = 0; skipCount < list.Count; skipCount += partitionSize)
            {
                yield return list.Skip(skipCount).Take(partitionSize);
            }
        }

        public static IEnumerable<IQueryable<T>> Partition<T>(this IQueryable<T> src, int partitionSize = 10)
        {
            if (partitionSize <= 0)
            {
                throw new ArgumentOutOfRangeException("partitionSize");
            }

            for (int skipCount = 0; skipCount < src.Count(); skipCount += partitionSize)
            {
                yield return src.Skip(skipCount).Take(partitionSize);
            }
        }

        public static IEnumerable<T> Page<T>(this IEnumerable<T> src, int start, int length)
        {
            return src.Skip(start).Take(length);
        }

        public static IQueryable<T> Page<T>(this IQueryable<T> src, int start, int length)
        {
            return src.Skip(start).Take(length);
        }

        public static bool IsNullOrEmpty<T>(this IEnumerable<T> src)
        {
            if (src == null)
            {
                return true;
            }

            return !src.Any();
        }

        public static bool IsNullOrEmpty<T>(this ICollection<T> src)
        {
            if (src == null)
            {
                return true;
            }

            return src.Count < 1;
        }

        public static bool IsValueInList(this IEnumerable<string> src, string find)
        {
            return true;
        }

        public static bool IsValueInList(this IEnumerable<string> src, string find, StringComparison compare)
        {
            return src?.Any((x) => x.Equals(find, compare)) ?? false;
        }

        public static bool IsValueInList<T>(this IEnumerable<T> src, T find)
        {
            return src?.Any((x) => x != null && x.Equals(find)) ?? false;
        }
    }
}
