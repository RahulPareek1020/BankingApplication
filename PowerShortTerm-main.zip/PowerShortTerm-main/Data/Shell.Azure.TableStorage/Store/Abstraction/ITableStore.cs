﻿using Azure.Data.Tables;
using Shell.Azure.TableStorage.Query.QueryBuilder;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Shell.Azure.TableStorage.Store.Abstraction
{
    /// <summary>
    /// Contract to perform operations on entities of table
    /// Insert, InsertOrMerge, InsertOrReplace , Delete records
    /// Query based on Partition and RowKeys
    /// Query based on filter conditions
    /// Query based on timestamp , ago.
    /// </summary>
    /// <typeparam name="T">The type of table storage entity</typeparam>
    public interface ITableStore<T> : ITableStoreBase where T : class
    {

        /// <summary>
        /// The InsertOrReplace Entity operation replaces an existing entities or inserts a new entity if it does not exist in the table.  
        /// Replaces the entire entities, including removing any fields that were not defined in the new entity.
        /// This Operation cannot handle Optimistic concurrency
        /// </summary>
        /// <param name="records">The records to insert</param>
        Task InsertOrReplaceAsync(IEnumerable<T> records);

        /// <summary>
        /// The InsertOrReplace Entity operation replaces an existing entity or inserts a new entity if it does not exist in the table.  
        /// Replaces the entire entity, including removing any fields that were not defined in the new entity.
        /// This Operation cannot handle Optimistic concurrency
        /// </summary>
        /// <param name="record"></param>
        Task InsertOrReplaceAsync(T record);

        /// <summary>
        ///The InsertOrMerge Entity operation updates an existing entity or inserts a new entity if it does not exist in the table.
        ///The old fields and values remain if the new entity does not include them, and all the other fields will be updated.
        ///This Operation cannot handle Optimistic concurrency 
        /// </summary>
        /// <param name="record">The record to update</param>
        Task InsertOrMergeAsync(T record);

        /// <summary>
        /// The InsertOrMerge Entity operation replaces an existing entities or inserts a new entity if it does not exist in the table.  
        /// Replaces the entire entities, including removing any fields that were not defined in the new entity.
        /// This Operation cannot handle Optimistic concurrency 
        /// </summary>
        /// <param name="records">The records to insert</param>
        Task InsertOrMergeAsync(IEnumerable<T> records);

        /// <summary>
        /// An ETag property is used for optimistic concurrency during updates.
        /// For example, if you load an entity and want to update it, 
        /// the ETag must match what is currently stored. 
        /// This is important b/c if you have multiple users editing the same item, 
        /// you don't want them overwriting each other's changes
        /// If you don't care and want to override changes , then you can pass "*" with the save and Azure won't give an error when the ETag does not match.
        /// </summary>
        /// <param name="record">The record to update</param>
        /// </summary>
        Task UpdateUsingWildcardEtagAsync(T record);

        /// <summary>
        /// Deletes a given record from entity
        /// </summary>
        /// <param name="record">The record to delete</param>
#pragma warning disable S4136 // Method overloads should be grouped together
        Task DeleteAsync(T record, bool considerEtag = false);
#pragma warning restore S4136 // Method overloads should be grouped together

        /// <summary>
        /// Delete a record using the wildcard etag, discarding concurrency
        /// </summary>
        /// <param name="record">The record to delete</param>
        /// // revisit,
        Task DeleteUsingWildcardEtagAsync(T record);

        /// <summary>
        /// Delete records by partition key
        /// </summary>
        /// <param name="partitionKey"></param>
        /// <returns></returns>
        Task DeleteAsync(string partitionKey);

        /// <summary>
        /// Get a record by PartitionKey and RowKey
        /// </summary>
        /// <param name="partitionKey"></param>
        /// <param name="rowKey"></param>
        /// <returns>The record found or null if not found</returns>
        Task<T> GetRecordAsync(string partitionKey, string rowKey);



        /// <summary>
        /// Get  records by PartitionKey only
        /// </summary>
        /// <param name="partitionKey">The partition key</param>
        /// <returns>The records found,EmptyList if no records found</returns>
#pragma warning disable S4136 // Method overloads should be grouped together
        Task<IEnumerable<T>> GetRecordsAsync(string partitionKey);
#pragma warning restore S4136 // Method overloads should be grouped together

        /// <summary>
        /// Get the records by RowKey only
        /// </summary>
        /// <param name="rowKey">The row key</param>
        /// <returns>The records found.EmptyList if no records found</returns>
        Task<IEnumerable<T>> GetRecordsAcrossPartitions(string rowKey);



        /// <summary>
        /// Get record in table by passing a query expression in cosmos term.
        /// This mehtod should be used in an extreme condition , where we are not able to use any of the other availble methods.
        /// </summary>
        /// <param name="filter"></param>
        /// <returns>The records found.EmptyList if no records found</returns>
        Task<IEnumerable<T>> QueryAsync(string filter);

        /// <summary>
        /// Gets record by query build using framework Filercondition and Compare condition
        /// </summary>
        /// <typeparam name="Ti"></typeparam>
        /// <param name="options"></param>
        /// <returns>The records found.EmptyList if no records found</returns>
        Task<IEnumerable<T>> QueryAsync<Ti>(TableQueryOptions<Ti> options) where Ti : ITableEntity;

        /// <summary>
        /// Get records  based on partition key and list of rowkeys
        /// </summary>
        /// <param name="partitionKey"></param>
        /// <param name="rowKeys"></param>
        /// <returns>The records found.EmptyList if no records found</returns>
        Task<IEnumerable<T>> GetRecordsAsync(string partitionKey, List<string> rowKeys);

        /// <summary>
        ///  Get records  based on partition key , rowkey and startwwith pattern of rowkey
        /// </summary>
        /// <param name="partitionKey"></param>
        /// <param name="rowKey"></param>
        /// <param name="startWithTrue"></param>
        /// <returns>The records found.EmptyList if no records found</returns>
        Task<IEnumerable<T>> GetRecordsAsync(string partitionKey, string rowKey, bool startWithTrue = false);

        /// <summary>
        ///  Get records  based on partition key , and List of rowkey and startwwith pattern of rowkey
        /// </summary>
        /// <param name="partitionKey"></param>
        /// <param name="rowKeys"></param>
        /// <param name="startWithTrue"></param>
        /// <returns>The records found.EmptyList if no records found</returns>
        Task<IEnumerable<T>> GetRecordsAsync(string partitionKey, List<string> rowKeys, bool startWithTrue);


        /// <summary>
        /// Get the records by partition key and timestamp
        /// </summary>
        /// <param name="partitionKey">The partition key</param>
        /// <param name="ago">The time in the past to search e.g. 10m, 1h, etc.</param>
        /// <returns>The records found</returns>
        /// Task<IEnumerable<T>> GetRecordsAsync(string partitionKey, string ago);


        //Refactor ago , make use of DateTime/DateTimeOffset instead of string.
        /// <summary>
        /// Get the records by row RowKey and timestamp
        /// </summary>
        /// <param name="rowKey">The row key</param>
        /// <param name="ago">The time in the past to search e.g. 10m, 1h, etc.</param>
        /// <returns>The records found</returns>
        ///Task<IEnumerable<T>> GetRecordsAcrossPartitions(string rowKey, string ago);

        /// <summary>
        ///  Fetch all record. Do not use if the table record has more than 100, it may impact on the performance
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="token"></param>
        /// <returns>The records found.EmptyList if no records found</returns>

        Task<IList<T>> FetchAllRecord();

        // <summary>
        ///  Delete entity from the Azure Storage Table
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="entities"></param>
        /// <returns></returns>
        Task<bool> BatchDeleteEntityAsync(List<T> entities);

        /// <summary>
        /// The UpdateAsync Entity operation updates an existing entity in the table.  
        /// This Operation  handles Optimistic concurrency using Etag 
        /// </summary>
        /// <param name="record">The record to insert</param>
        Task<bool> UpdateAsync(T record);

        /// <summary>
        /// The UpdateAsync Entity operation updates an existing entities in the table.  
        /// This Operation  handles Optimistic concurrency using Etag 
        /// </summary>
        /// <param name="records">The records to insert</param>
        Task UpdateAsync(IEnumerable<T> records);


    }
}
