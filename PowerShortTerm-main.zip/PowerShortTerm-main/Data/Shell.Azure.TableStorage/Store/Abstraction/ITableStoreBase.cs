﻿using System.Threading.Tasks;

namespace Shell.Azure.TableStorage.Store.Abstraction
{
	/// <summary>
	/// Contract  defines DDL operations on table
	/// </summary>
	public interface ITableStoreBase
    {

        /// <summary>
        /// Creates the table in Asyncronously 
        /// </summary>
        Task CreateTableAsync();

        /// <summary>
        /// Check if table exists Asyncronously
        /// </summary>
        /// <returns></returns>
        Task<bool> TableExistsAsync();

        /// <summary>
        /// Deletes the table Asyncronously
        /// </summary>
        Task DeleteTableAsync();

    }
}
