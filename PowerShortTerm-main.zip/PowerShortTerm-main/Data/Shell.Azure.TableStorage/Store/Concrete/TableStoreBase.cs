﻿using Polly;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Threading.Tasks;
using Azure.Data.Tables;
using Azure.Core;
using System.Linq;

namespace Shell.Azure.TableStorage.Store.Concrete
{
	/// <summary>
	/// Base class performs table level operations
	/// creation
	/// deletion
	/// setting up of cloud client and retry policy
	/// </summary>
	public class TableStoreBase
    {
        /// <summary>
        /// The max size for a single partition to be added to Table Storage
        /// </summary>
        protected const int MaxPartitionSize = 100;

        /// <summary>
        /// Represents microsoft azure table
        /// </summary>
        //protected readonly CloudTable _cloudTable;

        protected readonly TableClient _tableClient;


        /// <summary>
        /// Provides a client-side logical representation of the Microsoft Azure Table service. 
        /// This client is used to configure and execute requests against the Table service.
        /// The CloudTableClient object encapsulates the base URI for the Table service. 
        /// If the service client will be used for authenticated access, it also encapsulates the credentials for accessing the storage account.
        /// </summary>
        protected readonly TableServiceClient _tableServiceClient;

        /// <summary>
        /// Allows configuring automatic retries.
        /// </summary>
        protected readonly Policy _retryStorageExceptionPolicy;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="tableName">The table name</param>
        /// <param name="storageConnectionString">The connection string</param>
        protected TableStoreBase(string tableName, string storageConnectionString) : this(tableName, storageConnectionString, new TableStorageOptions())
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="tableName">The table name</param>
        /// <param name="storageConnectionString">The connection string</param>
        /// <param name="options">Table storage options</param>
        protected TableStoreBase(string tableName, string storageConnectionString, TableStorageOptions options)
        {
            int retries = 0;
            int maxRetryAttempts = 5;
            _retryStorageExceptionPolicy = Policy
                .Handle<TableTransactionFailedException>()
                .WaitAndRetry(maxRetryAttempts, sleepDuration => TimeSpan.FromSeconds(Math.Pow(2, sleepDuration)),
                    onRetry: (exception, calculatedWaitDuration) =>
                    {
                        retries++;
                        Debug.WriteLine(
                            new Dictionary<string, string>
                            {
                    {"Message", $"A StorageException occurred when trying to Execute Query With Retry. This exception has been caught and will be retried." },
                    {"Current Retry Count", retries.ToString() },
                    //{"tableName", table.Name},
                    {"ExtendedErrorInformation.ErrorCode", (exception as TableTransactionFailedException)?.ErrorCode! },
                    {"ExtendedErrorInformation.ErrorMessage", (exception as TableTransactionFailedException)?.Message!}
                            });
                    });
            if (string.IsNullOrWhiteSpace(tableName))
            {
                throw new ArgumentException("Table name cannot be null or empty", nameof(tableName));
            }

            if (string.IsNullOrWhiteSpace(storageConnectionString))
            {
                throw new ArgumentException("Table connection string cannot be null or empty", nameof(storageConnectionString));
            }

            if (options == null)
            {
                throw new ArgumentNullException(nameof(options), "Table storage options cannot be null");
            }

            OptimisePerformance(storageConnectionString, options);
            var tableClientOptions = SetupTableClientOptions(options);
            _tableServiceClient = CreateTableServiceClient(storageConnectionString, tableClientOptions);
            _tableClient = GetTableClient(tableName);

            if (options.EnsureTableExists)
            {
                CreateIfNotExists();
            }
        }

        private TableServiceClient CreateTableServiceClient(string storageConnectionString, TableClientOptions tableClientOptions)
        {
            var account = new TableServiceClient(storageConnectionString, tableClientOptions);
            return account;
        }

        private TableClientOptions SetupTableClientOptions(TableStorageOptions options)
        {
            TableClientOptions option = new TableClientOptions();
            option.Retry.Delay = TimeSpan.FromSeconds(options.RetryWaitTimeInSeconds);
            option.Retry.MaxRetries = options.Retries;
            option.Retry.Mode = RetryMode.Exponential;
            return option;
        }


        #region GetTableReference
        /// <summary>
        /// Returns the Azure Table based in cloud table name
        /// </summary>
        /// <typeparam name="T">Table Entity for which cloud table reference has to be fetched</typeparam>
        /// <returns>Cloud Table reference based on cloudTableName</returns>
        public TableClient GetTableClient(string cloudTableName)
        {
            return _retryStorageExceptionPolicy
                .Execute(() =>
                {
                    return _tableServiceClient.GetTableClient(cloudTableName);
                });
        }
        #endregion
        /// <summary>
        /// Settings to improve performance
        /// </summary>
        private static void OptimisePerformance(string storageConnectionString, TableStorageOptions options)
        {
            var blocks = storageConnectionString.Split(";").ToList();
            var accountName = blocks.FirstOrDefault(x => x.Split("=")[0] == "AccountName")!.Split("=")[1];
            var defaultEndpointsProtocol = blocks.FirstOrDefault(x => x.Split("=")[0] == "DefaultEndpointsProtocol")!.Split("=")[1];
            var uri = $"{defaultEndpointsProtocol}://{accountName}.table.core.windows.net";
            var tableServicePoint = ServicePointManager.FindServicePoint(new Uri(uri));
            tableServicePoint.UseNagleAlgorithm = options.UseNagleAlgorithm;
            tableServicePoint.Expect100Continue = options.Expect100Continue;
            tableServicePoint.ConnectionLimit = options.ConnectionLimit;

        }



        /// <summary>
        /// Create table if not exists
        /// </summary>
        private void CreateIfNotExists()
        {
            _tableClient.CreateIfNotExists();
        }

        /// <summary>
        /// Initiliazes an aysnc operatio to create a table if it doesnt exist.
        /// </summary>
        public async Task CreateTableAsync()
        {
            await _tableClient.CreateIfNotExistsAsync().ConfigureAwait(false);
        }

        /// <summary>
        /// Initiliazes an aysnc operatio to check if table exist.
        /// </summary>
        /// <returns></returns>
        public async Task<bool> TableExistsAsync()
        {
            var result = await _tableServiceClient.QueryAsync(t => t.Name == _tableClient.Name).ToListAsync();
            return result.Any();

        }

        /// <summary>
        /// Initiliazes an aysnc operatio to delete a table
        /// </summary>
        public async Task DeleteTableAsync()
        {
            await _tableClient.DeleteAsync().ConfigureAwait(false);
        }

        /// <summary>
        /// Get the number of the records in the table
        /// </summary>
        /// <returns>The record count</returns>


        #region Helpers

        /// <summary>
        /// Ensures the partition key is not null.
        /// </summary>
        /// <param name="partitionKey">The partition key.</param>
        /// <exception cref="ArgumentNullException">partitionKey</exception>
        protected void EnsurePartitionKeyNotNull(string partitionKey)
        {
            if (string.IsNullOrWhiteSpace(partitionKey))
            {
                throw new ArgumentNullException(nameof(partitionKey));
            }
        }

        /// <summary>
        /// Ensures the row key is not null.
        /// </summary>
        /// <param name="rowKey">The row key.</param>
        /// <exception cref="ArgumentNullException">rowKey</exception>
        protected void EnsureRowKeyNotNull(string rowKey)
        {
            if (string.IsNullOrWhiteSpace(rowKey))
            {
                throw new ArgumentNullException(nameof(rowKey));
            }
        }
        /// <summary>
        /// Ensure record is not null
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="record"></param>
        protected void EnsureRecordNotNull<T>(T record)
        {
            if (record == null)
            {
                throw new ArgumentNullException(nameof(record));
            }
        }

        #endregion Helpers
    }
}
