﻿using Azure;
using Azure.Data.Tables;
using Shell.Azure.TableStorage.Constants;
using Shell.Azure.TableStorage.Converters;
using Shell.Azure.TableStorage.Extension;
using Shell.Azure.TableStorage.Query.QueryBuilder;
using Shell.Azure.TableStorage.Store.Abstraction;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Shell.Azure.TableStorage.Store.Concrete
{
	/// <summary>
	/// Concrete implementation to perform operations on entities of table
	/// </summary>
	/// <typeparam name="T"></typeparam>
	public class TableStore<T> : TableStoreBase,
    ITableStore<T> where T : class,
    ITableEntity,
    new()
    {
        #region Construction

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="tableName">The table name</param>
        /// <param name="storageConnectionString">The connection string</param>
        public TableStore(string tableName, string storageConnectionString) : base(tableName, storageConnectionString, new TableStorageOptions()) { }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="tableName">The table name</param>
        /// <param name="storageConnectionString">The connection string</param>
        /// <param name="options">Table storage options</param>
        public TableStore(string tableName, string storageConnectionString, TableStorageOptions options) : base(tableName, storageConnectionString, options) { }

        #endregion Construction

        #region Asynchronous Methods
        /// <summary>
        /// The InsertOrReplace Entity operation replaces an existing entities or inserts a new entity if it does not exist in the table.  
        /// Replaces the entire entities, including removing any fields that were not defined in the new entity.
        /// This Operation cannot handle Optimistic concurrency
        /// </summary>
        /// <param name="records">The records to insert</param>
#pragma warning disable S4136 // Method overloads should be grouped together
        public async Task InsertOrReplaceAsync(IEnumerable<T> records)
#pragma warning restore S4136 // Method overloads should be grouped together
        {
            CheckRecordIsNull(records);
            //Convert recotds to TableEntity , So that we can store complex types in Azure Table 
            var tabelEntitys = ConvertTotableEntity(records);

            var partitionKeySeparation = tabelEntitys.GroupBy(x => x.PartitionKey).OrderBy(g => g.Key).Select(g => g.AsEnumerable()).SelectMany(entry => entry.Partition(MaxPartitionSize)).ToList();

            await InsertOrReplaceRecords(partitionKeySeparation);
        }

        private void HandleDateTimeKindUnSpecified(IEnumerable<T> records)
        {
            records.ToList().ForEach(x =>
            {
                List<PropertyInfo> propertyInfo = x.GetType().GetProperties().ToList();
                propertyInfo.ForEach(y =>
                {
                    if (y.PropertyType == typeof(DateTime) || y.PropertyType == typeof(DateTime?))
                    {
                        var dateTime = Convert.ToDateTime(y.GetValue(x));
                        if (dateTime.Kind == DateTimeKind.Unspecified)
                        {
                            dateTime = DateTime.SpecifyKind(dateTime, DateTimeKind.Utc);
                            y.SetValue(x, dateTime, null);
                        }
                    }
                });
            });
        }

        private void CheckRecordIsNull(IEnumerable<T> records)
        {
            if (records == null)
            {
                throw new ArgumentNullException(nameof(records));
            }
        }

        private async Task InsertOrReplaceRecords(List<IEnumerable<TableEntity>> partitionKeySeparation)
        {
            foreach (var entry in partitionKeySeparation)
            {
                var batch = new List<TableTransactionAction>();
                entry.ToList().ForEach(x => batch.Add(new TableTransactionAction(TableTransactionActionType.UpsertReplace, x)));

                //Execute the transaction
                if (batch.Any())
                {
                    await _retryStorageExceptionPolicy.Execute(async () =>
                    {
                        try
                        {
                            await _tableClient.SubmitTransactionAsync(batch).ConfigureAwait(false);

                        }
                        catch (TableTransactionFailedException ex)
                        {
                            if (ex.ErrorCode == ServiceConstants.InvalidDuplicateRow && ex.Status == 400 &&
                            ex.Message.Contains(ServiceConstants.DuplicateRowMessage, StringComparison.InvariantCultureIgnoreCase))
                            {
                                try
                                {
                                    await RetryBatchSubmitTransaction(batch);
                                }
                                catch (TableTransactionFailedException e)
                                {
                                    string errorMessage = $"Exception : ErrorCode : {e.ErrorCode}, ErrorMessage: {e.Message}";
                                    Debug.WriteLine(errorMessage);
                                    throw;
                                }
                            }
                            else
                            {
                                string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                                Debug.WriteLine(errorMessage);
                                throw;
                            }
                        }
                    });
                }
            }
        }


        private async Task RetryBatchSubmitTransaction(List<TableTransactionAction> batch)
        {
            //remove all duplicate rows
            var UniqueRowsBatch = batch.GroupBy(x => x.Entity.RowKey).Select(y => y.First()).ToList();
            await _tableClient.SubmitTransactionAsync(UniqueRowsBatch).ConfigureAwait(false);
        }



        /// <summary>
        /// The InsertOrReplace Entity operation replaces an existing entity or inserts a new entity if it does not exist in the table.  
        /// Replaces the entire entity, including removing any fields that were not defined in the new entity.
        /// This Operation cannot handle Optimistic concurrency 
        /// </summary>
        /// <param name="record"></param>
        public async Task InsertOrReplaceAsync(T record)
        {
            EnsureRecordNotNull(record);

            var tabelEntity = ConvertTotableEntity(new List<T>() { record }).FirstOrDefault();

            await _retryStorageExceptionPolicy.Execute(async () =>
            {
                try
                {
                    await _tableClient.UpsertEntityAsync(tabelEntity, TableUpdateMode.Replace).ConfigureAwait(false);
                }
                catch (TableTransactionFailedException ex)
                {
                    string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                    Debug.WriteLine(errorMessage);
                    throw;
                }
            });

        }

        /// <summary>
        ///The InsertOrMerge Entity operation updates an existing entity or inserts a new entity if it does not exist in the table.
        ///The old fields and values remain if the new entity does not include them, and all the other fields will be updated.
        ///This Operation cannot handle Optimistic concurrency
        /// </summary>
        /// <param name="record">The record to update</param>
        public async Task InsertOrMergeAsync(T record)
        {
            EnsureRecordNotNull(record);
            var tabelEntity = ConvertTotableEntity(new List<T>() { record }).FirstOrDefault();

            await _retryStorageExceptionPolicy.Execute(async () =>
            {
                try
                {
                    await _tableClient.UpsertEntityAsync(tabelEntity, TableUpdateMode.Merge).ConfigureAwait(false);
                }
                catch (TableTransactionFailedException ex)
                {
                    string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                    Debug.WriteLine(errorMessage);
                    throw;
                }
            });
        }


        /// <summary>
        /// The InsertOrMerge Entity operation replaces an existing entities or inserts a new entity if it does not exist in the table.  
        /// Replaces the entire entities, including removing any fields that were not defined in the new entity.
        /// This Operation cannot handle Optimistic concurrency 
        /// </summary>
        /// <param name="records">The records to insert</param>
        public async Task InsertOrMergeAsync(IEnumerable<T> records)
        {
            CheckRecordIsNull(records);
            var tabelEntitys = ConvertTotableEntity(records);

            var partitionKeySeparation = tabelEntitys.GroupBy(x => x.PartitionKey).OrderBy(g => g.Key).Select(g => g.AsEnumerable()).SelectMany(entry => entry.Partition(MaxPartitionSize)).ToList();

            foreach (var entry in partitionKeySeparation)
            {
                var batch = new List<TableTransactionAction>();
                entry.ToList().ForEach(x => batch.Add(new TableTransactionAction(TableTransactionActionType.UpsertMerge, x)));

                //Execute the transaction
                if (batch.Any())
                {
                    await _retryStorageExceptionPolicy.Execute(async () =>
                    {
                        try
                        {
                            await _tableClient.SubmitTransactionAsync(batch).ConfigureAwait(false);

                        }
                        catch (TableTransactionFailedException ex)
                        {
                            if (ex.ErrorCode == ServiceConstants.InvalidDuplicateRow && ex.Status == 400 &&
                            ex.Message.Contains(ServiceConstants.DuplicateRowMessage, StringComparison.InvariantCultureIgnoreCase))
                            {
                                try
                                {
                                    await RetryBatchSubmitTransaction(batch);
                                }
                                catch (TableTransactionFailedException e)
                                {
                                    string errorMessage = $"Exception : ErrorCode : {e.ErrorCode}, ErrorMessage: {e.Message}";
                                    Debug.WriteLine(errorMessage);
                                    throw;
                                }
                            }
                            else
                            {
                                string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                                Debug.WriteLine(errorMessage);
                                throw;
                            }
                        }
                    });
                }
            }
        }

        /// <summary>
        /// An ETag property is used for optimistic concurrency during updates.
        /// For example, if you load an entity and want to update it, 
        /// the ETag must match what is currently stored. 
        /// This is important b/c if you have multiple users editing the same item, 
        /// you don't want them overwriting each other's changes
        /// If you don't care and want to override changes , then you can pass "*" with the save and Azure won't give an error when the ETag does not match.
        /// </summary>
        /// <param name="record">The record to update</param>
        /// </summary>
        public async Task UpdateUsingWildcardEtagAsync(T record)
        {
            EnsureRecordNotNull(record);
            record.ETag = new ETag("*");
            await InsertOrMergeAsync(record).ConfigureAwait(false);
        }

        /// <summary>
        /// Deletes a given record from entity
        /// </summary>
        /// <param name="record">The record to delete</param>
#pragma warning disable S4136 // Method overloads should be grouped together
        public async Task DeleteAsync(T record, bool considerEtag = false)
#pragma warning restore S4136 // Method overloads should be grouped together
        {
            EnsureRecordNotNull(record);
            await _retryStorageExceptionPolicy.Execute(async () =>
            {
                try
                {
                    if (considerEtag)
                    {
                        await _tableClient.DeleteEntityAsync(record.PartitionKey, record.RowKey, record.ETag);

                    }
                    else
                    {
                        await _tableClient.DeleteEntityAsync(record.PartitionKey, record.RowKey);

                    }
                }
                catch (TableTransactionFailedException ex)
                {
                    string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                    Debug.WriteLine(errorMessage);
                    throw;
                }
            });
        }

        /// <summary>
        /// Delete a record using the wildcard etag, discarding concurrency
        /// </summary>
        /// <param name="record">The record to delete</param>
        /// // revisit,
        public async Task DeleteUsingWildcardEtagAsync(T record)
        {
            EnsureRecordNotNull(record);
            record.ETag = new ETag("*");
            await DeleteAsync(record, true).ConfigureAwait(false);
        }

        /// <summary>
        /// Delete records by partition key
        /// </summary>
        /// <param name="partitionKey"></param>
        /// <returns></returns>
        public async Task DeleteAsync(string partitionKey)
        {
            //Gets the  all Records based on PartitionKey, which we need to delete.
            var records = new List<T>();
            var recordsTobeDeleted = await _tableClient.QueryAsync<TableEntity>(e => e.PartitionKey == partitionKey, null).ToListAsync();
            recordsTobeDeleted.ForEach(x => records.Add(x.FromTableEntity<T, object, object>(e => e.PartitionKey, e => e.RowKey)));
            var tableTransactionActions = new List<TableTransactionAction>();
            records.ForEach(x => tableTransactionActions.Add(new TableTransactionAction(TableTransactionActionType.Delete, x)));

            //devide the recordsTobeDeleted into batches and process the batches one by one 
            var batches = tableTransactionActions.Batch(100);

            foreach (var batch in batches)
            {
                await _retryStorageExceptionPolicy.Execute(async () =>
                {
                    try
                    {
                        await _tableClient.SubmitTransactionAsync(batch).ConfigureAwait(false);
                    }
                    catch (TableTransactionFailedException ex)
                    {
                        string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                        Debug.WriteLine(errorMessage);
                        throw;
                    }
                });
            }
        }

        private List<TableEntity> ConvertTotableEntity(IEnumerable<T> records)
        {
            List<TableEntity> tableEntities = new List<TableEntity>();
            records.ToList().ForEach(r => tableEntities.Add(r.ToTableEntity(e => e.PartitionKey, e => e.RowKey)));
            return tableEntities;
        }


        #endregion Asynchronous Methods

        #region query
        /// <summary>
        /// Get an record by partition and row key
        /// </summary>
        /// <param name="partitionKey"></param>
        /// <param name="rowKey"></param>
        /// <returns>The record found or null if not found</returns>
        public async Task<T> GetRecordAsync(string partitionKey, string rowKey)
        {
            EnsurePartitionKeyNotNull(partitionKey);
            EnsureRowKeyNotNull(rowKey);
            T record = new T();
            //we will retrieve the record in TableEntity type then will Convert it to T using
            //FromTableEntity extension method . This will hanlde Complex types.
            try
            {
                var tableEntity = await _tableClient.GetEntityAsync<TableEntity>(partitionKey, rowKey).ConfigureAwait(false);
                record = tableEntity.Value.FromTableEntity<T, object, object>(e => e.PartitionKey, e => e.RowKey);
            }
            catch (RequestFailedException ex)
            {
                if (Convert.ToInt32(ex.Status) != Convert.ToInt32(System.Net.HttpStatusCode.NotFound))
                {
                    string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                    Debug.WriteLine(errorMessage);
                    throw;
                }

                record = null;
            }
            if (record != null)
            {
                HandleDateTimeKindUnSpecified(new List<T> { record });
            }
            return record;
        }

        /// <summary>
        /// Get the records by partition key
        /// </summary>
        /// <param name="partitionKey">The partition key</param>
        /// <returns>The records found, EmptyList if no records found</returns>
#pragma warning disable S4136 // Method overloads should be grouped together
        public async Task<IEnumerable<T>> GetRecordsAsync(string partitionKey)
#pragma warning restore S4136 // Method overloads should be grouped together
        {
            EnsurePartitionKeyNotNull(partitionKey);

            var records = new List<T>();
            try
            {
                var tableEntities = await _tableClient.QueryAsync<TableEntity>(e => e.PartitionKey == partitionKey).ToListAsync();
                tableEntities.ForEach(x => records.Add(x.FromTableEntity<T, object, object>(e => e.PartitionKey, e => e.RowKey)));
            }
            catch (RequestFailedException ex)
            {
                if (Convert.ToInt32(ex.Status) != Convert.ToInt32(System.Net.HttpStatusCode.NotFound))
                {
                    string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                    Debug.WriteLine(errorMessage);
                    throw;
                }
            }
            HandleDateTimeKindUnSpecified(records);
            return records;
        }

        /// <summary>
        /// Get records  based on partition key and list of rowkeys
        /// </summary>
        /// <param name="partitionKey"></param>
        /// <param name="rowKeys"></param>
        /// <returns>The records found.EmptyList if no records found</returns>
        /// Check how to handle n number of rowkeys
        public async Task<IEnumerable<T>> GetRecordsAsync(string partitionKey, List<string> rowKeys)
        {
            EnsurePartitionKeyNotNull(partitionKey);
            EnsureRowKeysNotNull(rowKeys);

            //Excpetion is Handled inside the method.
            var allItems = (List<T>)await GetRecordsAsyncForPartitionKeyAndListOfRowKeys(partitionKey, rowKeys);
            HandleDateTimeKindUnSpecified(allItems);
            return allItems;
        }

        private void EnsureRowKeysNotNull(List<string> rowKeys)
        {
            if (!rowKeys.Any())
            {
                throw new ArgumentNullException(nameof(rowKeys));
            }
        }

        private async Task<IEnumerable<T>> GetRecordsAsyncForPartitionKeyAndListOfRowKeys(string partitionKey, List<string> rowKeys)
        {
            var allItems = new List<T>();
            await _retryStorageExceptionPolicy.Execute(async () =>
            {
                try
                {
                    var rowKeysQuerys = BuildRowKeysQuery(rowKeys);

                    foreach (var rowKeysQuery in rowKeysQuerys)
                    {
                        string filter = $"PartitionKey eq '{partitionKey}' and({rowKeysQuery})";

                        var queryResult = await _tableClient.QueryAsync<TableEntity>(filter).ToListAsync();
                        queryResult.ForEach(x => allItems.Add(x.FromTableEntity<T, object, object>(e => e.PartitionKey, e => e.RowKey)));
                    }

                }
                catch (RequestFailedException ex)
                {
                    if (Convert.ToInt32(ex.Status) != Convert.ToInt32(System.Net.HttpStatusCode.NotFound))
                    {
                        string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                        Debug.WriteLine(errorMessage);
                        throw;
                    }
                }
            });
            return allItems;
        }

        private List<string> BuildRowKeysQuery(List<string> rowKeys)
        {
            var queries = new List<string>();
            var rowKeysBatches = rowKeys.Batch(90);

            foreach (var rowKeysbatch in rowKeysBatches)
            {
                StringBuilder stringBuilder = new StringBuilder();
                var first = true;
                foreach (var rowKey in rowKeysbatch)
                {
                    if (first)
                    {
                        stringBuilder.Append($"RowKey eq '{rowKey}'");
                        first = false;
                    }
                    else
                    {
                        stringBuilder.Append($" or RowKey eq '{rowKey}'");
                    }
                }
                queries.Add(stringBuilder.ToString());
            }
            return queries;
        }

        /// <summary>
        /// Get the records by row key
        /// </summary>
        /// <param name="rowKey">The row key</param>
        /// <returns>The records found, EmptyList if no record found </returns>
        public async Task<IEnumerable<T>> GetRecordsAcrossPartitions(string rowKey)
        {
            EnsureRowKeyNotNull(rowKey);
            var records = new List<T>();
            try
            {
                var tableEntities = await _tableClient.QueryAsync<TableEntity>(e => e.RowKey == rowKey).ToListAsync();
                tableEntities.ForEach(x => records.Add(x.FromTableEntity<T, object, object>(e => e.PartitionKey, e => e.RowKey)));
            }
            catch (RequestFailedException ex)
            {
                if (Convert.ToInt32(ex.Status) != Convert.ToInt32(System.Net.HttpStatusCode.NotFound))
                {
                    string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                    Debug.WriteLine(errorMessage);
                    throw;
                }
            }
            HandleDateTimeKindUnSpecified(records);
            return records;
        }

        /// <summary>
        /// Gets entities by query. 
        /// Supports TakeCount parameter.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns>The records found.EmptyList if no records found</returns>
#pragma warning disable S4136 // Method overloads should be grouped together
        public async Task<IEnumerable<T>> QueryAsync(string filter)
#pragma warning restore S4136 // Method overloads should be grouped together
        {
            var records = new List<T>();
            await _retryStorageExceptionPolicy.Execute(async () =>
            {
                try
                {
                    var queryResult = await _tableClient.QueryAsync<TableEntity>(filter).ToListAsync();
                    queryResult.ForEach(x => records.Add(x.FromTableEntity<T, object, object>(e => e.PartitionKey, e => e.RowKey)));
                }
                catch (RequestFailedException ex)
                {
                    if (Convert.ToInt32(ex.Status) != Convert.ToInt32(System.Net.HttpStatusCode.NotFound))
                    {
                        string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                        Debug.WriteLine(errorMessage);
                        throw;
                    }
                }
            });
            HandleDateTimeKindUnSpecified(records);
            return records;
        }


        /// <summary>
        ///  Get records  based on partition key , rowkey and startwwith pattern of rowkey : FIX: 
        /// </summary>
        /// <param name="partitionKey"></param>
        /// <param name="rowKey"></param>
        /// <param name="startWithTrue"></param>
        /// <returns>The records found.EmptyList if no records found</returns>
        public async Task<IEnumerable<T>> GetRecordsAsync(string partitionKey, string rowKey, bool startWithTrue = false)
        {
            var allItems = new List<T>();
            await _retryStorageExceptionPolicy.Execute(async () =>
            {
                try
                {
                    if (startWithTrue)
                    {
                        var rowKeyFilter = CreateRowKeyStartswithFilter(partitionKey, new List<string>() { rowKey });
                        var queryResult = await _tableClient.QueryAsync<TableEntity>(rowKeyFilter).ToListAsync();
                        queryResult.ForEach(x => allItems.Add(x.FromTableEntity<T, object, object>(e => e.PartitionKey, e => e.RowKey)));

                    }
                    else
                    {
                        var queryResult = await _tableClient.QueryAsync<TableEntity>(e => e.PartitionKey == partitionKey && e.RowKey == rowKey).ToListAsync();
                        queryResult.ForEach(x => allItems.Add(x.FromTableEntity<T, object, object>(e => e.PartitionKey, e => e.RowKey)));
                    }

                }
                catch (RequestFailedException ex)
                {
                    if (Convert.ToInt32(ex.Status) != Convert.ToInt32(System.Net.HttpStatusCode.NotFound))
                    {
                        string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                        Debug.WriteLine(errorMessage);
                        throw;
                    }
                }
            });
            HandleDateTimeKindUnSpecified(allItems);
            return allItems;
        }

        private string CreateRowKeyStartswithFilter(string partitionKey, IEnumerable<string> rowKeys)
        {
            StringBuilder s = new StringBuilder($" PartitionKey eq '{partitionKey}' and");
            if (rowKeys.Any() && rowKeys.Count() == 1)
            {
                s.Append($"(RowKey ge '{rowKeys.FirstOrDefault()}' and RowKey lt '{rowKeys.FirstOrDefault()}~')");
            }
            else
            {
                s.Append("(");
                var isFirst = true;
                foreach (var rowKey in rowKeys)
                {
                    if (isFirst)
                    {
                        s.Append($"(RowKey ge '{rowKey}' and RowKey lt '{rowKey}~')");
                        isFirst = false;
                    }
                    else
                    {
                        s.Append($" or (RowKey ge '{rowKey}' and RowKey lt '{rowKey}~')");
                    }
                }
                s.Append(")");
            }
            return s.ToString();
        }

        /// <summary>
        ///  Get records  based on partition key , and List of rowkey and startwwith pattern of rowkey
        /// </summary>
        /// <param name="partitionKey"></param>
        /// <param name="rowKeys"></param>
        /// <param name="startWithTrue"></param>
        /// <returns>The records found.EmptyList if no records found</returns>
        public async Task<IEnumerable<T>> GetRecordsAsync(string partitionKey, List<string> rowKeys, bool startWithTrue)
        {
            var allItems = new List<T>();
            await _retryStorageExceptionPolicy.Execute(async () =>
            {
                try
                {
                    if (startWithTrue)
                    {
                        var rowKeyFilter = CreateRowKeyStartswithFilter(partitionKey, rowKeys);
                        var queryResult = await _tableClient.QueryAsync<TableEntity>(rowKeyFilter).ToListAsync();
                        queryResult.ForEach(x => allItems.Add(x.FromTableEntity<T, object, object>(e => e.PartitionKey, e => e.RowKey)));

                    }
                    else
                    {
                        var rowKeysQuerys = BuildRowKeysQuery(rowKeys);
                        foreach (var rowKeysQuery in rowKeysQuerys)
                        {
                            string filter = $"PartitionKey eq '{partitionKey}' and({rowKeysQuery})";
                            var queryResult = await _tableClient.QueryAsync<TableEntity>(filter).ToListAsync();

                            queryResult.ForEach(x => allItems.Add(x.FromTableEntity<T, object, object>(e => e.PartitionKey, e => e.RowKey)));
                        }

                    }

                }
                catch (RequestFailedException ex)
                {
                    if (Convert.ToInt32(ex.Status) != Convert.ToInt32(System.Net.HttpStatusCode.NotFound))
                    {
                        string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                        Debug.WriteLine(errorMessage);
                        throw;
                    }
                }
            });
            HandleDateTimeKindUnSpecified(allItems);
            return allItems;
        }

        /// <summary>
        /// Gets record by query build using framework Filercondition and Compare condition
        /// </summary>
        /// <typeparam name="Ti"></typeparam>
        /// <param name="options"></param>
        /// <returns>The records found.EmptyList if no records found</returns>
        public async Task<IEnumerable<T>> QueryAsync<Ti>(TableQueryOptions<Ti> options) where Ti : ITableEntity
        {
            var entities = new List<T>();
            //Build String Query from options
            var filter = TableUriQueryBuilder.Build(options);

            await _retryStorageExceptionPolicy.Execute(async () =>
            {
                try
                {
                    //Since SelectProperties are Comma Seperated properties extract them into list
                    var selectProperties = options.SelectProperties?.Split(",").ToList() ?? new List<string>();

                    if (!selectProperties.Any())
                        selectProperties = null;

                    int? top = options.Top > 0 ? options.Top : null;
                    var queryResult = new List<TableEntity>();
                    if (top != null && top > 0)
                    {
                        if (top <= 1000)
                        {
                            Pageable<TableEntity> queryResultsMaxPerPage = _tableClient.Query<TableEntity>(filter, select: selectProperties, maxPerPage: top);
                            queryResult.AddRange(queryResultsMaxPerPage.AsPages()?.FirstOrDefault()?.Values ?? new List<TableEntity>());
                        }
                        else
                        {
                            await GetRecordsFromMutiplePages(filter, selectProperties, (int)top, queryResult);
                        }

                    }
                    else
                    {
                        queryResult = await _tableClient.QueryAsync<TableEntity>(filter, select: selectProperties).ToListAsync();

                    }

                    queryResult.ForEach(x => entities.Add(x.FromTableEntity<T, object, object>(e => e.PartitionKey, e => e.RowKey)));

                }
                catch (RequestFailedException ex)
                {
                    if (Convert.ToInt32(ex.Status) != Convert.ToInt32(System.Net.HttpStatusCode.NotFound))
                    {
                        string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                        Debug.WriteLine(errorMessage);
                        throw;
                    }
                }
            });
            HandleDateTimeKindUnSpecified(entities);
            return await Task.FromResult(entities);
        }

        private async Task GetRecordsFromMutiplePages(string filter, List<string>? selectProperties, int top, List<TableEntity>? queryResult)
        {
            int noOfPagesToTraverse = top / 1000;
            int noOfItemsFromLastPartialPage = top % 1000;

            AsyncPageable<TableEntity> queryResultsMaxPerPage = _tableClient.QueryAsync<TableEntity>(filter, select: selectProperties, maxPerPage: 1000);

            //Here we get all Data from the  pages based on top. if top =3200 then we need to access 4 pages as one page contains 1000 records.

            var totalpagesCount = noOfItemsFromLastPartialPage != 0 ? noOfPagesToTraverse + 1 : noOfPagesToTraverse;
            var allPagesData = await queryResultsMaxPerPage.AsPages().Take(totalpagesCount).ToListAsync();

            // Here out of n pages that we extracted in th last step we copy only those pages that are full. (i.e out of 4 pages 3 pages . last page has only 200 records.)
            allPagesData.Take(noOfPagesToTraverse).ToList().ForEach(x => queryResult!.AddRange(x.Values));

            //copy records from lastPartialpage
            if (noOfItemsFromLastPartialPage != 0)
                queryResult!.AddRange(allPagesData[noOfPagesToTraverse].Values.Take(noOfItemsFromLastPartialPage));
        }

        /// <summary>
        /// Fetch all record. Do not use if the table record has more than 100, it may impact on the performance 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="token"></param>
        /// <returns>The records found.EmptyList if no records found</returns>
        public async Task<IList<T>> FetchAllRecord()
        {
            var allRecords = new List<T>();
            try
            {
                var tableEntities = await _tableClient.QueryAsync<TableEntity>().ToListAsync();
                tableEntities.ForEach(x => allRecords.Add(x.FromTableEntity<T, object, object>(e => e.PartitionKey, e => e.RowKey)));
            }
            catch (RequestFailedException ex)
            {
                if (Convert.ToInt32(ex.Status) != Convert.ToInt32(System.Net.HttpStatusCode.NotFound))
                {
                    string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                    Debug.WriteLine(errorMessage);
                    throw;
                }
            }
            HandleDateTimeKindUnSpecified(allRecords);

            return allRecords;
        }

        /// <summary>
        /// Delete a batch entities from ATS library
        /// We are creating a batch of 50 records and deleting
        /// We have observed issues with 100 size batches ,hence we are chunking with 50, 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="entities"></param>
        /// <returns></returns>
        public async Task<bool> BatchDeleteEntityAsync(List<T> entities)
        {
            bool isSuccess = false;
            //Create batches of Entities to be deleted
            var batches = entities.Batch(ServiceConstants.BatchSize);
            //Execute batch and in case we run into any error in any batch we get out of loop and deletion is not proccessd further
            foreach (var batch in batches)
            {
                var batchToBeDeleted = batch.ToList();
                var tableTransactionActions = new List<TableTransactionAction>();

                if (batchToBeDeleted.Count > 0)
                {
                    try
                    {
                        batchToBeDeleted.ForEach(x => tableTransactionActions.Add(new TableTransactionAction(TableTransactionActionType.Delete, x)));
                        if (tableTransactionActions.Any())
                        {
                            await _tableClient.SubmitTransactionAsync(tableTransactionActions).ConfigureAwait(false);
                        }
                        isSuccess = true;
                    }
                    catch (TableTransactionFailedException ex)
                    {
                        if (ex.Status == 404)
                        {
                            isSuccess = true;
                            Console.WriteLine("Attempted to delete non-existent entity");
                        }
                        else if (ex.ErrorCode == ServiceConstants.InvalidDuplicateRow && ex.Status == 400 &&
                        ex.Message.Contains(ServiceConstants.DuplicateRowMessage, StringComparison.InvariantCultureIgnoreCase))
                        {
                            try
                            {
                                await RetryBatchSubmitTransaction(tableTransactionActions);
                            }
                            catch (TableTransactionFailedException e)
                            {
                                if (e.Status == 404)
                                {
                                    isSuccess = true;
                                    Console.WriteLine("Attempted to delete non-existent entity");
                                }
                                else
                                {
                                    string errorMessage = $"Exception : ErrorCode : {e.ErrorCode}, ErrorMessage: {e.Message}";
                                    Debug.WriteLine(errorMessage);
                                    throw;
                                }

                            }
                        }
                        else
                        {
                            string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                            Debug.WriteLine(errorMessage);
                            throw;
                        }
                    }

                }
            }
            return isSuccess;
        }
        /// <summary>
        /// The UpdateAsync Entity operation updates an existing entity in the table.  
        /// This Operation  handles Optimistic concurrency using Etag 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="record">The record to insert</param>
        /// <returns>retruns true on successful updation of record</returns>
        public async Task<bool> UpdateAsync(T record)
        {
            bool isUpdated = false;
            EnsureRecordNotNull(record);
            //Convert recotds to TableEntity , So that we can store complex types in Azure Table 
            var tabelEntity = ConvertTotableEntity(new List<T>() { record }).FirstOrDefault();
            try
            {
                var etag = (ETag)tabelEntity.ToList().FirstOrDefault(x => x.Key.Equals("odata.etag")).Value;
                await _tableClient.UpdateEntityAsync(tabelEntity, etag).ConfigureAwait(false);
                isUpdated = true;
            }
            catch (RequestFailedException ex)
            {
                string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                Debug.WriteLine(errorMessage);
                throw;
            }


            return isUpdated;
        }

        /// <summary>
        /// The UpdateAsync Entity operation updates an existing entities in the table.  
        /// This Operation  handles Optimistic concurrency using Etag 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="records">The records to insert</param>
        /// <returns></returns>
        public async Task UpdateAsync(IEnumerable<T> records)
        {
            CheckRecordIsNull(records);
            //Convert recotds to TableEntity , So that we can store complex types in Azure Table 
            var tabelEntities = ConvertTotableEntity(records);
            var partitionKeySeparation = tabelEntities.GroupBy(x => x.PartitionKey).OrderBy(g => g.Key).Select(g => g.AsEnumerable()).SelectMany(entry => entry.Partition(MaxPartitionSize)).ToList();

            await UpdateRecords(partitionKeySeparation);
        }
        private async Task UpdateRecords(List<IEnumerable<TableEntity>> partitionKeySeparation)
        {
            foreach (var entry in partitionKeySeparation)
            {
                var batch = new List<TableTransactionAction>();
                entry.ToList().ForEach(x => batch.Add(new TableTransactionAction(TableTransactionActionType.UpdateMerge, x, (ETag)x.ToList().FirstOrDefault(x => x.Key.Equals("odata.etag")).Value)));

                //Execute the transaction
                if (batch.Any())
                {
                    try
                    {
                        await _tableClient.SubmitTransactionAsync(batch).ConfigureAwait(false);

                    }
                    catch (TableTransactionFailedException ex)
                    {
                        if (ex.ErrorCode == ServiceConstants.InvalidDuplicateRow && ex.Status == 400 &&
                        ex.Message.Contains(ServiceConstants.DuplicateRowMessage, StringComparison.InvariantCultureIgnoreCase))
                        {
                            try
                            {
                                await RetryBatchSubmitTransaction(batch);
                            }
                            catch (TableTransactionFailedException e)
                            {
                                string errorMessage = $"Exception : ErrorCode : {e.ErrorCode}, ErrorMessage: {e.Message}";
                                Debug.WriteLine(errorMessage);
                                throw;
                            }
                        }
                        else
                        {
                            string errorMessage = $"Exception : ErrorCode : {ex.ErrorCode}, ErrorMessage: {ex.Message}";
                            Debug.WriteLine(errorMessage);
                            throw;
                        }
                    }

                }
            }
        }

        #endregion
    }
}