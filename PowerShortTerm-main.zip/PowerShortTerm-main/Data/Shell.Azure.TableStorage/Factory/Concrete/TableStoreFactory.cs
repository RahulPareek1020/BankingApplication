﻿using Azure.Data.Tables;
using Shell.Azure.TableStorage.Factory.Abstraction;
using Shell.Azure.TableStorage.Store;
using Shell.Azure.TableStorage.Store.Abstraction;
using Shell.Azure.TableStorage.Store.Concrete;

namespace Shell.Azure.TableStorage.Factory.Concrete
{
    public class TableStoreFactory : ITableStoreFactory
    {
        public ITableStore<T> CreateTableStore<T>(string tableName, string storageConnectionString) where T : class, ITableEntity, new()
        {
            return new TableStore<T>(tableName, storageConnectionString, new TableStorageOptions());
        }

        public ITableStore<T> CreateTableStore<T>(string tableName, string storageConnectionString, TableStorageOptions options) where T : class, ITableEntity, new()
        {
            return new TableStore<T>(tableName, storageConnectionString, options);
        }


    }
}
