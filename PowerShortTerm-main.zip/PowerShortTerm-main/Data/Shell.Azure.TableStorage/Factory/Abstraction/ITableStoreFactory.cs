﻿using Azure.Data.Tables;
using Shell.Azure.TableStorage.Store;
using Shell.Azure.TableStorage.Store.Abstraction;

namespace Shell.Azure.TableStorage.Factory.Abstraction
{
    public interface ITableStoreFactory
    {
        ITableStore<T> CreateTableStore<T>(string tableName, string storageConnectionString) where T : class, ITableEntity, new();

        ITableStore<T> CreateTableStore<T>(string tableName, string storageConnectionString, TableStorageOptions options) where T : class, ITableEntity, new();


    }
}
