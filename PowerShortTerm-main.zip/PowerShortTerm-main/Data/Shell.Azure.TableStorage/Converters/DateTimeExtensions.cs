﻿using System;

namespace Shell.Azure.TableStorage.Converters
{
	public static class DateTimeExtensions
    {
        //Added this Extension method to resolve exception
        //"The UTC time represented when the offset is applied must be between year 0 and 10,000. Parameter name: offset"
        //ref:  https://stackoverflow.com/questions/13799214/the-utc-time-represented-when-the-offset-is-applied-must-be-between-year-0-and-1#:~:text=18,against%20the%20MaxValue.
        public static DateTimeOffset ToDateTimeOffset(this DateTime dateTime)
        {
            return dateTime.ToUniversalTime() <= DateTimeOffset.MinValue.UtcDateTime
                       ? DateTimeOffset.MinValue
                       : new DateTimeOffset(dateTime);
        }
    }
}
