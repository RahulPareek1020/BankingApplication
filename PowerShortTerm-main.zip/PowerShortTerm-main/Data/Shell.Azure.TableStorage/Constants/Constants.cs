﻿namespace Shell.Azure.TableStorage.Constants
{
	public static class ServiceConstants
    {

        internal static int BatchSize = 50;
        internal static string InvalidDuplicateRow = "InvalidDuplicateRow";
        internal static string DuplicateRowMessage = "The batch request contains multiple changes with same row key. An entity can appear only once in a batch request";

    }
}
