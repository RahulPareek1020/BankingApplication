using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using OpenTelemetry;
using OpenTelemetry.Context.Propagation;
using Shell.Energy.SNE.Common.OpenTelemetry;
using Shell.Energy.STPower.Data.Common.Model;
using Shell.Energy.STPower.Data.Integration.Services;
using Shell.Energy.STPower.Service.KafkaConsumer;
using Shell.Energy.STPower.Service.KafkaProducer.Schema;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Constants;
using System.Diagnostics;
using System.Globalization;

namespace Shell.Energy.SNE.Integration.ConsumeTradeMessage
{
    /// <summary>
    /// Function to consume trade messages from Kafka topics
    /// </summary>
    public class ConsumeTradeMessage
    {
        private readonly IAppLogger _logger;
        private readonly IConfiguration _config;
        private IEtrmConsumer _etrmConsumer;
        private readonly IPowertrakTradeService _powerTrakTradeService;
        private readonly ITelemetryActivity _telemetryActivity;
        private readonly string _telemetryActivityName = "Consuming trades from Kafka";
        private readonly string _traceFlags = "1";

        public ConsumeTradeMessage(IAppLogger logger, IConfiguration config, IEtrmConsumer etrmConsumer,
            IPowertrakTradeService powertrakTradeService,ITelemetryActivity telemetryActivity)
        {
            _logger = logger;
            _config = config;
            _etrmConsumer = etrmConsumer;
            _powerTrakTradeService = powertrakTradeService;
            _telemetryActivity = telemetryActivity;
        }

        [Function(nameof(ConsumeTradeMessage))]
        public async Task<string> RunAsync([TimerTrigger("%TimerTriggerCronExpression%", RunOnStartup = true)] TimerInfo myTimer)
        {
            try
            {
                // Record the start time
                var startTime = DateTime.Now;
                bool isNominationRunOtelIdsNull = true;
                _logger.LogInformation($"{nameof(ConsumeTradeMessage)} {LogMessages.StartedProcessing}");

                var topics = _config["KafkaConsumer:Topics"]?.Split(",");

                if(topics == null || topics.Length == 0)
                {
                    _logger.LogInformation($"{nameof(ConsumeTradeMessage)} {LogMessages.CompletedProcessing} : {ResponseMessages.NoTopicsConfigured}");
                    return ResponseMessages.NoTopicsConfigured;
                }
                // Consume messages from Kafka topics.
                var consumeResults = await Task.WhenAll(topics?.Select(GetKafkaMessagesAsync));
                // Transform the consumed messages.
                var consumeResultTaskList = consumeResults
                    .SelectMany(consumeResult => JsonConvert.DeserializeObject<List<KafkaSNEMessage>>(consumeResult) ?? new List<KafkaSNEMessage>());

                if (consumeResultTaskList == null || consumeResultTaskList.Count() == 0)
                {
                    _logger.LogInformation($"{nameof(ConsumeTradeMessage)} {LogMessages.CompletedProcessing} {ResponseMessages.NoMessages}");
                    return ResponseMessages.NoMessages;
                }
                var rawTradeList = new List<Aligne_Raw_Trade>();
                foreach (var kafkaSNEMessage in consumeResultTaskList)
                {
                    if (kafkaSNEMessage.Aligne_Raw_Trades != null)
                    {
                        rawTradeList.AddRange(kafkaSNEMessage.Aligne_Raw_Trades);
                    }
                }
                _logger.LogInformation($"Consumed {rawTradeList.Count} Aligne raw trades");

                // Batch insert messages into the database
                int batchSize = Convert.ToInt32(_config["KafkaConsumer:InsertBatchSize"]);
                var isSuccess = true;

                //Grouping the rawtrades by batch run id and inserting the raw trades in batches
                var rawTradesByRunId = rawTradeList.GroupBy(x => x.BATCH_RUN_ID).Select(group => group.ToList()).ToList();

                foreach (var rawTrades in rawTradesByRunId)
                {
                    var nominationRunId = Convert.ToInt32(rawTrades.FirstOrDefault()?.BATCH_RUN_ID,CultureInfo.InvariantCulture);
                    NominationRunOtelIds nominationRunOtelIds = await _powerTrakTradeService.GetNominationRunTraceSpanId(nominationRunId);
                    isNominationRunOtelIdsNull = IsNominationRunOtelIdsNull(nominationRunOtelIds);

                    if (!isNominationRunOtelIdsNull)
                    {
                        StartTelemetryActivity(nominationRunOtelIds);
                    }
                    _logger.LogInformation($"Inserting {rawTrades.Count} raw trades for batch run id : {rawTrades.FirstOrDefault()?.BATCH_RUN_ID}");
                    for (int i = 0; i < rawTrades.Count; i += batchSize)
                    {
                        var batch = rawTrades.Skip(i).Take(batchSize);
                        isSuccess &= await _powerTrakTradeService.InsertAligneRawTradeDataInDB(batch);
                    }

                    if (!isNominationRunOtelIdsNull && !_telemetryActivity.IsStopped)
                    {
                        _telemetryActivity.AddEvent($"Consumed {rawTrades.Count} raw trades for NominationRunId: {nominationRunId}");
                        _telemetryActivity.StopActivity();
                    }
                }
                
                _logger.LogInformation($"Successfully consumed kafka messages and saved in DB");
                var endTime = DateTime.Now;
                // Calculate the total execution time
                var executionTime = endTime - startTime;
                _logger.LogInformation($"Total time taken to consume messages and insert {rawTradeList.Count} raw trades : {executionTime.TotalSeconds} seconds");

                if (isSuccess)
                {
                    _logger.LogInformation($"{nameof(ConsumeTradeMessage)} {LogMessages.CompletedProcessing} : {ResponseMessages.SaveTradeSuccess}");
                }                
                return ResponseMessages.SaveTradeSuccess;
            }
            catch (Exception ex)
            {
                _logger.LogError($"{nameof(ConsumeTradeMessage)} {LogMessages.CompletedProcessing} : {ex.Message}");
                return ex.Message;
            }
        }

        /// <summary>
        /// Get Kafka messages from the topic
        /// </summary>
        /// <param name="topicName"></param>
        /// <returns></returns>
        private async Task<string?> GetKafkaMessagesAsync(string topicName)
        {
            var messages = await Task.Run(() => _etrmConsumer.ConsumeMessage(topicName));
            return messages;
        }

        private static bool IsNominationRunOtelIdsNull(NominationRunOtelIds nominationRunOtelIds)
        {
            return nominationRunOtelIds == null || string.IsNullOrEmpty(nominationRunOtelIds.SpanId) || string.IsNullOrEmpty(nominationRunOtelIds.TraceId);
        }

        private void StartTelemetryActivity(NominationRunOtelIds nominationRunOtelIds)
        {
            var parentContext = new ActivityContext(
                traceId: ActivityTraceId.CreateFromString(nominationRunOtelIds.TraceId),
                spanId: ActivitySpanId.CreateFromString(nominationRunOtelIds.SpanId),
                (ActivityTraceFlags)Enum.Parse(typeof(ActivityTraceFlags), _traceFlags)
            );

            var propagationContext = new PropagationContext(parentContext, Baggage.Current);
            _telemetryActivity.StartConsumerActivity(_telemetryActivityName, propagationContext, ActivityKind.Consumer);
        }
    }
}
