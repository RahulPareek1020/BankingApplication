﻿using Microsoft.Extensions.DependencyInjection;
using Shell.Energy.STPower.Data.Integration.DataAccess;
using Shell.Energy.STPower.Data.Integration.Services;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.PowerTrak;

namespace Shell.Energy.SNE.Integration.ConsumeTradeMessage.Modules
{
    /// <summary>
    /// DI class for adding core modules
    /// </summary>
    public static class PowerSTCoreModule
    {
        public static IServiceCollection AddPowerSTCore(this IServiceCollection collection)
        {
            collection.AddScoped<IAppLogger, AppLogger>();
            collection.AddScoped<IPowerTrakTradeSender, PowerTrakTradeSender>();
            collection.AddScoped<ISqlDataRepository, SqlDataRepository>();
            collection.AddScoped<IPowertrakTradeService, PowertrakTradeService>();
            collection.AddHttpClient();
            return collection;
        }
    }
}
