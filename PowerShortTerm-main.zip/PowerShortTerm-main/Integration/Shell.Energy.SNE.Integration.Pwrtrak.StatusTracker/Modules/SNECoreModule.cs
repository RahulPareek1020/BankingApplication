﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Auth;

namespace Shell.Energy.STPower.Integration.Pwrtrak.Tracker.Modules
{
    /// <summary>
    /// DI class for adding core modules
    /// </summary>
    public static class SneCoreModule
    {
        public static IServiceCollection AddSTPowerCore(this IServiceCollection collection,IConfiguration configuration)
        {
            collection.AddScoped<IAppLogger, AppLogger>();
            collection.AddSingleton<IDateTimeProvider, DateTimeProvider>();
            collection.AddTransient<ITokenService, TokenService>();
            collection.AddHttpClient();
            return collection;
        }
    }
}
