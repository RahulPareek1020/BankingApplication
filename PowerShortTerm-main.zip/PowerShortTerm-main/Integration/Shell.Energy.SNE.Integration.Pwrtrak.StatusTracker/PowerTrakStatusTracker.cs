using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Shell.Energy.STPower.Shared.Auth;
using Shell.Energy.STPower.Shared.Constants;
using Shell.Energy.STPower.Shared;

namespace Shell.Energy.SNE.Integration.Pwrtrak.StatusTracker;

/// <summary>
/// This class is responsible for tracking the status of trades in PowerTrak.
/// </summary>
public class PowerTrakStatusTracker
{
    private readonly IAppLogger _logger;
    private readonly IConfiguration _configuration;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ITokenService _tokenService;
    private readonly IDateTimeProvider _dateTimeProvider;

    public PowerTrakStatusTracker(IAppLogger logger, IConfiguration configuration, IHttpClientFactory httpClientFactory,
        ITokenService tokenService, IDateTimeProvider dateTimeProvider)
    {
        _logger = logger;
        _configuration = configuration;
        _httpClientFactory = httpClientFactory;
        _tokenService = tokenService;
        _dateTimeProvider = dateTimeProvider;
    }

    /// <summary>
    /// Azure function to track the status of trades in PowerTrak.
    /// </summary>
    /// <param name="myTimer"></param>
    /// <returns></returns>
    [Function("PowerTrakStatusTracker")]
    public async Task RunAsync([TimerTrigger("%TimerTriggerCronExpression%", RunOnStartup = true)] TimerInfo myTimer)
    {
        try
        {
            _logger.LogInformation($"PowerTrakStatusTracker Timer trigger function execution started at: {_dateTimeProvider.Now}");
            var sneApiUrlValue = _configuration?.GetSection($"{CommonConstants.SNEStatusAPIUrl}")?.Value;
            if (string.IsNullOrEmpty(sneApiUrlValue))
            {
                throw new InvalidOperationException(LogMessages.StatusAPIConfigMissing);
            }
            var sneApiUrl = new Uri(sneApiUrlValue);
            var client = _httpClientFactory.CreateClient();
            var request = new HttpRequestMessage(HttpMethod.Get, sneApiUrl);
            var token = await _tokenService.GenerateToken();

            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

            var response = await client.SendAsync(request);

            var responseContent = await response.Content.ReadAsStringAsync();
            _logger.LogInformation($"API Response:: Updated status for NominationRunIds: {responseContent}");
            _logger.LogInformation(LogMessages.TrackerSuccessMessage);
            _logger.LogInformation($"PowerTrakStatusTracker Timer trigger function execution completed at: {_dateTimeProvider.Now}");
        }
        catch (Exception ex)
        {
            _logger.LogError(LogMessages.TrackerFailureMessage + ex.Message);
            throw;
        }
    }
}