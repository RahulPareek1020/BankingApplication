using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.DurableTask;
using Microsoft.DurableTask.Client;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NPOI.SS.Formula.Functions;
using Shell.Energy.STPower.Data.Common.Model;
using Shell.Energy.STPower.Data.Integration.Model;
using Shell.Energy.STPower.Data.Integration.Services;
using Shell.Energy.STPower.Service.KafkaProducer;
using Shell.Energy.STPower.Shared.Constants;
using Shell.Energy.STPower.Shared.Enums;
using System.Data;

namespace Shell.Energy.STPower.Integration.PushMessage
{
    public class PublishTradeMessage
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger<PublishTradeMessage> _logger;
        private readonly IKafkaMessageProducer<T> _etrmProducer;
        private readonly IAligneTradeService _tradeServiceProvider;
        private readonly List<string>? _tradeTypes;

        public PublishTradeMessage(IServiceProvider serviceProvider, ILogger<PublishTradeMessage> logger, ITableStoreFactory tableStoreFactory, IOptions<FunctionOptions> options,IAligneTradeService tradeServiceProvider, IKafkaMessageProducer<T> etrmProducer)
        {
            _serviceProvider = serviceProvider;
            _logger = logger;
            _tradeServiceProvider = tradeServiceProvider;
            _etrmProducer = etrmProducer;
            _azureTableStore = tableStoreFactory.CreateTableStore<AzureStorageTable>(options.Value.TableStorageTableNameString, options.Value.TableStorageConnectionString);
            _azureTableStorePowerTrak = tableStoreFactory.CreateTableStore<AzureStoragePowerTrack>(options.Value.PowerTrakTableStorageTableNameString, options.Value.TableStorageConnectionString);
            _tradeTypes = options.Value.TradeTypes?.Split(',').ToList();

        }
        /// <summary>
        /// Orchestrator function to publish the trade message to the kafka topic
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        [Function(nameof(PublishTradeMessage))]
        public async Task RunOrchestrator(
            [OrchestrationTrigger] TaskOrchestrationContext context)
        {

            var logger = context.CreateReplaySafeLogger("PublishTradeMessage");
            var logScope = new Dictionary<string, string>() { ["OrchestratorId"] = context.InstanceId };

            using (logger.BeginScope(logScope))
            {

                var pushTradeMessageTasks = new Task<string>[_tradeTypes.Count];
                int taskIndex = 0;

                //Iterate through the trade types and publish the trade message to the kafka topic
                foreach (var tradeType in _tradeTypes)
                {
                    try
                    {
                        TradeType tradeTypeEnum = (TradeType)System.Enum.Parse(typeof(TradeType), tradeType);

                        if (tradeTypeEnum == TradeType.POWERTRAK)
                        {
                            //Publish the power trak trade message to the kafka topic
                            pushTradeMessageTasks[taskIndex] = context.CallActivityAsync<string>(nameof(PublishPowerTrakTradeMessage), tradeTypeEnum);

                        }
                        else if (tradeTypeEnum == TradeType.PROFILE)
                        {
                            //Publish the profile trade message to the kafka topic
                            pushTradeMessageTasks[taskIndex] = context.CallActivityAsync<string>(nameof(PublishProfileTransTradeMessage), tradeTypeEnum);

                        }
                        else if (tradeTypeEnum == TradeType.TRANSMISSION)
                        {
                            //Publish the Transmission trade message to the kafka topic
                            pushTradeMessageTasks[taskIndex] = context.CallActivityAsync<string>(nameof(PublishProfileTransTradeMessage), tradeTypeEnum);

                        }
                        else if (tradeTypeEnum == TradeType.BASELOAD)
                        {
                            //Publish the BaseLoad trade message to the kafka topic
                            pushTradeMessageTasks[taskIndex] = context.CallActivityAsync<string>(nameof(PublishBaseLoadTradeMessage), tradeTypeEnum);

                        }
                        else if (tradeTypeEnum == TradeType.DELETE)
                        {
                            //Publish the Delete trade message to the kafka topic
                            pushTradeMessageTasks[taskIndex] = context.CallActivityAsync<string>(nameof(PublishDeleteTradeMessage), tradeTypeEnum);
                        }
                        else
                        {
                            throw new Exception("Invalid Trade Type");
                        }
                        taskIndex++;
                    }
                    catch (Exception ex)
                    {
                        logger.LogError("Error occured during Publish Trade" + ex.StackTrace);
                        throw new Exception(ex.Message);
                    }
                }
                await Task.WhenAll(pushTradeMessageTasks);
            }
        }

        /// <summary>
        /// Get the unique sequences for the trade type
        /// </summary>
        /// <param name="tradeType"></param>
        /// <returns></returns>
        private async Task<string> GetTradeUniqueSequences(TradeType tradeType, string msgPriority)
        {
            try
            {
                _logger.LogInformation("Get Trade Unique Sequences = " + tradeType.ToString());

                //Get sequences from the table storage response
                var filter = $"PartitionKey eq '{tradeType}' and HORIZON eq '{msgPriority}'";

                var maxSequenceResponse = await _azureTableStore.QueryAsync(filter);

                //Get the max sequence from the table storage response
                var maxSequence = (maxSequenceResponse != null && maxSequenceResponse.Any()) ? maxSequenceResponse.Max(t => Convert.ToDouble(t.SEQUENCE)) : 0;


                _logger.LogInformation("Calling Aligne to Get Sequences");

                //Fetch the unique sequences from the trade service provider where the sequence is greater than the max sequence
                var tradeSequences = await _tradeServiceProvider.FetchTradeSequences(tradeType, msgPriority, maxSequence.ToString());

                _logger.LogInformation("Called Aligne to Get Sequences");

                //Get the unique sequence in to a string(comma separated) variable
                return string.Join(",", tradeSequences.Select(x => x.SEQUENCE).Distinct());
            }
            catch (Exception ex)
            {
                _logger.LogError("Error occured during Get Trade Details" + ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Get max power counter for the trade type
        /// </summary>
        /// <param name="tradeType"></param>
        /// <returns></returns>
        private async Task<int> GetMaxPowerTrakCounter(TradeType tradeType)
        {
            try
            {
                _logger.LogInformation("Get Get Max Trade Counter = " + tradeType.ToString());

                //Get sequences from the table storage response
                var filter = $"PartitionKey eq '{tradeType}'";

                var maxSequenceResponse = await _azureTableStorePowerTrak.QueryAsync(filter);

                //Get the max sequence from the table storage response
                var maxSequence = (maxSequenceResponse != null && maxSequenceResponse.Any()) ? maxSequenceResponse.Max(t => Convert.ToDouble(t.POWER_COUNTER)) : 0;

                //Get the unique sequence in to a string(comma separated) variable
                return (int)maxSequence;
            }
            catch (Exception ex)
            {
                _logger.LogError("Error occured during Get Trade Details" + ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Get the unique sequence and Message Priority for the trade type
        /// </summary>
        /// <param name="tradeType"></param>
        /// <returns></returns>
        private (string, string) GetTradeSequences(TradeType tradeType)
        {
            try
            {
                string strMsgPriority = string.Empty;
                var uniqueTradeSequences = string.Empty;

                //Get the unique sequence in to a string(comma separated) variable
                // TODO : Code refactoring required
                uniqueTradeSequences = GetTradeUniqueSequences(tradeType, MessagePriority.WD).Result;
                strMsgPriority = MessagePriority.WD;
                if (string.IsNullOrEmpty(uniqueTradeSequences))
                {
                    uniqueTradeSequences = GetTradeUniqueSequences(tradeType, MessagePriority.DA).Result;
                    strMsgPriority = MessagePriority.DA;
                    if (string.IsNullOrEmpty(uniqueTradeSequences))
                    {
                        uniqueTradeSequences = GetTradeUniqueSequences(tradeType, MessagePriority.BOM).Result;
                        strMsgPriority = MessagePriority.BOM;
                        if (string.IsNullOrEmpty(uniqueTradeSequences))
                        {
                            uniqueTradeSequences = GetTradeUniqueSequences(tradeType, MessagePriority.ENDOFDAY).Result;
                            strMsgPriority = MessagePriority.ENDOFDAY;
                            if (string.IsNullOrEmpty(uniqueTradeSequences))
                            {
                                uniqueTradeSequences = GetTradeUniqueSequences(tradeType, MessagePriority.SHORT_TERM).Result;
                                strMsgPriority = MessagePriority.SHORT_TERM;
                                if (string.IsNullOrEmpty(uniqueTradeSequences))
                                {
                                    uniqueTradeSequences = GetTradeUniqueSequences(tradeType, MessagePriority.MEDIUM_TERM).Result;
                                    strMsgPriority = MessagePriority.MEDIUM_TERM;
                                    if (string.IsNullOrEmpty(uniqueTradeSequences))
                                    {
                                        uniqueTradeSequences = GetTradeUniqueSequences(tradeType, MessagePriority.LONG_TERM).Result;
                                        strMsgPriority = MessagePriority.LONG_TERM;
                                    }
                                }
                            }
                        }
                    }
                }
                return (uniqueTradeSequences, strMsgPriority);
            }
            catch (Exception ex)
            {
                _logger.LogError("Error occured during Get Trade Sequences" + ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Publish the Profile/Trans trade message to the kafka topic
        /// </summary>
        /// <param name="uniqueSequences"></param>
        /// <param name="executionContext"></param>
        /// <returns></returns>
        [Function(nameof(PublishPowerTrakTradeMessage))]
        public async Task PublishPowerTrakTradeMessage([ActivityTrigger] TradeType tradeType, FunctionContext executionContext)
        {

            try
            {
                _logger.LogInformation($"Start - Publish Power Trak Aggregated TradeMessage");

                // Record the start time
                var startTime = DateTime.Now;
                TimeSpan executionTime =TimeSpan.Zero;

                // Get the unique power count and message priority
                int maxTradePowerCounter = GetMaxPowerTrakCounter(tradeType).Result;

                //Get the Delivery dates from the trade details
                List<DateTime> uniqueTradeDeliveyDates = new List<DateTime>();
                uniqueTradeDeliveyDates = await _tradeServiceProvider.FetchTradeDeliveryDates(maxTradePowerCounter.ToString());


                if (uniqueTradeDeliveyDates.Count == 0)
                {
                    _logger.LogInformation($"No Trades to Publish");
                    _logger.LogInformation($"End - Publish Power Trak Aggregated TradeMessage");
                    return;
                }
                
                //Get the unique deliver Dates
                string strDeliveryDates = string.Join(",", uniqueTradeDeliveyDates.Select(x => x.ToString(TradeConstants.DateFormat)).Distinct());

                //Get the unique sequence from the trade details
                List<PowerTrakTrade> tradePowerTrakTradeDetails = await _tradeServiceProvider.FetchPowerTrakAggregatedTrades(maxTradePowerCounter.ToString(), "'" + strDeliveryDates.Replace(",", "','") + "'" );

                if (tradePowerTrakTradeDetails.Count == 0)
                {
                    _logger.LogInformation($"No Trades to Publish");
                    _logger.LogInformation($"End - Publish Power Trak Aggregated TradeMessage");
                    return;
                }

                //Get the unique deliver Dates
                List<System.DateTime?> uniquedeliverDates = tradePowerTrakTradeDetails
                   .Select(e => e.DELIVERYDATE)
                   .Distinct()
                   .ToList();

                //Iterate through the unique sequence and publish the trade message to the kafka topic
                foreach (var uniquedeliverDate in uniquedeliverDates)
                {
                    
                    //Get the unique market operators  
                    List<string?> filteredMarketList = tradePowerTrakTradeDetails.Where(item => item.DELIVERYDATE == uniquedeliverDate).Select(e => e.FROMMARKETOPERATOR).Distinct().ToList();


                    foreach (var uniqueMarket in filteredMarketList)
                    {

                        //Filter the trade details based on the unique sequence
                        List<PowerTrakTrade> filteredList = tradePowerTrakTradeDetails.Where(item => (item.FROMMARKETOPERATOR == uniqueMarket && item.DELIVERYDATE == uniquedeliverDate)).ToList();
                        try
                        {
                            //Publish the trade message to the kafka topic
                            if (filteredList != null)
                            {
                                Task<bool> blnResponse = _etrmProducer.ProduceKafkaMessage<PowerTrakTrade>(tradeType, filteredList);

                                foreach (var filteredListItem in filteredList)
                                {
                                    //Construct the DEC response model
                                    AzureStoragePowerTrack decResponseModel = new AzureStoragePowerTrack()
                                    {
                                        POWER_COUNTER = Convert.ToInt32(filteredListItem.POWER_COUNTER),
                                        REFERENCE = filteredListItem.REFERENCE,
                                        STATUS = blnResponse.Result ? DecStatusCode.PROCESSED.ToString() : DecStatusCode.FAILED.ToString(),
                                        RowKey = Guid.NewGuid().ToString(),
                                        PartitionKey = TradeType.POWERTRAK.ToString()
                                    };
                                    //Update the table storage with the processed status
                                    await PowerTrakStateManagement(decResponseModel, executionContext);
                                }
                            }

                            // Record the end Time
                            var endSingleTradeEndTime = DateTime.Now;

                            // Calculate the execution time for Delivery Date and Market
                            TimeSpan singleTradeExecutionTime = TimeSpan.FromSeconds((endSingleTradeEndTime - startTime).TotalSeconds);

                            _logger.LogInformation($"Time taken to send  Aggregated Trades to Kafka for Delivery Date : {uniquedeliverDate} And Market : {uniqueMarket}  - {singleTradeExecutionTime.ToString(@"hh\:mm\:ss")}");


                        }
                        catch (Exception ex)
                        {
                            _logger.LogError("Error occured during PublishPowerTrakTradeMessage");
                            throw new Exception(ex.Message);
                        }
                    }
                }

                // Record the total end Time
                var totalEndTime = DateTime.Now;

                // Calculate the total execution time
                TimeSpan totalExecutionTime = TimeSpan.FromSeconds((totalEndTime - startTime).TotalSeconds);

                _logger.LogInformation($"Total execution time to send {tradePowerTrakTradeDetails.Count} Aggregated Trades to Kafka : {totalExecutionTime.ToString(@"hh\:mm\:ss")}");
                _logger.LogInformation($"End - Publish Power Trak Aggregated TradeMessage");
            }
            catch (Exception ex)
            {
                _logger.LogError("Error occured during PublishPowerTrakTradeMessage");
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Publish the Profile/Trans trade message to the kafka topic
        /// </summary>
        /// <param name="uniqueSequences"></param>
        /// <param name="executionContext"></param>
        /// <returns></returns>
        [Function(nameof(PublishProfileTransTradeMessage))]
        public async Task PublishProfileTransTradeMessage([ActivityTrigger] TradeType tradeType, FunctionContext executionContext)
        {

            try
            {
                _logger.LogInformation($"Start - PublishProfileTransTradeMessage");

                // Record the start time
                var startTime = DateTime.Now;

                // Get the unique sequence and message priority
                var (uniqueTradeSequences, strMsgPriority) = GetTradeSequences(tradeType);

                //Get the unique sequence from the trade details
                var tradeProfileTransTradeDetails = await _tradeServiceProvider.FetchProfileTransTrades(tradeType,uniqueTradeSequences);

                // Record the end Time
                var endTime = DateTime.Now;

                // Calculate the total execution time
                var executionTime = endTime - startTime;

                //Get the unique sequence in to a string(comma separated) variable
                var uniqueSequence = (uniqueTradeSequences != string.Empty) ? uniqueTradeSequences?.Split(',').ToList() : new List<string>();

                
                //Check if the unique sequence is null
                if (uniqueSequence is not null)
                {
                    _logger.LogInformation($"Start -  Publish {tradeType} Trade Message");

                    //Iterate through the unique sequence and publish the trade message to the kafka topic
                    foreach (var sequence in uniqueSequence)
                    {
                        //Filter the trade details based on the unique sequence
                        List<ProfileTransTrade> filteredList = tradeProfileTransTradeDetails.Where(item => item.PWTRK_COUNTER == sequence).ToList();
                        try
                        {
                            //Publish the trade message to the kafka topic
                            if (filteredList != null && filteredList.Count > 0)
                            {
                                Task<bool> blnResponse = _etrmProducer.ProduceKafkaMessage<ProfileTransTrade>(tradeType, filteredList);

                                //Construct the DEC response model
                                AzureStorageTable decResponseModel = new AzureStorageTable()
                                {
                                    SEQUENCE = filteredList[0].PWTRK_COUNTER?.ToString(),
                                    DEALID = Convert.ToInt32(filteredList[0]?.REFERENCE),
                                    STATUS = DecStatusCode.PROCESSED.ToString(),//blnResponse.Result ? DECStatusCode.PROCESSED.ToString() : DECStatusCode.FAILED.ToString(),
                                    HORIZON = strMsgPriority,
                                    RowKey = Guid.NewGuid().ToString(),
                                    PartitionKey = tradeType.ToString()
                                };
                                //Update the table storage with the processed status
                                await StateManagement(decResponseModel, executionContext);
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError("Error occured during Publish Profile Trans Trade Message" + ex.StackTrace);
                            throw new Exception(ex.Message);
                        }
                    }
                    _logger.LogInformation($"Total execution time to Get {uniqueSequence.Count} (Records : {tradeProfileTransTradeDetails.Count} ) {tradeType} Trades from Aline: {executionTime.TotalSeconds} seconds");
                }
                _logger.LogInformation($"End - Publish {tradeType} Trade Message");
            }
            catch (Exception ex)
            {
                _logger.LogError("Error occured during PublishProfileTransTradeMessage");
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Publish the Base Load trade message to the kafka topic
        /// </summary>
        /// <param name="uniqueSequences"></param>
        /// <param name="executionContext"></param>
        /// <returns></returns>
        [Function(nameof(PublishBaseLoadTradeMessage))]
        public async Task PublishBaseLoadTradeMessage([ActivityTrigger] TradeType tradeType, FunctionContext executionContext)
        {

            // Record the start time
            var startTime = DateTime.Now;
            // Get the unique sequence and message priority
            var (uniqueTradeSequences, strMsgPriority) = GetTradeSequences(tradeType);

            //Get the unique sequence from the trade details
            var tradeBaseLoadTradeDetails = await _tradeServiceProvider.FetchBaseLoadTrades(tradeType, uniqueTradeSequences);

            // Record the end Time
            var endTime = DateTime.Now;

            // Calculate the total execution time
            var executionTime = endTime - startTime;

            //Get the unique sequence in to a string(comma separated) variable
            var uniqueSequence = (uniqueTradeSequences != string.Empty) ? uniqueTradeSequences?.Split(',').ToList() : new List<string>();

            //Check if the unique sequence is null
            if (uniqueSequence is not null)
            {
                _logger.LogInformation($"Total execution time to Get {uniqueSequence.Count} (Records : {tradeBaseLoadTradeDetails.Count} ) BaseLoad Trades from Aline: {executionTime.TotalSeconds} seconds");
                _logger.LogInformation("Start - Publish Base Load Trade Message");

                //Iterate through the unique sequence and publish the trade message to the kafka topic
                foreach (var sequence in uniqueSequence)
                {
                    //Filter the trade details based on the unique sequence
                    List<BaseLoadTrade> filteredList = tradeBaseLoadTradeDetails.Where(item => item.PWTRK_COUNTER == sequence).ToList();

                    try
                    {
                        //Publish the trade message to the kafka topic
                        if (filteredList != null && filteredList.Count > 0)
                        {
                            Task<bool> blnResponse = _etrmProducer.ProduceKafkaMessage<BaseLoadTrade>(tradeType, filteredList);

                            //Construct the DEC response model
                            AzureStorageTable decResponseModel = new AzureStorageTable()
                            {
                                SEQUENCE = filteredList[0].PWTRK_COUNTER?.ToString(),
                                DEALID = Convert.ToInt32(filteredList[0]?.REFERENCE),
                                STATUS = blnResponse.Result ? DecStatusCode.PROCESSED.ToString() : DecStatusCode.FAILED.ToString(),
                                HORIZON = strMsgPriority,
                                RowKey = Guid.NewGuid().ToString(),
                                PartitionKey = tradeType.ToString()
                            };
                            //Update the table storage with the processed status
                            await StateManagement(decResponseModel, executionContext);
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError("Error occured during Publish Delete Trade Message" + ex.StackTrace);
                        throw new Exception(ex.Message);
                    }
                }
            }
            _logger.LogInformation("End - Publish Profile/Trans Trade Message");
        }

        /// <summary>
        /// Publish the trade message to the kafka topic
        /// </summary>
        /// <param name="uniqueSequences"></param>
        /// <param name="executionContext"></param>
        /// <returns></returns>
        [Function(nameof(PublishDeleteTradeMessage))]
        public async Task PublishDeleteTradeMessage([ActivityTrigger] TradeType tradeType, FunctionContext executionContext)
        {

            // Record the start time
            var startTime = DateTime.Now;

            //Get the unique sequence in to a string(comma separated) variable
            var uniqueTradeSequences = GetTradeUniqueSequences(tradeType, MessagePriority.VOID).Result;

            //Get the unique sequence from the trade details    
            var tradeDeleteDetails = await _tradeServiceProvider.FetchDeleteTrades(tradeType, uniqueTradeSequences);

            // Record the end Time
            var endTime = DateTime.Now;

            // Calculate the total execution time
            var executionTime = endTime - startTime;

            //Get the unique sequence in to a string(comma separated) variable
            var uniqueSequence = (uniqueTradeSequences != string.Empty) ? uniqueTradeSequences?.Split(',').ToList() : new List<string>();


            //Check if the unique sequence is null
            if (uniqueSequence is not null)
            {
                _logger.LogInformation($"Total execution time to Get {uniqueSequence.Count} (Records : {tradeDeleteDetails.Count} ) Delete Trades from Aline: {executionTime.TotalSeconds} seconds");
                _logger.LogInformation("Start - Publish Delete Trade Message");

                //Iterate through the unique sequence and publish the trade message to the kafka topic
                foreach (var sequence in uniqueSequence)
                {
                    //Filter the trade details based on the unique sequence
                    List<DeleteTrade> filteredList = tradeDeleteDetails.Where(item => item.PWTRK_COUNTER == sequence).ToList();

                    try
                    {
                        //Publish the trade message to the kafka topic
                        if (filteredList != null && filteredList.Count > 0)
                        {
                            Task<bool> blnResponse = _etrmProducer.ProduceKafkaMessage<DeleteTrade>(tradeType, filteredList);

                            //Construct the DEC response model
                            AzureStorageTable decResponseModel = new AzureStorageTable()
                            {
                                SEQUENCE = filteredList[0].PWTRK_COUNTER,
                                DEALID = Convert.ToInt32(filteredList[0]?.REFERENCE),
                                STATUS = blnResponse.Result ? DecStatusCode.PROCESSED.ToString() : DecStatusCode.FAILED.ToString(),
                                HORIZON = MessagePriority.VOID,
                                RowKey = Guid.NewGuid().ToString(),
                                PartitionKey = tradeType.ToString()
                            };
                            //Update the table storage with the processed status
                            await StateManagement(decResponseModel, executionContext);
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError("Error occured during Publish Delete Trade Message" + ex.StackTrace);
                        throw new Exception(ex.Message);
                    }
                }
            }
            _logger.LogInformation("End - Publish Delete Trade Message");
        }

        /// <summary>
        /// Add the processed trade's status to the table storage
        /// </summary>
        /// <param name="partitionKey"></param>
        /// <param name="tableName"></param>
        /// <param name="entity"></param>
        /// <param name="executionContext"></param>
        /// <returns></returns>
        [Function(nameof(StateManagement))]
        public async Task StateManagement([Microsoft.Azure.Functions.Worker.ActivityTrigger] AzureStorageTable entity, FunctionContext executionContext)
        {
            try
            {
                //Update the table storage with the processed status
                await _azureTableStore.InsertOrMergeAsync(entity);
                _logger.LogInformation($"Added  {Convert.ToInt32(entity.DEALID)} Trade Id to the Statemanagement");
            }
            catch (Exception ex)
            {
                _logger.LogError("Error occured during StateManagement" + ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Add the processed trade's status to the table storage
        /// </summary>
        /// <param name="partitionKey"></param>
        /// <param name="tableName"></param>
        /// <param name="entity"></param>
        /// <param name="executionContext"></param>
        /// <returns></returns>
        [Function(nameof(PowerTrakStateManagement))]
        public async Task PowerTrakStateManagement([Microsoft.Azure.Functions.Worker.ActivityTrigger] AzureStoragePowerTrack entity, FunctionContext executionContext)
        {
            try
            {
                //Update the table storage with the processed status
                await _azureTableStorePowerTrak.InsertOrMergeAsync(entity);
                _logger.LogInformation($"Added  Reference - {entity.REFERENCE} to the Statemanagement Table");
            }
            catch (Exception ex)
            {
                _logger.LogError("Error occured during StateManagement" + ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Http trigger function to push the trade message to the kafka topic
        /// </summary>
        /// <param name="req"></param>
        /// <param name="client"></param>
        /// <param name="executionContext"></param>
        /// <returns></returns>
        [Function("PublishTradeMessageToKafka")]
        public static async Task<string> PublishTradeMessageToKafka(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post")] HttpRequestData req,
            //[TimerTrigger("0 */5 * * * *")] TimerInfo info,
            [DurableClient] DurableTaskClient client,
            FunctionContext executionContext)
        {
            var logger = executionContext.GetLogger("PublishTradeMessageToKafka");
            try
            {

                // Record the start time
                var startTime = DateTime.Now;

                // Function input comes from the request content.
                string instanceId = await client.ScheduleNewOrchestrationInstanceAsync(nameof(PublishTradeMessage));

                logger.LogInformation($"Started orchestration with [Instance ID: '{instanceId}'.");
                var orchestrationStatus = await client.GetInstanceAsync(instanceId);
                var status = orchestrationStatus?.RuntimeStatus.ToString().ToUpperInvariant();
                logger.LogInformation($"Waiting to complete Orchestration function [Status: {status}] [Instance ID: '{instanceId}']");

                while (status is "PENDING" or "RUNNING")
                {
                    await Task.Delay(1000);
                    orchestrationStatus = await client.GetInstanceAsync(instanceId);
                    status = orchestrationStatus?.RuntimeStatus.ToString().ToUpperInvariant();
                }

                logger.LogInformation($"{nameof(PublishTradeMessageToKafka)} function completed [Instance ID: '{instanceId}']");

                // Record the end time
                var endTime = DateTime.Now;

                // Calculate the total execution time
                var executionTime = endTime - startTime;

                logger.LogInformation($"Total PublishTradeMessageToKafka execution time: {executionTime.TotalSeconds} seconds");

                return instanceId;

            }
            catch (Exception ex)
            {
                logger.LogError("Error occured during PublishTradeMessageToKafka" + ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }
    }
}
