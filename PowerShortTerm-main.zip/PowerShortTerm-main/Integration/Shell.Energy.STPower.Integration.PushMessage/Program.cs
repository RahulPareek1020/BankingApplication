using Microsoft.ApplicationInsights.WorkerService;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Shell.Energy.STPower.Data.Integration.DataAccess;
using Shell.Energy.STPower.Data.Integration.Services;
using Shell.Energy.STPower.Integration.PushMessage;
using Shell.Energy.STPower.Service.KafkaProducer;
using Shell.Energy.STPower.Shared;

var host = new HostBuilder()
    .ConfigureFunctionsWebApplication()
    .ConfigureAppConfiguration((context, config) =>
    {
        config.AddUserSecrets<Program>().AddEnvironmentVariables()
            .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true).Build();

        //var env = context.Configuration.GetSection("Environment")?.Value;
        //config.AddKeyVault<Program>(env);

    })

    .ConfigureServices((hostContext, services) =>
    {
        services.AddApplicationInsightsTelemetryWorkerService(new ApplicationInsightsServiceOptions() { EnableAdaptiveSampling = false });
        services.ConfigureFunctionsApplicationInsights();
        services.Configure<LoggerFilterOptions>(options =>
        {
            // The Application Insights SDK adds a default logging filter that instructs ILogger to capture only Warning and more severe logs.
            // Application Insights requires an explicit override.
            // Log levels can also be configured using appsettings.json.
            // For more information, see https://learn.microsoft.com/en-us/azure/azure-monitor/app/worker-service#ilogger-logs
            LoggerFilterRule toRemove = options.Rules.FirstOrDefault(rule => rule.ProviderName
                == "Microsoft.Extensions.Logging.ApplicationInsights.ApplicationInsightsLoggerProvider");

            if (toRemove is not null)
            {
                options.Rules.Remove(toRemove);
            }
        });

        services.AddApplicationInsightsTelemetryWorkerService();
        
        services.AddScoped<IRepository, Repository>();
        services.AddScoped<IAligneTradeService, AligneTradeService>();
        services.AddScoped<IAppLogger, AppLogger>();

        services.AddOptions<FunctionOptions>()
        .Configure<IConfiguration>((settings, configuration) =>
        {
            settings.TableStorageConnectionString = configuration.GetSection("TableStorageConnectionString").Value;
            settings.TableStorageTableNameString = configuration.GetSection("TableStorageTableNameString").Value;
            settings.PowerTrakTableStorageTableNameString = configuration.GetSection("PowerTrakTableStorageTableNameString").Value;
            settings.TradeTypes = configuration.GetSection("TradeTypes").Value;
        });
        
        services.ConfigureProducer(hostContext.Configuration);
        //services.AddStratosKeyVault();
        services.Configure<KestrelServerOptions>(options =>
        {
            options.AllowSynchronousIO = true;
        });

        // If using IIS:
        services.Configure<IISServerOptions>(options =>
        {
            options.AllowSynchronousIO = true;
        });
    })
    .Build();

host.Run();
