﻿namespace Shell.Energy.STPower.Integration.PushMessage
{
    public class FunctionOptions
    {
        public string? TableStorageConnectionString { get; set; }
        public string? TableStorageTableNameString { get; set; }
        public string? PowerTrakTableStorageTableNameString { get; set; }
        public string? TradeTypes { get; set; }
        public string? MesssagePriority { get; set; }
    }
}