using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Shell.Energy.SNE.Integration.SendNominations.Modules;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Auth;
using Shell.Energy.STPower.Shared.Modules;
using Shell.Stratos.DotNet.SDK.KeyVault;

var host = new HostBuilder()
    .ConfigureFunctionsWebApplication()
    .ConfigureAppConfiguration((context, config) =>
    {
        config.AddUserSecrets<Program>().AddEnvironmentVariables()
            .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true).Build();
        var env = context.Configuration.GetSection("Environment")?.Value;
        config.AddKeyVault<Program>(env);
    })

    .ConfigureServices((hostContext, services) =>
    {
        services.AddSneCore(hostContext.Configuration);
        services.AddScoped<IAppLogger, AppLogger>();
        services.AddStratosKeyVault();
        services.AddHttpClient();
    
        services.Configure<LoggerFilterOptions>(options =>
        {
            LoggerFilterRule? toRemove = options.Rules?.FirstOrDefault(rule => rule.ProviderName
            == "Microsoft.Extensions.Logging.ApplicationInsights.ApplicationInsightsLoggerProvider");

            if (toRemove is not null)
            {
                options.Rules?.Remove(toRemove);
            }
        });
        services.Configure<KestrelServerOptions>(options =>
        {
            options.AllowSynchronousIO = true;
        });
        services.AddTransient<ITokenService, TokenService>();
    })
    .Build();

host.Run();
