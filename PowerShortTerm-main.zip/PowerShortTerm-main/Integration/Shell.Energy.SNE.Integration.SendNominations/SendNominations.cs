using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Shell.Energy.STPower.Data.Common.Model;
using Shell.Energy.STPower.Data.Integration.Services;
using Shell.Energy.STPower.Shared.Auth;
using Shell.Energy.STPower.Shared.Constants;

namespace Shell.Energy.SNE.Integration.SendNominations
{
    public class SendNominations
    {
        private readonly ILogger _logger;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;
        private readonly string _apiurlConfig = CommonConstants.SNEAPIURL;
        private readonly IPowertrakTradeService _powertrakTradeService;
        private readonly int _nomSentStepId = 6;
        private readonly ITokenService _tokenService;

        public SendNominations(ILoggerFactory loggerFactory, 
            IHttpClientFactory httpClientFactory, 
            IConfiguration configuration, 
            IPowertrakTradeService powertrakTradeService, 
            ITokenService tokenService)
        {
            _logger = loggerFactory.CreateLogger<SendNominations>();
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
            _powertrakTradeService = powertrakTradeService;
            _tokenService = tokenService;
        }

        [Function("SendNominations")]
        public async Task Run([TimerTrigger("%TimerTriggerCronExpression%", RunOnStartup = true)] TimerInfo timerInfo)
        {
            _logger.LogInformation("{SendNominations} {StartedProcessing}", nameof(SendNominations), LogMessages.StartedProcessing);

            try
            {
                // Fetch nomination in ready status
                var readyNominations = await GetReadyNominations();

                if (readyNominations != null && readyNominations.NominationRunIDs?.Any() == true)
                {
                    var runids = string.Join(",", readyNominations.NominationRunIDs);
                    _logger.LogInformation("Fetched ready nominations , run ids :{RunIds}", runids);

                    foreach (var nominationRunId in readyNominations.NominationRunIDs)
                    {
                        //Send nomination to powertrak through SNE API
                        Task.Run(() => SendNominationToPowertrak(nominationRunId));

                        _logger.LogInformation("{SendNominations} {SendtoPowertrak} {NominationRunId}", nameof(SendNominations), LogMessages.SendtoPowertrak, nominationRunId);
                    }
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occured during sending of ready nominations, Exception trace: {StackTrace} ", ex.StackTrace);
            }
        }

        private async Task SendNominationToPowertrak(int? nominationRunId)
        {
            try
            {
                //Send nomination to powertrak through SNE API
                var env = _configuration?.GetSection(CommonConstants.STPowerEnv)?.Value?.ToUpperInvariant();
                var sneapiurl = new Uri(_configuration?.GetSection($"{_apiurlConfig}-{env}")?.Value + CommonConstants.SendNominationPosToPowertrak);
                var client = _httpClientFactory.CreateClient();
                var relativeUri = $"{CommonConstants.NominationRunId}{nominationRunId}";
                var requestUri = new Uri(sneapiurl, relativeUri);

                var token = await _tokenService.GenerateToken();
                var request = new HttpRequestMessage(HttpMethod.Get, requestUri);
                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

                await client.SendAsync(request);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occured during sending of ready nominations, Exception trace: {StackTrace} ", ex.StackTrace);
            }
        }

        private async Task<NominationReady?> GetReadyNominations()
        {
            try
            {
                //Call SNE API to fetch ready nominations 
                var env = _configuration?.GetSection(CommonConstants.STPowerEnv)?.Value?.ToUpperInvariant();
                var sneapiurl = new Uri(_configuration?.GetSection($"{_apiurlConfig}-{env}")?.Value + CommonConstants.GetReadyNominations);
                var client = _httpClientFactory.CreateClient();

                var token = await _tokenService.GenerateToken();
                var request = new HttpRequestMessage(HttpMethod.Get, sneapiurl);
                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

                var response = await client.SendAsync(request);
                var responseString = await response.Content.ReadAsStringAsync();
                if (response.IsSuccessStatusCode)
                {
                    var readyNominations = JsonConvert.DeserializeObject<NominationReady>(responseString);
                    return readyNominations;
                }
                else
                {
                    _logger.LogInformation(responseString);
                }

                _logger.LogInformation(CommonConstants.LogMessageReadyNom);
                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occured during fetching of ready nominations, Exception trace: {StackTrace} ", ex.StackTrace);
                return null;
            }
        }
    }
}
