﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Data.Integration.DataAccess;
using Shell.Energy.STPower.Data.Integration.Services;

namespace Shell.Energy.SNE.Integration.SendNominations.Modules
{
    /// <summary>
    /// DI class for adding core modules
    /// </summary>
    public static class SneCore
    {
        public static IServiceCollection AddSneCore(this IServiceCollection collection,IConfiguration configuration)
        {
            collection.AddScoped<ISqlDataRepository, SqlDataRepository>();
            collection.AddScoped<IPowertrakTradeService, PowertrakTradeService>();
            collection.AddScoped<IAppLogger, AppLogger>();
            collection.AddHttpClient();
            return collection;
        }
    }
}
