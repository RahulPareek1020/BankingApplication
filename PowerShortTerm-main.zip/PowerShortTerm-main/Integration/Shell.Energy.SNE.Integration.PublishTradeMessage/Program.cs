using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Shell.Energy.STPower.Data.Integration.DataAccess;
using Shell.Energy.STPower.Data.Integration.Services;
using Shell.Energy.STPower.Service.KafkaProducer;
using Shell.Energy.STPower.Shared;
using Shell.Stratos.DotNet.SDK.KeyVault;
using Shell.Energy.STPower.Shared.Modules;
using OpenTelemetry;
using Shell.Energy.SNE.Integration.PublishTradeMessage;
using OpenTelemetry.Trace;
using OpenTelemetry.Resources;
using OpenTelemetry.Exporter;
using Shell.Energy.SNE.Common.OpenTelemetry;

const string otlpClientName = "SNE_OtlpClient";
const string serviceName = "ShellNominationEngine.SendNomination";

var host = new HostBuilder()
    .ConfigureFunctionsWebApplication()
    .ConfigureAppConfiguration((context, config) =>
    {
        config.AddUserSecrets<Program>().AddEnvironmentVariables()
            .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true).Build();
        var env = context.Configuration.GetSection("Environment")?.Value;
        config.AddKeyVault<Program>(env);
    })
    .ConfigureServices((hostContext, services) =>
    {
        services.ConfigureProducer(hostContext.Configuration);
        services.AddScoped<ISqlDataRepository, SqlDataRepository>();
        services.AddScoped<IRepository, Repository>();
        services.AddScoped<IAligneTradeService, AligneTradeService>();
        services.AddScoped<IPowertrakTradeService, PowertrakTradeService>();
        services.AddScoped<IAppLogger, AppLogger>();
        services.AddStratosKeyVault();

        services.Configure<LoggerFilterOptions>(options =>
        {
            LoggerFilterRule? toRemove = options.Rules?.FirstOrDefault(rule => rule.ProviderName
            == "Microsoft.Extensions.Logging.ApplicationInsights.ApplicationInsightsLoggerProvider");

            if (toRemove is not null)
            {
                options.Rules?.Remove(toRemove);
            }
        });
        services.Configure<KestrelServerOptions>(options =>
        {
            options.AllowSynchronousIO = true;
        });

        services.ConfigureOpenTelemetryDependencies(hostContext.Configuration, serviceName, otlpClientName);
    })
    .Build();

var serviceProvider = host.Services;
var openTelemetrySettings = serviceProvider.GetService<OpenTelemetrySettings>();
var otelCustomAttributes = serviceProvider.GetService<CustomAttributes>();
var serviceInfo = typeof(PublishTradeMessage).GetServiceNameAndVersion();
Sdk.CreateTracerProviderBuilder()
    .AddSource(serviceName)
    .ConfigureResource(r =>
    {
        r.AddService(serviceName, serviceInfo.ServiceVersion);
        r.AddAttributes(new Dictionary<string, object>
        {
            { "service.name", serviceInfo.ServiceName },
            { "service.version", serviceInfo.ServiceVersion },
            { "service.environment", otelCustomAttributes!.Environment ?? string.Empty},
            { "application.id", otelCustomAttributes.ApplicationId ?? string.Empty }
        });
    })
    .AddOtlpExporter(exporter =>
    {
        exporter.Endpoint = openTelemetrySettings!.OtlpExporterEndpoint!;
        exporter.Protocol = OtlpExportProtocol.HttpProtobuf;
        exporter.ExportProcessorType = ExportProcessorType.Simple;
        exporter.HttpClientFactory = () =>
        {
            var httpClientFactory = serviceProvider.GetRequiredService<IHttpClientFactory>();
            return httpClientFactory.CreateClient(otlpClientName);
        };
    })
    .AddConsoleExporter(options => { }) // Fix: Add options parameter
    .Build();

host.Run();
