using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using NPOI.SS.Formula.Functions;
using OpenTelemetry;
using OpenTelemetry.Context.Propagation;
using Shell.Energy.SNE.Common.OpenTelemetry;
using Shell.Energy.STPower.Data.Common.Model;
using Shell.Energy.STPower.Data.Integration.Constants;
using Shell.Energy.STPower.Data.Integration.Services;
using Shell.Energy.STPower.Service.KafkaProducer;
using Shell.Energy.STPower.Shared.Constants;
using System.Diagnostics;
using System.Globalization;
using Status = Shell.Energy.STPower.Shared.Enums.Status;

namespace Shell.Energy.SNE.Integration.PublishTradeMessage
{
    public class PublishTradeMessage
    {
        private readonly ILogger _logger;
        private readonly IAligneTradeService _tradeServiceProvider;
        private readonly IKafkaMessageProducer _etrmProducer;
        private readonly IConfiguration _configuration;
        private readonly ITelemetryActivity _telemetryActivity;
        private readonly IPowertrakTradeService _powerTrakTradeService;
        private readonly string _telemetryActivityName = "Publishing trades to Kafka";
        private readonly string _traceFlags = "1";

        public PublishTradeMessage(ILoggerFactory loggerFactory, IAligneTradeService tradeServiceProvider, IKafkaMessageProducer etrmProducer, 
            IConfiguration configuration, IPowertrakTradeService powerTrakTradeService,ITelemetryActivity telemetryActivity)
        {
            _logger = loggerFactory.CreateLogger<PublishTradeMessage>();
            _tradeServiceProvider = tradeServiceProvider;
            _etrmProducer = etrmProducer;
            _configuration = configuration;
            _powerTrakTradeService = powerTrakTradeService;
            _telemetryActivity = telemetryActivity;
        }

        [Function("PublishRawTradeMessage")]
        public async Task Run([TimerTrigger("%TimerTrigger%", RunOnStartup = true)] TimerInfo timerInfo)
         {
            _logger.LogInformation($"{nameof(PublishTradeMessage)} {LogMessages.StartedProcessing}");
            try
            {
                var batchRunIdCount = Convert.ToInt32(_configuration.GetSection("batchRunIdCount").Value, CultureInfo.InvariantCulture);
                var batchRunIds = await _tradeServiceProvider.GetBatchRunIds(batchRunIdCount);
                if (batchRunIds != null && batchRunIds.Count > 0)
                {
                    var runids = string.Join(",", batchRunIds);
                    _logger.LogInformation("Batch run ids count : {BatchRunIds}, runIds: {Runids}", batchRunIds.Count, runids);

                    foreach (var batchRunIdVnet in batchRunIds)
                    {
                        // Record the start time
                        var startTime = DateTime.Now;
                        var startTimeFetchData = DateTime.Now;
                        await FetchRawTradesAndSendToKafka(startTime, startTimeFetchData, batchRunIdVnet);
                    }
                }
                else
                {
                    _logger.LogInformation($"Batch run ids count : 0");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occured during PublishPowerTrakTradeMessage {Message}", ex.Message);
            }
        }

        private async Task FetchRawTradesAndSendToKafka(DateTime startTime, DateTime startTimeFetchData, long batchRunIdVnet)
        {
            //Fetch all aligne raw trades from DB
            var aligneRawTrades = await _tradeServiceProvider.FetchAligneRawTrades(batchRunIdVnet);
            var endTimeFetchData = DateTime.Now;
            var tasks = new List<Task>();
            var totalRowCount = aligneRawTrades.Count;
            aligneRawTrades.ForEach(x => x.TotalBatchRowCount = totalRowCount);
            bool isNominationRunOtelIdsNull = true;
            // Calculate the execution time for fetching data from DB
            TimeSpan fetchDataExecutionTime = TimeSpan.FromSeconds((endTimeFetchData - startTimeFetchData).TotalSeconds);
            var logmessage = $"{ServiceConstants.TimeTakenToFetch}{fetchDataExecutionTime.ToString(@"hh\:mm\:ss", CultureInfo.InvariantCulture)}";
            _logger.LogInformation(logmessage);

            var sendDataToKafkaStartTime = DateTime.Now;

            if (aligneRawTrades != null && aligneRawTrades.Count > 0)
            {
                var batchRunDate = aligneRawTrades.Max(item => item.BatchRunDate);
                var batchRunTime = aligneRawTrades.Min(item => item.BatchRunTime);
                var batchRunId = aligneRawTrades.Min(item => item.BatchRunId);

                var nominationRunOtelIds = await _powerTrakTradeService.GetNominationRunTraceSpanId(Convert.ToInt32(batchRunIdVnet));
                isNominationRunOtelIdsNull = IsNominationRunOtelIdsNull(nominationRunOtelIds);
                if (!isNominationRunOtelIdsNull)
                {
                    StartTelemetryActivity(nominationRunOtelIds);
                }

                var loggingMessageBatch = $" , BatchRunDate: {batchRunDate}, BatchRunTIme: {batchRunTime}, BatchRunId:{batchRunId}";
                try
                {
                    //Split the raw trades to logical chunks based on trade type entity and transaction type to be sent to Kafka
                    var aligneGroupedList = aligneRawTrades.GroupBy(rawTrade => new { rawTrade.TradeType, rawTrade.Entity, rawTrade.TransactionType }).Select(group => group.ToList()).ToList();

                    foreach (var aligneGroupedListItem in aligneGroupedList)
                    {
                        //Send raw trades to Kafka
                        await PublishAligneRawTrades(aligneGroupedListItem);
                    }
                }
                catch (Exception ex)
                {
                    if (!isNominationRunOtelIdsNull && !_telemetryActivity.IsStopped)
                    {
                        _telemetryActivity.AddEvent(ServiceConstants.ErrorPublish);
                        _telemetryActivity.StopActivity();
                    }

                    var logMsgs = $"{ServiceConstants.ErrorPublish}{ex.Message}{loggingMessageBatch}";
                    _logger.LogError(ex, logMsgs);
                    const Status incompleteStatus = Status.INCOMPLETE;
                    await _tradeServiceProvider.InsertBatchRunStatus(batchRunDate, batchRunTime, batchRunId, incompleteStatus.ToString(), aligneRawTrades.Count);
                }

                //Update batch run status
                const Status status = Status.COMPLETE;
                var aligneRawTradesCount = aligneRawTrades.Count;
                await _tradeServiceProvider.InsertBatchRunStatus(batchRunDate, batchRunTime, batchRunId, status.ToString(), aligneRawTradesCount);

                // Record the end Time
                var endSingleTradeEndTime = DateTime.Now;

                // Calculate the execution time for sending message to Kafka
                TimeSpan sendDataToKafkaExecutionTime = TimeSpan.FromSeconds((endSingleTradeEndTime - sendDataToKafkaStartTime).TotalSeconds);
                var logM = $"{ServiceConstants.TimeTakenToSend}{sendDataToKafkaExecutionTime.ToString(@"hh\:mm\:ss", CultureInfo.InvariantCulture)}{loggingMessageBatch}";
                _logger.LogInformation(logM);

                // Calculate the execution time for Delivery Date and Market
                TimeSpan singleTradeExecutionTime = TimeSpan.FromSeconds((endSingleTradeEndTime - startTime).TotalSeconds);
                var log = $"{ServiceConstants.TotalTimeTakenToSend}{singleTradeExecutionTime.ToString(@"hh\:mm\:ss", CultureInfo.InvariantCulture)}{loggingMessageBatch}";
                _logger.LogInformation(log);

                if (!_telemetryActivity!.IsStopped && !isNominationRunOtelIdsNull)
                {
                    _telemetryActivity.AddEvent($"Published {aligneRawTrades.Count} raw trades to Kafka for NominationRunId: {batchRunId}");
                    _telemetryActivity.StopActivity();
                }
            }
            else
            {
                _logger.LogInformation($"No data from Aligne");
            }
        }

        private async Task PublishAligneRawTrades(IEnumerable<AligneRawTrade> aligneRawTrades)
        {

            if (aligneRawTrades != null && aligneRawTrades.Any())
            {
                try
                {
                    await _etrmProducer.ProduceKafkaMessage(aligneRawTrades);
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
        }
        private static bool IsNominationRunOtelIdsNull(NominationRunOtelIds nominationRunOtelIds)
        {
            return nominationRunOtelIds == null || string.IsNullOrEmpty(nominationRunOtelIds.SpanId) || string.IsNullOrEmpty(nominationRunOtelIds.TraceId);
        }

        private void StartTelemetryActivity(NominationRunOtelIds nominationRunOtelIds)
        {
            var parentContext = new ActivityContext(
                traceId: ActivityTraceId.CreateFromString(nominationRunOtelIds.TraceId),
                spanId: ActivitySpanId.CreateFromString(nominationRunOtelIds.SpanId),
                (ActivityTraceFlags)Enum.Parse(typeof(ActivityTraceFlags), _traceFlags)
            );
            var propagationContext = new PropagationContext(parentContext, Baggage.Current);
            _telemetryActivity.StartConsumerActivity(_telemetryActivityName, propagationContext, ActivityKind.Consumer);
        }
    }
}
