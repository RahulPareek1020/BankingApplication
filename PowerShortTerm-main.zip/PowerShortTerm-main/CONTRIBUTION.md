# How to contribute

Here are some guidelines to help you get started.

## Getting Started

1. Send request to join the team: https://github.com/orgs/sede-x/teams/powerst

1. **Fork the repository**: Click the "Fork" button at the top right of the repository page.
2. **Clone your fork**: 
    ```git clone https://github.com/sede-x/PowerShortTerm.git```
3. **Create a branch**: 
    ```git checkout -b feature/your-feature-name```
4. **Install dependencies**: 
```dotnet restore```
## Making Changes

1. **Make your changes**: Ensure your code follows the project's coding standards.
2. **Run tests**: Make sure all tests pass before submitting your changes.
    ```dotnet test```
3. **Commit your changes**: 
     ```git add .```
     ```git commit -m "Description of your changes"```
4. **Push to your fork**: 
   ```git push origin feature/your-feature-name```

## Submitting a Pull Request

1. **Open a pull request**: Go to the repository and click the "New pull request" button.
2. **Describe your changes**: Provide a clear description of what you have done and why.
3. **Link to issues**: If your pull request addresses any issues, link to them in the description.
