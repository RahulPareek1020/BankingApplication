﻿using Microsoft.Extensions.DependencyInjection;
using Shell.Energy.STPower.Service.KafkaProducer.Schema;
using Shell.Energy.STPower.Shared.Constants;
using Shell.Energy.STPower.Shared.Exceptions;

namespace Shell.Energy.STPower.Service.KafkaConsumer
{
    /// <summary>
    /// Wrapper class for consuming messages from Kafka from different topics
    /// </summary>
    public class EtrmConsumer : IEtrmConsumer
    {
        private readonly IServiceProvider _serviceProvider;
        public EtrmConsumer(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        /// <summary>
        /// Consume message from Kafka based on topic
        /// </summary>
        /// <param name="topicName"></param>
        /// <returns></returns>
        public string? ConsumeMessage(string topicName)
        {
            return ConsumeAligneRawTrade(topicName);
        }

        private string? ConsumeAligneRawTrade(string topicName)
        {
            var consumerService = _serviceProvider.GetService<IConsumerService<AligneRawTradeSchema_Key, AligneRawTradeSchema>>();
            if (consumerService == null)
            {
                return null;
            }
            var _consumer = consumerService.BuildConsumer();
            return consumerService.Consume(_consumer, topicName);
        }
    }
}
