﻿using Shell.Energy.STPower.Service.KafkaProducer.Schema;

namespace Shell.Energy.STPower.Shared
{
    /// <summary>
    /// Class for holding objects of Kafka Short Term Message
    /// </summary>
    public class KafkaSNEMessage
    {
        public IEnumerable<Aligne_Raw_Trade>? Aligne_Raw_Trades { get; set; }
    }
}