﻿using Shell.Energy.Kafka;

namespace Shell.Energy.STPower.Service.KafkaConsumer
{
    /// <summary>
    /// Interface for Consumer Service
    /// </summary>
    /// <typeparam name="TKey"></typeparam>
    /// <typeparam name="TValue"></typeparam>
    public interface IConsumerService<TKey, TValue>
        where TKey : class
        where TValue : class
    {
        IKafkaConsumer<TKey, TValue> BuildConsumer();
        string Consume(
            IKafkaConsumer<TKey, TValue> eventBackboneConsumer,
            string topicName);
    }
}