﻿namespace Shell.Energy.STPower.Service.KafkaConsumer
{
    /// <summary>
    /// Interface for ETRM Consumer
    /// </summary>
    public interface IEtrmConsumer
    {
        string? ConsumeMessage(string topicName);
    }
}
