﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Shell.Energy.Kafka.Extensions;
using Shell.Energy.Kafka.Models;
using Shell.Energy.Kafka.Options;

namespace Shell.Energy.STPower.Service.KafkaConsumer
{
    /// <summary>
    /// Class to inject dependencies for consumer during function startup
    /// </summary>
    public static class ConsumerDependencyInjector
    {
        public static void ConfigureConsumer(this IServiceCollection services, IConfiguration config)
        {
            //Adding Kafka OAuth configurations from the secrets to the service collection
            services
                .AddOptions<KafkaOAuthAppOptions>()
                .BindConfiguration("kafkaOAuthAppOptions")
                .ValidateDataAnnotations();

            //Adding Schema Registry Auth options from the secrets to the service collection
            services
                .AddOptions<SchemaRegistryAuthenticationOptions>()
                .BindConfiguration("schemaRegistryAuthenticationOptions")
                .ValidateDataAnnotations();

            //Adding open telemetry and service discovery options from the secrets to the service collection
            var openTelemetryExporterOptions = config.GetSection("openTelemetryExporterOptions").Get<OpenTelemetryExporterOptions>();
            var serviceDiscoveryOptions = config.GetSection("serviceDiscoveryOptions").Get<ServiceDiscoveryOptions>();

            //Adding Kafka Ada event backbone consumer library to the service collection
            services.AddKafka(
                "Shell.Energy.STPower.Service.KafkaConsumer",
                serviceDiscoveryOptions,
                openTelemetryExporterOptions);

            services.AddScoped(typeof(IConsumerService<,>), typeof(ConsumerService<,>));
            services.AddScoped<IEtrmConsumer, EtrmConsumer>();
        }
    }
}
