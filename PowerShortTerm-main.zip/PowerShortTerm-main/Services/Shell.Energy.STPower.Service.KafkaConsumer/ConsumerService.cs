﻿using Confluent.Kafka;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Shell.Energy.Kafka;
using Shell.Energy.Kafka.Extensions;
using Shell.Energy.Kafka.Models;
using Shell.Energy.Kafka.Options;
using Shell.Energy.STPower.Service.KafkaProducer.Schema;
using Shell.Energy.STPower.Shared;
using System.Globalization;

namespace Shell.Energy.STPower.Service.KafkaConsumer
{
    /// <summary>
    /// This class is a generic Kafka consumer service.
    /// </summary>
    /// <typeparam name="TKey"></typeparam>
    /// <typeparam name="TValue"></typeparam>
    public class ConsumerService<TKey, TValue> : IConsumerService<TKey, TValue>
        where TKey : class
        where TValue : class
    {
        // These fields store configuration values and services needed by the consumer.
        private readonly string? ConsumeActivityName;
        private readonly string? ConsumerGroupId;
        private readonly string? ClientId;
        private readonly int WaitTimeForMessagesInSeconds;
        private readonly IKafkaConsumerBuilder<TKey, TValue> _eventBackboneConsumerBuilder;
        private readonly IAppLogger _logger;
        private readonly KafkaOAuthAppOptions _kafkaOAuthAppOptions;
        private readonly SchemaRegistryAuthenticationOptions _schemaRegistryAuthenticationOptions;
        private readonly string KafkaConsumerConfigKey= "KafkaConsumer";

        /// <summary>
        /// Constructor for ConsumerService, initializes the consumer service with necessary dependencies.
        /// </summary>
        /// <param name="eventBackboneConsumerBuilder"></param>
        /// <param name="kafkaOAuthAppOptions"></param>
        /// <param name="schemaRegistryAuthenticationOptions"></param>
        /// <param name="logger"></param>
        /// <param name="config"></param>
        public ConsumerService(
            IKafkaConsumerBuilder<TKey, TValue> eventBackboneConsumerBuilder,
            IOptions<KafkaOAuthAppOptions> kafkaOAuthAppOptions,
            IOptions<SchemaRegistryAuthenticationOptions> schemaRegistryAuthenticationOptions,
            IAppLogger logger, IConfiguration config)
        {
            _eventBackboneConsumerBuilder = eventBackboneConsumerBuilder;
            _logger = logger;
            _kafkaOAuthAppOptions = kafkaOAuthAppOptions.Value;
            _schemaRegistryAuthenticationOptions = schemaRegistryAuthenticationOptions.Value;
            ConsumeActivityName=config.GetSection(KafkaConsumerConfigKey).GetSection("ConsumeActivityName").Value;
            ConsumerGroupId = config.GetSection(KafkaConsumerConfigKey).GetSection("ConsumerGroupId").Value;
            ClientId = config.GetSection(KafkaConsumerConfigKey).GetSection("ClientId").Value;
            WaitTimeForMessagesInSeconds = Convert.ToInt32(config.GetSection(KafkaConsumerConfigKey).GetSection("WaitTimeForMessagesInSeconds").Value, CultureInfo.InvariantCulture);
        }

        /// <summary>
        /// This method consumes messages from a Kafka topic.
        /// </summary>
        /// <param name="eventBackboneConsumer"></param>
        /// <param name="topicName"></param>
        /// <returns></returns>
        public string Consume(IKafkaConsumer<TKey, TValue> eventBackboneConsumer, string topicName)
        {
            if (eventBackboneConsumer is null)
            {
                return null;
            }
            var traceMetadata = new ConsumerTraceMetadata
            {
                ActivityName = ConsumeActivityName
            };

            // Subscribe to the topic.
            eventBackboneConsumer.Subscribe(topicName);
            // Create a cancellation token that cancels after defined minutes.
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(WaitTimeForMessagesInSeconds));
            _logger.LogInformation($"Waiting for {WaitTimeForMessagesInSeconds} seconds to consume messages from {topicName}.");
            var token = cts.Token;
            List<KafkaSNEMessage> kafkaSTMessages = new List<KafkaSNEMessage>();

            //// Consume messages until the cancellation token is cancelled.
            while (!token.IsCancellationRequested)
            {
                try
                {
                    var receivedMessage = eventBackboneConsumer.Receive(traceMetadata);
                    if (receivedMessage == null)
                    {
                        continue;
                    }
                    var kafkaRawMessage = new KafkaRawMessage<TKey, TValue> { MessageKey = receivedMessage.Message.Key, MessageValue = receivedMessage.Message.Value };

                    if (kafkaRawMessage.MessageValue is AligneRawTradeSchema aligneRawTradeSchema)
                    {
                        kafkaSTMessages.Add(new KafkaSNEMessage { Aligne_Raw_Trades = aligneRawTradeSchema.Aligne_Raw_Trades });
                    }
                    eventBackboneConsumer.Commit(receivedMessage);
                }
                catch (OperationCanceledException)
                {
                    // The token was cancelled, break the loop
                    break;
                }  
            }
            _logger.LogInformation($"Consumed {kafkaSTMessages.Count} messages.");
            eventBackboneConsumer.Dispose();

            return JsonConvert.SerializeObject(kafkaSTMessages, Formatting.None);
        }

        /// <summary>
        /// This method builds a Kafka consumer with the specified configuration.
        /// </summary>
        /// <returns></returns>
        public IKafkaConsumer<TKey, TValue> BuildConsumer()
        {
            return _eventBackboneConsumerBuilder
                .WithClientId(ClientId)
                .WithGroupId(ConsumerGroupId)
                .WithAuthentication(_kafkaOAuthAppOptions)
                .AddLogging(OnKafkaLog)
                .AddErrorHandler(OnKafkaError)
                .SetAvroValueDeserializer(_schemaRegistryAuthenticationOptions)
                .SetAvroKeyDeserializer(_schemaRegistryAuthenticationOptions)
                .Build();
        }

        // This method logs Kafka events.
        private void OnKafkaLog(object sender, LogMessage e)
            => _logger.LogDebug($"{nameof(ConsumerService<TKey, TValue>)} ConfluentKafka : [{e.Name}] [{e.Facility}] [{e.Level}] [{e.Message}]");

        // This method handles Kafka errors.
        private void OnKafkaError(object sender, Error e) =>
            _logger.LogError($"{nameof(ConsumerService<TKey, TValue>)} ConfluentKafka : [{e.Reason}] IsFatal={e.IsFatal} IsError={e.IsError} IsLocalError={e.IsLocalError} IsBrokerError={e.IsBrokerError}");
        // This method saves the offset to a file.
    }
}
