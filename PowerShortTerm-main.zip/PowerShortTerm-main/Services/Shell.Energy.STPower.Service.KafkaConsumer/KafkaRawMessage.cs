﻿namespace Shell.Energy.STPower.Service.KafkaConsumer
{
    public class KafkaRawMessage<Tkey,TValue> where Tkey : class where TValue : class
    {
        public TValue? MessageValue { get; set; }
        public Tkey? MessageKey { get; set; }
    }
}
