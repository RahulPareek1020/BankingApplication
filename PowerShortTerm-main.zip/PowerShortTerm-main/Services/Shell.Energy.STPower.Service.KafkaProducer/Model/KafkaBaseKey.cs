﻿namespace Shell.Energy.STPower.Service.KafkaProducer.Model
{
    public class KafkaBaseKey
    {
        public string? ENTITY { get; set; }
        public string? MARKET { get; set; }

    }
}
