﻿namespace Shell.Energy.STPower.Service.KafkaProducer.Model
{
    public class KafkaProfileTransKey : KafkaBaseKey
    {
        public Int32? TRADETYPE { get; set; }
        public Int32? GRANULARITY { get; set; }
    }
}
