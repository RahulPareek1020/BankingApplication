﻿using Confluent.Kafka;
using Shell.Energy.Kafka;

namespace Shell.Energy.STPower.Service.KafkaProducer
{
    public interface IProducerService<TKey, TValue>
       where TKey : class
       where TValue : class
    {
        IKafkaProducer<TKey, TValue> BuildProducer();
        Task<DeliveryResult<TKey, TValue>> PublishMessage(
            IKafkaProducer<TKey, TValue> eventBackboneProducer,
            string topicName,
            string messageIdentifier,
            TValue value,
            TKey key = null);
        Task<DeliveryResult<TKey, TValue>> PublishTradeMessage(
            IKafkaProducer<TKey, TValue> eventBackboneProducer,
            string topicName
            );

        void DisposeProducer(IKafkaProducer<TKey, TValue>? eventBackboneProducer);
    }
}
