﻿using Confluent.Kafka;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Shell.Energy.Kafka;
using Shell.Energy.Kafka.Extensions;
using Shell.Energy.Kafka.Models;
using Shell.Energy.Kafka.Options;

namespace Shell.Energy.STPower.Service.KafkaProducer
{
    public class ProducerService<TKey, TValue> : IProducerService<TKey, TValue>
            where TKey : class
            where TValue : class
    {
        private const string ProduceActivityName = "Shell.Energy.STPower.Service.KafkaProducer";

        private readonly IKafkaProducerBuilder<TKey, TValue> _eventBackboneProducerBuilder;
        private readonly ILogger<ProducerService<TKey, TValue>> _logger;
        private readonly KafkaOAuthAppOptions _kafkaOAuthAppOptions;
        private readonly SchemaRegistryAuthenticationOptions _schemaRegistryAuthenticationOptions;

        public ProducerService(
            IKafkaProducerBuilder<TKey, TValue> eventBackboneProducerBuilder,
            IOptions<KafkaOAuthAppOptions> kafkaOAuthAppOptions,
            IOptions<SchemaRegistryAuthenticationOptions> schemaRegistryAuthenticationOptions,
            ILogger<ProducerService<TKey, TValue>> logger)
        {
            _eventBackboneProducerBuilder = eventBackboneProducerBuilder;
            _logger = logger;
            _kafkaOAuthAppOptions = kafkaOAuthAppOptions.Value;
            _schemaRegistryAuthenticationOptions = schemaRegistryAuthenticationOptions.Value;
        }

        public async Task<DeliveryResult<TKey, TValue>> PublishMessage(
            IKafkaProducer<TKey, TValue> eventBackboneProducer,
            string topicName,
            string messageIdentifier,
            TValue value,
            TKey key = null)
        {
            Message<TKey, TValue> message = new()
            {
                Key = key,
                Value = value
            };

            var traceBaggage = new Dictionary<string, string>
            {
                { "CurrentTimestamp", DateTime.UtcNow.ToString() }
            };

            ProducerTraceMetadata traceMetadata = new()
            {
                ActivityName = ProduceActivityName,
                MessageIdentifier = messageIdentifier,
                TraceBaggage = traceBaggage
            };

            return await eventBackboneProducer.ProduceAsync(topicName, message, traceMetadata);
        }

        public IKafkaProducer<TKey, TValue> BuildProducer()
        {
            return _eventBackboneProducerBuilder
                .WithAuthentication(
                    _kafkaOAuthAppOptions)
                .SetLogging(OnKafkaLog)
                .SetErrorHandler(OnKafkaError)
                .SetAvroValueSerializer(_schemaRegistryAuthenticationOptions)
                .SetAvroKeySerializer(_schemaRegistryAuthenticationOptions)
                .Build();
        }

        public void DisposeProducer(IKafkaProducer<TKey, TValue>? eventBackboneProducer)
        {
            if (eventBackboneProducer != null)
            {
                eventBackboneProducer.Dispose();
            }
        }

        private void OnKafkaLog(object sender, LogMessage e) =>
            _logger.LogDebug($"{nameof(ProducerService<TKey, TValue>)} ConfluentKafka : [{e.Name}] [{e.Facility}] [{e.Level}] [{e.Message}]");

        private void OnKafkaError(object sender, Error e) =>
            _logger.LogError($"{nameof(ProducerService<TKey, TValue>)} ConfluentKafka : [{e.Reason}] IsFatal={e.IsFatal} IsError={e.IsError} IsLocalError={e.IsLocalError} IsBrokerError={e.IsBrokerError}");

        public Task<DeliveryResult<TKey, TValue>> PublishTradeMessage(IKafkaProducer<TKey, TValue> eventBackboneProducer, string topicName)
        {
            throw new NotImplementedException();
        }
    }
}
