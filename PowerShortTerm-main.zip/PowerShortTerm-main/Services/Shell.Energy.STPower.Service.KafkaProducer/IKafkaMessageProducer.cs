﻿using Shell.Energy.STPower.Data.Common.Model;

namespace Shell.Energy.STPower.Service.KafkaProducer
{
    public interface IKafkaMessageProducer
    {
     Task ProduceKafkaMessage(IEnumerable<AligneRawTrade> tradeData);
    }
}
