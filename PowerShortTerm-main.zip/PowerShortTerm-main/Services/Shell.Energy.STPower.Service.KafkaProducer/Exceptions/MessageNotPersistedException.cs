﻿using System.Runtime.Serialization;
using Confluent.Kafka;

namespace Shell.Energy.STPower.Service.KafkaProducer.Exceptions
{
    [Serializable]
    public class MessageNotPersistedException : Exception
    {
        public MessageNotPersistedException() { }
        public MessageNotPersistedException(PersistenceStatus persistenceStatus) 
            : base($"Kafka message has not been persisted. Status: {persistenceStatus.ToString()}") { }

        public MessageNotPersistedException(PersistenceStatus persistenceStatus, Exception exception)
            : base($"Kafka message has not been persisted. Status {persistenceStatus} is not published.", 
                exception)
        { }

        protected MessageNotPersistedException(SerializationInfo info, StreamingContext context)
            : base(info, context) { }
    }
}
