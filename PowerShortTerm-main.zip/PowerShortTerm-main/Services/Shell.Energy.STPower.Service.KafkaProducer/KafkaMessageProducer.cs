﻿using Confluent.Kafka;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Shell.Energy.STPower.Data.Common.Model;
using Shell.Energy.STPower.Data.Integration.Constants;
using Shell.Energy.STPower.Data.Integration.Services;
using Shell.Energy.STPower.Service.KafkaProducer.Exceptions;
using Shell.Energy.STPower.Service.KafkaProducer.Schema;
using Shell.Energy.STPower.Shared;
using Shell.Energy.STPower.Shared.Enums;
using System.Globalization;
using System.Text.Json;

namespace Shell.Energy.STPower.Service.KafkaProducer
{
    public class KafkaMessageProducer : IKafkaMessageProducer
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly IAppLogger _logger;
        private readonly IAligneTradeService _tradeServiceProvider;
        private readonly IConfiguration _configuration;


        public KafkaMessageProducer(IServiceProvider serviceProvider, IAppLogger logger, IAligneTradeService tradeServiceProvider, IConfiguration configuration)
        {
            _serviceProvider = serviceProvider;
            _logger = logger;
            _tradeServiceProvider = tradeServiceProvider;
            _configuration = configuration;
        }

        public async Task ProduceKafkaMessage(IEnumerable<AligneRawTrade> tradeData)
        {

            //Get the topic name based on the trade type
            string topicName = _configuration.GetValue<string>("KafkaTopicName") ?? string.Empty;

            _logger.LogInformation($"Produce kafka Message is called");

            try
            {
                await ProduceAligneRawTrades(topicName, tradeData);
            }
            catch (Exception ex)
            {
                _logger.LogError(Messages.FunctionObjectCreationError);
                throw new MessageNotPersistedException(PersistenceStatus.NotPersisted);
            }
        }

        private async Task ProduceAligneRawTrades(string strTopicName, IEnumerable<AligneRawTrade> aligneRawTrades)
        {
            try
            {
                // Get the trade ID
                var tradeID = aligneRawTrades.ToList()[0].Reference;
                var batchRunDate = aligneRawTrades?.Max(item => item.BatchRunDate);
                var batchRunTime = aligneRawTrades?.Min(item => item.BatchRunTime);
                var batchRunId = aligneRawTrades?.Min(item => item.BatchRunId);
                string logMessage = $", BatchRunDate: {batchRunDate}, BatchRunTIme: {batchRunTime}, BatchRunId:{batchRunId}";

                _logger.LogInformation($"Total messsage in batch {aligneRawTrades?.Count()}{logMessage}");

                //Fetch no of raw trades to be sent from configuration 
                var size = Convert.ToInt32(_configuration.GetSection("rawTradesSize").Value, CultureInfo.InvariantCulture);

                //Split the rows into chunks of specified size
                var aligneGroupedList = aligneRawTrades.Chunk(size).ToList();
                int totalMessageSentToKafka = 0;
                int totalRawTradesSentToKafka = 0;

                KafkaMessageOutput kafkaMessageOutput = new KafkaMessageOutput();

                foreach (var aligneRawDataList in aligneGroupedList)
                {
                    // Create a KafkaBaseKey object 
                    var aligneRawTradeSchema_Key = new AligneRawTradeSchema_Key
                    {
                        TRADETYPE = aligneRawDataList[0]?.TradeType,
                        ENTITY = aligneRawDataList[0]?.Entity,
                        TRANSACTIONTYPE = aligneRawDataList[0]?.TransactionType
                    };

                    //Serialize to proper format
                    var serializeAligneTradeData = JsonSerializer.Serialize(aligneRawDataList.ToList());
                    var alingRawTrades = JsonSerializer.Deserialize<List<Aligne_Raw_Trade>>(serializeAligneTradeData);

                    var avroAligneTradeDataSchema = new AligneRawTradeSchema();
                    avroAligneTradeDataSchema.Aligne_Raw_Trades = alingRawTrades;
                    try
                    {

                        var producerService = _serviceProvider.GetService<IProducerService<AligneRawTradeSchema_Key, AligneRawTradeSchema>>();
                        var externalID = $"TestExternalID-{DateTime.UtcNow}";
                        var _producer = producerService?.BuildProducer();

                        _logger.LogInformation($"{ServiceConstants.NumberOfRowsSent}{aligneRawDataList.ToList().Count}{logMessage}");

                        // Publish the message to Kafka
                        var deliveryResult = (producerService != null && _producer != null) ? await producerService.PublishMessage(
                           _producer,
                           strTopicName,
                           externalID,
                           avroAligneTradeDataSchema,
                           aligneRawTradeSchema_Key) : null;

                        if (deliveryResult?.Status == PersistenceStatus.Persisted)
                        {
                            _logger.LogInformation($"{ServiceConstants.TradeMessagesToKafka}{strTopicName}{logMessage}");
                            totalMessageSentToKafka++;
                            totalRawTradesSentToKafka += aligneRawDataList.ToList().Count;
                        }
                        else
                        {

                            await _tradeServiceProvider.InsertErrorRecords(aligneRawDataList.ToList());

                            _logger.LogInformation($"{ServiceConstants.ErrorMessagesToKafka}{strTopicName}{logMessage}");
                        }

                        producerService?.DisposeProducer(_producer);

                    }
                    catch (Exception ex)
                    {
                        _logger.LogInformation($"{ServiceConstants.ErrorMessagesToKafka}{strTopicName}{logMessage}");
                        _logger.LogError(ex.Message);

                        //Update error records to DB
                        await _tradeServiceProvider.InsertErrorRecords(aligneRawDataList.ToList());
                    }
                }
                kafkaMessageOutput.TotalMessagesSent = totalMessageSentToKafka;
                kafkaMessageOutput.TotalRawTradesSent = totalRawTradesSentToKafka;
                _logger.LogInformation($"Total number of messages in batch {totalMessageSentToKafka}{logMessage} batchRunId : {batchRunId}");
                _logger.LogInformation($"Total number of raw trades in batch {totalRawTradesSentToKafka}{logMessage} batchRunId : {batchRunId}");

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw new MessageNotPersistedException(PersistenceStatus.NotPersisted);
            }
        }
    }
}
