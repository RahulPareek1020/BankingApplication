﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Shell.Energy.Kafka.Extensions;
using Shell.Energy.Kafka.Models;
using Shell.Energy.Kafka.Options;

namespace Shell.Energy.STPower.Service.KafkaProducer
{
    public static class ProducerDependencyInjector
    {
        public static void ConfigureProducer(this IServiceCollection services, IConfiguration config)
        {
            services
                .AddOptions<KafkaOAuthAppOptions>()
                .BindConfiguration("kafkaOAuthAppOptions")
                .ValidateDataAnnotations();

            services
                .AddOptions<SchemaRegistryAuthenticationOptions>()
                .BindConfiguration("schemaRegistryAuthenticationOptions")
                .ValidateDataAnnotations();

            var openTelemetryExporterOptions = config.GetSection("openTelemetryExporterOptions").Get<OpenTelemetryExporterOptions>();
            var serviceDiscoveryOptions = config.GetSection("serviceDiscoveryOptions").Get<ServiceDiscoveryOptions>();

            services.AddKafka(
                                "Shell.Energy.STPower.Service.KafkaProducer",
                                                serviceDiscoveryOptions,
                                                                openTelemetryExporterOptions);

            services.AddScoped(typeof(IProducerService<,>), typeof(ProducerService<,>));
            services.AddScoped(typeof(IKafkaMessageProducer), typeof(KafkaMessageProducer));
        }
    }
}

